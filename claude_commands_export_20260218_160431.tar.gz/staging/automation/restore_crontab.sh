#!/bin/bash
# restore_crontab.sh - Restore standard jleechanorg automation crontab entries
#
# This script restores the standard cron jobs for the jleechanorg automation system:
# 1. PR monitoring (hourly)
# 2. Codex GitHub Mentions automation (hourly at :15)
# 3. PR fixing with orchestration (every 30 minutes)
# 4. Claude conversations backup (every 4 hours)
#
# Usage:
#   ./restore_crontab.sh                 # Interactive mode (prompts before restore)
#   ./restore_crontab.sh --force         # Force restore without prompts
#   ./restore_crontab.sh --dry-run       # Show what would be restored without applying

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

main() {
    # Detect if running in dry-run or force mode
    DRY_RUN=false
    FORCE=false
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --dry-run)
                DRY_RUN=true
                echo -e "${BLUE}📋 DRY RUN MODE - No changes will be made${NC}\n"
                ;;
            --force)
                FORCE=true
                echo -e "${YELLOW}⚡ FORCE MODE - Skipping confirmation prompts${NC}\n"
                ;;
            -h|--help)
                echo "Usage: $0 [--dry-run|--force]"
                return 0
                ;;
            *)
                echo -e "${RED}❌ ERROR: Unknown argument: $1${NC}"
                echo "Usage: $0 [--dry-run|--force]"
                return 2
                ;;
        esac
        shift
    done

    # Prefer (and export) GITHUB_TOKEN so cron jobs can authenticate.
    # The restore itself can proceed without it.
    if [[ -n "${GITHUB_TOKEN:-}" ]]; then
        export GITHUB_TOKEN
    else
        echo -e "${YELLOW}⚠️  WARNING: GITHUB_TOKEN is not set; cron jobs may fail until configured.${NC}"
    fi

    # Backup current crontab
    BACKUP_FILE="$HOME/.crontab_backup_$(date +%Y%m%d_%H%M%S)"
    if [[ "$DRY_RUN" == "false" ]]; then
        echo -e "${BLUE}💾 Backing up current crontab to: $BACKUP_FILE${NC}"
        if crontab -l > "$BACKUP_FILE" 2>"$BACKUP_FILE.stderr"; then
            rm -f "$BACKUP_FILE.stderr"
        else
            if grep -qi "no crontab for" "$BACKUP_FILE.stderr"; then
                echo "# No existing crontab" > "$BACKUP_FILE"
                rm -f "$BACKUP_FILE.stderr"
            else
                echo -e "${RED}❌ ERROR: Failed to read current crontab:${NC}"
                cat "$BACKUP_FILE.stderr" >&2
                return 1
            fi
        fi
        echo -e "${GREEN}✅ Backup saved${NC}\n"
    else
        echo -e "${BLUE}💾 Would backup current crontab to: $BACKUP_FILE${NC}\n"
    fi

    render_crontab() {
        sed "s/\$(date +\"%Y-%m-%d %H:%M:%S\")/$(date +"%Y-%m-%d %H:%M:%S")/g" | \
        sed "s|\$HOME|$HOME|g"
    }

    # Standard crontab template (source of truth lives in automation/crontab.template)
    CRONTAB_TEMPLATE="$(cat "$(dirname "$0")/crontab.template")"

    # Preserve any existing GITHUB_TOKEN line from current crontab without storing it in-repo.
    EXISTING_GITHUB_TOKEN_LINE="$(crontab -l 2>/dev/null | awk '/^GITHUB_TOKEN=/{print; exit}')"
    if [[ -n "$EXISTING_GITHUB_TOKEN_LINE" ]]; then
        CRONTAB_TEMPLATE="$EXISTING_GITHUB_TOKEN_LINE"$'\n\n'"$CRONTAB_TEMPLATE"
    fi

    # Show what will be restored
    echo -e "${BLUE}📝 Crontab entries to be restored:${NC}"
    echo -e "${YELLOW}──────────────────────────────────────────────────────────────${NC}"
    # Show with $HOME expanded so preview matches what will be installed
    echo "$CRONTAB_TEMPLATE" | render_crontab
    echo -e "${YELLOW}──────────────────────────────────────────────────────────────${NC}\n"

    # Confirm before proceeding (unless --force or --dry-run)
    if [[ "$DRY_RUN" == "false" ]] && [[ "$FORCE" == "false" ]]; then
        if [[ ! -t 0 ]]; then
            echo -e "${RED}❌ ERROR: Non-interactive shell detected. Use --force or --dry-run.${NC}"
            return 1
        fi
        echo -e "${YELLOW}⚠️  This will replace your current crontab with the standard automation jobs.${NC}"
        echo -e "   Your existing crontab has been backed up to: $BACKUP_FILE"
        echo ""
        read -p "Do you want to proceed? (y/N) " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            echo -e "${RED}❌ Aborted by user${NC}"
            return 1
        fi
    fi

    # Apply the new crontab
    if [[ "$DRY_RUN" == "false" ]]; then
        echo -e "${BLUE}🔧 Installing crontab entries...${NC}"
        # Expand $HOME since crontab doesn't support shell variable expansion
        echo "$CRONTAB_TEMPLATE" | render_crontab | crontab -
        echo -e "${GREEN}✅ Crontab restored successfully!${NC}\n"
    else
        echo -e "${BLUE}🔧 DRY RUN: Would install crontab entries${NC}\n"
    fi

    # Verification
    echo -e "${BLUE}🔍 Verification Commands:${NC}"
    echo -e "   View current crontab:    ${GREEN}crontab -l${NC}"
    echo -e "   Test PR monitor:         ${GREEN}jleechanorg-pr-monitor --dry-run${NC}"
    echo -e "   Check safety status:     ${GREEN}automation-safety-cli status${NC}"
    echo ""

    # Check if jleechanorg-pr-monitor is installed
    if ! command -v jleechanorg-pr-monitor &> /dev/null; then
        echo -e "${YELLOW}⚠️  WARNING: jleechanorg-pr-monitor command not found${NC}"
        echo -e "   Install the package with: ${BLUE}pip install jleechanorg-pr-automation${NC}"
        echo -e "   Or from source:          ${BLUE}cd automation && pip install -e .${NC}"
        echo ""
    fi

    # Check if GITHUB_TOKEN is available to cron
    echo -e "${BLUE}🔑 GitHub Token Configuration:${NC}"
    if [[ -n "${GITHUB_TOKEN:-}" ]]; then
        echo -e "${GREEN}✅ GITHUB_TOKEN is set in current shell${NC}"
        echo -e "   To make it available to cron jobs, add this to ~/.zshrc or ~/.bash_profile:"
        echo -e "   ${BLUE}export GITHUB_TOKEN='(your-token-here)'${NC}"
    else
        echo -e "${RED}❌ GITHUB_TOKEN is not set${NC}"
    fi
    echo ""

    # Chrome CDP check for Codex automation
    echo -e "${BLUE}🌐 Chrome CDP Configuration (for Codex automation):${NC}"
    if VERSION_JSON="$(curl -fsS --max-time 2 http://localhost:9222/json/version)"; then
        echo -e "${GREEN}✅ Chrome is running with remote debugging on port 9222${NC}"
        if command -v jq &> /dev/null; then
            CHROME_VERSION="$(jq -r '.Browser // empty' <<<"$VERSION_JSON" 2>/dev/null || true)"
        else
            CHROME_VERSION="$(echo "$VERSION_JSON" | grep -o '"Browser":"[^"]*"' | cut -d'"' -f4 || true)"
        fi
        if [[ -z "$CHROME_VERSION" ]]; then
            CHROME_VERSION="Unknown"
        fi
        echo -e "   Version: ${BLUE}$CHROME_VERSION${NC}"
    else
        echo -e "${YELLOW}⚠️  Chrome is not running with remote debugging${NC}"
        echo -e "   The Codex automation requires Chrome with CDP enabled."
        echo -e "   See ${BLUE}automation/README.md${NC} Workflow 3 for setup instructions."
    fi
    echo ""

    # Summary
    if [[ "$DRY_RUN" == "false" ]]; then
        echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
        echo -e "${GREEN}✅ Crontab restore complete!${NC}"
        echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
        echo -e ""
        echo -e "Next steps:"
        echo -e "  1. Verify crontab:     ${BLUE}crontab -l${NC}"
        echo -e "  2. Test manually:      ${BLUE}jleechanorg-pr-monitor --dry-run${NC}"
        echo -e ""
        echo -e "Backup location: ${BLUE}$BACKUP_FILE${NC}"
    else
        echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
        echo -e "${BLUE}DRY RUN COMPLETE - No changes were made${NC}"
        echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    fi
}

main "$@"
