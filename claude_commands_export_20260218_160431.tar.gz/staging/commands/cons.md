---
description: /cons Command (Alias)
---
Execute `/consensus` with all provided arguments.
