---
description: Generate large amounts of code using Cerebras (alias for /cerebras)
---
Execute `/cerebras` with all provided arguments.
