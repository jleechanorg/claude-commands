---
description: Context Estimation Command (Alias)
---
Execute `/contexte` with all provided arguments.
