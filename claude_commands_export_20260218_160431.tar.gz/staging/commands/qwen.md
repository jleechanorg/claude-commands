---
description: Legacy alias for Cerebras code generation (redirects to /cerebras)
---
Execute `/cerebras` with all provided arguments.
