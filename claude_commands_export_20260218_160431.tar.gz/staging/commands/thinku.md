---
description: Think Ultra Command (Alias)
---
Execute `/think ultra` with the provided problem/question.
