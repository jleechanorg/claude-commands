---
description: debugp - Alias for Debug Protocol
---
Execute `/debug-protocol` with all provided arguments.
