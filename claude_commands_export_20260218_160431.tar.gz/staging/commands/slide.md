---
description: /slide
---
Execute `/presentation` with all provided arguments.
