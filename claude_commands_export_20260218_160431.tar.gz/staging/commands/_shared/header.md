## Execution Instructions
**Execute these steps immediately. Use TodoWrite to track multi-phase workflows.**

