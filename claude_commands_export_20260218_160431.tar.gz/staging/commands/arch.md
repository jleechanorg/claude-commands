---
description: /arch Command (Alias)
---
Execute `/archreview` with all provided arguments. MVP-focused architecture review for solo developers.
