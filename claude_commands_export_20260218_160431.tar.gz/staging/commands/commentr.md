---
description: Comment Reply Command (Alias)
---
Execute `/commentreply` with all provided arguments.
