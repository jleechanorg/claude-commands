# Tests for copilot modules
