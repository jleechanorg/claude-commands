#!/usr/bin/env python3
"""
Tests for per-comment cache structure.

TDD: Tests written first, implementation follows.
"""

import json
import shutil
import tempfile
import time
import unittest
from pathlib import Path

# Import the cache class
import sys

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))
from per_comment_cache import PerCommentCache


class TestPerCommentCache(unittest.TestCase):
    """Test suite for per-comment cache structure."""

    def setUp(self):
        """Set up test fixtures."""
        self.temp_dir = Path(tempfile.mkdtemp())
        self.cache_dir = self.temp_dir / "test_cache"
        self.cache = PerCommentCache(self.cache_dir)

    def tearDown(self):
        """Clean up test fixtures."""
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_save_single_comment(self):
        """Test saving a single comment creates individual file."""
        # Arrange
        comment = {
            "id": "12345",
            "type": "general",
            "body": "Test comment",
            "author": "testuser",
            "created_at": "2026-01-16T00:00:00Z"
        }
        
        # Act
        self.cache.save_comment(comment)
        
        # Assert
        comment_file = self.cache_dir / "comments" / "12345.json"
        self.assertTrue(comment_file.exists())
        with open(comment_file) as f:
            saved = json.load(f)
        self.assertEqual(saved["id"], "12345")
        self.assertEqual(saved["body"], "Test comment")

    def test_save_multiple_comments(self):
        """Test saving multiple comments creates individual files."""
        # Arrange
        comments = [
            {"id": "1", "type": "general", "body": "Comment 1"},
            {"id": "2", "type": "inline", "body": "Comment 2"},
            {"id": "3", "type": "review", "body": "Comment 3"}
        ]
        
        # Act
        self.cache.save_comments(comments, "123", "2026-01-16T00:00:00Z", {})
        
        # Assert
        self.assertTrue((self.cache_dir / "comments" / "1.json").exists())
        self.assertTrue((self.cache_dir / "comments" / "2.json").exists())
        self.assertTrue((self.cache_dir / "comments" / "3.json").exists())
        
        index_file = self.cache_dir / "comments_index.json"
        self.assertTrue(index_file.exists())
        with open(index_file) as f:
            index = json.load(f)
        self.assertEqual(index["total"], 3)
        self.assertEqual(len(index["comment_ids"]), 3)

    def test_load_single_comment(self):
        """Test loading a single comment by ID."""
        # Arrange
        comment = {"id": "12345", "body": "Test"}
        self.cache.save_comment(comment)
        
        # Act
        loaded = self.cache.load_comment("12345")
        
        # Assert
        self.assertIsNotNone(loaded)
        self.assertEqual(loaded["id"], "12345")

    def test_load_all_comments(self):
        """Test loading all comments from cache."""
        # Arrange
        comments = [
            {"id": "1", "body": "Comment 1"},
            {"id": "2", "body": "Comment 2"}
        ]
        self.cache.save_comments(comments, "123", "2026-01-16T00:00:00Z", {})
        
        # Act
        loaded = self.cache.load_all_comments()
        
        # Assert
        self.assertEqual(len(loaded), 2)
        self.assertEqual({str(c["id"]) for c in loaded}, {"1", "2"})

    def test_add_or_update_comment(self):
        """Test adding a new comment or updating existing."""
        # Arrange
        initial_comment = {"id": "1", "body": "Original", "type": "general"}
        self.cache.save_comments([initial_comment], "123", "2026-01-16T00:00:00Z", {})
        
        # Act - Update existing
        updated = {"id": "1", "body": "Updated", "type": "general"}
        self.cache.add_or_update_comment(updated)
        
        # Assert
        loaded = self.cache.load_comment("1")
        self.assertEqual(loaded["body"], "Updated")
        
        # Act - Add new
        new_comment = {"id": "2", "body": "New", "type": "general"}
        self.cache.add_or_update_comment(new_comment)
        
        # Assert
        self.assertTrue((self.cache_dir / "comments" / "2.json").exists())
        all_comments = self.cache.load_all_comments()
        self.assertEqual(len(all_comments), 2)

    def test_index_metadata(self):
        """Test index file contains correct metadata."""
        # Arrange
        comments = [
            {"id": "1", "type": "general"},
            {"id": "2", "type": "inline"},
            {"id": "3", "type": "general"}
        ]
        ci_status = {"overall_state": "PASSING"}
        
        # Act
        self.cache.save_comments(comments, "123", "2026-01-16T00:00:00Z", ci_status)
        
        # Assert
        with open(self.cache_dir / "comments_index.json") as f:
            index = json.load(f)
        self.assertEqual(index["pr"], "123")
        self.assertEqual(index["total"], 3)
        self.assertEqual(index["by_type"]["general"], 2)
        self.assertEqual(index["by_type"]["inline"], 1)
        self.assertEqual(index["ci_status"], ci_status)

    def test_incremental_update_efficiency(self):
        """Test that updating one comment doesn't rewrite all files."""
        # Arrange
        comments = [{"id": str(i), "body": f"Comment {i}", "type": "general"} for i in range(10)]
        self.cache.save_comments(comments, "123", "2026-01-16T00:00:00Z", {})
        
        # Get initial modification times
        time.sleep(0.1)  # Ensure different timestamps
        initial_mtimes = {}
        for i in range(10):
            if i != 5:  # Skip the one we'll update
                file_path = self.cache_dir / "comments" / f"{i}.json"
                initial_mtimes[i] = file_path.stat().st_mtime
        
        # Act - Update only comment 5
        updated = {"id": "5", "body": "Updated comment 5", "type": "general"}
        self.cache.add_or_update_comment(updated)
        
        # Assert - Only comment 5 and index should be modified
        for i in range(10):
            file_path = self.cache_dir / "comments" / f"{i}.json"
            if i == 5:
                self.assertGreaterEqual(file_path.stat().st_mtime, initial_mtimes.get(5, 0))
            else:
                # Allow small time differences due to filesystem precision
                self.assertAlmostEqual(file_path.stat().st_mtime, initial_mtimes[i], delta=1)


class TestHandledTracking(unittest.TestCase):
    """Test suite for handled comment tracking - TDD for cache redesign."""

    def setUp(self):
        """Set up test fixtures."""
        self.temp_dir = Path(tempfile.mkdtemp())
        self.cache_dir = self.temp_dir / "test_cache"
        self.cache = PerCommentCache(self.cache_dir)

    def tearDown(self):
        """Clean up test fixtures."""
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_mark_handled_adds_handled_field(self):
        """Test that mark_handled adds a 'handled' field to the comment."""
        # Arrange
        comment = {
            "id": "12345",
            "type": "general",
            "body": "Test comment",
            "requires_response": True
        }
        self.cache.save_comment(comment)

        # Act
        self.cache.mark_handled("12345", reply_id="67890", status="replied")

        # Assert
        loaded = self.cache.load_comment("12345")
        self.assertIn("handled", loaded)
        self.assertEqual(loaded["handled"]["status"], "replied")
        self.assertEqual(loaded["handled"]["reply_id"], "67890")
        self.assertIn("handled_at", loaded["handled"])

    def test_mark_handled_preserves_original_fields(self):
        """Test that mark_handled preserves all original comment fields."""
        # Arrange
        comment = {
            "id": "12345",
            "type": "inline",
            "body": "Original body",
            "author": "testuser",
            "file": "test.py",
            "line": 42
        }
        self.cache.save_comment(comment)

        # Act
        self.cache.mark_handled("12345", reply_id="67890")

        # Assert
        loaded = self.cache.load_comment("12345")
        self.assertEqual(loaded["body"], "Original body")
        self.assertEqual(loaded["author"], "testuser")
        self.assertEqual(loaded["file"], "test.py")
        self.assertEqual(loaded["line"], 42)

    def test_mark_handled_with_different_statuses(self):
        """Test mark_handled with different status values."""
        # Arrange
        for i, status in enumerate(["replied", "acknowledged", "skipped"]):
            comment = {"id": str(i), "body": f"Comment {i}"}
            self.cache.save_comment(comment)

            # Act
            self.cache.mark_handled(str(i), reply_id=f"reply_{i}", status=status)

            # Assert
            loaded = self.cache.load_comment(str(i))
            self.assertEqual(loaded["handled"]["status"], status)

    def test_mark_handled_nonexistent_comment(self):
        """Test that mark_handled handles nonexistent comment gracefully."""
        # Act - should not raise
        self.cache.mark_handled("nonexistent", reply_id="12345")

        # Assert - no file created for nonexistent comment
        self.assertFalse((self.cache_dir / "comments" / "nonexistent.json").exists())

    def test_is_handled_returns_true_for_handled_comment(self):
        """Test is_handled returns True for a handled comment."""
        # Arrange
        comment = {"id": "12345", "body": "Test"}
        self.cache.save_comment(comment)
        self.cache.mark_handled("12345", reply_id="67890")

        # Act & Assert
        self.assertTrue(self.cache.is_handled("12345"))

    def test_is_handled_returns_false_for_unhandled_comment(self):
        """Test is_handled returns False for an unhandled comment."""
        # Arrange
        comment = {"id": "12345", "body": "Test"}
        self.cache.save_comment(comment)

        # Act & Assert
        self.assertFalse(self.cache.is_handled("12345"))

    def test_is_handled_returns_false_for_nonexistent_comment(self):
        """Test is_handled returns False for nonexistent comment."""
        # Act & Assert
        self.assertFalse(self.cache.is_handled("nonexistent"))

    def test_get_unhandled_comments_returns_only_unhandled(self):
        """Test get_unhandled_comments returns only unhandled comments."""
        # Arrange
        comments = [
            {"id": "1", "body": "Comment 1", "requires_response": True},
            {"id": "2", "body": "Comment 2", "requires_response": True},
            {"id": "3", "body": "Comment 3", "requires_response": True},
        ]
        self.cache.save_comments(comments, "123", "2026-01-16T00:00:00Z", {})

        # Mark some as handled
        self.cache.mark_handled("1", reply_id="reply_1")
        self.cache.mark_handled("3", reply_id="reply_3")

        # Act
        unhandled = self.cache.get_unhandled_comments()

        # Assert
        self.assertEqual(len(unhandled), 1)
        self.assertEqual(unhandled[0]["id"], "2")

    def test_get_unhandled_comments_excludes_no_response_needed(self):
        """Test get_unhandled_comments excludes comments not requiring response."""
        # Arrange
        comments = [
            {"id": "1", "body": "Needs response", "requires_response": True},
            {"id": "2", "body": "No response needed", "requires_response": False},
            {"id": "3", "body": "Also needs response", "requires_response": True},
        ]
        self.cache.save_comments(comments, "123", "2026-01-16T00:00:00Z", {})

        # Act
        unhandled = self.cache.get_unhandled_comments()

        # Assert
        self.assertEqual(len(unhandled), 2)
        unhandled_ids = {c["id"] for c in unhandled}
        self.assertEqual(unhandled_ids, {"1", "3"})

    def test_get_unhandled_comments_empty_cache(self):
        """Test get_unhandled_comments returns empty list for empty cache."""
        # Act
        unhandled = self.cache.get_unhandled_comments()

        # Assert
        self.assertEqual(unhandled, [])

    def test_resumable_workflow(self):
        """Test that workflow can be resumed after partial processing."""
        # Arrange - simulate 5 comments
        comments = [
            {"id": str(i), "body": f"Comment {i}", "requires_response": True}
            for i in range(5)
        ]
        self.cache.save_comments(comments, "123", "2026-01-16T00:00:00Z", {})

        # Simulate processing first 2 comments
        self.cache.mark_handled("0", reply_id="reply_0")
        self.cache.mark_handled("1", reply_id="reply_1")

        # Act - "resume" by getting unhandled
        unhandled = self.cache.get_unhandled_comments()

        # Assert - should have 3 remaining
        self.assertEqual(len(unhandled), 3)
        unhandled_ids = {c["id"] for c in unhandled}
        self.assertEqual(unhandled_ids, {"2", "3", "4"})

    def test_thread_independence(self):
        """Test that thread replies are tracked independently."""
        # Arrange - parent comment and two replies
        comments = [
            {"id": "parent_1", "body": "Parent", "requires_response": True},
            {"id": "reply_1", "body": "Reply 1", "in_reply_to_id": "parent_1", "requires_response": True},
            {"id": "reply_2", "body": "Reply 2", "in_reply_to_id": "parent_1", "requires_response": True},
        ]
        self.cache.save_comments(comments, "123", "2026-01-16T00:00:00Z", {})

        # Mark only parent as handled
        self.cache.mark_handled("parent_1", reply_id="our_reply_1")

        # Act
        unhandled = self.cache.get_unhandled_comments()

        # Assert - replies should still be unhandled
        self.assertEqual(len(unhandled), 2)
        unhandled_ids = {c["id"] for c in unhandled}
        self.assertEqual(unhandled_ids, {"reply_1", "reply_2"})


if __name__ == "__main__":
    unittest.main()
