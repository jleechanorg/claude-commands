---
description: "Generate comprehensive, general-purpose test suites for any system component using systematic test design methodology"
disable-model-invocation: true
---

Invoke the generalized-testing skill and follow it exactly as presented to you

ARGUMENTS: ${ARGUMENTS}
