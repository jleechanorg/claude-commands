---
description: Alias for /simulate - Predict next user prompt
type: ai
execution_mode: immediate
---
## EXECUTION INSTRUCTIONS FOR CLAUDE
**This is an alias for `/simulate`.** Execute the `/simulate` command with all provided arguments.

ARGUMENTS: $ARGUMENTS
