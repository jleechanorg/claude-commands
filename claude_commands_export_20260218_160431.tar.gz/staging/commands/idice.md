---
description: Alias for /investigatedice - Investigate dice integrity warnings for a campaign
type: llm-orchestration
execution_mode: immediate
---
## EXECUTION INSTRUCTIONS FOR CLAUDE
**This is an alias for `/investigatedice`.**

Execute the `/investigatedice` command with the same arguments passed to `/idice`.

See `.claude/commands/investigatedice.md` for the full workflow.
