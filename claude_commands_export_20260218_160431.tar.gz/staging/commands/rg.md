---
description: Red-Code-Green Debug Command (Alias)
---
Execute `/redgreen` with all provided arguments.
