---
description: /pres
---
Execute `/presentation` with all provided arguments.
