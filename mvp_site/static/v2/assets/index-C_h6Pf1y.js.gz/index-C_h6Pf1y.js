import { r as yv, j as z, R as mv } from './ui-CbO0uvlw.js';
import { r as ov, a as gv, g as bv } from './vendor-DJG_os-6.js';
(function () {
  const vl = document.createElement('link').relList;
  if (vl && vl.supports && vl.supports('modulepreload')) return;
  for (const W of document.querySelectorAll('link[rel="modulepreload"]')) o(W);
  new MutationObserver((W) => {
    for (const el of W)
      if (el.type === 'childList')
        for (const it of el.addedNodes)
          it.tagName === 'LINK' && it.rel === 'modulepreload' && o(it);
  }).observe(document, { childList: !0, subtree: !0 });
  function gl(W) {
    const el = {};
    return (
      W.integrity && (el.integrity = W.integrity),
      W.referrerPolicy && (el.referrerPolicy = W.referrerPolicy),
      W.crossOrigin === 'use-credentials'
        ? (el.credentials = 'include')
        : W.crossOrigin === 'anonymous'
          ? (el.credentials = 'omit')
          : (el.credentials = 'same-origin'),
      el
    );
  }
  function o(W) {
    if (W.ep) return;
    W.ep = !0;
    const el = gl(W);
    fetch(W.href, el);
  }
})();
var Jf = { exports: {} },
  fe = {},
  wf = { exports: {} },
  Wf = {};
/**
 * @license React
 * scheduler.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Zd;
function Sv() {
  return (
    Zd ||
      ((Zd = 1),
      (function (E) {
        function vl(S, A) {
          var U = S.length;
          S.push(A);
          l: for (; 0 < U; ) {
            var L = (U - 1) >>> 1,
              J = S[L];
            if (0 < W(J, A)) ((S[L] = A), (S[U] = J), (U = L));
            else break l;
          }
        }
        function gl(S) {
          return S.length === 0 ? null : S[0];
        }
        function o(S) {
          if (S.length === 0) return null;
          var A = S[0],
            U = S.pop();
          if (U !== A) {
            S[0] = U;
            l: for (var L = 0, J = S.length, rl = J >>> 1; L < rl; ) {
              var k = 2 * (L + 1) - 1,
                G = S[k],
                fl = k + 1,
                tt = S[fl];
              if (0 > W(G, U))
                fl < J && 0 > W(tt, G)
                  ? ((S[L] = tt), (S[fl] = U), (L = fl))
                  : ((S[L] = G), (S[k] = U), (L = k));
              else if (fl < J && 0 > W(tt, U))
                ((S[L] = tt), (S[fl] = U), (L = fl));
              else break l;
            }
          }
          return A;
        }
        function W(S, A) {
          var U = S.sortIndex - A.sortIndex;
          return U !== 0 ? U : S.id - A.id;
        }
        if (
          ((E.unstable_now = void 0),
          typeof performance == 'object' &&
            typeof performance.now == 'function')
        ) {
          var el = performance;
          E.unstable_now = function () {
            return el.now();
          };
        } else {
          var it = Date,
            ie = it.now();
          E.unstable_now = function () {
            return it.now() - ie;
          };
        }
        var Wl = [],
          kl = [],
          V = 1,
          Al = null,
          P = 3,
          st = !1,
          Yl = !1,
          xt = !1,
          la = !1,
          se = typeof setTimeout == 'function' ? setTimeout : null,
          iu = typeof clearTimeout == 'function' ? clearTimeout : null,
          jl = typeof setImmediate < 'u' ? setImmediate : null;
        function Ut(S) {
          for (var A = gl(kl); A !== null; ) {
            if (A.callback === null) o(kl);
            else if (A.startTime <= S)
              (o(kl), (A.sortIndex = A.expirationTime), vl(Wl, A));
            else break;
            A = gl(kl);
          }
        }
        function ta(S) {
          if (((xt = !1), Ut(S), !Yl))
            if (gl(Wl) !== null) ((Yl = !0), lt || ((lt = !0), Gl()));
            else {
              var A = gl(kl);
              A !== null && ht(ta, A.startTime - S);
            }
        }
        var lt = !1,
          dt = -1,
          $l = 5,
          za = -1;
        function de() {
          return la ? !0 : !(E.unstable_now() - za < $l);
        }
        function Aa() {
          if (((la = !1), lt)) {
            var S = E.unstable_now();
            za = S;
            var A = !0;
            try {
              l: {
                ((Yl = !1), xt && ((xt = !1), iu(dt), (dt = -1)), (st = !0));
                var U = P;
                try {
                  t: {
                    for (
                      Ut(S), Al = gl(Wl);
                      Al !== null && !(Al.expirationTime > S && de());

                    ) {
                      var L = Al.callback;
                      if (typeof L == 'function') {
                        ((Al.callback = null), (P = Al.priorityLevel));
                        var J = L(Al.expirationTime <= S);
                        if (((S = E.unstable_now()), typeof J == 'function')) {
                          ((Al.callback = J), Ut(S), (A = !0));
                          break t;
                        }
                        (Al === gl(Wl) && o(Wl), Ut(S));
                      } else o(Wl);
                      Al = gl(Wl);
                    }
                    if (Al !== null) A = !0;
                    else {
                      var rl = gl(kl);
                      (rl !== null && ht(ta, rl.startTime - S), (A = !1));
                    }
                  }
                  break l;
                } finally {
                  ((Al = null), (P = U), (st = !1));
                }
                A = void 0;
              }
            } finally {
              A ? Gl() : (lt = !1);
            }
          }
        }
        var Gl;
        if (typeof jl == 'function')
          Gl = function () {
            jl(Aa);
          };
        else if (typeof MessageChannel < 'u') {
          var he = new MessageChannel(),
            su = he.port2;
          ((he.port1.onmessage = Aa),
            (Gl = function () {
              su.postMessage(null);
            }));
        } else
          Gl = function () {
            se(Aa, 0);
          };
        function ht(S, A) {
          dt = se(function () {
            S(E.unstable_now());
          }, A);
        }
        ((E.unstable_IdlePriority = 5),
          (E.unstable_ImmediatePriority = 1),
          (E.unstable_LowPriority = 4),
          (E.unstable_NormalPriority = 3),
          (E.unstable_Profiling = null),
          (E.unstable_UserBlockingPriority = 2),
          (E.unstable_cancelCallback = function (S) {
            S.callback = null;
          }),
          (E.unstable_forceFrameRate = function (S) {
            0 > S || 125 < S
              ? console.error(
                  'forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported',
                )
              : ($l = 0 < S ? Math.floor(1e3 / S) : 5);
          }),
          (E.unstable_getCurrentPriorityLevel = function () {
            return P;
          }),
          (E.unstable_next = function (S) {
            switch (P) {
              case 1:
              case 2:
              case 3:
                var A = 3;
                break;
              default:
                A = P;
            }
            var U = P;
            P = A;
            try {
              return S();
            } finally {
              P = U;
            }
          }),
          (E.unstable_requestPaint = function () {
            la = !0;
          }),
          (E.unstable_runWithPriority = function (S, A) {
            switch (S) {
              case 1:
              case 2:
              case 3:
              case 4:
              case 5:
                break;
              default:
                S = 3;
            }
            var U = P;
            P = S;
            try {
              return A();
            } finally {
              P = U;
            }
          }),
          (E.unstable_scheduleCallback = function (S, A, U) {
            var L = E.unstable_now();
            switch (
              (typeof U == 'object' && U !== null
                ? ((U = U.delay),
                  (U = typeof U == 'number' && 0 < U ? L + U : L))
                : (U = L),
              S)
            ) {
              case 1:
                var J = -1;
                break;
              case 2:
                J = 250;
                break;
              case 5:
                J = 1073741823;
                break;
              case 4:
                J = 1e4;
                break;
              default:
                J = 5e3;
            }
            return (
              (J = U + J),
              (S = {
                id: V++,
                callback: A,
                priorityLevel: S,
                startTime: U,
                expirationTime: J,
                sortIndex: -1,
              }),
              U > L
                ? ((S.sortIndex = U),
                  vl(kl, S),
                  gl(Wl) === null &&
                    S === gl(kl) &&
                    (xt ? (iu(dt), (dt = -1)) : (xt = !0), ht(ta, U - L)))
                : ((S.sortIndex = J),
                  vl(Wl, S),
                  Yl || st || ((Yl = !0), lt || ((lt = !0), Gl()))),
              S
            );
          }),
          (E.unstable_shouldYield = de),
          (E.unstable_wrapCallback = function (S) {
            var A = P;
            return function () {
              var U = P;
              P = A;
              try {
                return S.apply(this, arguments);
              } finally {
                P = U;
              }
            };
          }));
      })(Wf)),
    Wf
  );
}
var Vd;
function rv() {
  return (Vd || ((Vd = 1), (wf.exports = Sv())), wf.exports);
}
/**
 * @license React
 * react-dom-client.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Cd;
function zv() {
  if (Cd) return fe;
  Cd = 1;
  var E = rv(),
    vl = ov(),
    gl = gv();
  function o(l) {
    var t = 'https://react.dev/errors/' + l;
    if (1 < arguments.length) {
      t += '?args[]=' + encodeURIComponent(arguments[1]);
      for (var a = 2; a < arguments.length; a++)
        t += '&args[]=' + encodeURIComponent(arguments[a]);
    }
    return (
      'Minified React error #' +
      l +
      '; visit ' +
      t +
      ' for the full message or use the non-minified dev environment for full errors and additional helpful warnings.'
    );
  }
  function W(l) {
    return !(!l || (l.nodeType !== 1 && l.nodeType !== 9 && l.nodeType !== 11));
  }
  function el(l) {
    var t = l,
      a = l;
    if (l.alternate) for (; t.return; ) t = t.return;
    else {
      l = t;
      do ((t = l), (t.flags & 4098) !== 0 && (a = t.return), (l = t.return));
      while (l);
    }
    return t.tag === 3 ? a : null;
  }
  function it(l) {
    if (l.tag === 13) {
      var t = l.memoizedState;
      if (
        (t === null && ((l = l.alternate), l !== null && (t = l.memoizedState)),
        t !== null)
      )
        return t.dehydrated;
    }
    return null;
  }
  function ie(l) {
    if (el(l) !== l) throw Error(o(188));
  }
  function Wl(l) {
    var t = l.alternate;
    if (!t) {
      if (((t = el(l)), t === null)) throw Error(o(188));
      return t !== l ? null : l;
    }
    for (var a = l, u = t; ; ) {
      var e = a.return;
      if (e === null) break;
      var n = e.alternate;
      if (n === null) {
        if (((u = e.return), u !== null)) {
          a = u;
          continue;
        }
        break;
      }
      if (e.child === n.child) {
        for (n = e.child; n; ) {
          if (n === a) return (ie(e), l);
          if (n === u) return (ie(e), t);
          n = n.sibling;
        }
        throw Error(o(188));
      }
      if (a.return !== u.return) ((a = e), (u = n));
      else {
        for (var c = !1, f = e.child; f; ) {
          if (f === a) {
            ((c = !0), (a = e), (u = n));
            break;
          }
          if (f === u) {
            ((c = !0), (u = e), (a = n));
            break;
          }
          f = f.sibling;
        }
        if (!c) {
          for (f = n.child; f; ) {
            if (f === a) {
              ((c = !0), (a = n), (u = e));
              break;
            }
            if (f === u) {
              ((c = !0), (u = n), (a = e));
              break;
            }
            f = f.sibling;
          }
          if (!c) throw Error(o(189));
        }
      }
      if (a.alternate !== u) throw Error(o(190));
    }
    if (a.tag !== 3) throw Error(o(188));
    return a.stateNode.current === a ? l : t;
  }
  function kl(l) {
    var t = l.tag;
    if (t === 5 || t === 26 || t === 27 || t === 6) return l;
    for (l = l.child; l !== null; ) {
      if (((t = kl(l)), t !== null)) return t;
      l = l.sibling;
    }
    return null;
  }
  var V = Object.assign,
    Al = Symbol.for('react.element'),
    P = Symbol.for('react.transitional.element'),
    st = Symbol.for('react.portal'),
    Yl = Symbol.for('react.fragment'),
    xt = Symbol.for('react.strict_mode'),
    la = Symbol.for('react.profiler'),
    se = Symbol.for('react.provider'),
    iu = Symbol.for('react.consumer'),
    jl = Symbol.for('react.context'),
    Ut = Symbol.for('react.forward_ref'),
    ta = Symbol.for('react.suspense'),
    lt = Symbol.for('react.suspense_list'),
    dt = Symbol.for('react.memo'),
    $l = Symbol.for('react.lazy'),
    za = Symbol.for('react.activity'),
    de = Symbol.for('react.memo_cache_sentinel'),
    Aa = Symbol.iterator;
  function Gl(l) {
    return l === null || typeof l != 'object'
      ? null
      : ((l = (Aa && l[Aa]) || l['@@iterator']),
        typeof l == 'function' ? l : null);
  }
  var he = Symbol.for('react.client.reference');
  function su(l) {
    if (l == null) return null;
    if (typeof l == 'function')
      return l.$$typeof === he ? null : l.displayName || l.name || null;
    if (typeof l == 'string') return l;
    switch (l) {
      case Yl:
        return 'Fragment';
      case la:
        return 'Profiler';
      case xt:
        return 'StrictMode';
      case ta:
        return 'Suspense';
      case lt:
        return 'SuspenseList';
      case za:
        return 'Activity';
    }
    if (typeof l == 'object')
      switch (l.$$typeof) {
        case st:
          return 'Portal';
        case jl:
          return (l.displayName || 'Context') + '.Provider';
        case iu:
          return (l._context.displayName || 'Context') + '.Consumer';
        case Ut:
          var t = l.render;
          return (
            (l = l.displayName),
            l ||
              ((l = t.displayName || t.name || ''),
              (l = l !== '' ? 'ForwardRef(' + l + ')' : 'ForwardRef')),
            l
          );
        case dt:
          return (
            (t = l.displayName || null),
            t !== null ? t : su(l.type) || 'Memo'
          );
        case $l:
          ((t = l._payload), (l = l._init));
          try {
            return su(l(t));
          } catch {}
      }
    return null;
  }
  var ht = Array.isArray,
    S = vl.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
    A = gl.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
    U = { pending: !1, data: null, method: null, action: null },
    L = [],
    J = -1;
  function rl(l) {
    return { current: l };
  }
  function k(l) {
    0 > J || ((l.current = L[J]), (L[J] = null), J--);
  }
  function G(l, t) {
    (J++, (L[J] = l.current), (l.current = t));
  }
  var fl = rl(null),
    tt = rl(null),
    Nt = rl(null),
    ve = rl(null);
  function ye(l, t) {
    switch ((G(Nt, t), G(tt, l), G(fl, null), t.nodeType)) {
      case 9:
      case 11:
        l = (l = t.documentElement) && (l = l.namespaceURI) ? od(l) : 0;
        break;
      default:
        if (((l = t.tagName), (t = t.namespaceURI)))
          ((t = od(t)), (l = gd(t, l)));
        else
          switch (l) {
            case 'svg':
              l = 1;
              break;
            case 'math':
              l = 2;
              break;
            default:
              l = 0;
          }
    }
    (k(fl), G(fl, l));
  }
  function Ta() {
    (k(fl), k(tt), k(Nt));
  }
  function Hn(l) {
    l.memoizedState !== null && G(ve, l);
    var t = fl.current,
      a = gd(t, l.type);
    t !== a && (G(tt, l), G(fl, a));
  }
  function me(l) {
    (tt.current === l && (k(fl), k(tt)),
      ve.current === l && (k(ve), (ae._currentValue = U)));
  }
  var _n = Object.prototype.hasOwnProperty,
    Rn = E.unstable_scheduleCallback,
    qn = E.unstable_cancelCallback,
    Ld = E.unstable_shouldYield,
    Jd = E.unstable_requestPaint,
    at = E.unstable_now,
    wd = E.unstable_getCurrentPriorityLevel,
    kf = E.unstable_ImmediatePriority,
    $f = E.unstable_UserBlockingPriority,
    oe = E.unstable_NormalPriority,
    Wd = E.unstable_LowPriority,
    Ff = E.unstable_IdlePriority,
    kd = E.log,
    $d = E.unstable_setDisableYieldValue,
    du = null,
    xl = null;
  function Ht(l) {
    if (
      (typeof kd == 'function' && $d(l),
      xl && typeof xl.setStrictMode == 'function')
    )
      try {
        xl.setStrictMode(du, l);
      } catch {}
  }
  var Ul = Math.clz32 ? Math.clz32 : Pd,
    Fd = Math.log,
    Id = Math.LN2;
  function Pd(l) {
    return ((l >>>= 0), l === 0 ? 32 : (31 - ((Fd(l) / Id) | 0)) | 0);
  }
  var ge = 256,
    be = 4194304;
  function aa(l) {
    var t = l & 42;
    if (t !== 0) return t;
    switch (l & -l) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
        return 64;
      case 128:
        return 128;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return l & 4194048;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return l & 62914560;
      case 67108864:
        return 67108864;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 0;
      default:
        return l;
    }
  }
  function Se(l, t, a) {
    var u = l.pendingLanes;
    if (u === 0) return 0;
    var e = 0,
      n = l.suspendedLanes,
      c = l.pingedLanes;
    l = l.warmLanes;
    var f = u & 134217727;
    return (
      f !== 0
        ? ((u = f & ~n),
          u !== 0
            ? (e = aa(u))
            : ((c &= f),
              c !== 0
                ? (e = aa(c))
                : a || ((a = f & ~l), a !== 0 && (e = aa(a)))))
        : ((f = u & ~n),
          f !== 0
            ? (e = aa(f))
            : c !== 0
              ? (e = aa(c))
              : a || ((a = u & ~l), a !== 0 && (e = aa(a)))),
      e === 0
        ? 0
        : t !== 0 &&
            t !== e &&
            (t & n) === 0 &&
            ((n = e & -e),
            (a = t & -t),
            n >= a || (n === 32 && (a & 4194048) !== 0))
          ? t
          : e
    );
  }
  function hu(l, t) {
    return (l.pendingLanes & ~(l.suspendedLanes & ~l.pingedLanes) & t) === 0;
  }
  function lh(l, t) {
    switch (l) {
      case 1:
      case 2:
      case 4:
      case 8:
      case 64:
        return t + 250;
      case 16:
      case 32:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return t + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return -1;
      case 67108864:
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function If() {
    var l = ge;
    return ((ge <<= 1), (ge & 4194048) === 0 && (ge = 256), l);
  }
  function Pf() {
    var l = be;
    return ((be <<= 1), (be & 62914560) === 0 && (be = 4194304), l);
  }
  function pn(l) {
    for (var t = [], a = 0; 31 > a; a++) t.push(l);
    return t;
  }
  function vu(l, t) {
    ((l.pendingLanes |= t),
      t !== 268435456 &&
        ((l.suspendedLanes = 0), (l.pingedLanes = 0), (l.warmLanes = 0)));
  }
  function th(l, t, a, u, e, n) {
    var c = l.pendingLanes;
    ((l.pendingLanes = a),
      (l.suspendedLanes = 0),
      (l.pingedLanes = 0),
      (l.warmLanes = 0),
      (l.expiredLanes &= a),
      (l.entangledLanes &= a),
      (l.errorRecoveryDisabledLanes &= a),
      (l.shellSuspendCounter = 0));
    var f = l.entanglements,
      i = l.expirationTimes,
      v = l.hiddenUpdates;
    for (a = c & ~a; 0 < a; ) {
      var g = 31 - Ul(a),
        r = 1 << g;
      ((f[g] = 0), (i[g] = -1));
      var y = v[g];
      if (y !== null)
        for (v[g] = null, g = 0; g < y.length; g++) {
          var m = y[g];
          m !== null && (m.lane &= -536870913);
        }
      a &= ~r;
    }
    (u !== 0 && li(l, u, 0),
      n !== 0 && e === 0 && l.tag !== 0 && (l.suspendedLanes |= n & ~(c & ~t)));
  }
  function li(l, t, a) {
    ((l.pendingLanes |= t), (l.suspendedLanes &= ~t));
    var u = 31 - Ul(t);
    ((l.entangledLanes |= t),
      (l.entanglements[u] = l.entanglements[u] | 1073741824 | (a & 4194090)));
  }
  function ti(l, t) {
    var a = (l.entangledLanes |= t);
    for (l = l.entanglements; a; ) {
      var u = 31 - Ul(a),
        e = 1 << u;
      ((e & t) | (l[u] & t) && (l[u] |= t), (a &= ~e));
    }
  }
  function Bn(l) {
    switch (l) {
      case 2:
        l = 1;
        break;
      case 8:
        l = 4;
        break;
      case 32:
        l = 16;
        break;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        l = 128;
        break;
      case 268435456:
        l = 134217728;
        break;
      default:
        l = 0;
    }
    return l;
  }
  function Yn(l) {
    return (
      (l &= -l),
      2 < l ? (8 < l ? ((l & 134217727) !== 0 ? 32 : 268435456) : 8) : 2
    );
  }
  function ai() {
    var l = A.p;
    return l !== 0 ? l : ((l = window.event), l === void 0 ? 32 : Bd(l.type));
  }
  function ah(l, t) {
    var a = A.p;
    try {
      return ((A.p = l), t());
    } finally {
      A.p = a;
    }
  }
  var _t = Math.random().toString(36).slice(2),
    bl = '__reactFiber$' + _t,
    Tl = '__reactProps$' + _t,
    Ma = '__reactContainer$' + _t,
    jn = '__reactEvents$' + _t,
    uh = '__reactListeners$' + _t,
    eh = '__reactHandles$' + _t,
    ui = '__reactResources$' + _t,
    yu = '__reactMarker$' + _t;
  function Gn(l) {
    (delete l[bl], delete l[Tl], delete l[jn], delete l[uh], delete l[eh]);
  }
  function Ea(l) {
    var t = l[bl];
    if (t) return t;
    for (var a = l.parentNode; a; ) {
      if ((t = a[Ma] || a[bl])) {
        if (
          ((a = t.alternate),
          t.child !== null || (a !== null && a.child !== null))
        )
          for (l = zd(l); l !== null; ) {
            if ((a = l[bl])) return a;
            l = zd(l);
          }
        return t;
      }
      ((l = a), (a = l.parentNode));
    }
    return null;
  }
  function Da(l) {
    if ((l = l[bl] || l[Ma])) {
      var t = l.tag;
      if (t === 5 || t === 6 || t === 13 || t === 26 || t === 27 || t === 3)
        return l;
    }
    return null;
  }
  function mu(l) {
    var t = l.tag;
    if (t === 5 || t === 26 || t === 27 || t === 6) return l.stateNode;
    throw Error(o(33));
  }
  function Oa(l) {
    var t = l[ui];
    return (
      t ||
        (t = l[ui] =
          { hoistableStyles: new Map(), hoistableScripts: new Map() }),
      t
    );
  }
  function il(l) {
    l[yu] = !0;
  }
  var ei = new Set(),
    ni = {};
  function ua(l, t) {
    (xa(l, t), xa(l + 'Capture', t));
  }
  function xa(l, t) {
    for (ni[l] = t, l = 0; l < t.length; l++) ei.add(t[l]);
  }
  var nh = RegExp(
      '^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$',
    ),
    ci = {},
    fi = {};
  function ch(l) {
    return _n.call(fi, l)
      ? !0
      : _n.call(ci, l)
        ? !1
        : nh.test(l)
          ? (fi[l] = !0)
          : ((ci[l] = !0), !1);
  }
  function re(l, t, a) {
    if (ch(t))
      if (a === null) l.removeAttribute(t);
      else {
        switch (typeof a) {
          case 'undefined':
          case 'function':
          case 'symbol':
            l.removeAttribute(t);
            return;
          case 'boolean':
            var u = t.toLowerCase().slice(0, 5);
            if (u !== 'data-' && u !== 'aria-') {
              l.removeAttribute(t);
              return;
            }
        }
        l.setAttribute(t, '' + a);
      }
  }
  function ze(l, t, a) {
    if (a === null) l.removeAttribute(t);
    else {
      switch (typeof a) {
        case 'undefined':
        case 'function':
        case 'symbol':
        case 'boolean':
          l.removeAttribute(t);
          return;
      }
      l.setAttribute(t, '' + a);
    }
  }
  function vt(l, t, a, u) {
    if (u === null) l.removeAttribute(a);
    else {
      switch (typeof u) {
        case 'undefined':
        case 'function':
        case 'symbol':
        case 'boolean':
          l.removeAttribute(a);
          return;
      }
      l.setAttributeNS(t, a, '' + u);
    }
  }
  var Xn, ii;
  function Ua(l) {
    if (Xn === void 0)
      try {
        throw Error();
      } catch (a) {
        var t = a.stack.trim().match(/\n( *(at )?)/);
        ((Xn = (t && t[1]) || ''),
          (ii =
            -1 <
            a.stack.indexOf(`
    at`)
              ? ' (<anonymous>)'
              : -1 < a.stack.indexOf('@')
                ? '@unknown:0:0'
                : ''));
      }
    return (
      `
` +
      Xn +
      l +
      ii
    );
  }
  var Qn = !1;
  function Zn(l, t) {
    if (!l || Qn) return '';
    Qn = !0;
    var a = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      var u = {
        DetermineComponentFrameRoot: function () {
          try {
            if (t) {
              var r = function () {
                throw Error();
              };
              if (
                (Object.defineProperty(r.prototype, 'props', {
                  set: function () {
                    throw Error();
                  },
                }),
                typeof Reflect == 'object' && Reflect.construct)
              ) {
                try {
                  Reflect.construct(r, []);
                } catch (m) {
                  var y = m;
                }
                Reflect.construct(l, [], r);
              } else {
                try {
                  r.call();
                } catch (m) {
                  y = m;
                }
                l.call(r.prototype);
              }
            } else {
              try {
                throw Error();
              } catch (m) {
                y = m;
              }
              (r = l()) &&
                typeof r.catch == 'function' &&
                r.catch(function () {});
            }
          } catch (m) {
            if (m && y && typeof m.stack == 'string') return [m.stack, y.stack];
          }
          return [null, null];
        },
      };
      u.DetermineComponentFrameRoot.displayName = 'DetermineComponentFrameRoot';
      var e = Object.getOwnPropertyDescriptor(
        u.DetermineComponentFrameRoot,
        'name',
      );
      e &&
        e.configurable &&
        Object.defineProperty(u.DetermineComponentFrameRoot, 'name', {
          value: 'DetermineComponentFrameRoot',
        });
      var n = u.DetermineComponentFrameRoot(),
        c = n[0],
        f = n[1];
      if (c && f) {
        var i = c.split(`
`),
          v = f.split(`
`);
        for (
          e = u = 0;
          u < i.length && !i[u].includes('DetermineComponentFrameRoot');

        )
          u++;
        for (; e < v.length && !v[e].includes('DetermineComponentFrameRoot'); )
          e++;
        if (u === i.length || e === v.length)
          for (
            u = i.length - 1, e = v.length - 1;
            1 <= u && 0 <= e && i[u] !== v[e];

          )
            e--;
        for (; 1 <= u && 0 <= e; u--, e--)
          if (i[u] !== v[e]) {
            if (u !== 1 || e !== 1)
              do
                if ((u--, e--, 0 > e || i[u] !== v[e])) {
                  var g =
                    `
` + i[u].replace(' at new ', ' at ');
                  return (
                    l.displayName &&
                      g.includes('<anonymous>') &&
                      (g = g.replace('<anonymous>', l.displayName)),
                    g
                  );
                }
              while (1 <= u && 0 <= e);
            break;
          }
      }
    } finally {
      ((Qn = !1), (Error.prepareStackTrace = a));
    }
    return (a = l ? l.displayName || l.name : '') ? Ua(a) : '';
  }
  function fh(l) {
    switch (l.tag) {
      case 26:
      case 27:
      case 5:
        return Ua(l.type);
      case 16:
        return Ua('Lazy');
      case 13:
        return Ua('Suspense');
      case 19:
        return Ua('SuspenseList');
      case 0:
      case 15:
        return Zn(l.type, !1);
      case 11:
        return Zn(l.type.render, !1);
      case 1:
        return Zn(l.type, !0);
      case 31:
        return Ua('Activity');
      default:
        return '';
    }
  }
  function si(l) {
    try {
      var t = '';
      do ((t += fh(l)), (l = l.return));
      while (l);
      return t;
    } catch (a) {
      return (
        `
Error generating stack: ` +
        a.message +
        `
` +
        a.stack
      );
    }
  }
  function Xl(l) {
    switch (typeof l) {
      case 'bigint':
      case 'boolean':
      case 'number':
      case 'string':
      case 'undefined':
        return l;
      case 'object':
        return l;
      default:
        return '';
    }
  }
  function di(l) {
    var t = l.type;
    return (
      (l = l.nodeName) &&
      l.toLowerCase() === 'input' &&
      (t === 'checkbox' || t === 'radio')
    );
  }
  function ih(l) {
    var t = di(l) ? 'checked' : 'value',
      a = Object.getOwnPropertyDescriptor(l.constructor.prototype, t),
      u = '' + l[t];
    if (
      !l.hasOwnProperty(t) &&
      typeof a < 'u' &&
      typeof a.get == 'function' &&
      typeof a.set == 'function'
    ) {
      var e = a.get,
        n = a.set;
      return (
        Object.defineProperty(l, t, {
          configurable: !0,
          get: function () {
            return e.call(this);
          },
          set: function (c) {
            ((u = '' + c), n.call(this, c));
          },
        }),
        Object.defineProperty(l, t, { enumerable: a.enumerable }),
        {
          getValue: function () {
            return u;
          },
          setValue: function (c) {
            u = '' + c;
          },
          stopTracking: function () {
            ((l._valueTracker = null), delete l[t]);
          },
        }
      );
    }
  }
  function Ae(l) {
    l._valueTracker || (l._valueTracker = ih(l));
  }
  function hi(l) {
    if (!l) return !1;
    var t = l._valueTracker;
    if (!t) return !0;
    var a = t.getValue(),
      u = '';
    return (
      l && (u = di(l) ? (l.checked ? 'true' : 'false') : l.value),
      (l = u),
      l !== a ? (t.setValue(l), !0) : !1
    );
  }
  function Te(l) {
    if (
      ((l = l || (typeof document < 'u' ? document : void 0)), typeof l > 'u')
    )
      return null;
    try {
      return l.activeElement || l.body;
    } catch {
      return l.body;
    }
  }
  var sh = /[\n"\\]/g;
  function Ql(l) {
    return l.replace(sh, function (t) {
      return '\\' + t.charCodeAt(0).toString(16) + ' ';
    });
  }
  function Vn(l, t, a, u, e, n, c, f) {
    ((l.name = ''),
      c != null &&
      typeof c != 'function' &&
      typeof c != 'symbol' &&
      typeof c != 'boolean'
        ? (l.type = c)
        : l.removeAttribute('type'),
      t != null
        ? c === 'number'
          ? ((t === 0 && l.value === '') || l.value != t) &&
            (l.value = '' + Xl(t))
          : l.value !== '' + Xl(t) && (l.value = '' + Xl(t))
        : (c !== 'submit' && c !== 'reset') || l.removeAttribute('value'),
      t != null
        ? Cn(l, c, Xl(t))
        : a != null
          ? Cn(l, c, Xl(a))
          : u != null && l.removeAttribute('value'),
      e == null && n != null && (l.defaultChecked = !!n),
      e != null &&
        (l.checked = e && typeof e != 'function' && typeof e != 'symbol'),
      f != null &&
      typeof f != 'function' &&
      typeof f != 'symbol' &&
      typeof f != 'boolean'
        ? (l.name = '' + Xl(f))
        : l.removeAttribute('name'));
  }
  function vi(l, t, a, u, e, n, c, f) {
    if (
      (n != null &&
        typeof n != 'function' &&
        typeof n != 'symbol' &&
        typeof n != 'boolean' &&
        (l.type = n),
      t != null || a != null)
    ) {
      if (!((n !== 'submit' && n !== 'reset') || t != null)) return;
      ((a = a != null ? '' + Xl(a) : ''),
        (t = t != null ? '' + Xl(t) : a),
        f || t === l.value || (l.value = t),
        (l.defaultValue = t));
    }
    ((u = u ?? e),
      (u = typeof u != 'function' && typeof u != 'symbol' && !!u),
      (l.checked = f ? l.checked : !!u),
      (l.defaultChecked = !!u),
      c != null &&
        typeof c != 'function' &&
        typeof c != 'symbol' &&
        typeof c != 'boolean' &&
        (l.name = c));
  }
  function Cn(l, t, a) {
    (t === 'number' && Te(l.ownerDocument) === l) ||
      l.defaultValue === '' + a ||
      (l.defaultValue = '' + a);
  }
  function Na(l, t, a, u) {
    if (((l = l.options), t)) {
      t = {};
      for (var e = 0; e < a.length; e++) t['$' + a[e]] = !0;
      for (a = 0; a < l.length; a++)
        ((e = t.hasOwnProperty('$' + l[a].value)),
          l[a].selected !== e && (l[a].selected = e),
          e && u && (l[a].defaultSelected = !0));
    } else {
      for (a = '' + Xl(a), t = null, e = 0; e < l.length; e++) {
        if (l[e].value === a) {
          ((l[e].selected = !0), u && (l[e].defaultSelected = !0));
          return;
        }
        t !== null || l[e].disabled || (t = l[e]);
      }
      t !== null && (t.selected = !0);
    }
  }
  function yi(l, t, a) {
    if (
      t != null &&
      ((t = '' + Xl(t)), t !== l.value && (l.value = t), a == null)
    ) {
      l.defaultValue !== t && (l.defaultValue = t);
      return;
    }
    l.defaultValue = a != null ? '' + Xl(a) : '';
  }
  function mi(l, t, a, u) {
    if (t == null) {
      if (u != null) {
        if (a != null) throw Error(o(92));
        if (ht(u)) {
          if (1 < u.length) throw Error(o(93));
          u = u[0];
        }
        a = u;
      }
      (a == null && (a = ''), (t = a));
    }
    ((a = Xl(t)),
      (l.defaultValue = a),
      (u = l.textContent),
      u === a && u !== '' && u !== null && (l.value = u));
  }
  function Ha(l, t) {
    if (t) {
      var a = l.firstChild;
      if (a && a === l.lastChild && a.nodeType === 3) {
        a.nodeValue = t;
        return;
      }
    }
    l.textContent = t;
  }
  var dh = new Set(
    'animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp'.split(
      ' ',
    ),
  );
  function oi(l, t, a) {
    var u = t.indexOf('--') === 0;
    a == null || typeof a == 'boolean' || a === ''
      ? u
        ? l.setProperty(t, '')
        : t === 'float'
          ? (l.cssFloat = '')
          : (l[t] = '')
      : u
        ? l.setProperty(t, a)
        : typeof a != 'number' || a === 0 || dh.has(t)
          ? t === 'float'
            ? (l.cssFloat = a)
            : (l[t] = ('' + a).trim())
          : (l[t] = a + 'px');
  }
  function gi(l, t, a) {
    if (t != null && typeof t != 'object') throw Error(o(62));
    if (((l = l.style), a != null)) {
      for (var u in a)
        !a.hasOwnProperty(u) ||
          (t != null && t.hasOwnProperty(u)) ||
          (u.indexOf('--') === 0
            ? l.setProperty(u, '')
            : u === 'float'
              ? (l.cssFloat = '')
              : (l[u] = ''));
      for (var e in t)
        ((u = t[e]), t.hasOwnProperty(e) && a[e] !== u && oi(l, e, u));
    } else for (var n in t) t.hasOwnProperty(n) && oi(l, n, t[n]);
  }
  function Kn(l) {
    if (l.indexOf('-') === -1) return !1;
    switch (l) {
      case 'annotation-xml':
      case 'color-profile':
      case 'font-face':
      case 'font-face-src':
      case 'font-face-uri':
      case 'font-face-format':
      case 'font-face-name':
      case 'missing-glyph':
        return !1;
      default:
        return !0;
    }
  }
  var hh = new Map([
      ['acceptCharset', 'accept-charset'],
      ['htmlFor', 'for'],
      ['httpEquiv', 'http-equiv'],
      ['crossOrigin', 'crossorigin'],
      ['accentHeight', 'accent-height'],
      ['alignmentBaseline', 'alignment-baseline'],
      ['arabicForm', 'arabic-form'],
      ['baselineShift', 'baseline-shift'],
      ['capHeight', 'cap-height'],
      ['clipPath', 'clip-path'],
      ['clipRule', 'clip-rule'],
      ['colorInterpolation', 'color-interpolation'],
      ['colorInterpolationFilters', 'color-interpolation-filters'],
      ['colorProfile', 'color-profile'],
      ['colorRendering', 'color-rendering'],
      ['dominantBaseline', 'dominant-baseline'],
      ['enableBackground', 'enable-background'],
      ['fillOpacity', 'fill-opacity'],
      ['fillRule', 'fill-rule'],
      ['floodColor', 'flood-color'],
      ['floodOpacity', 'flood-opacity'],
      ['fontFamily', 'font-family'],
      ['fontSize', 'font-size'],
      ['fontSizeAdjust', 'font-size-adjust'],
      ['fontStretch', 'font-stretch'],
      ['fontStyle', 'font-style'],
      ['fontVariant', 'font-variant'],
      ['fontWeight', 'font-weight'],
      ['glyphName', 'glyph-name'],
      ['glyphOrientationHorizontal', 'glyph-orientation-horizontal'],
      ['glyphOrientationVertical', 'glyph-orientation-vertical'],
      ['horizAdvX', 'horiz-adv-x'],
      ['horizOriginX', 'horiz-origin-x'],
      ['imageRendering', 'image-rendering'],
      ['letterSpacing', 'letter-spacing'],
      ['lightingColor', 'lighting-color'],
      ['markerEnd', 'marker-end'],
      ['markerMid', 'marker-mid'],
      ['markerStart', 'marker-start'],
      ['overlinePosition', 'overline-position'],
      ['overlineThickness', 'overline-thickness'],
      ['paintOrder', 'paint-order'],
      ['panose-1', 'panose-1'],
      ['pointerEvents', 'pointer-events'],
      ['renderingIntent', 'rendering-intent'],
      ['shapeRendering', 'shape-rendering'],
      ['stopColor', 'stop-color'],
      ['stopOpacity', 'stop-opacity'],
      ['strikethroughPosition', 'strikethrough-position'],
      ['strikethroughThickness', 'strikethrough-thickness'],
      ['strokeDasharray', 'stroke-dasharray'],
      ['strokeDashoffset', 'stroke-dashoffset'],
      ['strokeLinecap', 'stroke-linecap'],
      ['strokeLinejoin', 'stroke-linejoin'],
      ['strokeMiterlimit', 'stroke-miterlimit'],
      ['strokeOpacity', 'stroke-opacity'],
      ['strokeWidth', 'stroke-width'],
      ['textAnchor', 'text-anchor'],
      ['textDecoration', 'text-decoration'],
      ['textRendering', 'text-rendering'],
      ['transformOrigin', 'transform-origin'],
      ['underlinePosition', 'underline-position'],
      ['underlineThickness', 'underline-thickness'],
      ['unicodeBidi', 'unicode-bidi'],
      ['unicodeRange', 'unicode-range'],
      ['unitsPerEm', 'units-per-em'],
      ['vAlphabetic', 'v-alphabetic'],
      ['vHanging', 'v-hanging'],
      ['vIdeographic', 'v-ideographic'],
      ['vMathematical', 'v-mathematical'],
      ['vectorEffect', 'vector-effect'],
      ['vertAdvY', 'vert-adv-y'],
      ['vertOriginX', 'vert-origin-x'],
      ['vertOriginY', 'vert-origin-y'],
      ['wordSpacing', 'word-spacing'],
      ['writingMode', 'writing-mode'],
      ['xmlnsXlink', 'xmlns:xlink'],
      ['xHeight', 'x-height'],
    ]),
    vh =
      /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
  function Me(l) {
    return vh.test('' + l)
      ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')"
      : l;
  }
  var Ln = null;
  function Jn(l) {
    return (
      (l = l.target || l.srcElement || window),
      l.correspondingUseElement && (l = l.correspondingUseElement),
      l.nodeType === 3 ? l.parentNode : l
    );
  }
  var _a = null,
    Ra = null;
  function bi(l) {
    var t = Da(l);
    if (t && (l = t.stateNode)) {
      var a = l[Tl] || null;
      l: switch (((l = t.stateNode), t.type)) {
        case 'input':
          if (
            (Vn(
              l,
              a.value,
              a.defaultValue,
              a.defaultValue,
              a.checked,
              a.defaultChecked,
              a.type,
              a.name,
            ),
            (t = a.name),
            a.type === 'radio' && t != null)
          ) {
            for (a = l; a.parentNode; ) a = a.parentNode;
            for (
              a = a.querySelectorAll(
                'input[name="' + Ql('' + t) + '"][type="radio"]',
              ),
                t = 0;
              t < a.length;
              t++
            ) {
              var u = a[t];
              if (u !== l && u.form === l.form) {
                var e = u[Tl] || null;
                if (!e) throw Error(o(90));
                Vn(
                  u,
                  e.value,
                  e.defaultValue,
                  e.defaultValue,
                  e.checked,
                  e.defaultChecked,
                  e.type,
                  e.name,
                );
              }
            }
            for (t = 0; t < a.length; t++)
              ((u = a[t]), u.form === l.form && hi(u));
          }
          break l;
        case 'textarea':
          yi(l, a.value, a.defaultValue);
          break l;
        case 'select':
          ((t = a.value), t != null && Na(l, !!a.multiple, t, !1));
      }
    }
  }
  var wn = !1;
  function Si(l, t, a) {
    if (wn) return l(t, a);
    wn = !0;
    try {
      var u = l(t);
      return u;
    } finally {
      if (
        ((wn = !1),
        (_a !== null || Ra !== null) &&
          (sn(), _a && ((t = _a), (l = Ra), (Ra = _a = null), bi(t), l)))
      )
        for (t = 0; t < l.length; t++) bi(l[t]);
    }
  }
  function ou(l, t) {
    var a = l.stateNode;
    if (a === null) return null;
    var u = a[Tl] || null;
    if (u === null) return null;
    a = u[t];
    l: switch (t) {
      case 'onClick':
      case 'onClickCapture':
      case 'onDoubleClick':
      case 'onDoubleClickCapture':
      case 'onMouseDown':
      case 'onMouseDownCapture':
      case 'onMouseMove':
      case 'onMouseMoveCapture':
      case 'onMouseUp':
      case 'onMouseUpCapture':
      case 'onMouseEnter':
        ((u = !u.disabled) ||
          ((l = l.type),
          (u = !(
            l === 'button' ||
            l === 'input' ||
            l === 'select' ||
            l === 'textarea'
          ))),
          (l = !u));
        break l;
      default:
        l = !1;
    }
    if (l) return null;
    if (a && typeof a != 'function') throw Error(o(231, t, typeof a));
    return a;
  }
  var yt = !(
      typeof window > 'u' ||
      typeof window.document > 'u' ||
      typeof window.document.createElement > 'u'
    ),
    Wn = !1;
  if (yt)
    try {
      var gu = {};
      (Object.defineProperty(gu, 'passive', {
        get: function () {
          Wn = !0;
        },
      }),
        window.addEventListener('test', gu, gu),
        window.removeEventListener('test', gu, gu));
    } catch {
      Wn = !1;
    }
  var Rt = null,
    kn = null,
    Ee = null;
  function ri() {
    if (Ee) return Ee;
    var l,
      t = kn,
      a = t.length,
      u,
      e = 'value' in Rt ? Rt.value : Rt.textContent,
      n = e.length;
    for (l = 0; l < a && t[l] === e[l]; l++);
    var c = a - l;
    for (u = 1; u <= c && t[a - u] === e[n - u]; u++);
    return (Ee = e.slice(l, 1 < u ? 1 - u : void 0));
  }
  function De(l) {
    var t = l.keyCode;
    return (
      'charCode' in l
        ? ((l = l.charCode), l === 0 && t === 13 && (l = 13))
        : (l = t),
      l === 10 && (l = 13),
      32 <= l || l === 13 ? l : 0
    );
  }
  function Oe() {
    return !0;
  }
  function zi() {
    return !1;
  }
  function Ml(l) {
    function t(a, u, e, n, c) {
      ((this._reactName = a),
        (this._targetInst = e),
        (this.type = u),
        (this.nativeEvent = n),
        (this.target = c),
        (this.currentTarget = null));
      for (var f in l)
        l.hasOwnProperty(f) && ((a = l[f]), (this[f] = a ? a(n) : n[f]));
      return (
        (this.isDefaultPrevented = (
          n.defaultPrevented != null ? n.defaultPrevented : n.returnValue === !1
        )
          ? Oe
          : zi),
        (this.isPropagationStopped = zi),
        this
      );
    }
    return (
      V(t.prototype, {
        preventDefault: function () {
          this.defaultPrevented = !0;
          var a = this.nativeEvent;
          a &&
            (a.preventDefault
              ? a.preventDefault()
              : typeof a.returnValue != 'unknown' && (a.returnValue = !1),
            (this.isDefaultPrevented = Oe));
        },
        stopPropagation: function () {
          var a = this.nativeEvent;
          a &&
            (a.stopPropagation
              ? a.stopPropagation()
              : typeof a.cancelBubble != 'unknown' && (a.cancelBubble = !0),
            (this.isPropagationStopped = Oe));
        },
        persist: function () {},
        isPersistent: Oe,
      }),
      t
    );
  }
  var ea = {
      eventPhase: 0,
      bubbles: 0,
      cancelable: 0,
      timeStamp: function (l) {
        return l.timeStamp || Date.now();
      },
      defaultPrevented: 0,
      isTrusted: 0,
    },
    xe = Ml(ea),
    bu = V({}, ea, { view: 0, detail: 0 }),
    yh = Ml(bu),
    $n,
    Fn,
    Su,
    Ue = V({}, bu, {
      screenX: 0,
      screenY: 0,
      clientX: 0,
      clientY: 0,
      pageX: 0,
      pageY: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      getModifierState: Pn,
      button: 0,
      buttons: 0,
      relatedTarget: function (l) {
        return l.relatedTarget === void 0
          ? l.fromElement === l.srcElement
            ? l.toElement
            : l.fromElement
          : l.relatedTarget;
      },
      movementX: function (l) {
        return 'movementX' in l
          ? l.movementX
          : (l !== Su &&
              (Su && l.type === 'mousemove'
                ? (($n = l.screenX - Su.screenX), (Fn = l.screenY - Su.screenY))
                : (Fn = $n = 0),
              (Su = l)),
            $n);
      },
      movementY: function (l) {
        return 'movementY' in l ? l.movementY : Fn;
      },
    }),
    Ai = Ml(Ue),
    mh = V({}, Ue, { dataTransfer: 0 }),
    oh = Ml(mh),
    gh = V({}, bu, { relatedTarget: 0 }),
    In = Ml(gh),
    bh = V({}, ea, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }),
    Sh = Ml(bh),
    rh = V({}, ea, {
      clipboardData: function (l) {
        return 'clipboardData' in l ? l.clipboardData : window.clipboardData;
      },
    }),
    zh = Ml(rh),
    Ah = V({}, ea, { data: 0 }),
    Ti = Ml(Ah),
    Th = {
      Esc: 'Escape',
      Spacebar: ' ',
      Left: 'ArrowLeft',
      Up: 'ArrowUp',
      Right: 'ArrowRight',
      Down: 'ArrowDown',
      Del: 'Delete',
      Win: 'OS',
      Menu: 'ContextMenu',
      Apps: 'ContextMenu',
      Scroll: 'ScrollLock',
      MozPrintableKey: 'Unidentified',
    },
    Mh = {
      8: 'Backspace',
      9: 'Tab',
      12: 'Clear',
      13: 'Enter',
      16: 'Shift',
      17: 'Control',
      18: 'Alt',
      19: 'Pause',
      20: 'CapsLock',
      27: 'Escape',
      32: ' ',
      33: 'PageUp',
      34: 'PageDown',
      35: 'End',
      36: 'Home',
      37: 'ArrowLeft',
      38: 'ArrowUp',
      39: 'ArrowRight',
      40: 'ArrowDown',
      45: 'Insert',
      46: 'Delete',
      112: 'F1',
      113: 'F2',
      114: 'F3',
      115: 'F4',
      116: 'F5',
      117: 'F6',
      118: 'F7',
      119: 'F8',
      120: 'F9',
      121: 'F10',
      122: 'F11',
      123: 'F12',
      144: 'NumLock',
      145: 'ScrollLock',
      224: 'Meta',
    },
    Eh = {
      Alt: 'altKey',
      Control: 'ctrlKey',
      Meta: 'metaKey',
      Shift: 'shiftKey',
    };
  function Dh(l) {
    var t = this.nativeEvent;
    return t.getModifierState
      ? t.getModifierState(l)
      : (l = Eh[l])
        ? !!t[l]
        : !1;
  }
  function Pn() {
    return Dh;
  }
  var Oh = V({}, bu, {
      key: function (l) {
        if (l.key) {
          var t = Th[l.key] || l.key;
          if (t !== 'Unidentified') return t;
        }
        return l.type === 'keypress'
          ? ((l = De(l)), l === 13 ? 'Enter' : String.fromCharCode(l))
          : l.type === 'keydown' || l.type === 'keyup'
            ? Mh[l.keyCode] || 'Unidentified'
            : '';
      },
      code: 0,
      location: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      repeat: 0,
      locale: 0,
      getModifierState: Pn,
      charCode: function (l) {
        return l.type === 'keypress' ? De(l) : 0;
      },
      keyCode: function (l) {
        return l.type === 'keydown' || l.type === 'keyup' ? l.keyCode : 0;
      },
      which: function (l) {
        return l.type === 'keypress'
          ? De(l)
          : l.type === 'keydown' || l.type === 'keyup'
            ? l.keyCode
            : 0;
      },
    }),
    xh = Ml(Oh),
    Uh = V({}, Ue, {
      pointerId: 0,
      width: 0,
      height: 0,
      pressure: 0,
      tangentialPressure: 0,
      tiltX: 0,
      tiltY: 0,
      twist: 0,
      pointerType: 0,
      isPrimary: 0,
    }),
    Mi = Ml(Uh),
    Nh = V({}, bu, {
      touches: 0,
      targetTouches: 0,
      changedTouches: 0,
      altKey: 0,
      metaKey: 0,
      ctrlKey: 0,
      shiftKey: 0,
      getModifierState: Pn,
    }),
    Hh = Ml(Nh),
    _h = V({}, ea, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }),
    Rh = Ml(_h),
    qh = V({}, Ue, {
      deltaX: function (l) {
        return 'deltaX' in l
          ? l.deltaX
          : 'wheelDeltaX' in l
            ? -l.wheelDeltaX
            : 0;
      },
      deltaY: function (l) {
        return 'deltaY' in l
          ? l.deltaY
          : 'wheelDeltaY' in l
            ? -l.wheelDeltaY
            : 'wheelDelta' in l
              ? -l.wheelDelta
              : 0;
      },
      deltaZ: 0,
      deltaMode: 0,
    }),
    ph = Ml(qh),
    Bh = V({}, ea, { newState: 0, oldState: 0 }),
    Yh = Ml(Bh),
    jh = [9, 13, 27, 32],
    lc = yt && 'CompositionEvent' in window,
    ru = null;
  yt && 'documentMode' in document && (ru = document.documentMode);
  var Gh = yt && 'TextEvent' in window && !ru,
    Ei = yt && (!lc || (ru && 8 < ru && 11 >= ru)),
    Di = ' ',
    Oi = !1;
  function xi(l, t) {
    switch (l) {
      case 'keyup':
        return jh.indexOf(t.keyCode) !== -1;
      case 'keydown':
        return t.keyCode !== 229;
      case 'keypress':
      case 'mousedown':
      case 'focusout':
        return !0;
      default:
        return !1;
    }
  }
  function Ui(l) {
    return (
      (l = l.detail),
      typeof l == 'object' && 'data' in l ? l.data : null
    );
  }
  var qa = !1;
  function Xh(l, t) {
    switch (l) {
      case 'compositionend':
        return Ui(t);
      case 'keypress':
        return t.which !== 32 ? null : ((Oi = !0), Di);
      case 'textInput':
        return ((l = t.data), l === Di && Oi ? null : l);
      default:
        return null;
    }
  }
  function Qh(l, t) {
    if (qa)
      return l === 'compositionend' || (!lc && xi(l, t))
        ? ((l = ri()), (Ee = kn = Rt = null), (qa = !1), l)
        : null;
    switch (l) {
      case 'paste':
        return null;
      case 'keypress':
        if (!(t.ctrlKey || t.altKey || t.metaKey) || (t.ctrlKey && t.altKey)) {
          if (t.char && 1 < t.char.length) return t.char;
          if (t.which) return String.fromCharCode(t.which);
        }
        return null;
      case 'compositionend':
        return Ei && t.locale !== 'ko' ? null : t.data;
      default:
        return null;
    }
  }
  var Zh = {
    color: !0,
    date: !0,
    datetime: !0,
    'datetime-local': !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0,
  };
  function Ni(l) {
    var t = l && l.nodeName && l.nodeName.toLowerCase();
    return t === 'input' ? !!Zh[l.type] : t === 'textarea';
  }
  function Hi(l, t, a, u) {
    (_a ? (Ra ? Ra.push(u) : (Ra = [u])) : (_a = u),
      (t = on(t, 'onChange')),
      0 < t.length &&
        ((a = new xe('onChange', 'change', null, a, u)),
        l.push({ event: a, listeners: t })));
  }
  var zu = null,
    Au = null;
  function Vh(l) {
    dd(l, 0);
  }
  function Ne(l) {
    var t = mu(l);
    if (hi(t)) return l;
  }
  function _i(l, t) {
    if (l === 'change') return t;
  }
  var Ri = !1;
  if (yt) {
    var tc;
    if (yt) {
      var ac = 'oninput' in document;
      if (!ac) {
        var qi = document.createElement('div');
        (qi.setAttribute('oninput', 'return;'),
          (ac = typeof qi.oninput == 'function'));
      }
      tc = ac;
    } else tc = !1;
    Ri = tc && (!document.documentMode || 9 < document.documentMode);
  }
  function pi() {
    zu && (zu.detachEvent('onpropertychange', Bi), (Au = zu = null));
  }
  function Bi(l) {
    if (l.propertyName === 'value' && Ne(Au)) {
      var t = [];
      (Hi(t, Au, l, Jn(l)), Si(Vh, t));
    }
  }
  function Ch(l, t, a) {
    l === 'focusin'
      ? (pi(), (zu = t), (Au = a), zu.attachEvent('onpropertychange', Bi))
      : l === 'focusout' && pi();
  }
  function Kh(l) {
    if (l === 'selectionchange' || l === 'keyup' || l === 'keydown')
      return Ne(Au);
  }
  function Lh(l, t) {
    if (l === 'click') return Ne(t);
  }
  function Jh(l, t) {
    if (l === 'input' || l === 'change') return Ne(t);
  }
  function wh(l, t) {
    return (l === t && (l !== 0 || 1 / l === 1 / t)) || (l !== l && t !== t);
  }
  var Nl = typeof Object.is == 'function' ? Object.is : wh;
  function Tu(l, t) {
    if (Nl(l, t)) return !0;
    if (
      typeof l != 'object' ||
      l === null ||
      typeof t != 'object' ||
      t === null
    )
      return !1;
    var a = Object.keys(l),
      u = Object.keys(t);
    if (a.length !== u.length) return !1;
    for (u = 0; u < a.length; u++) {
      var e = a[u];
      if (!_n.call(t, e) || !Nl(l[e], t[e])) return !1;
    }
    return !0;
  }
  function Yi(l) {
    for (; l && l.firstChild; ) l = l.firstChild;
    return l;
  }
  function ji(l, t) {
    var a = Yi(l);
    l = 0;
    for (var u; a; ) {
      if (a.nodeType === 3) {
        if (((u = l + a.textContent.length), l <= t && u >= t))
          return { node: a, offset: t - l };
        l = u;
      }
      l: {
        for (; a; ) {
          if (a.nextSibling) {
            a = a.nextSibling;
            break l;
          }
          a = a.parentNode;
        }
        a = void 0;
      }
      a = Yi(a);
    }
  }
  function Gi(l, t) {
    return l && t
      ? l === t
        ? !0
        : l && l.nodeType === 3
          ? !1
          : t && t.nodeType === 3
            ? Gi(l, t.parentNode)
            : 'contains' in l
              ? l.contains(t)
              : l.compareDocumentPosition
                ? !!(l.compareDocumentPosition(t) & 16)
                : !1
      : !1;
  }
  function Xi(l) {
    l =
      l != null &&
      l.ownerDocument != null &&
      l.ownerDocument.defaultView != null
        ? l.ownerDocument.defaultView
        : window;
    for (var t = Te(l.document); t instanceof l.HTMLIFrameElement; ) {
      try {
        var a = typeof t.contentWindow.location.href == 'string';
      } catch {
        a = !1;
      }
      if (a) l = t.contentWindow;
      else break;
      t = Te(l.document);
    }
    return t;
  }
  function uc(l) {
    var t = l && l.nodeName && l.nodeName.toLowerCase();
    return (
      t &&
      ((t === 'input' &&
        (l.type === 'text' ||
          l.type === 'search' ||
          l.type === 'tel' ||
          l.type === 'url' ||
          l.type === 'password')) ||
        t === 'textarea' ||
        l.contentEditable === 'true')
    );
  }
  var Wh = yt && 'documentMode' in document && 11 >= document.documentMode,
    pa = null,
    ec = null,
    Mu = null,
    nc = !1;
  function Qi(l, t, a) {
    var u =
      a.window === a ? a.document : a.nodeType === 9 ? a : a.ownerDocument;
    nc ||
      pa == null ||
      pa !== Te(u) ||
      ((u = pa),
      'selectionStart' in u && uc(u)
        ? (u = { start: u.selectionStart, end: u.selectionEnd })
        : ((u = (
            (u.ownerDocument && u.ownerDocument.defaultView) ||
            window
          ).getSelection()),
          (u = {
            anchorNode: u.anchorNode,
            anchorOffset: u.anchorOffset,
            focusNode: u.focusNode,
            focusOffset: u.focusOffset,
          })),
      (Mu && Tu(Mu, u)) ||
        ((Mu = u),
        (u = on(ec, 'onSelect')),
        0 < u.length &&
          ((t = new xe('onSelect', 'select', null, t, a)),
          l.push({ event: t, listeners: u }),
          (t.target = pa))));
  }
  function na(l, t) {
    var a = {};
    return (
      (a[l.toLowerCase()] = t.toLowerCase()),
      (a['Webkit' + l] = 'webkit' + t),
      (a['Moz' + l] = 'moz' + t),
      a
    );
  }
  var Ba = {
      animationend: na('Animation', 'AnimationEnd'),
      animationiteration: na('Animation', 'AnimationIteration'),
      animationstart: na('Animation', 'AnimationStart'),
      transitionrun: na('Transition', 'TransitionRun'),
      transitionstart: na('Transition', 'TransitionStart'),
      transitioncancel: na('Transition', 'TransitionCancel'),
      transitionend: na('Transition', 'TransitionEnd'),
    },
    cc = {},
    Zi = {};
  yt &&
    ((Zi = document.createElement('div').style),
    'AnimationEvent' in window ||
      (delete Ba.animationend.animation,
      delete Ba.animationiteration.animation,
      delete Ba.animationstart.animation),
    'TransitionEvent' in window || delete Ba.transitionend.transition);
  function ca(l) {
    if (cc[l]) return cc[l];
    if (!Ba[l]) return l;
    var t = Ba[l],
      a;
    for (a in t) if (t.hasOwnProperty(a) && a in Zi) return (cc[l] = t[a]);
    return l;
  }
  var Vi = ca('animationend'),
    Ci = ca('animationiteration'),
    Ki = ca('animationstart'),
    kh = ca('transitionrun'),
    $h = ca('transitionstart'),
    Fh = ca('transitioncancel'),
    Li = ca('transitionend'),
    Ji = new Map(),
    fc =
      'abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel'.split(
        ' ',
      );
  fc.push('scrollEnd');
  function Fl(l, t) {
    (Ji.set(l, t), ua(t, [l]));
  }
  var wi = new WeakMap();
  function Zl(l, t) {
    if (typeof l == 'object' && l !== null) {
      var a = wi.get(l);
      return a !== void 0
        ? a
        : ((t = { value: l, source: t, stack: si(t) }), wi.set(l, t), t);
    }
    return { value: l, source: t, stack: si(t) };
  }
  var Vl = [],
    Ya = 0,
    ic = 0;
  function He() {
    for (var l = Ya, t = (ic = Ya = 0); t < l; ) {
      var a = Vl[t];
      Vl[t++] = null;
      var u = Vl[t];
      Vl[t++] = null;
      var e = Vl[t];
      Vl[t++] = null;
      var n = Vl[t];
      if (((Vl[t++] = null), u !== null && e !== null)) {
        var c = u.pending;
        (c === null ? (e.next = e) : ((e.next = c.next), (c.next = e)),
          (u.pending = e));
      }
      n !== 0 && Wi(a, e, n);
    }
  }
  function _e(l, t, a, u) {
    ((Vl[Ya++] = l),
      (Vl[Ya++] = t),
      (Vl[Ya++] = a),
      (Vl[Ya++] = u),
      (ic |= u),
      (l.lanes |= u),
      (l = l.alternate),
      l !== null && (l.lanes |= u));
  }
  function sc(l, t, a, u) {
    return (_e(l, t, a, u), Re(l));
  }
  function ja(l, t) {
    return (_e(l, null, null, t), Re(l));
  }
  function Wi(l, t, a) {
    l.lanes |= a;
    var u = l.alternate;
    u !== null && (u.lanes |= a);
    for (var e = !1, n = l.return; n !== null; )
      ((n.childLanes |= a),
        (u = n.alternate),
        u !== null && (u.childLanes |= a),
        n.tag === 22 &&
          ((l = n.stateNode), l === null || l._visibility & 1 || (e = !0)),
        (l = n),
        (n = n.return));
    return l.tag === 3
      ? ((n = l.stateNode),
        e &&
          t !== null &&
          ((e = 31 - Ul(a)),
          (l = n.hiddenUpdates),
          (u = l[e]),
          u === null ? (l[e] = [t]) : u.push(t),
          (t.lane = a | 536870912)),
        n)
      : null;
  }
  function Re(l) {
    if (50 < Wu) throw ((Wu = 0), (gf = null), Error(o(185)));
    for (var t = l.return; t !== null; ) ((l = t), (t = l.return));
    return l.tag === 3 ? l.stateNode : null;
  }
  var Ga = {};
  function Ih(l, t, a, u) {
    ((this.tag = l),
      (this.key = a),
      (this.sibling =
        this.child =
        this.return =
        this.stateNode =
        this.type =
        this.elementType =
          null),
      (this.index = 0),
      (this.refCleanup = this.ref = null),
      (this.pendingProps = t),
      (this.dependencies =
        this.memoizedState =
        this.updateQueue =
        this.memoizedProps =
          null),
      (this.mode = u),
      (this.subtreeFlags = this.flags = 0),
      (this.deletions = null),
      (this.childLanes = this.lanes = 0),
      (this.alternate = null));
  }
  function Hl(l, t, a, u) {
    return new Ih(l, t, a, u);
  }
  function dc(l) {
    return ((l = l.prototype), !(!l || !l.isReactComponent));
  }
  function mt(l, t) {
    var a = l.alternate;
    return (
      a === null
        ? ((a = Hl(l.tag, t, l.key, l.mode)),
          (a.elementType = l.elementType),
          (a.type = l.type),
          (a.stateNode = l.stateNode),
          (a.alternate = l),
          (l.alternate = a))
        : ((a.pendingProps = t),
          (a.type = l.type),
          (a.flags = 0),
          (a.subtreeFlags = 0),
          (a.deletions = null)),
      (a.flags = l.flags & 65011712),
      (a.childLanes = l.childLanes),
      (a.lanes = l.lanes),
      (a.child = l.child),
      (a.memoizedProps = l.memoizedProps),
      (a.memoizedState = l.memoizedState),
      (a.updateQueue = l.updateQueue),
      (t = l.dependencies),
      (a.dependencies =
        t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }),
      (a.sibling = l.sibling),
      (a.index = l.index),
      (a.ref = l.ref),
      (a.refCleanup = l.refCleanup),
      a
    );
  }
  function ki(l, t) {
    l.flags &= 65011714;
    var a = l.alternate;
    return (
      a === null
        ? ((l.childLanes = 0),
          (l.lanes = t),
          (l.child = null),
          (l.subtreeFlags = 0),
          (l.memoizedProps = null),
          (l.memoizedState = null),
          (l.updateQueue = null),
          (l.dependencies = null),
          (l.stateNode = null))
        : ((l.childLanes = a.childLanes),
          (l.lanes = a.lanes),
          (l.child = a.child),
          (l.subtreeFlags = 0),
          (l.deletions = null),
          (l.memoizedProps = a.memoizedProps),
          (l.memoizedState = a.memoizedState),
          (l.updateQueue = a.updateQueue),
          (l.type = a.type),
          (t = a.dependencies),
          (l.dependencies =
            t === null
              ? null
              : { lanes: t.lanes, firstContext: t.firstContext })),
      l
    );
  }
  function qe(l, t, a, u, e, n) {
    var c = 0;
    if (((u = l), typeof l == 'function')) dc(l) && (c = 1);
    else if (typeof l == 'string')
      c = lv(l, a, fl.current)
        ? 26
        : l === 'html' || l === 'head' || l === 'body'
          ? 27
          : 5;
    else
      l: switch (l) {
        case za:
          return (
            (l = Hl(31, a, t, e)),
            (l.elementType = za),
            (l.lanes = n),
            l
          );
        case Yl:
          return fa(a.children, e, n, t);
        case xt:
          ((c = 8), (e |= 24));
          break;
        case la:
          return (
            (l = Hl(12, a, t, e | 2)),
            (l.elementType = la),
            (l.lanes = n),
            l
          );
        case ta:
          return (
            (l = Hl(13, a, t, e)),
            (l.elementType = ta),
            (l.lanes = n),
            l
          );
        case lt:
          return (
            (l = Hl(19, a, t, e)),
            (l.elementType = lt),
            (l.lanes = n),
            l
          );
        default:
          if (typeof l == 'object' && l !== null)
            switch (l.$$typeof) {
              case se:
              case jl:
                c = 10;
                break l;
              case iu:
                c = 9;
                break l;
              case Ut:
                c = 11;
                break l;
              case dt:
                c = 14;
                break l;
              case $l:
                ((c = 16), (u = null));
                break l;
            }
          ((c = 29),
            (a = Error(o(130, l === null ? 'null' : typeof l, ''))),
            (u = null));
      }
    return (
      (t = Hl(c, a, t, e)),
      (t.elementType = l),
      (t.type = u),
      (t.lanes = n),
      t
    );
  }
  function fa(l, t, a, u) {
    return ((l = Hl(7, l, u, t)), (l.lanes = a), l);
  }
  function hc(l, t, a) {
    return ((l = Hl(6, l, null, t)), (l.lanes = a), l);
  }
  function vc(l, t, a) {
    return (
      (t = Hl(4, l.children !== null ? l.children : [], l.key, t)),
      (t.lanes = a),
      (t.stateNode = {
        containerInfo: l.containerInfo,
        pendingChildren: null,
        implementation: l.implementation,
      }),
      t
    );
  }
  var Xa = [],
    Qa = 0,
    pe = null,
    Be = 0,
    Cl = [],
    Kl = 0,
    ia = null,
    ot = 1,
    gt = '';
  function sa(l, t) {
    ((Xa[Qa++] = Be), (Xa[Qa++] = pe), (pe = l), (Be = t));
  }
  function $i(l, t, a) {
    ((Cl[Kl++] = ot), (Cl[Kl++] = gt), (Cl[Kl++] = ia), (ia = l));
    var u = ot;
    l = gt;
    var e = 32 - Ul(u) - 1;
    ((u &= ~(1 << e)), (a += 1));
    var n = 32 - Ul(t) + e;
    if (30 < n) {
      var c = e - (e % 5);
      ((n = (u & ((1 << c) - 1)).toString(32)),
        (u >>= c),
        (e -= c),
        (ot = (1 << (32 - Ul(t) + e)) | (a << e) | u),
        (gt = n + l));
    } else ((ot = (1 << n) | (a << e) | u), (gt = l));
  }
  function yc(l) {
    l.return !== null && (sa(l, 1), $i(l, 1, 0));
  }
  function mc(l) {
    for (; l === pe; )
      ((pe = Xa[--Qa]), (Xa[Qa] = null), (Be = Xa[--Qa]), (Xa[Qa] = null));
    for (; l === ia; )
      ((ia = Cl[--Kl]),
        (Cl[Kl] = null),
        (gt = Cl[--Kl]),
        (Cl[Kl] = null),
        (ot = Cl[--Kl]),
        (Cl[Kl] = null));
  }
  var zl = null,
    F = null,
    B = !1,
    da = null,
    ut = !1,
    oc = Error(o(519));
  function ha(l) {
    var t = Error(o(418, ''));
    throw (Ou(Zl(t, l)), oc);
  }
  function Fi(l) {
    var t = l.stateNode,
      a = l.type,
      u = l.memoizedProps;
    switch (((t[bl] = l), (t[Tl] = u), a)) {
      case 'dialog':
        (R('cancel', t), R('close', t));
        break;
      case 'iframe':
      case 'object':
      case 'embed':
        R('load', t);
        break;
      case 'video':
      case 'audio':
        for (a = 0; a < $u.length; a++) R($u[a], t);
        break;
      case 'source':
        R('error', t);
        break;
      case 'img':
      case 'image':
      case 'link':
        (R('error', t), R('load', t));
        break;
      case 'details':
        R('toggle', t);
        break;
      case 'input':
        (R('invalid', t),
          vi(
            t,
            u.value,
            u.defaultValue,
            u.checked,
            u.defaultChecked,
            u.type,
            u.name,
            !0,
          ),
          Ae(t));
        break;
      case 'select':
        R('invalid', t);
        break;
      case 'textarea':
        (R('invalid', t), mi(t, u.value, u.defaultValue, u.children), Ae(t));
    }
    ((a = u.children),
      (typeof a != 'string' && typeof a != 'number' && typeof a != 'bigint') ||
      t.textContent === '' + a ||
      u.suppressHydrationWarning === !0 ||
      md(t.textContent, a)
        ? (u.popover != null && (R('beforetoggle', t), R('toggle', t)),
          u.onScroll != null && R('scroll', t),
          u.onScrollEnd != null && R('scrollend', t),
          u.onClick != null && (t.onclick = gn),
          (t = !0))
        : (t = !1),
      t || ha(l));
  }
  function Ii(l) {
    for (zl = l.return; zl; )
      switch (zl.tag) {
        case 5:
        case 13:
          ut = !1;
          return;
        case 27:
        case 3:
          ut = !0;
          return;
        default:
          zl = zl.return;
      }
  }
  function Eu(l) {
    if (l !== zl) return !1;
    if (!B) return (Ii(l), (B = !0), !1);
    var t = l.tag,
      a;
    if (
      ((a = t !== 3 && t !== 27) &&
        ((a = t === 5) &&
          ((a = l.type),
          (a =
            !(a !== 'form' && a !== 'button') || Rf(l.type, l.memoizedProps))),
        (a = !a)),
      a && F && ha(l),
      Ii(l),
      t === 13)
    ) {
      if (((l = l.memoizedState), (l = l !== null ? l.dehydrated : null), !l))
        throw Error(o(317));
      l: {
        for (l = l.nextSibling, t = 0; l; ) {
          if (l.nodeType === 8)
            if (((a = l.data), a === '/$')) {
              if (t === 0) {
                F = Pl(l.nextSibling);
                break l;
              }
              t--;
            } else (a !== '$' && a !== '$!' && a !== '$?') || t++;
          l = l.nextSibling;
        }
        F = null;
      }
    } else
      t === 27
        ? ((t = F), Wt(l.type) ? ((l = Yf), (Yf = null), (F = l)) : (F = t))
        : (F = zl ? Pl(l.stateNode.nextSibling) : null);
    return !0;
  }
  function Du() {
    ((F = zl = null), (B = !1));
  }
  function Pi() {
    var l = da;
    return (
      l !== null &&
        (Ol === null ? (Ol = l) : Ol.push.apply(Ol, l), (da = null)),
      l
    );
  }
  function Ou(l) {
    da === null ? (da = [l]) : da.push(l);
  }
  var gc = rl(null),
    va = null,
    bt = null;
  function qt(l, t, a) {
    (G(gc, t._currentValue), (t._currentValue = a));
  }
  function St(l) {
    ((l._currentValue = gc.current), k(gc));
  }
  function bc(l, t, a) {
    for (; l !== null; ) {
      var u = l.alternate;
      if (
        ((l.childLanes & t) !== t
          ? ((l.childLanes |= t), u !== null && (u.childLanes |= t))
          : u !== null && (u.childLanes & t) !== t && (u.childLanes |= t),
        l === a)
      )
        break;
      l = l.return;
    }
  }
  function Sc(l, t, a, u) {
    var e = l.child;
    for (e !== null && (e.return = l); e !== null; ) {
      var n = e.dependencies;
      if (n !== null) {
        var c = e.child;
        n = n.firstContext;
        l: for (; n !== null; ) {
          var f = n;
          n = e;
          for (var i = 0; i < t.length; i++)
            if (f.context === t[i]) {
              ((n.lanes |= a),
                (f = n.alternate),
                f !== null && (f.lanes |= a),
                bc(n.return, a, l),
                u || (c = null));
              break l;
            }
          n = f.next;
        }
      } else if (e.tag === 18) {
        if (((c = e.return), c === null)) throw Error(o(341));
        ((c.lanes |= a),
          (n = c.alternate),
          n !== null && (n.lanes |= a),
          bc(c, a, l),
          (c = null));
      } else c = e.child;
      if (c !== null) c.return = e;
      else
        for (c = e; c !== null; ) {
          if (c === l) {
            c = null;
            break;
          }
          if (((e = c.sibling), e !== null)) {
            ((e.return = c.return), (c = e));
            break;
          }
          c = c.return;
        }
      e = c;
    }
  }
  function xu(l, t, a, u) {
    l = null;
    for (var e = t, n = !1; e !== null; ) {
      if (!n) {
        if ((e.flags & 524288) !== 0) n = !0;
        else if ((e.flags & 262144) !== 0) break;
      }
      if (e.tag === 10) {
        var c = e.alternate;
        if (c === null) throw Error(o(387));
        if (((c = c.memoizedProps), c !== null)) {
          var f = e.type;
          Nl(e.pendingProps.value, c.value) ||
            (l !== null ? l.push(f) : (l = [f]));
        }
      } else if (e === ve.current) {
        if (((c = e.alternate), c === null)) throw Error(o(387));
        c.memoizedState.memoizedState !== e.memoizedState.memoizedState &&
          (l !== null ? l.push(ae) : (l = [ae]));
      }
      e = e.return;
    }
    (l !== null && Sc(t, l, a, u), (t.flags |= 262144));
  }
  function Ye(l) {
    for (l = l.firstContext; l !== null; ) {
      if (!Nl(l.context._currentValue, l.memoizedValue)) return !0;
      l = l.next;
    }
    return !1;
  }
  function ya(l) {
    ((va = l),
      (bt = null),
      (l = l.dependencies),
      l !== null && (l.firstContext = null));
  }
  function Sl(l) {
    return l0(va, l);
  }
  function je(l, t) {
    return (va === null && ya(l), l0(l, t));
  }
  function l0(l, t) {
    var a = t._currentValue;
    if (((t = { context: t, memoizedValue: a, next: null }), bt === null)) {
      if (l === null) throw Error(o(308));
      ((bt = t),
        (l.dependencies = { lanes: 0, firstContext: t }),
        (l.flags |= 524288));
    } else bt = bt.next = t;
    return a;
  }
  var Ph =
      typeof AbortController < 'u'
        ? AbortController
        : function () {
            var l = [],
              t = (this.signal = {
                aborted: !1,
                addEventListener: function (a, u) {
                  l.push(u);
                },
              });
            this.abort = function () {
              ((t.aborted = !0),
                l.forEach(function (a) {
                  return a();
                }));
            };
          },
    l1 = E.unstable_scheduleCallback,
    t1 = E.unstable_NormalPriority,
    nl = {
      $$typeof: jl,
      Consumer: null,
      Provider: null,
      _currentValue: null,
      _currentValue2: null,
      _threadCount: 0,
    };
  function rc() {
    return { controller: new Ph(), data: new Map(), refCount: 0 };
  }
  function Uu(l) {
    (l.refCount--,
      l.refCount === 0 &&
        l1(t1, function () {
          l.controller.abort();
        }));
  }
  var Nu = null,
    zc = 0,
    Za = 0,
    Va = null;
  function a1(l, t) {
    if (Nu === null) {
      var a = (Nu = []);
      ((zc = 0),
        (Za = Mf()),
        (Va = {
          status: 'pending',
          value: void 0,
          then: function (u) {
            a.push(u);
          },
        }));
    }
    return (zc++, t.then(t0, t0), t);
  }
  function t0() {
    if (--zc === 0 && Nu !== null) {
      Va !== null && (Va.status = 'fulfilled');
      var l = Nu;
      ((Nu = null), (Za = 0), (Va = null));
      for (var t = 0; t < l.length; t++) (0, l[t])();
    }
  }
  function u1(l, t) {
    var a = [],
      u = {
        status: 'pending',
        value: null,
        reason: null,
        then: function (e) {
          a.push(e);
        },
      };
    return (
      l.then(
        function () {
          ((u.status = 'fulfilled'), (u.value = t));
          for (var e = 0; e < a.length; e++) (0, a[e])(t);
        },
        function (e) {
          for (u.status = 'rejected', u.reason = e, e = 0; e < a.length; e++)
            (0, a[e])(void 0);
        },
      ),
      u
    );
  }
  var a0 = S.S;
  S.S = function (l, t) {
    (typeof t == 'object' &&
      t !== null &&
      typeof t.then == 'function' &&
      a1(l, t),
      a0 !== null && a0(l, t));
  };
  var ma = rl(null);
  function Ac() {
    var l = ma.current;
    return l !== null ? l : K.pooledCache;
  }
  function Ge(l, t) {
    t === null ? G(ma, ma.current) : G(ma, t.pool);
  }
  function u0() {
    var l = Ac();
    return l === null ? null : { parent: nl._currentValue, pool: l };
  }
  var Hu = Error(o(460)),
    e0 = Error(o(474)),
    Xe = Error(o(542)),
    Tc = { then: function () {} };
  function n0(l) {
    return ((l = l.status), l === 'fulfilled' || l === 'rejected');
  }
  function Qe() {}
  function c0(l, t, a) {
    switch (
      ((a = l[a]),
      a === void 0 ? l.push(t) : a !== t && (t.then(Qe, Qe), (t = a)),
      t.status)
    ) {
      case 'fulfilled':
        return t.value;
      case 'rejected':
        throw ((l = t.reason), i0(l), l);
      default:
        if (typeof t.status == 'string') t.then(Qe, Qe);
        else {
          if (((l = K), l !== null && 100 < l.shellSuspendCounter))
            throw Error(o(482));
          ((l = t),
            (l.status = 'pending'),
            l.then(
              function (u) {
                if (t.status === 'pending') {
                  var e = t;
                  ((e.status = 'fulfilled'), (e.value = u));
                }
              },
              function (u) {
                if (t.status === 'pending') {
                  var e = t;
                  ((e.status = 'rejected'), (e.reason = u));
                }
              },
            ));
        }
        switch (t.status) {
          case 'fulfilled':
            return t.value;
          case 'rejected':
            throw ((l = t.reason), i0(l), l);
        }
        throw ((_u = t), Hu);
    }
  }
  var _u = null;
  function f0() {
    if (_u === null) throw Error(o(459));
    var l = _u;
    return ((_u = null), l);
  }
  function i0(l) {
    if (l === Hu || l === Xe) throw Error(o(483));
  }
  var pt = !1;
  function Mc(l) {
    l.updateQueue = {
      baseState: l.memoizedState,
      firstBaseUpdate: null,
      lastBaseUpdate: null,
      shared: { pending: null, lanes: 0, hiddenCallbacks: null },
      callbacks: null,
    };
  }
  function Ec(l, t) {
    ((l = l.updateQueue),
      t.updateQueue === l &&
        (t.updateQueue = {
          baseState: l.baseState,
          firstBaseUpdate: l.firstBaseUpdate,
          lastBaseUpdate: l.lastBaseUpdate,
          shared: l.shared,
          callbacks: null,
        }));
  }
  function Bt(l) {
    return { lane: l, tag: 0, payload: null, callback: null, next: null };
  }
  function Yt(l, t, a) {
    var u = l.updateQueue;
    if (u === null) return null;
    if (((u = u.shared), (Y & 2) !== 0)) {
      var e = u.pending;
      return (
        e === null ? (t.next = t) : ((t.next = e.next), (e.next = t)),
        (u.pending = t),
        (t = Re(l)),
        Wi(l, null, a),
        t
      );
    }
    return (_e(l, u, t, a), Re(l));
  }
  function Ru(l, t, a) {
    if (
      ((t = t.updateQueue), t !== null && ((t = t.shared), (a & 4194048) !== 0))
    ) {
      var u = t.lanes;
      ((u &= l.pendingLanes), (a |= u), (t.lanes = a), ti(l, a));
    }
  }
  function Dc(l, t) {
    var a = l.updateQueue,
      u = l.alternate;
    if (u !== null && ((u = u.updateQueue), a === u)) {
      var e = null,
        n = null;
      if (((a = a.firstBaseUpdate), a !== null)) {
        do {
          var c = {
            lane: a.lane,
            tag: a.tag,
            payload: a.payload,
            callback: null,
            next: null,
          };
          (n === null ? (e = n = c) : (n = n.next = c), (a = a.next));
        } while (a !== null);
        n === null ? (e = n = t) : (n = n.next = t);
      } else e = n = t;
      ((a = {
        baseState: u.baseState,
        firstBaseUpdate: e,
        lastBaseUpdate: n,
        shared: u.shared,
        callbacks: u.callbacks,
      }),
        (l.updateQueue = a));
      return;
    }
    ((l = a.lastBaseUpdate),
      l === null ? (a.firstBaseUpdate = t) : (l.next = t),
      (a.lastBaseUpdate = t));
  }
  var Oc = !1;
  function qu() {
    if (Oc) {
      var l = Va;
      if (l !== null) throw l;
    }
  }
  function pu(l, t, a, u) {
    Oc = !1;
    var e = l.updateQueue;
    pt = !1;
    var n = e.firstBaseUpdate,
      c = e.lastBaseUpdate,
      f = e.shared.pending;
    if (f !== null) {
      e.shared.pending = null;
      var i = f,
        v = i.next;
      ((i.next = null), c === null ? (n = v) : (c.next = v), (c = i));
      var g = l.alternate;
      g !== null &&
        ((g = g.updateQueue),
        (f = g.lastBaseUpdate),
        f !== c &&
          (f === null ? (g.firstBaseUpdate = v) : (f.next = v),
          (g.lastBaseUpdate = i)));
    }
    if (n !== null) {
      var r = e.baseState;
      ((c = 0), (g = v = i = null), (f = n));
      do {
        var y = f.lane & -536870913,
          m = y !== f.lane;
        if (m ? (q & y) === y : (u & y) === y) {
          (y !== 0 && y === Za && (Oc = !0),
            g !== null &&
              (g = g.next =
                {
                  lane: 0,
                  tag: f.tag,
                  payload: f.payload,
                  callback: null,
                  next: null,
                }));
          l: {
            var x = l,
              D = f;
            y = t;
            var Z = a;
            switch (D.tag) {
              case 1:
                if (((x = D.payload), typeof x == 'function')) {
                  r = x.call(Z, r, y);
                  break l;
                }
                r = x;
                break l;
              case 3:
                x.flags = (x.flags & -65537) | 128;
              case 0:
                if (
                  ((x = D.payload),
                  (y = typeof x == 'function' ? x.call(Z, r, y) : x),
                  y == null)
                )
                  break l;
                r = V({}, r, y);
                break l;
              case 2:
                pt = !0;
            }
          }
          ((y = f.callback),
            y !== null &&
              ((l.flags |= 64),
              m && (l.flags |= 8192),
              (m = e.callbacks),
              m === null ? (e.callbacks = [y]) : m.push(y)));
        } else
          ((m = {
            lane: y,
            tag: f.tag,
            payload: f.payload,
            callback: f.callback,
            next: null,
          }),
            g === null ? ((v = g = m), (i = r)) : (g = g.next = m),
            (c |= y));
        if (((f = f.next), f === null)) {
          if (((f = e.shared.pending), f === null)) break;
          ((m = f),
            (f = m.next),
            (m.next = null),
            (e.lastBaseUpdate = m),
            (e.shared.pending = null));
        }
      } while (!0);
      (g === null && (i = r),
        (e.baseState = i),
        (e.firstBaseUpdate = v),
        (e.lastBaseUpdate = g),
        n === null && (e.shared.lanes = 0),
        (Kt |= c),
        (l.lanes = c),
        (l.memoizedState = r));
    }
  }
  function s0(l, t) {
    if (typeof l != 'function') throw Error(o(191, l));
    l.call(t);
  }
  function d0(l, t) {
    var a = l.callbacks;
    if (a !== null)
      for (l.callbacks = null, l = 0; l < a.length; l++) s0(a[l], t);
  }
  var Ca = rl(null),
    Ze = rl(0);
  function h0(l, t) {
    ((l = Dt), G(Ze, l), G(Ca, t), (Dt = l | t.baseLanes));
  }
  function xc() {
    (G(Ze, Dt), G(Ca, Ca.current));
  }
  function Uc() {
    ((Dt = Ze.current), k(Ca), k(Ze));
  }
  var jt = 0,
    N = null,
    X = null,
    al = null,
    Ve = !1,
    Ka = !1,
    oa = !1,
    Ce = 0,
    Bu = 0,
    La = null,
    e1 = 0;
  function ll() {
    throw Error(o(321));
  }
  function Nc(l, t) {
    if (t === null) return !1;
    for (var a = 0; a < t.length && a < l.length; a++)
      if (!Nl(l[a], t[a])) return !1;
    return !0;
  }
  function Hc(l, t, a, u, e, n) {
    return (
      (jt = n),
      (N = t),
      (t.memoizedState = null),
      (t.updateQueue = null),
      (t.lanes = 0),
      (S.H = l === null || l.memoizedState === null ? W0 : k0),
      (oa = !1),
      (n = a(u, e)),
      (oa = !1),
      Ka && (n = y0(t, a, u, e)),
      v0(l),
      n
    );
  }
  function v0(l) {
    S.H = ke;
    var t = X !== null && X.next !== null;
    if (((jt = 0), (al = X = N = null), (Ve = !1), (Bu = 0), (La = null), t))
      throw Error(o(300));
    l === null ||
      sl ||
      ((l = l.dependencies), l !== null && Ye(l) && (sl = !0));
  }
  function y0(l, t, a, u) {
    N = l;
    var e = 0;
    do {
      if ((Ka && (La = null), (Bu = 0), (Ka = !1), 25 <= e))
        throw Error(o(301));
      if (((e += 1), (al = X = null), l.updateQueue != null)) {
        var n = l.updateQueue;
        ((n.lastEffect = null),
          (n.events = null),
          (n.stores = null),
          n.memoCache != null && (n.memoCache.index = 0));
      }
      ((S.H = h1), (n = t(a, u)));
    } while (Ka);
    return n;
  }
  function n1() {
    var l = S.H,
      t = l.useState()[0];
    return (
      (t = typeof t.then == 'function' ? Yu(t) : t),
      (l = l.useState()[0]),
      (X !== null ? X.memoizedState : null) !== l && (N.flags |= 1024),
      t
    );
  }
  function _c() {
    var l = Ce !== 0;
    return ((Ce = 0), l);
  }
  function Rc(l, t, a) {
    ((t.updateQueue = l.updateQueue), (t.flags &= -2053), (l.lanes &= ~a));
  }
  function qc(l) {
    if (Ve) {
      for (l = l.memoizedState; l !== null; ) {
        var t = l.queue;
        (t !== null && (t.pending = null), (l = l.next));
      }
      Ve = !1;
    }
    ((jt = 0), (al = X = N = null), (Ka = !1), (Bu = Ce = 0), (La = null));
  }
  function El() {
    var l = {
      memoizedState: null,
      baseState: null,
      baseQueue: null,
      queue: null,
      next: null,
    };
    return (al === null ? (N.memoizedState = al = l) : (al = al.next = l), al);
  }
  function ul() {
    if (X === null) {
      var l = N.alternate;
      l = l !== null ? l.memoizedState : null;
    } else l = X.next;
    var t = al === null ? N.memoizedState : al.next;
    if (t !== null) ((al = t), (X = l));
    else {
      if (l === null)
        throw N.alternate === null ? Error(o(467)) : Error(o(310));
      ((X = l),
        (l = {
          memoizedState: X.memoizedState,
          baseState: X.baseState,
          baseQueue: X.baseQueue,
          queue: X.queue,
          next: null,
        }),
        al === null ? (N.memoizedState = al = l) : (al = al.next = l));
    }
    return al;
  }
  function pc() {
    return { lastEffect: null, events: null, stores: null, memoCache: null };
  }
  function Yu(l) {
    var t = Bu;
    return (
      (Bu += 1),
      La === null && (La = []),
      (l = c0(La, l, t)),
      (t = N),
      (al === null ? t.memoizedState : al.next) === null &&
        ((t = t.alternate),
        (S.H = t === null || t.memoizedState === null ? W0 : k0)),
      l
    );
  }
  function Ke(l) {
    if (l !== null && typeof l == 'object') {
      if (typeof l.then == 'function') return Yu(l);
      if (l.$$typeof === jl) return Sl(l);
    }
    throw Error(o(438, String(l)));
  }
  function Bc(l) {
    var t = null,
      a = N.updateQueue;
    if ((a !== null && (t = a.memoCache), t == null)) {
      var u = N.alternate;
      u !== null &&
        ((u = u.updateQueue),
        u !== null &&
          ((u = u.memoCache),
          u != null &&
            (t = {
              data: u.data.map(function (e) {
                return e.slice();
              }),
              index: 0,
            })));
    }
    if (
      (t == null && (t = { data: [], index: 0 }),
      a === null && ((a = pc()), (N.updateQueue = a)),
      (a.memoCache = t),
      (a = t.data[t.index]),
      a === void 0)
    )
      for (a = t.data[t.index] = Array(l), u = 0; u < l; u++) a[u] = de;
    return (t.index++, a);
  }
  function rt(l, t) {
    return typeof t == 'function' ? t(l) : t;
  }
  function Le(l) {
    var t = ul();
    return Yc(t, X, l);
  }
  function Yc(l, t, a) {
    var u = l.queue;
    if (u === null) throw Error(o(311));
    u.lastRenderedReducer = a;
    var e = l.baseQueue,
      n = u.pending;
    if (n !== null) {
      if (e !== null) {
        var c = e.next;
        ((e.next = n.next), (n.next = c));
      }
      ((t.baseQueue = e = n), (u.pending = null));
    }
    if (((n = l.baseState), e === null)) l.memoizedState = n;
    else {
      t = e.next;
      var f = (c = null),
        i = null,
        v = t,
        g = !1;
      do {
        var r = v.lane & -536870913;
        if (r !== v.lane ? (q & r) === r : (jt & r) === r) {
          var y = v.revertLane;
          if (y === 0)
            (i !== null &&
              (i = i.next =
                {
                  lane: 0,
                  revertLane: 0,
                  action: v.action,
                  hasEagerState: v.hasEagerState,
                  eagerState: v.eagerState,
                  next: null,
                }),
              r === Za && (g = !0));
          else if ((jt & y) === y) {
            ((v = v.next), y === Za && (g = !0));
            continue;
          } else
            ((r = {
              lane: 0,
              revertLane: v.revertLane,
              action: v.action,
              hasEagerState: v.hasEagerState,
              eagerState: v.eagerState,
              next: null,
            }),
              i === null ? ((f = i = r), (c = n)) : (i = i.next = r),
              (N.lanes |= y),
              (Kt |= y));
          ((r = v.action),
            oa && a(n, r),
            (n = v.hasEagerState ? v.eagerState : a(n, r)));
        } else
          ((y = {
            lane: r,
            revertLane: v.revertLane,
            action: v.action,
            hasEagerState: v.hasEagerState,
            eagerState: v.eagerState,
            next: null,
          }),
            i === null ? ((f = i = y), (c = n)) : (i = i.next = y),
            (N.lanes |= r),
            (Kt |= r));
        v = v.next;
      } while (v !== null && v !== t);
      if (
        (i === null ? (c = n) : (i.next = f),
        !Nl(n, l.memoizedState) && ((sl = !0), g && ((a = Va), a !== null)))
      )
        throw a;
      ((l.memoizedState = n),
        (l.baseState = c),
        (l.baseQueue = i),
        (u.lastRenderedState = n));
    }
    return (e === null && (u.lanes = 0), [l.memoizedState, u.dispatch]);
  }
  function jc(l) {
    var t = ul(),
      a = t.queue;
    if (a === null) throw Error(o(311));
    a.lastRenderedReducer = l;
    var u = a.dispatch,
      e = a.pending,
      n = t.memoizedState;
    if (e !== null) {
      a.pending = null;
      var c = (e = e.next);
      do ((n = l(n, c.action)), (c = c.next));
      while (c !== e);
      (Nl(n, t.memoizedState) || (sl = !0),
        (t.memoizedState = n),
        t.baseQueue === null && (t.baseState = n),
        (a.lastRenderedState = n));
    }
    return [n, u];
  }
  function m0(l, t, a) {
    var u = N,
      e = ul(),
      n = B;
    if (n) {
      if (a === void 0) throw Error(o(407));
      a = a();
    } else a = t();
    var c = !Nl((X || e).memoizedState, a);
    (c && ((e.memoizedState = a), (sl = !0)), (e = e.queue));
    var f = b0.bind(null, u, e, l);
    if (
      (ju(2048, 8, f, [l]),
      e.getSnapshot !== t || c || (al !== null && al.memoizedState.tag & 1))
    ) {
      if (
        ((u.flags |= 2048),
        Ja(9, Je(), g0.bind(null, u, e, a, t), null),
        K === null)
      )
        throw Error(o(349));
      n || (jt & 124) !== 0 || o0(u, t, a);
    }
    return a;
  }
  function o0(l, t, a) {
    ((l.flags |= 16384),
      (l = { getSnapshot: t, value: a }),
      (t = N.updateQueue),
      t === null
        ? ((t = pc()), (N.updateQueue = t), (t.stores = [l]))
        : ((a = t.stores), a === null ? (t.stores = [l]) : a.push(l)));
  }
  function g0(l, t, a, u) {
    ((t.value = a), (t.getSnapshot = u), S0(t) && r0(l));
  }
  function b0(l, t, a) {
    return a(function () {
      S0(t) && r0(l);
    });
  }
  function S0(l) {
    var t = l.getSnapshot;
    l = l.value;
    try {
      var a = t();
      return !Nl(l, a);
    } catch {
      return !0;
    }
  }
  function r0(l) {
    var t = ja(l, 2);
    t !== null && Bl(t, l, 2);
  }
  function Gc(l) {
    var t = El();
    if (typeof l == 'function') {
      var a = l;
      if (((l = a()), oa)) {
        Ht(!0);
        try {
          a();
        } finally {
          Ht(!1);
        }
      }
    }
    return (
      (t.memoizedState = t.baseState = l),
      (t.queue = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: rt,
        lastRenderedState: l,
      }),
      t
    );
  }
  function z0(l, t, a, u) {
    return ((l.baseState = a), Yc(l, X, typeof u == 'function' ? u : rt));
  }
  function c1(l, t, a, u, e) {
    if (We(l)) throw Error(o(485));
    if (((l = t.action), l !== null)) {
      var n = {
        payload: e,
        action: l,
        next: null,
        isTransition: !0,
        status: 'pending',
        value: null,
        reason: null,
        listeners: [],
        then: function (c) {
          n.listeners.push(c);
        },
      };
      (S.T !== null ? a(!0) : (n.isTransition = !1),
        u(n),
        (a = t.pending),
        a === null
          ? ((n.next = t.pending = n), A0(t, n))
          : ((n.next = a.next), (t.pending = a.next = n)));
    }
  }
  function A0(l, t) {
    var a = t.action,
      u = t.payload,
      e = l.state;
    if (t.isTransition) {
      var n = S.T,
        c = {};
      S.T = c;
      try {
        var f = a(e, u),
          i = S.S;
        (i !== null && i(c, f), T0(l, t, f));
      } catch (v) {
        Xc(l, t, v);
      } finally {
        S.T = n;
      }
    } else
      try {
        ((n = a(e, u)), T0(l, t, n));
      } catch (v) {
        Xc(l, t, v);
      }
  }
  function T0(l, t, a) {
    a !== null && typeof a == 'object' && typeof a.then == 'function'
      ? a.then(
          function (u) {
            M0(l, t, u);
          },
          function (u) {
            return Xc(l, t, u);
          },
        )
      : M0(l, t, a);
  }
  function M0(l, t, a) {
    ((t.status = 'fulfilled'),
      (t.value = a),
      E0(t),
      (l.state = a),
      (t = l.pending),
      t !== null &&
        ((a = t.next),
        a === t ? (l.pending = null) : ((a = a.next), (t.next = a), A0(l, a))));
  }
  function Xc(l, t, a) {
    var u = l.pending;
    if (((l.pending = null), u !== null)) {
      u = u.next;
      do ((t.status = 'rejected'), (t.reason = a), E0(t), (t = t.next));
      while (t !== u);
    }
    l.action = null;
  }
  function E0(l) {
    l = l.listeners;
    for (var t = 0; t < l.length; t++) (0, l[t])();
  }
  function D0(l, t) {
    return t;
  }
  function O0(l, t) {
    if (B) {
      var a = K.formState;
      if (a !== null) {
        l: {
          var u = N;
          if (B) {
            if (F) {
              t: {
                for (var e = F, n = ut; e.nodeType !== 8; ) {
                  if (!n) {
                    e = null;
                    break t;
                  }
                  if (((e = Pl(e.nextSibling)), e === null)) {
                    e = null;
                    break t;
                  }
                }
                ((n = e.data), (e = n === 'F!' || n === 'F' ? e : null));
              }
              if (e) {
                ((F = Pl(e.nextSibling)), (u = e.data === 'F!'));
                break l;
              }
            }
            ha(u);
          }
          u = !1;
        }
        u && (t = a[0]);
      }
    }
    return (
      (a = El()),
      (a.memoizedState = a.baseState = t),
      (u = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: D0,
        lastRenderedState: t,
      }),
      (a.queue = u),
      (a = L0.bind(null, N, u)),
      (u.dispatch = a),
      (u = Gc(!1)),
      (n = Kc.bind(null, N, !1, u.queue)),
      (u = El()),
      (e = { state: t, dispatch: null, action: l, pending: null }),
      (u.queue = e),
      (a = c1.bind(null, N, e, n, a)),
      (e.dispatch = a),
      (u.memoizedState = l),
      [t, a, !1]
    );
  }
  function x0(l) {
    var t = ul();
    return U0(t, X, l);
  }
  function U0(l, t, a) {
    if (
      ((t = Yc(l, t, D0)[0]),
      (l = Le(rt)[0]),
      typeof t == 'object' && t !== null && typeof t.then == 'function')
    )
      try {
        var u = Yu(t);
      } catch (c) {
        throw c === Hu ? Xe : c;
      }
    else u = t;
    t = ul();
    var e = t.queue,
      n = e.dispatch;
    return (
      a !== t.memoizedState &&
        ((N.flags |= 2048), Ja(9, Je(), f1.bind(null, e, a), null)),
      [u, n, l]
    );
  }
  function f1(l, t) {
    l.action = t;
  }
  function N0(l) {
    var t = ul(),
      a = X;
    if (a !== null) return U0(t, a, l);
    (ul(), (t = t.memoizedState), (a = ul()));
    var u = a.queue.dispatch;
    return ((a.memoizedState = l), [t, u, !1]);
  }
  function Ja(l, t, a, u) {
    return (
      (l = { tag: l, create: a, deps: u, inst: t, next: null }),
      (t = N.updateQueue),
      t === null && ((t = pc()), (N.updateQueue = t)),
      (a = t.lastEffect),
      a === null
        ? (t.lastEffect = l.next = l)
        : ((u = a.next), (a.next = l), (l.next = u), (t.lastEffect = l)),
      l
    );
  }
  function Je() {
    return { destroy: void 0, resource: void 0 };
  }
  function H0() {
    return ul().memoizedState;
  }
  function we(l, t, a, u) {
    var e = El();
    ((u = u === void 0 ? null : u),
      (N.flags |= l),
      (e.memoizedState = Ja(1 | t, Je(), a, u)));
  }
  function ju(l, t, a, u) {
    var e = ul();
    u = u === void 0 ? null : u;
    var n = e.memoizedState.inst;
    X !== null && u !== null && Nc(u, X.memoizedState.deps)
      ? (e.memoizedState = Ja(t, n, a, u))
      : ((N.flags |= l), (e.memoizedState = Ja(1 | t, n, a, u)));
  }
  function _0(l, t) {
    we(8390656, 8, l, t);
  }
  function R0(l, t) {
    ju(2048, 8, l, t);
  }
  function q0(l, t) {
    return ju(4, 2, l, t);
  }
  function p0(l, t) {
    return ju(4, 4, l, t);
  }
  function B0(l, t) {
    if (typeof t == 'function') {
      l = l();
      var a = t(l);
      return function () {
        typeof a == 'function' ? a() : t(null);
      };
    }
    if (t != null)
      return (
        (l = l()),
        (t.current = l),
        function () {
          t.current = null;
        }
      );
  }
  function Y0(l, t, a) {
    ((a = a != null ? a.concat([l]) : null), ju(4, 4, B0.bind(null, t, l), a));
  }
  function Qc() {}
  function j0(l, t) {
    var a = ul();
    t = t === void 0 ? null : t;
    var u = a.memoizedState;
    return t !== null && Nc(t, u[1]) ? u[0] : ((a.memoizedState = [l, t]), l);
  }
  function G0(l, t) {
    var a = ul();
    t = t === void 0 ? null : t;
    var u = a.memoizedState;
    if (t !== null && Nc(t, u[1])) return u[0];
    if (((u = l()), oa)) {
      Ht(!0);
      try {
        l();
      } finally {
        Ht(!1);
      }
    }
    return ((a.memoizedState = [u, t]), u);
  }
  function Zc(l, t, a) {
    return a === void 0 || (jt & 1073741824) !== 0
      ? (l.memoizedState = t)
      : ((l.memoizedState = a), (l = Zs()), (N.lanes |= l), (Kt |= l), a);
  }
  function X0(l, t, a, u) {
    return Nl(a, t)
      ? a
      : Ca.current !== null
        ? ((l = Zc(l, a, u)), Nl(l, t) || (sl = !0), l)
        : (jt & 42) === 0
          ? ((sl = !0), (l.memoizedState = a))
          : ((l = Zs()), (N.lanes |= l), (Kt |= l), t);
  }
  function Q0(l, t, a, u, e) {
    var n = A.p;
    A.p = n !== 0 && 8 > n ? n : 8;
    var c = S.T,
      f = {};
    ((S.T = f), Kc(l, !1, t, a));
    try {
      var i = e(),
        v = S.S;
      if (
        (v !== null && v(f, i),
        i !== null && typeof i == 'object' && typeof i.then == 'function')
      ) {
        var g = u1(i, u);
        Gu(l, t, g, pl(l));
      } else Gu(l, t, u, pl(l));
    } catch (r) {
      Gu(l, t, { then: function () {}, status: 'rejected', reason: r }, pl());
    } finally {
      ((A.p = n), (S.T = c));
    }
  }
  function i1() {}
  function Vc(l, t, a, u) {
    if (l.tag !== 5) throw Error(o(476));
    var e = Z0(l).queue;
    Q0(
      l,
      e,
      t,
      U,
      a === null
        ? i1
        : function () {
            return (V0(l), a(u));
          },
    );
  }
  function Z0(l) {
    var t = l.memoizedState;
    if (t !== null) return t;
    t = {
      memoizedState: U,
      baseState: U,
      baseQueue: null,
      queue: {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: rt,
        lastRenderedState: U,
      },
      next: null,
    };
    var a = {};
    return (
      (t.next = {
        memoizedState: a,
        baseState: a,
        baseQueue: null,
        queue: {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: rt,
          lastRenderedState: a,
        },
        next: null,
      }),
      (l.memoizedState = t),
      (l = l.alternate),
      l !== null && (l.memoizedState = t),
      t
    );
  }
  function V0(l) {
    var t = Z0(l).next.queue;
    Gu(l, t, {}, pl());
  }
  function Cc() {
    return Sl(ae);
  }
  function C0() {
    return ul().memoizedState;
  }
  function K0() {
    return ul().memoizedState;
  }
  function s1(l) {
    for (var t = l.return; t !== null; ) {
      switch (t.tag) {
        case 24:
        case 3:
          var a = pl();
          l = Bt(a);
          var u = Yt(t, l, a);
          (u !== null && (Bl(u, t, a), Ru(u, t, a)),
            (t = { cache: rc() }),
            (l.payload = t));
          return;
      }
      t = t.return;
    }
  }
  function d1(l, t, a) {
    var u = pl();
    ((a = {
      lane: u,
      revertLane: 0,
      action: a,
      hasEagerState: !1,
      eagerState: null,
      next: null,
    }),
      We(l)
        ? J0(t, a)
        : ((a = sc(l, t, a, u)), a !== null && (Bl(a, l, u), w0(a, t, u))));
  }
  function L0(l, t, a) {
    var u = pl();
    Gu(l, t, a, u);
  }
  function Gu(l, t, a, u) {
    var e = {
      lane: u,
      revertLane: 0,
      action: a,
      hasEagerState: !1,
      eagerState: null,
      next: null,
    };
    if (We(l)) J0(t, e);
    else {
      var n = l.alternate;
      if (
        l.lanes === 0 &&
        (n === null || n.lanes === 0) &&
        ((n = t.lastRenderedReducer), n !== null)
      )
        try {
          var c = t.lastRenderedState,
            f = n(c, a);
          if (((e.hasEagerState = !0), (e.eagerState = f), Nl(f, c)))
            return (_e(l, t, e, 0), K === null && He(), !1);
        } catch {
        } finally {
        }
      if (((a = sc(l, t, e, u)), a !== null))
        return (Bl(a, l, u), w0(a, t, u), !0);
    }
    return !1;
  }
  function Kc(l, t, a, u) {
    if (
      ((u = {
        lane: 2,
        revertLane: Mf(),
        action: u,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      }),
      We(l))
    ) {
      if (t) throw Error(o(479));
    } else ((t = sc(l, a, u, 2)), t !== null && Bl(t, l, 2));
  }
  function We(l) {
    var t = l.alternate;
    return l === N || (t !== null && t === N);
  }
  function J0(l, t) {
    Ka = Ve = !0;
    var a = l.pending;
    (a === null ? (t.next = t) : ((t.next = a.next), (a.next = t)),
      (l.pending = t));
  }
  function w0(l, t, a) {
    if ((a & 4194048) !== 0) {
      var u = t.lanes;
      ((u &= l.pendingLanes), (a |= u), (t.lanes = a), ti(l, a));
    }
  }
  var ke = {
      readContext: Sl,
      use: Ke,
      useCallback: ll,
      useContext: ll,
      useEffect: ll,
      useImperativeHandle: ll,
      useLayoutEffect: ll,
      useInsertionEffect: ll,
      useMemo: ll,
      useReducer: ll,
      useRef: ll,
      useState: ll,
      useDebugValue: ll,
      useDeferredValue: ll,
      useTransition: ll,
      useSyncExternalStore: ll,
      useId: ll,
      useHostTransitionStatus: ll,
      useFormState: ll,
      useActionState: ll,
      useOptimistic: ll,
      useMemoCache: ll,
      useCacheRefresh: ll,
    },
    W0 = {
      readContext: Sl,
      use: Ke,
      useCallback: function (l, t) {
        return ((El().memoizedState = [l, t === void 0 ? null : t]), l);
      },
      useContext: Sl,
      useEffect: _0,
      useImperativeHandle: function (l, t, a) {
        ((a = a != null ? a.concat([l]) : null),
          we(4194308, 4, B0.bind(null, t, l), a));
      },
      useLayoutEffect: function (l, t) {
        return we(4194308, 4, l, t);
      },
      useInsertionEffect: function (l, t) {
        we(4, 2, l, t);
      },
      useMemo: function (l, t) {
        var a = El();
        t = t === void 0 ? null : t;
        var u = l();
        if (oa) {
          Ht(!0);
          try {
            l();
          } finally {
            Ht(!1);
          }
        }
        return ((a.memoizedState = [u, t]), u);
      },
      useReducer: function (l, t, a) {
        var u = El();
        if (a !== void 0) {
          var e = a(t);
          if (oa) {
            Ht(!0);
            try {
              a(t);
            } finally {
              Ht(!1);
            }
          }
        } else e = t;
        return (
          (u.memoizedState = u.baseState = e),
          (l = {
            pending: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: l,
            lastRenderedState: e,
          }),
          (u.queue = l),
          (l = l.dispatch = d1.bind(null, N, l)),
          [u.memoizedState, l]
        );
      },
      useRef: function (l) {
        var t = El();
        return ((l = { current: l }), (t.memoizedState = l));
      },
      useState: function (l) {
        l = Gc(l);
        var t = l.queue,
          a = L0.bind(null, N, t);
        return ((t.dispatch = a), [l.memoizedState, a]);
      },
      useDebugValue: Qc,
      useDeferredValue: function (l, t) {
        var a = El();
        return Zc(a, l, t);
      },
      useTransition: function () {
        var l = Gc(!1);
        return (
          (l = Q0.bind(null, N, l.queue, !0, !1)),
          (El().memoizedState = l),
          [!1, l]
        );
      },
      useSyncExternalStore: function (l, t, a) {
        var u = N,
          e = El();
        if (B) {
          if (a === void 0) throw Error(o(407));
          a = a();
        } else {
          if (((a = t()), K === null)) throw Error(o(349));
          (q & 124) !== 0 || o0(u, t, a);
        }
        e.memoizedState = a;
        var n = { value: a, getSnapshot: t };
        return (
          (e.queue = n),
          _0(b0.bind(null, u, n, l), [l]),
          (u.flags |= 2048),
          Ja(9, Je(), g0.bind(null, u, n, a, t), null),
          a
        );
      },
      useId: function () {
        var l = El(),
          t = K.identifierPrefix;
        if (B) {
          var a = gt,
            u = ot;
          ((a = (u & ~(1 << (32 - Ul(u) - 1))).toString(32) + a),
            (t = '«' + t + 'R' + a),
            (a = Ce++),
            0 < a && (t += 'H' + a.toString(32)),
            (t += '»'));
        } else ((a = e1++), (t = '«' + t + 'r' + a.toString(32) + '»'));
        return (l.memoizedState = t);
      },
      useHostTransitionStatus: Cc,
      useFormState: O0,
      useActionState: O0,
      useOptimistic: function (l) {
        var t = El();
        t.memoizedState = t.baseState = l;
        var a = {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: null,
          lastRenderedState: null,
        };
        return (
          (t.queue = a),
          (t = Kc.bind(null, N, !0, a)),
          (a.dispatch = t),
          [l, t]
        );
      },
      useMemoCache: Bc,
      useCacheRefresh: function () {
        return (El().memoizedState = s1.bind(null, N));
      },
    },
    k0 = {
      readContext: Sl,
      use: Ke,
      useCallback: j0,
      useContext: Sl,
      useEffect: R0,
      useImperativeHandle: Y0,
      useInsertionEffect: q0,
      useLayoutEffect: p0,
      useMemo: G0,
      useReducer: Le,
      useRef: H0,
      useState: function () {
        return Le(rt);
      },
      useDebugValue: Qc,
      useDeferredValue: function (l, t) {
        var a = ul();
        return X0(a, X.memoizedState, l, t);
      },
      useTransition: function () {
        var l = Le(rt)[0],
          t = ul().memoizedState;
        return [typeof l == 'boolean' ? l : Yu(l), t];
      },
      useSyncExternalStore: m0,
      useId: C0,
      useHostTransitionStatus: Cc,
      useFormState: x0,
      useActionState: x0,
      useOptimistic: function (l, t) {
        var a = ul();
        return z0(a, X, l, t);
      },
      useMemoCache: Bc,
      useCacheRefresh: K0,
    },
    h1 = {
      readContext: Sl,
      use: Ke,
      useCallback: j0,
      useContext: Sl,
      useEffect: R0,
      useImperativeHandle: Y0,
      useInsertionEffect: q0,
      useLayoutEffect: p0,
      useMemo: G0,
      useReducer: jc,
      useRef: H0,
      useState: function () {
        return jc(rt);
      },
      useDebugValue: Qc,
      useDeferredValue: function (l, t) {
        var a = ul();
        return X === null ? Zc(a, l, t) : X0(a, X.memoizedState, l, t);
      },
      useTransition: function () {
        var l = jc(rt)[0],
          t = ul().memoizedState;
        return [typeof l == 'boolean' ? l : Yu(l), t];
      },
      useSyncExternalStore: m0,
      useId: C0,
      useHostTransitionStatus: Cc,
      useFormState: N0,
      useActionState: N0,
      useOptimistic: function (l, t) {
        var a = ul();
        return X !== null
          ? z0(a, X, l, t)
          : ((a.baseState = l), [l, a.queue.dispatch]);
      },
      useMemoCache: Bc,
      useCacheRefresh: K0,
    },
    wa = null,
    Xu = 0;
  function $e(l) {
    var t = Xu;
    return ((Xu += 1), wa === null && (wa = []), c0(wa, l, t));
  }
  function Qu(l, t) {
    ((t = t.props.ref), (l.ref = t !== void 0 ? t : null));
  }
  function Fe(l, t) {
    throw t.$$typeof === Al
      ? Error(o(525))
      : ((l = Object.prototype.toString.call(t)),
        Error(
          o(
            31,
            l === '[object Object]'
              ? 'object with keys {' + Object.keys(t).join(', ') + '}'
              : l,
          ),
        ));
  }
  function $0(l) {
    var t = l._init;
    return t(l._payload);
  }
  function F0(l) {
    function t(d, s) {
      if (l) {
        var h = d.deletions;
        h === null ? ((d.deletions = [s]), (d.flags |= 16)) : h.push(s);
      }
    }
    function a(d, s) {
      if (!l) return null;
      for (; s !== null; ) (t(d, s), (s = s.sibling));
      return null;
    }
    function u(d) {
      for (var s = new Map(); d !== null; )
        (d.key !== null ? s.set(d.key, d) : s.set(d.index, d), (d = d.sibling));
      return s;
    }
    function e(d, s) {
      return ((d = mt(d, s)), (d.index = 0), (d.sibling = null), d);
    }
    function n(d, s, h) {
      return (
        (d.index = h),
        l
          ? ((h = d.alternate),
            h !== null
              ? ((h = h.index), h < s ? ((d.flags |= 67108866), s) : h)
              : ((d.flags |= 67108866), s))
          : ((d.flags |= 1048576), s)
      );
    }
    function c(d) {
      return (l && d.alternate === null && (d.flags |= 67108866), d);
    }
    function f(d, s, h, b) {
      return s === null || s.tag !== 6
        ? ((s = hc(h, d.mode, b)), (s.return = d), s)
        : ((s = e(s, h)), (s.return = d), s);
    }
    function i(d, s, h, b) {
      var T = h.type;
      return T === Yl
        ? g(d, s, h.props.children, b, h.key)
        : s !== null &&
            (s.elementType === T ||
              (typeof T == 'object' &&
                T !== null &&
                T.$$typeof === $l &&
                $0(T) === s.type))
          ? ((s = e(s, h.props)), Qu(s, h), (s.return = d), s)
          : ((s = qe(h.type, h.key, h.props, null, d.mode, b)),
            Qu(s, h),
            (s.return = d),
            s);
    }
    function v(d, s, h, b) {
      return s === null ||
        s.tag !== 4 ||
        s.stateNode.containerInfo !== h.containerInfo ||
        s.stateNode.implementation !== h.implementation
        ? ((s = vc(h, d.mode, b)), (s.return = d), s)
        : ((s = e(s, h.children || [])), (s.return = d), s);
    }
    function g(d, s, h, b, T) {
      return s === null || s.tag !== 7
        ? ((s = fa(h, d.mode, b, T)), (s.return = d), s)
        : ((s = e(s, h)), (s.return = d), s);
    }
    function r(d, s, h) {
      if (
        (typeof s == 'string' && s !== '') ||
        typeof s == 'number' ||
        typeof s == 'bigint'
      )
        return ((s = hc('' + s, d.mode, h)), (s.return = d), s);
      if (typeof s == 'object' && s !== null) {
        switch (s.$$typeof) {
          case P:
            return (
              (h = qe(s.type, s.key, s.props, null, d.mode, h)),
              Qu(h, s),
              (h.return = d),
              h
            );
          case st:
            return ((s = vc(s, d.mode, h)), (s.return = d), s);
          case $l:
            var b = s._init;
            return ((s = b(s._payload)), r(d, s, h));
        }
        if (ht(s) || Gl(s))
          return ((s = fa(s, d.mode, h, null)), (s.return = d), s);
        if (typeof s.then == 'function') return r(d, $e(s), h);
        if (s.$$typeof === jl) return r(d, je(d, s), h);
        Fe(d, s);
      }
      return null;
    }
    function y(d, s, h, b) {
      var T = s !== null ? s.key : null;
      if (
        (typeof h == 'string' && h !== '') ||
        typeof h == 'number' ||
        typeof h == 'bigint'
      )
        return T !== null ? null : f(d, s, '' + h, b);
      if (typeof h == 'object' && h !== null) {
        switch (h.$$typeof) {
          case P:
            return h.key === T ? i(d, s, h, b) : null;
          case st:
            return h.key === T ? v(d, s, h, b) : null;
          case $l:
            return ((T = h._init), (h = T(h._payload)), y(d, s, h, b));
        }
        if (ht(h) || Gl(h)) return T !== null ? null : g(d, s, h, b, null);
        if (typeof h.then == 'function') return y(d, s, $e(h), b);
        if (h.$$typeof === jl) return y(d, s, je(d, h), b);
        Fe(d, h);
      }
      return null;
    }
    function m(d, s, h, b, T) {
      if (
        (typeof b == 'string' && b !== '') ||
        typeof b == 'number' ||
        typeof b == 'bigint'
      )
        return ((d = d.get(h) || null), f(s, d, '' + b, T));
      if (typeof b == 'object' && b !== null) {
        switch (b.$$typeof) {
          case P:
            return (
              (d = d.get(b.key === null ? h : b.key) || null),
              i(s, d, b, T)
            );
          case st:
            return (
              (d = d.get(b.key === null ? h : b.key) || null),
              v(s, d, b, T)
            );
          case $l:
            var H = b._init;
            return ((b = H(b._payload)), m(d, s, h, b, T));
        }
        if (ht(b) || Gl(b))
          return ((d = d.get(h) || null), g(s, d, b, T, null));
        if (typeof b.then == 'function') return m(d, s, h, $e(b), T);
        if (b.$$typeof === jl) return m(d, s, h, je(s, b), T);
        Fe(s, b);
      }
      return null;
    }
    function x(d, s, h, b) {
      for (
        var T = null, H = null, M = s, O = (s = 0), hl = null;
        M !== null && O < h.length;
        O++
      ) {
        M.index > O ? ((hl = M), (M = null)) : (hl = M.sibling);
        var p = y(d, M, h[O], b);
        if (p === null) {
          M === null && (M = hl);
          break;
        }
        (l && M && p.alternate === null && t(d, M),
          (s = n(p, s, O)),
          H === null ? (T = p) : (H.sibling = p),
          (H = p),
          (M = hl));
      }
      if (O === h.length) return (a(d, M), B && sa(d, O), T);
      if (M === null) {
        for (; O < h.length; O++)
          ((M = r(d, h[O], b)),
            M !== null &&
              ((s = n(M, s, O)),
              H === null ? (T = M) : (H.sibling = M),
              (H = M)));
        return (B && sa(d, O), T);
      }
      for (M = u(M); O < h.length; O++)
        ((hl = m(M, d, O, h[O], b)),
          hl !== null &&
            (l &&
              hl.alternate !== null &&
              M.delete(hl.key === null ? O : hl.key),
            (s = n(hl, s, O)),
            H === null ? (T = hl) : (H.sibling = hl),
            (H = hl)));
      return (
        l &&
          M.forEach(function (Pt) {
            return t(d, Pt);
          }),
        B && sa(d, O),
        T
      );
    }
    function D(d, s, h, b) {
      if (h == null) throw Error(o(151));
      for (
        var T = null, H = null, M = s, O = (s = 0), hl = null, p = h.next();
        M !== null && !p.done;
        O++, p = h.next()
      ) {
        M.index > O ? ((hl = M), (M = null)) : (hl = M.sibling);
        var Pt = y(d, M, p.value, b);
        if (Pt === null) {
          M === null && (M = hl);
          break;
        }
        (l && M && Pt.alternate === null && t(d, M),
          (s = n(Pt, s, O)),
          H === null ? (T = Pt) : (H.sibling = Pt),
          (H = Pt),
          (M = hl));
      }
      if (p.done) return (a(d, M), B && sa(d, O), T);
      if (M === null) {
        for (; !p.done; O++, p = h.next())
          ((p = r(d, p.value, b)),
            p !== null &&
              ((s = n(p, s, O)),
              H === null ? (T = p) : (H.sibling = p),
              (H = p)));
        return (B && sa(d, O), T);
      }
      for (M = u(M); !p.done; O++, p = h.next())
        ((p = m(M, d, O, p.value, b)),
          p !== null &&
            (l && p.alternate !== null && M.delete(p.key === null ? O : p.key),
            (s = n(p, s, O)),
            H === null ? (T = p) : (H.sibling = p),
            (H = p)));
      return (
        l &&
          M.forEach(function (vv) {
            return t(d, vv);
          }),
        B && sa(d, O),
        T
      );
    }
    function Z(d, s, h, b) {
      if (
        (typeof h == 'object' &&
          h !== null &&
          h.type === Yl &&
          h.key === null &&
          (h = h.props.children),
        typeof h == 'object' && h !== null)
      ) {
        switch (h.$$typeof) {
          case P:
            l: {
              for (var T = h.key; s !== null; ) {
                if (s.key === T) {
                  if (((T = h.type), T === Yl)) {
                    if (s.tag === 7) {
                      (a(d, s.sibling),
                        (b = e(s, h.props.children)),
                        (b.return = d),
                        (d = b));
                      break l;
                    }
                  } else if (
                    s.elementType === T ||
                    (typeof T == 'object' &&
                      T !== null &&
                      T.$$typeof === $l &&
                      $0(T) === s.type)
                  ) {
                    (a(d, s.sibling),
                      (b = e(s, h.props)),
                      Qu(b, h),
                      (b.return = d),
                      (d = b));
                    break l;
                  }
                  a(d, s);
                  break;
                } else t(d, s);
                s = s.sibling;
              }
              h.type === Yl
                ? ((b = fa(h.props.children, d.mode, b, h.key)),
                  (b.return = d),
                  (d = b))
                : ((b = qe(h.type, h.key, h.props, null, d.mode, b)),
                  Qu(b, h),
                  (b.return = d),
                  (d = b));
            }
            return c(d);
          case st:
            l: {
              for (T = h.key; s !== null; ) {
                if (s.key === T)
                  if (
                    s.tag === 4 &&
                    s.stateNode.containerInfo === h.containerInfo &&
                    s.stateNode.implementation === h.implementation
                  ) {
                    (a(d, s.sibling),
                      (b = e(s, h.children || [])),
                      (b.return = d),
                      (d = b));
                    break l;
                  } else {
                    a(d, s);
                    break;
                  }
                else t(d, s);
                s = s.sibling;
              }
              ((b = vc(h, d.mode, b)), (b.return = d), (d = b));
            }
            return c(d);
          case $l:
            return ((T = h._init), (h = T(h._payload)), Z(d, s, h, b));
        }
        if (ht(h)) return x(d, s, h, b);
        if (Gl(h)) {
          if (((T = Gl(h)), typeof T != 'function')) throw Error(o(150));
          return ((h = T.call(h)), D(d, s, h, b));
        }
        if (typeof h.then == 'function') return Z(d, s, $e(h), b);
        if (h.$$typeof === jl) return Z(d, s, je(d, h), b);
        Fe(d, h);
      }
      return (typeof h == 'string' && h !== '') ||
        typeof h == 'number' ||
        typeof h == 'bigint'
        ? ((h = '' + h),
          s !== null && s.tag === 6
            ? (a(d, s.sibling), (b = e(s, h)), (b.return = d), (d = b))
            : (a(d, s), (b = hc(h, d.mode, b)), (b.return = d), (d = b)),
          c(d))
        : a(d, s);
    }
    return function (d, s, h, b) {
      try {
        Xu = 0;
        var T = Z(d, s, h, b);
        return ((wa = null), T);
      } catch (M) {
        if (M === Hu || M === Xe) throw M;
        var H = Hl(29, M, null, d.mode);
        return ((H.lanes = b), (H.return = d), H);
      } finally {
      }
    };
  }
  var Wa = F0(!0),
    I0 = F0(!1),
    Ll = rl(null),
    et = null;
  function Gt(l) {
    var t = l.alternate;
    (G(cl, cl.current & 1),
      G(Ll, l),
      et === null &&
        (t === null || Ca.current !== null || t.memoizedState !== null) &&
        (et = l));
  }
  function P0(l) {
    if (l.tag === 22) {
      if ((G(cl, cl.current), G(Ll, l), et === null)) {
        var t = l.alternate;
        t !== null && t.memoizedState !== null && (et = l);
      }
    } else Xt();
  }
  function Xt() {
    (G(cl, cl.current), G(Ll, Ll.current));
  }
  function zt(l) {
    (k(Ll), et === l && (et = null), k(cl));
  }
  var cl = rl(0);
  function Ie(l) {
    for (var t = l; t !== null; ) {
      if (t.tag === 13) {
        var a = t.memoizedState;
        if (
          a !== null &&
          ((a = a.dehydrated), a === null || a.data === '$?' || Bf(a))
        )
          return t;
      } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
        if ((t.flags & 128) !== 0) return t;
      } else if (t.child !== null) {
        ((t.child.return = t), (t = t.child));
        continue;
      }
      if (t === l) break;
      for (; t.sibling === null; ) {
        if (t.return === null || t.return === l) return null;
        t = t.return;
      }
      ((t.sibling.return = t.return), (t = t.sibling));
    }
    return null;
  }
  function Lc(l, t, a, u) {
    ((t = l.memoizedState),
      (a = a(u, t)),
      (a = a == null ? t : V({}, t, a)),
      (l.memoizedState = a),
      l.lanes === 0 && (l.updateQueue.baseState = a));
  }
  var Jc = {
    enqueueSetState: function (l, t, a) {
      l = l._reactInternals;
      var u = pl(),
        e = Bt(u);
      ((e.payload = t),
        a != null && (e.callback = a),
        (t = Yt(l, e, u)),
        t !== null && (Bl(t, l, u), Ru(t, l, u)));
    },
    enqueueReplaceState: function (l, t, a) {
      l = l._reactInternals;
      var u = pl(),
        e = Bt(u);
      ((e.tag = 1),
        (e.payload = t),
        a != null && (e.callback = a),
        (t = Yt(l, e, u)),
        t !== null && (Bl(t, l, u), Ru(t, l, u)));
    },
    enqueueForceUpdate: function (l, t) {
      l = l._reactInternals;
      var a = pl(),
        u = Bt(a);
      ((u.tag = 2),
        t != null && (u.callback = t),
        (t = Yt(l, u, a)),
        t !== null && (Bl(t, l, a), Ru(t, l, a)));
    },
  };
  function ls(l, t, a, u, e, n, c) {
    return (
      (l = l.stateNode),
      typeof l.shouldComponentUpdate == 'function'
        ? l.shouldComponentUpdate(u, n, c)
        : t.prototype && t.prototype.isPureReactComponent
          ? !Tu(a, u) || !Tu(e, n)
          : !0
    );
  }
  function ts(l, t, a, u) {
    ((l = t.state),
      typeof t.componentWillReceiveProps == 'function' &&
        t.componentWillReceiveProps(a, u),
      typeof t.UNSAFE_componentWillReceiveProps == 'function' &&
        t.UNSAFE_componentWillReceiveProps(a, u),
      t.state !== l && Jc.enqueueReplaceState(t, t.state, null));
  }
  function ga(l, t) {
    var a = t;
    if ('ref' in t) {
      a = {};
      for (var u in t) u !== 'ref' && (a[u] = t[u]);
    }
    if ((l = l.defaultProps)) {
      a === t && (a = V({}, a));
      for (var e in l) a[e] === void 0 && (a[e] = l[e]);
    }
    return a;
  }
  var Pe =
    typeof reportError == 'function'
      ? reportError
      : function (l) {
          if (
            typeof window == 'object' &&
            typeof window.ErrorEvent == 'function'
          ) {
            var t = new window.ErrorEvent('error', {
              bubbles: !0,
              cancelable: !0,
              message:
                typeof l == 'object' &&
                l !== null &&
                typeof l.message == 'string'
                  ? String(l.message)
                  : String(l),
              error: l,
            });
            if (!window.dispatchEvent(t)) return;
          } else if (
            typeof process == 'object' &&
            typeof process.emit == 'function'
          ) {
            process.emit('uncaughtException', l);
            return;
          }
          console.error(l);
        };
  function as(l) {
    Pe(l);
  }
  function us(l) {
    console.error(l);
  }
  function es(l) {
    Pe(l);
  }
  function ln(l, t) {
    try {
      var a = l.onUncaughtError;
      a(t.value, { componentStack: t.stack });
    } catch (u) {
      setTimeout(function () {
        throw u;
      });
    }
  }
  function ns(l, t, a) {
    try {
      var u = l.onCaughtError;
      u(a.value, {
        componentStack: a.stack,
        errorBoundary: t.tag === 1 ? t.stateNode : null,
      });
    } catch (e) {
      setTimeout(function () {
        throw e;
      });
    }
  }
  function wc(l, t, a) {
    return (
      (a = Bt(a)),
      (a.tag = 3),
      (a.payload = { element: null }),
      (a.callback = function () {
        ln(l, t);
      }),
      a
    );
  }
  function cs(l) {
    return ((l = Bt(l)), (l.tag = 3), l);
  }
  function fs(l, t, a, u) {
    var e = a.type.getDerivedStateFromError;
    if (typeof e == 'function') {
      var n = u.value;
      ((l.payload = function () {
        return e(n);
      }),
        (l.callback = function () {
          ns(t, a, u);
        }));
    }
    var c = a.stateNode;
    c !== null &&
      typeof c.componentDidCatch == 'function' &&
      (l.callback = function () {
        (ns(t, a, u),
          typeof e != 'function' &&
            (Lt === null ? (Lt = new Set([this])) : Lt.add(this)));
        var f = u.stack;
        this.componentDidCatch(u.value, {
          componentStack: f !== null ? f : '',
        });
      });
  }
  function v1(l, t, a, u, e) {
    if (
      ((a.flags |= 32768),
      u !== null && typeof u == 'object' && typeof u.then == 'function')
    ) {
      if (
        ((t = a.alternate),
        t !== null && xu(t, a, e, !0),
        (a = Ll.current),
        a !== null)
      ) {
        switch (a.tag) {
          case 13:
            return (
              et === null ? Sf() : a.alternate === null && I === 0 && (I = 3),
              (a.flags &= -257),
              (a.flags |= 65536),
              (a.lanes = e),
              u === Tc
                ? (a.flags |= 16384)
                : ((t = a.updateQueue),
                  t === null ? (a.updateQueue = new Set([u])) : t.add(u),
                  zf(l, u, e)),
              !1
            );
          case 22:
            return (
              (a.flags |= 65536),
              u === Tc
                ? (a.flags |= 16384)
                : ((t = a.updateQueue),
                  t === null
                    ? ((t = {
                        transitions: null,
                        markerInstances: null,
                        retryQueue: new Set([u]),
                      }),
                      (a.updateQueue = t))
                    : ((a = t.retryQueue),
                      a === null ? (t.retryQueue = new Set([u])) : a.add(u)),
                  zf(l, u, e)),
              !1
            );
        }
        throw Error(o(435, a.tag));
      }
      return (zf(l, u, e), Sf(), !1);
    }
    if (B)
      return (
        (t = Ll.current),
        t !== null
          ? ((t.flags & 65536) === 0 && (t.flags |= 256),
            (t.flags |= 65536),
            (t.lanes = e),
            u !== oc && ((l = Error(o(422), { cause: u })), Ou(Zl(l, a))))
          : (u !== oc && ((t = Error(o(423), { cause: u })), Ou(Zl(t, a))),
            (l = l.current.alternate),
            (l.flags |= 65536),
            (e &= -e),
            (l.lanes |= e),
            (u = Zl(u, a)),
            (e = wc(l.stateNode, u, e)),
            Dc(l, e),
            I !== 4 && (I = 2)),
        !1
      );
    var n = Error(o(520), { cause: u });
    if (
      ((n = Zl(n, a)),
      wu === null ? (wu = [n]) : wu.push(n),
      I !== 4 && (I = 2),
      t === null)
    )
      return !0;
    ((u = Zl(u, a)), (a = t));
    do {
      switch (a.tag) {
        case 3:
          return (
            (a.flags |= 65536),
            (l = e & -e),
            (a.lanes |= l),
            (l = wc(a.stateNode, u, l)),
            Dc(a, l),
            !1
          );
        case 1:
          if (
            ((t = a.type),
            (n = a.stateNode),
            (a.flags & 128) === 0 &&
              (typeof t.getDerivedStateFromError == 'function' ||
                (n !== null &&
                  typeof n.componentDidCatch == 'function' &&
                  (Lt === null || !Lt.has(n)))))
          )
            return (
              (a.flags |= 65536),
              (e &= -e),
              (a.lanes |= e),
              (e = cs(e)),
              fs(e, l, a, u),
              Dc(a, e),
              !1
            );
      }
      a = a.return;
    } while (a !== null);
    return !1;
  }
  var is = Error(o(461)),
    sl = !1;
  function yl(l, t, a, u) {
    t.child = l === null ? I0(t, null, a, u) : Wa(t, l.child, a, u);
  }
  function ss(l, t, a, u, e) {
    a = a.render;
    var n = t.ref;
    if ('ref' in u) {
      var c = {};
      for (var f in u) f !== 'ref' && (c[f] = u[f]);
    } else c = u;
    return (
      ya(t),
      (u = Hc(l, t, a, c, n, e)),
      (f = _c()),
      l !== null && !sl
        ? (Rc(l, t, e), At(l, t, e))
        : (B && f && yc(t), (t.flags |= 1), yl(l, t, u, e), t.child)
    );
  }
  function ds(l, t, a, u, e) {
    if (l === null) {
      var n = a.type;
      return typeof n == 'function' &&
        !dc(n) &&
        n.defaultProps === void 0 &&
        a.compare === null
        ? ((t.tag = 15), (t.type = n), hs(l, t, n, u, e))
        : ((l = qe(a.type, null, u, t, t.mode, e)),
          (l.ref = t.ref),
          (l.return = t),
          (t.child = l));
    }
    if (((n = l.child), !tf(l, e))) {
      var c = n.memoizedProps;
      if (
        ((a = a.compare), (a = a !== null ? a : Tu), a(c, u) && l.ref === t.ref)
      )
        return At(l, t, e);
    }
    return (
      (t.flags |= 1),
      (l = mt(n, u)),
      (l.ref = t.ref),
      (l.return = t),
      (t.child = l)
    );
  }
  function hs(l, t, a, u, e) {
    if (l !== null) {
      var n = l.memoizedProps;
      if (Tu(n, u) && l.ref === t.ref)
        if (((sl = !1), (t.pendingProps = u = n), tf(l, e)))
          (l.flags & 131072) !== 0 && (sl = !0);
        else return ((t.lanes = l.lanes), At(l, t, e));
    }
    return Wc(l, t, a, u, e);
  }
  function vs(l, t, a) {
    var u = t.pendingProps,
      e = u.children,
      n = l !== null ? l.memoizedState : null;
    if (u.mode === 'hidden') {
      if ((t.flags & 128) !== 0) {
        if (((u = n !== null ? n.baseLanes | a : a), l !== null)) {
          for (e = t.child = l.child, n = 0; e !== null; )
            ((n = n | e.lanes | e.childLanes), (e = e.sibling));
          t.childLanes = n & ~u;
        } else ((t.childLanes = 0), (t.child = null));
        return ys(l, t, u, a);
      }
      if ((a & 536870912) !== 0)
        ((t.memoizedState = { baseLanes: 0, cachePool: null }),
          l !== null && Ge(t, n !== null ? n.cachePool : null),
          n !== null ? h0(t, n) : xc(),
          P0(t));
      else
        return (
          (t.lanes = t.childLanes = 536870912),
          ys(l, t, n !== null ? n.baseLanes | a : a, a)
        );
    } else
      n !== null
        ? (Ge(t, n.cachePool), h0(t, n), Xt(), (t.memoizedState = null))
        : (l !== null && Ge(t, null), xc(), Xt());
    return (yl(l, t, e, a), t.child);
  }
  function ys(l, t, a, u) {
    var e = Ac();
    return (
      (e = e === null ? null : { parent: nl._currentValue, pool: e }),
      (t.memoizedState = { baseLanes: a, cachePool: e }),
      l !== null && Ge(t, null),
      xc(),
      P0(t),
      l !== null && xu(l, t, u, !0),
      null
    );
  }
  function tn(l, t) {
    var a = t.ref;
    if (a === null) l !== null && l.ref !== null && (t.flags |= 4194816);
    else {
      if (typeof a != 'function' && typeof a != 'object') throw Error(o(284));
      (l === null || l.ref !== a) && (t.flags |= 4194816);
    }
  }
  function Wc(l, t, a, u, e) {
    return (
      ya(t),
      (a = Hc(l, t, a, u, void 0, e)),
      (u = _c()),
      l !== null && !sl
        ? (Rc(l, t, e), At(l, t, e))
        : (B && u && yc(t), (t.flags |= 1), yl(l, t, a, e), t.child)
    );
  }
  function ms(l, t, a, u, e, n) {
    return (
      ya(t),
      (t.updateQueue = null),
      (a = y0(t, u, a, e)),
      v0(l),
      (u = _c()),
      l !== null && !sl
        ? (Rc(l, t, n), At(l, t, n))
        : (B && u && yc(t), (t.flags |= 1), yl(l, t, a, n), t.child)
    );
  }
  function os(l, t, a, u, e) {
    if ((ya(t), t.stateNode === null)) {
      var n = Ga,
        c = a.contextType;
      (typeof c == 'object' && c !== null && (n = Sl(c)),
        (n = new a(u, n)),
        (t.memoizedState =
          n.state !== null && n.state !== void 0 ? n.state : null),
        (n.updater = Jc),
        (t.stateNode = n),
        (n._reactInternals = t),
        (n = t.stateNode),
        (n.props = u),
        (n.state = t.memoizedState),
        (n.refs = {}),
        Mc(t),
        (c = a.contextType),
        (n.context = typeof c == 'object' && c !== null ? Sl(c) : Ga),
        (n.state = t.memoizedState),
        (c = a.getDerivedStateFromProps),
        typeof c == 'function' && (Lc(t, a, c, u), (n.state = t.memoizedState)),
        typeof a.getDerivedStateFromProps == 'function' ||
          typeof n.getSnapshotBeforeUpdate == 'function' ||
          (typeof n.UNSAFE_componentWillMount != 'function' &&
            typeof n.componentWillMount != 'function') ||
          ((c = n.state),
          typeof n.componentWillMount == 'function' && n.componentWillMount(),
          typeof n.UNSAFE_componentWillMount == 'function' &&
            n.UNSAFE_componentWillMount(),
          c !== n.state && Jc.enqueueReplaceState(n, n.state, null),
          pu(t, u, n, e),
          qu(),
          (n.state = t.memoizedState)),
        typeof n.componentDidMount == 'function' && (t.flags |= 4194308),
        (u = !0));
    } else if (l === null) {
      n = t.stateNode;
      var f = t.memoizedProps,
        i = ga(a, f);
      n.props = i;
      var v = n.context,
        g = a.contextType;
      ((c = Ga), typeof g == 'object' && g !== null && (c = Sl(g)));
      var r = a.getDerivedStateFromProps;
      ((g =
        typeof r == 'function' ||
        typeof n.getSnapshotBeforeUpdate == 'function'),
        (f = t.pendingProps !== f),
        g ||
          (typeof n.UNSAFE_componentWillReceiveProps != 'function' &&
            typeof n.componentWillReceiveProps != 'function') ||
          ((f || v !== c) && ts(t, n, u, c)),
        (pt = !1));
      var y = t.memoizedState;
      ((n.state = y),
        pu(t, u, n, e),
        qu(),
        (v = t.memoizedState),
        f || y !== v || pt
          ? (typeof r == 'function' && (Lc(t, a, r, u), (v = t.memoizedState)),
            (i = pt || ls(t, a, i, u, y, v, c))
              ? (g ||
                  (typeof n.UNSAFE_componentWillMount != 'function' &&
                    typeof n.componentWillMount != 'function') ||
                  (typeof n.componentWillMount == 'function' &&
                    n.componentWillMount(),
                  typeof n.UNSAFE_componentWillMount == 'function' &&
                    n.UNSAFE_componentWillMount()),
                typeof n.componentDidMount == 'function' &&
                  (t.flags |= 4194308))
              : (typeof n.componentDidMount == 'function' &&
                  (t.flags |= 4194308),
                (t.memoizedProps = u),
                (t.memoizedState = v)),
            (n.props = u),
            (n.state = v),
            (n.context = c),
            (u = i))
          : (typeof n.componentDidMount == 'function' && (t.flags |= 4194308),
            (u = !1)));
    } else {
      ((n = t.stateNode),
        Ec(l, t),
        (c = t.memoizedProps),
        (g = ga(a, c)),
        (n.props = g),
        (r = t.pendingProps),
        (y = n.context),
        (v = a.contextType),
        (i = Ga),
        typeof v == 'object' && v !== null && (i = Sl(v)),
        (f = a.getDerivedStateFromProps),
        (v =
          typeof f == 'function' ||
          typeof n.getSnapshotBeforeUpdate == 'function') ||
          (typeof n.UNSAFE_componentWillReceiveProps != 'function' &&
            typeof n.componentWillReceiveProps != 'function') ||
          ((c !== r || y !== i) && ts(t, n, u, i)),
        (pt = !1),
        (y = t.memoizedState),
        (n.state = y),
        pu(t, u, n, e),
        qu());
      var m = t.memoizedState;
      c !== r ||
      y !== m ||
      pt ||
      (l !== null && l.dependencies !== null && Ye(l.dependencies))
        ? (typeof f == 'function' && (Lc(t, a, f, u), (m = t.memoizedState)),
          (g =
            pt ||
            ls(t, a, g, u, y, m, i) ||
            (l !== null && l.dependencies !== null && Ye(l.dependencies)))
            ? (v ||
                (typeof n.UNSAFE_componentWillUpdate != 'function' &&
                  typeof n.componentWillUpdate != 'function') ||
                (typeof n.componentWillUpdate == 'function' &&
                  n.componentWillUpdate(u, m, i),
                typeof n.UNSAFE_componentWillUpdate == 'function' &&
                  n.UNSAFE_componentWillUpdate(u, m, i)),
              typeof n.componentDidUpdate == 'function' && (t.flags |= 4),
              typeof n.getSnapshotBeforeUpdate == 'function' &&
                (t.flags |= 1024))
            : (typeof n.componentDidUpdate != 'function' ||
                (c === l.memoizedProps && y === l.memoizedState) ||
                (t.flags |= 4),
              typeof n.getSnapshotBeforeUpdate != 'function' ||
                (c === l.memoizedProps && y === l.memoizedState) ||
                (t.flags |= 1024),
              (t.memoizedProps = u),
              (t.memoizedState = m)),
          (n.props = u),
          (n.state = m),
          (n.context = i),
          (u = g))
        : (typeof n.componentDidUpdate != 'function' ||
            (c === l.memoizedProps && y === l.memoizedState) ||
            (t.flags |= 4),
          typeof n.getSnapshotBeforeUpdate != 'function' ||
            (c === l.memoizedProps && y === l.memoizedState) ||
            (t.flags |= 1024),
          (u = !1));
    }
    return (
      (n = u),
      tn(l, t),
      (u = (t.flags & 128) !== 0),
      n || u
        ? ((n = t.stateNode),
          (a =
            u && typeof a.getDerivedStateFromError != 'function'
              ? null
              : n.render()),
          (t.flags |= 1),
          l !== null && u
            ? ((t.child = Wa(t, l.child, null, e)),
              (t.child = Wa(t, null, a, e)))
            : yl(l, t, a, e),
          (t.memoizedState = n.state),
          (l = t.child))
        : (l = At(l, t, e)),
      l
    );
  }
  function gs(l, t, a, u) {
    return (Du(), (t.flags |= 256), yl(l, t, a, u), t.child);
  }
  var kc = {
    dehydrated: null,
    treeContext: null,
    retryLane: 0,
    hydrationErrors: null,
  };
  function $c(l) {
    return { baseLanes: l, cachePool: u0() };
  }
  function Fc(l, t, a) {
    return ((l = l !== null ? l.childLanes & ~a : 0), t && (l |= Jl), l);
  }
  function bs(l, t, a) {
    var u = t.pendingProps,
      e = !1,
      n = (t.flags & 128) !== 0,
      c;
    if (
      ((c = n) ||
        (c =
          l !== null && l.memoizedState === null ? !1 : (cl.current & 2) !== 0),
      c && ((e = !0), (t.flags &= -129)),
      (c = (t.flags & 32) !== 0),
      (t.flags &= -33),
      l === null)
    ) {
      if (B) {
        if ((e ? Gt(t) : Xt(), B)) {
          var f = F,
            i;
          if ((i = f)) {
            l: {
              for (i = f, f = ut; i.nodeType !== 8; ) {
                if (!f) {
                  f = null;
                  break l;
                }
                if (((i = Pl(i.nextSibling)), i === null)) {
                  f = null;
                  break l;
                }
              }
              f = i;
            }
            f !== null
              ? ((t.memoizedState = {
                  dehydrated: f,
                  treeContext: ia !== null ? { id: ot, overflow: gt } : null,
                  retryLane: 536870912,
                  hydrationErrors: null,
                }),
                (i = Hl(18, null, null, 0)),
                (i.stateNode = f),
                (i.return = t),
                (t.child = i),
                (zl = t),
                (F = null),
                (i = !0))
              : (i = !1);
          }
          i || ha(t);
        }
        if (
          ((f = t.memoizedState),
          f !== null && ((f = f.dehydrated), f !== null))
        )
          return (Bf(f) ? (t.lanes = 32) : (t.lanes = 536870912), null);
        zt(t);
      }
      return (
        (f = u.children),
        (u = u.fallback),
        e
          ? (Xt(),
            (e = t.mode),
            (f = an({ mode: 'hidden', children: f }, e)),
            (u = fa(u, e, a, null)),
            (f.return = t),
            (u.return = t),
            (f.sibling = u),
            (t.child = f),
            (e = t.child),
            (e.memoizedState = $c(a)),
            (e.childLanes = Fc(l, c, a)),
            (t.memoizedState = kc),
            u)
          : (Gt(t), Ic(t, f))
      );
    }
    if (
      ((i = l.memoizedState), i !== null && ((f = i.dehydrated), f !== null))
    ) {
      if (n)
        t.flags & 256
          ? (Gt(t), (t.flags &= -257), (t = Pc(l, t, a)))
          : t.memoizedState !== null
            ? (Xt(), (t.child = l.child), (t.flags |= 128), (t = null))
            : (Xt(),
              (e = u.fallback),
              (f = t.mode),
              (u = an({ mode: 'visible', children: u.children }, f)),
              (e = fa(e, f, a, null)),
              (e.flags |= 2),
              (u.return = t),
              (e.return = t),
              (u.sibling = e),
              (t.child = u),
              Wa(t, l.child, null, a),
              (u = t.child),
              (u.memoizedState = $c(a)),
              (u.childLanes = Fc(l, c, a)),
              (t.memoizedState = kc),
              (t = e));
      else if ((Gt(t), Bf(f))) {
        if (((c = f.nextSibling && f.nextSibling.dataset), c)) var v = c.dgst;
        ((c = v),
          (u = Error(o(419))),
          (u.stack = ''),
          (u.digest = c),
          Ou({ value: u, source: null, stack: null }),
          (t = Pc(l, t, a)));
      } else if (
        (sl || xu(l, t, a, !1), (c = (a & l.childLanes) !== 0), sl || c)
      ) {
        if (
          ((c = K),
          c !== null &&
            ((u = a & -a),
            (u = (u & 42) !== 0 ? 1 : Bn(u)),
            (u = (u & (c.suspendedLanes | a)) !== 0 ? 0 : u),
            u !== 0 && u !== i.retryLane))
        )
          throw ((i.retryLane = u), ja(l, u), Bl(c, l, u), is);
        (f.data === '$?' || Sf(), (t = Pc(l, t, a)));
      } else
        f.data === '$?'
          ? ((t.flags |= 192), (t.child = l.child), (t = null))
          : ((l = i.treeContext),
            (F = Pl(f.nextSibling)),
            (zl = t),
            (B = !0),
            (da = null),
            (ut = !1),
            l !== null &&
              ((Cl[Kl++] = ot),
              (Cl[Kl++] = gt),
              (Cl[Kl++] = ia),
              (ot = l.id),
              (gt = l.overflow),
              (ia = t)),
            (t = Ic(t, u.children)),
            (t.flags |= 4096));
      return t;
    }
    return e
      ? (Xt(),
        (e = u.fallback),
        (f = t.mode),
        (i = l.child),
        (v = i.sibling),
        (u = mt(i, { mode: 'hidden', children: u.children })),
        (u.subtreeFlags = i.subtreeFlags & 65011712),
        v !== null ? (e = mt(v, e)) : ((e = fa(e, f, a, null)), (e.flags |= 2)),
        (e.return = t),
        (u.return = t),
        (u.sibling = e),
        (t.child = u),
        (u = e),
        (e = t.child),
        (f = l.child.memoizedState),
        f === null
          ? (f = $c(a))
          : ((i = f.cachePool),
            i !== null
              ? ((v = nl._currentValue),
                (i = i.parent !== v ? { parent: v, pool: v } : i))
              : (i = u0()),
            (f = { baseLanes: f.baseLanes | a, cachePool: i })),
        (e.memoizedState = f),
        (e.childLanes = Fc(l, c, a)),
        (t.memoizedState = kc),
        u)
      : (Gt(t),
        (a = l.child),
        (l = a.sibling),
        (a = mt(a, { mode: 'visible', children: u.children })),
        (a.return = t),
        (a.sibling = null),
        l !== null &&
          ((c = t.deletions),
          c === null ? ((t.deletions = [l]), (t.flags |= 16)) : c.push(l)),
        (t.child = a),
        (t.memoizedState = null),
        a);
  }
  function Ic(l, t) {
    return (
      (t = an({ mode: 'visible', children: t }, l.mode)),
      (t.return = l),
      (l.child = t)
    );
  }
  function an(l, t) {
    return (
      (l = Hl(22, l, null, t)),
      (l.lanes = 0),
      (l.stateNode = {
        _visibility: 1,
        _pendingMarkers: null,
        _retryCache: null,
        _transitions: null,
      }),
      l
    );
  }
  function Pc(l, t, a) {
    return (
      Wa(t, l.child, null, a),
      (l = Ic(t, t.pendingProps.children)),
      (l.flags |= 2),
      (t.memoizedState = null),
      l
    );
  }
  function Ss(l, t, a) {
    l.lanes |= t;
    var u = l.alternate;
    (u !== null && (u.lanes |= t), bc(l.return, t, a));
  }
  function lf(l, t, a, u, e) {
    var n = l.memoizedState;
    n === null
      ? (l.memoizedState = {
          isBackwards: t,
          rendering: null,
          renderingStartTime: 0,
          last: u,
          tail: a,
          tailMode: e,
        })
      : ((n.isBackwards = t),
        (n.rendering = null),
        (n.renderingStartTime = 0),
        (n.last = u),
        (n.tail = a),
        (n.tailMode = e));
  }
  function rs(l, t, a) {
    var u = t.pendingProps,
      e = u.revealOrder,
      n = u.tail;
    if ((yl(l, t, u.children, a), (u = cl.current), (u & 2) !== 0))
      ((u = (u & 1) | 2), (t.flags |= 128));
    else {
      if (l !== null && (l.flags & 128) !== 0)
        l: for (l = t.child; l !== null; ) {
          if (l.tag === 13) l.memoizedState !== null && Ss(l, a, t);
          else if (l.tag === 19) Ss(l, a, t);
          else if (l.child !== null) {
            ((l.child.return = l), (l = l.child));
            continue;
          }
          if (l === t) break l;
          for (; l.sibling === null; ) {
            if (l.return === null || l.return === t) break l;
            l = l.return;
          }
          ((l.sibling.return = l.return), (l = l.sibling));
        }
      u &= 1;
    }
    switch ((G(cl, u), e)) {
      case 'forwards':
        for (a = t.child, e = null; a !== null; )
          ((l = a.alternate),
            l !== null && Ie(l) === null && (e = a),
            (a = a.sibling));
        ((a = e),
          a === null
            ? ((e = t.child), (t.child = null))
            : ((e = a.sibling), (a.sibling = null)),
          lf(t, !1, e, a, n));
        break;
      case 'backwards':
        for (a = null, e = t.child, t.child = null; e !== null; ) {
          if (((l = e.alternate), l !== null && Ie(l) === null)) {
            t.child = e;
            break;
          }
          ((l = e.sibling), (e.sibling = a), (a = e), (e = l));
        }
        lf(t, !0, a, null, n);
        break;
      case 'together':
        lf(t, !1, null, null, void 0);
        break;
      default:
        t.memoizedState = null;
    }
    return t.child;
  }
  function At(l, t, a) {
    if (
      (l !== null && (t.dependencies = l.dependencies),
      (Kt |= t.lanes),
      (a & t.childLanes) === 0)
    )
      if (l !== null) {
        if ((xu(l, t, a, !1), (a & t.childLanes) === 0)) return null;
      } else return null;
    if (l !== null && t.child !== l.child) throw Error(o(153));
    if (t.child !== null) {
      for (
        l = t.child, a = mt(l, l.pendingProps), t.child = a, a.return = t;
        l.sibling !== null;

      )
        ((l = l.sibling),
          (a = a.sibling = mt(l, l.pendingProps)),
          (a.return = t));
      a.sibling = null;
    }
    return t.child;
  }
  function tf(l, t) {
    return (l.lanes & t) !== 0
      ? !0
      : ((l = l.dependencies), !!(l !== null && Ye(l)));
  }
  function y1(l, t, a) {
    switch (t.tag) {
      case 3:
        (ye(t, t.stateNode.containerInfo),
          qt(t, nl, l.memoizedState.cache),
          Du());
        break;
      case 27:
      case 5:
        Hn(t);
        break;
      case 4:
        ye(t, t.stateNode.containerInfo);
        break;
      case 10:
        qt(t, t.type, t.memoizedProps.value);
        break;
      case 13:
        var u = t.memoizedState;
        if (u !== null)
          return u.dehydrated !== null
            ? (Gt(t), (t.flags |= 128), null)
            : (a & t.child.childLanes) !== 0
              ? bs(l, t, a)
              : (Gt(t), (l = At(l, t, a)), l !== null ? l.sibling : null);
        Gt(t);
        break;
      case 19:
        var e = (l.flags & 128) !== 0;
        if (
          ((u = (a & t.childLanes) !== 0),
          u || (xu(l, t, a, !1), (u = (a & t.childLanes) !== 0)),
          e)
        ) {
          if (u) return rs(l, t, a);
          t.flags |= 128;
        }
        if (
          ((e = t.memoizedState),
          e !== null &&
            ((e.rendering = null), (e.tail = null), (e.lastEffect = null)),
          G(cl, cl.current),
          u)
        )
          break;
        return null;
      case 22:
      case 23:
        return ((t.lanes = 0), vs(l, t, a));
      case 24:
        qt(t, nl, l.memoizedState.cache);
    }
    return At(l, t, a);
  }
  function zs(l, t, a) {
    if (l !== null)
      if (l.memoizedProps !== t.pendingProps) sl = !0;
      else {
        if (!tf(l, a) && (t.flags & 128) === 0) return ((sl = !1), y1(l, t, a));
        sl = (l.flags & 131072) !== 0;
      }
    else ((sl = !1), B && (t.flags & 1048576) !== 0 && $i(t, Be, t.index));
    switch (((t.lanes = 0), t.tag)) {
      case 16:
        l: {
          l = t.pendingProps;
          var u = t.elementType,
            e = u._init;
          if (((u = e(u._payload)), (t.type = u), typeof u == 'function'))
            dc(u)
              ? ((l = ga(u, l)), (t.tag = 1), (t = os(null, t, u, l, a)))
              : ((t.tag = 0), (t = Wc(null, t, u, l, a)));
          else {
            if (u != null) {
              if (((e = u.$$typeof), e === Ut)) {
                ((t.tag = 11), (t = ss(null, t, u, l, a)));
                break l;
              } else if (e === dt) {
                ((t.tag = 14), (t = ds(null, t, u, l, a)));
                break l;
              }
            }
            throw ((t = su(u) || u), Error(o(306, t, '')));
          }
        }
        return t;
      case 0:
        return Wc(l, t, t.type, t.pendingProps, a);
      case 1:
        return ((u = t.type), (e = ga(u, t.pendingProps)), os(l, t, u, e, a));
      case 3:
        l: {
          if ((ye(t, t.stateNode.containerInfo), l === null))
            throw Error(o(387));
          u = t.pendingProps;
          var n = t.memoizedState;
          ((e = n.element), Ec(l, t), pu(t, u, null, a));
          var c = t.memoizedState;
          if (
            ((u = c.cache),
            qt(t, nl, u),
            u !== n.cache && Sc(t, [nl], a, !0),
            qu(),
            (u = c.element),
            n.isDehydrated)
          )
            if (
              ((n = { element: u, isDehydrated: !1, cache: c.cache }),
              (t.updateQueue.baseState = n),
              (t.memoizedState = n),
              t.flags & 256)
            ) {
              t = gs(l, t, u, a);
              break l;
            } else if (u !== e) {
              ((e = Zl(Error(o(424)), t)), Ou(e), (t = gs(l, t, u, a)));
              break l;
            } else {
              switch (((l = t.stateNode.containerInfo), l.nodeType)) {
                case 9:
                  l = l.body;
                  break;
                default:
                  l = l.nodeName === 'HTML' ? l.ownerDocument.body : l;
              }
              for (
                F = Pl(l.firstChild),
                  zl = t,
                  B = !0,
                  da = null,
                  ut = !0,
                  a = I0(t, null, u, a),
                  t.child = a;
                a;

              )
                ((a.flags = (a.flags & -3) | 4096), (a = a.sibling));
            }
          else {
            if ((Du(), u === e)) {
              t = At(l, t, a);
              break l;
            }
            yl(l, t, u, a);
          }
          t = t.child;
        }
        return t;
      case 26:
        return (
          tn(l, t),
          l === null
            ? (a = Ed(t.type, null, t.pendingProps, null))
              ? (t.memoizedState = a)
              : B ||
                ((a = t.type),
                (l = t.pendingProps),
                (u = bn(Nt.current).createElement(a)),
                (u[bl] = t),
                (u[Tl] = l),
                ol(u, a, l),
                il(u),
                (t.stateNode = u))
            : (t.memoizedState = Ed(
                t.type,
                l.memoizedProps,
                t.pendingProps,
                l.memoizedState,
              )),
          null
        );
      case 27:
        return (
          Hn(t),
          l === null &&
            B &&
            ((u = t.stateNode = Ad(t.type, t.pendingProps, Nt.current)),
            (zl = t),
            (ut = !0),
            (e = F),
            Wt(t.type) ? ((Yf = e), (F = Pl(u.firstChild))) : (F = e)),
          yl(l, t, t.pendingProps.children, a),
          tn(l, t),
          l === null && (t.flags |= 4194304),
          t.child
        );
      case 5:
        return (
          l === null &&
            B &&
            ((e = u = F) &&
              ((u = Z1(u, t.type, t.pendingProps, ut)),
              u !== null
                ? ((t.stateNode = u),
                  (zl = t),
                  (F = Pl(u.firstChild)),
                  (ut = !1),
                  (e = !0))
                : (e = !1)),
            e || ha(t)),
          Hn(t),
          (e = t.type),
          (n = t.pendingProps),
          (c = l !== null ? l.memoizedProps : null),
          (u = n.children),
          Rf(e, n) ? (u = null) : c !== null && Rf(e, c) && (t.flags |= 32),
          t.memoizedState !== null &&
            ((e = Hc(l, t, n1, null, null, a)), (ae._currentValue = e)),
          tn(l, t),
          yl(l, t, u, a),
          t.child
        );
      case 6:
        return (
          l === null &&
            B &&
            ((l = a = F) &&
              ((a = V1(a, t.pendingProps, ut)),
              a !== null
                ? ((t.stateNode = a), (zl = t), (F = null), (l = !0))
                : (l = !1)),
            l || ha(t)),
          null
        );
      case 13:
        return bs(l, t, a);
      case 4:
        return (
          ye(t, t.stateNode.containerInfo),
          (u = t.pendingProps),
          l === null ? (t.child = Wa(t, null, u, a)) : yl(l, t, u, a),
          t.child
        );
      case 11:
        return ss(l, t, t.type, t.pendingProps, a);
      case 7:
        return (yl(l, t, t.pendingProps, a), t.child);
      case 8:
        return (yl(l, t, t.pendingProps.children, a), t.child);
      case 12:
        return (yl(l, t, t.pendingProps.children, a), t.child);
      case 10:
        return (
          (u = t.pendingProps),
          qt(t, t.type, u.value),
          yl(l, t, u.children, a),
          t.child
        );
      case 9:
        return (
          (e = t.type._context),
          (u = t.pendingProps.children),
          ya(t),
          (e = Sl(e)),
          (u = u(e)),
          (t.flags |= 1),
          yl(l, t, u, a),
          t.child
        );
      case 14:
        return ds(l, t, t.type, t.pendingProps, a);
      case 15:
        return hs(l, t, t.type, t.pendingProps, a);
      case 19:
        return rs(l, t, a);
      case 31:
        return (
          (u = t.pendingProps),
          (a = t.mode),
          (u = { mode: u.mode, children: u.children }),
          l === null
            ? ((a = an(u, a)),
              (a.ref = t.ref),
              (t.child = a),
              (a.return = t),
              (t = a))
            : ((a = mt(l.child, u)),
              (a.ref = t.ref),
              (t.child = a),
              (a.return = t),
              (t = a)),
          t
        );
      case 22:
        return vs(l, t, a);
      case 24:
        return (
          ya(t),
          (u = Sl(nl)),
          l === null
            ? ((e = Ac()),
              e === null &&
                ((e = K),
                (n = rc()),
                (e.pooledCache = n),
                n.refCount++,
                n !== null && (e.pooledCacheLanes |= a),
                (e = n)),
              (t.memoizedState = { parent: u, cache: e }),
              Mc(t),
              qt(t, nl, e))
            : ((l.lanes & a) !== 0 && (Ec(l, t), pu(t, null, null, a), qu()),
              (e = l.memoizedState),
              (n = t.memoizedState),
              e.parent !== u
                ? ((e = { parent: u, cache: u }),
                  (t.memoizedState = e),
                  t.lanes === 0 &&
                    (t.memoizedState = t.updateQueue.baseState = e),
                  qt(t, nl, u))
                : ((u = n.cache),
                  qt(t, nl, u),
                  u !== e.cache && Sc(t, [nl], a, !0))),
          yl(l, t, t.pendingProps.children, a),
          t.child
        );
      case 29:
        throw t.pendingProps;
    }
    throw Error(o(156, t.tag));
  }
  function Tt(l) {
    l.flags |= 4;
  }
  function As(l, t) {
    if (t.type !== 'stylesheet' || (t.state.loading & 4) !== 0)
      l.flags &= -16777217;
    else if (((l.flags |= 16777216), !Nd(t))) {
      if (
        ((t = Ll.current),
        t !== null &&
          ((q & 4194048) === q
            ? et !== null
            : ((q & 62914560) !== q && (q & 536870912) === 0) || t !== et))
      )
        throw ((_u = Tc), e0);
      l.flags |= 8192;
    }
  }
  function un(l, t) {
    (t !== null && (l.flags |= 4),
      l.flags & 16384 &&
        ((t = l.tag !== 22 ? Pf() : 536870912), (l.lanes |= t), (Ia |= t)));
  }
  function Zu(l, t) {
    if (!B)
      switch (l.tailMode) {
        case 'hidden':
          t = l.tail;
          for (var a = null; t !== null; )
            (t.alternate !== null && (a = t), (t = t.sibling));
          a === null ? (l.tail = null) : (a.sibling = null);
          break;
        case 'collapsed':
          a = l.tail;
          for (var u = null; a !== null; )
            (a.alternate !== null && (u = a), (a = a.sibling));
          u === null
            ? t || l.tail === null
              ? (l.tail = null)
              : (l.tail.sibling = null)
            : (u.sibling = null);
      }
  }
  function $(l) {
    var t = l.alternate !== null && l.alternate.child === l.child,
      a = 0,
      u = 0;
    if (t)
      for (var e = l.child; e !== null; )
        ((a |= e.lanes | e.childLanes),
          (u |= e.subtreeFlags & 65011712),
          (u |= e.flags & 65011712),
          (e.return = l),
          (e = e.sibling));
    else
      for (e = l.child; e !== null; )
        ((a |= e.lanes | e.childLanes),
          (u |= e.subtreeFlags),
          (u |= e.flags),
          (e.return = l),
          (e = e.sibling));
    return ((l.subtreeFlags |= u), (l.childLanes = a), t);
  }
  function m1(l, t, a) {
    var u = t.pendingProps;
    switch ((mc(t), t.tag)) {
      case 31:
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return ($(t), null);
      case 1:
        return ($(t), null);
      case 3:
        return (
          (a = t.stateNode),
          (u = null),
          l !== null && (u = l.memoizedState.cache),
          t.memoizedState.cache !== u && (t.flags |= 2048),
          St(nl),
          Ta(),
          a.pendingContext &&
            ((a.context = a.pendingContext), (a.pendingContext = null)),
          (l === null || l.child === null) &&
            (Eu(t)
              ? Tt(t)
              : l === null ||
                (l.memoizedState.isDehydrated && (t.flags & 256) === 0) ||
                ((t.flags |= 1024), Pi())),
          $(t),
          null
        );
      case 26:
        return (
          (a = t.memoizedState),
          l === null
            ? (Tt(t),
              a !== null ? ($(t), As(t, a)) : ($(t), (t.flags &= -16777217)))
            : a
              ? a !== l.memoizedState
                ? (Tt(t), $(t), As(t, a))
                : ($(t), (t.flags &= -16777217))
              : (l.memoizedProps !== u && Tt(t), $(t), (t.flags &= -16777217)),
          null
        );
      case 27:
        (me(t), (a = Nt.current));
        var e = t.type;
        if (l !== null && t.stateNode != null) l.memoizedProps !== u && Tt(t);
        else {
          if (!u) {
            if (t.stateNode === null) throw Error(o(166));
            return ($(t), null);
          }
          ((l = fl.current),
            Eu(t) ? Fi(t) : ((l = Ad(e, u, a)), (t.stateNode = l), Tt(t)));
        }
        return ($(t), null);
      case 5:
        if ((me(t), (a = t.type), l !== null && t.stateNode != null))
          l.memoizedProps !== u && Tt(t);
        else {
          if (!u) {
            if (t.stateNode === null) throw Error(o(166));
            return ($(t), null);
          }
          if (((l = fl.current), Eu(t))) Fi(t);
          else {
            switch (((e = bn(Nt.current)), l)) {
              case 1:
                l = e.createElementNS('http://www.w3.org/2000/svg', a);
                break;
              case 2:
                l = e.createElementNS('http://www.w3.org/1998/Math/MathML', a);
                break;
              default:
                switch (a) {
                  case 'svg':
                    l = e.createElementNS('http://www.w3.org/2000/svg', a);
                    break;
                  case 'math':
                    l = e.createElementNS(
                      'http://www.w3.org/1998/Math/MathML',
                      a,
                    );
                    break;
                  case 'script':
                    ((l = e.createElement('div')),
                      (l.innerHTML = '<script><\/script>'),
                      (l = l.removeChild(l.firstChild)));
                    break;
                  case 'select':
                    ((l =
                      typeof u.is == 'string'
                        ? e.createElement('select', { is: u.is })
                        : e.createElement('select')),
                      u.multiple
                        ? (l.multiple = !0)
                        : u.size && (l.size = u.size));
                    break;
                  default:
                    l =
                      typeof u.is == 'string'
                        ? e.createElement(a, { is: u.is })
                        : e.createElement(a);
                }
            }
            ((l[bl] = t), (l[Tl] = u));
            l: for (e = t.child; e !== null; ) {
              if (e.tag === 5 || e.tag === 6) l.appendChild(e.stateNode);
              else if (e.tag !== 4 && e.tag !== 27 && e.child !== null) {
                ((e.child.return = e), (e = e.child));
                continue;
              }
              if (e === t) break l;
              for (; e.sibling === null; ) {
                if (e.return === null || e.return === t) break l;
                e = e.return;
              }
              ((e.sibling.return = e.return), (e = e.sibling));
            }
            t.stateNode = l;
            l: switch ((ol(l, a, u), a)) {
              case 'button':
              case 'input':
              case 'select':
              case 'textarea':
                l = !!u.autoFocus;
                break l;
              case 'img':
                l = !0;
                break l;
              default:
                l = !1;
            }
            l && Tt(t);
          }
        }
        return ($(t), (t.flags &= -16777217), null);
      case 6:
        if (l && t.stateNode != null) l.memoizedProps !== u && Tt(t);
        else {
          if (typeof u != 'string' && t.stateNode === null) throw Error(o(166));
          if (((l = Nt.current), Eu(t))) {
            if (
              ((l = t.stateNode),
              (a = t.memoizedProps),
              (u = null),
              (e = zl),
              e !== null)
            )
              switch (e.tag) {
                case 27:
                case 5:
                  u = e.memoizedProps;
              }
            ((l[bl] = t),
              (l = !!(
                l.nodeValue === a ||
                (u !== null && u.suppressHydrationWarning === !0) ||
                md(l.nodeValue, a)
              )),
              l || ha(t));
          } else
            ((l = bn(l).createTextNode(u)), (l[bl] = t), (t.stateNode = l));
        }
        return ($(t), null);
      case 13:
        if (
          ((u = t.memoizedState),
          l === null ||
            (l.memoizedState !== null && l.memoizedState.dehydrated !== null))
        ) {
          if (((e = Eu(t)), u !== null && u.dehydrated !== null)) {
            if (l === null) {
              if (!e) throw Error(o(318));
              if (
                ((e = t.memoizedState),
                (e = e !== null ? e.dehydrated : null),
                !e)
              )
                throw Error(o(317));
              e[bl] = t;
            } else
              (Du(),
                (t.flags & 128) === 0 && (t.memoizedState = null),
                (t.flags |= 4));
            ($(t), (e = !1));
          } else
            ((e = Pi()),
              l !== null &&
                l.memoizedState !== null &&
                (l.memoizedState.hydrationErrors = e),
              (e = !0));
          if (!e) return t.flags & 256 ? (zt(t), t) : (zt(t), null);
        }
        if ((zt(t), (t.flags & 128) !== 0)) return ((t.lanes = a), t);
        if (
          ((a = u !== null), (l = l !== null && l.memoizedState !== null), a)
        ) {
          ((u = t.child),
            (e = null),
            u.alternate !== null &&
              u.alternate.memoizedState !== null &&
              u.alternate.memoizedState.cachePool !== null &&
              (e = u.alternate.memoizedState.cachePool.pool));
          var n = null;
          (u.memoizedState !== null &&
            u.memoizedState.cachePool !== null &&
            (n = u.memoizedState.cachePool.pool),
            n !== e && (u.flags |= 2048));
        }
        return (
          a !== l && a && (t.child.flags |= 8192),
          un(t, t.updateQueue),
          $(t),
          null
        );
      case 4:
        return (Ta(), l === null && xf(t.stateNode.containerInfo), $(t), null);
      case 10:
        return (St(t.type), $(t), null);
      case 19:
        if ((k(cl), (e = t.memoizedState), e === null)) return ($(t), null);
        if (((u = (t.flags & 128) !== 0), (n = e.rendering), n === null))
          if (u) Zu(e, !1);
          else {
            if (I !== 0 || (l !== null && (l.flags & 128) !== 0))
              for (l = t.child; l !== null; ) {
                if (((n = Ie(l)), n !== null)) {
                  for (
                    t.flags |= 128,
                      Zu(e, !1),
                      l = n.updateQueue,
                      t.updateQueue = l,
                      un(t, l),
                      t.subtreeFlags = 0,
                      l = a,
                      a = t.child;
                    a !== null;

                  )
                    (ki(a, l), (a = a.sibling));
                  return (G(cl, (cl.current & 1) | 2), t.child);
                }
                l = l.sibling;
              }
            e.tail !== null &&
              at() > cn &&
              ((t.flags |= 128), (u = !0), Zu(e, !1), (t.lanes = 4194304));
          }
        else {
          if (!u)
            if (((l = Ie(n)), l !== null)) {
              if (
                ((t.flags |= 128),
                (u = !0),
                (l = l.updateQueue),
                (t.updateQueue = l),
                un(t, l),
                Zu(e, !0),
                e.tail === null &&
                  e.tailMode === 'hidden' &&
                  !n.alternate &&
                  !B)
              )
                return ($(t), null);
            } else
              2 * at() - e.renderingStartTime > cn &&
                a !== 536870912 &&
                ((t.flags |= 128), (u = !0), Zu(e, !1), (t.lanes = 4194304));
          e.isBackwards
            ? ((n.sibling = t.child), (t.child = n))
            : ((l = e.last),
              l !== null ? (l.sibling = n) : (t.child = n),
              (e.last = n));
        }
        return e.tail !== null
          ? ((t = e.tail),
            (e.rendering = t),
            (e.tail = t.sibling),
            (e.renderingStartTime = at()),
            (t.sibling = null),
            (l = cl.current),
            G(cl, u ? (l & 1) | 2 : l & 1),
            t)
          : ($(t), null);
      case 22:
      case 23:
        return (
          zt(t),
          Uc(),
          (u = t.memoizedState !== null),
          l !== null
            ? (l.memoizedState !== null) !== u && (t.flags |= 8192)
            : u && (t.flags |= 8192),
          u
            ? (a & 536870912) !== 0 &&
              (t.flags & 128) === 0 &&
              ($(t), t.subtreeFlags & 6 && (t.flags |= 8192))
            : $(t),
          (a = t.updateQueue),
          a !== null && un(t, a.retryQueue),
          (a = null),
          l !== null &&
            l.memoizedState !== null &&
            l.memoizedState.cachePool !== null &&
            (a = l.memoizedState.cachePool.pool),
          (u = null),
          t.memoizedState !== null &&
            t.memoizedState.cachePool !== null &&
            (u = t.memoizedState.cachePool.pool),
          u !== a && (t.flags |= 2048),
          l !== null && k(ma),
          null
        );
      case 24:
        return (
          (a = null),
          l !== null && (a = l.memoizedState.cache),
          t.memoizedState.cache !== a && (t.flags |= 2048),
          St(nl),
          $(t),
          null
        );
      case 25:
        return null;
      case 30:
        return null;
    }
    throw Error(o(156, t.tag));
  }
  function o1(l, t) {
    switch ((mc(t), t.tag)) {
      case 1:
        return (
          (l = t.flags),
          l & 65536 ? ((t.flags = (l & -65537) | 128), t) : null
        );
      case 3:
        return (
          St(nl),
          Ta(),
          (l = t.flags),
          (l & 65536) !== 0 && (l & 128) === 0
            ? ((t.flags = (l & -65537) | 128), t)
            : null
        );
      case 26:
      case 27:
      case 5:
        return (me(t), null);
      case 13:
        if (
          (zt(t), (l = t.memoizedState), l !== null && l.dehydrated !== null)
        ) {
          if (t.alternate === null) throw Error(o(340));
          Du();
        }
        return (
          (l = t.flags),
          l & 65536 ? ((t.flags = (l & -65537) | 128), t) : null
        );
      case 19:
        return (k(cl), null);
      case 4:
        return (Ta(), null);
      case 10:
        return (St(t.type), null);
      case 22:
      case 23:
        return (
          zt(t),
          Uc(),
          l !== null && k(ma),
          (l = t.flags),
          l & 65536 ? ((t.flags = (l & -65537) | 128), t) : null
        );
      case 24:
        return (St(nl), null);
      case 25:
        return null;
      default:
        return null;
    }
  }
  function Ts(l, t) {
    switch ((mc(t), t.tag)) {
      case 3:
        (St(nl), Ta());
        break;
      case 26:
      case 27:
      case 5:
        me(t);
        break;
      case 4:
        Ta();
        break;
      case 13:
        zt(t);
        break;
      case 19:
        k(cl);
        break;
      case 10:
        St(t.type);
        break;
      case 22:
      case 23:
        (zt(t), Uc(), l !== null && k(ma));
        break;
      case 24:
        St(nl);
    }
  }
  function Vu(l, t) {
    try {
      var a = t.updateQueue,
        u = a !== null ? a.lastEffect : null;
      if (u !== null) {
        var e = u.next;
        a = e;
        do {
          if ((a.tag & l) === l) {
            u = void 0;
            var n = a.create,
              c = a.inst;
            ((u = n()), (c.destroy = u));
          }
          a = a.next;
        } while (a !== e);
      }
    } catch (f) {
      C(t, t.return, f);
    }
  }
  function Qt(l, t, a) {
    try {
      var u = t.updateQueue,
        e = u !== null ? u.lastEffect : null;
      if (e !== null) {
        var n = e.next;
        u = n;
        do {
          if ((u.tag & l) === l) {
            var c = u.inst,
              f = c.destroy;
            if (f !== void 0) {
              ((c.destroy = void 0), (e = t));
              var i = a,
                v = f;
              try {
                v();
              } catch (g) {
                C(e, i, g);
              }
            }
          }
          u = u.next;
        } while (u !== n);
      }
    } catch (g) {
      C(t, t.return, g);
    }
  }
  function Ms(l) {
    var t = l.updateQueue;
    if (t !== null) {
      var a = l.stateNode;
      try {
        d0(t, a);
      } catch (u) {
        C(l, l.return, u);
      }
    }
  }
  function Es(l, t, a) {
    ((a.props = ga(l.type, l.memoizedProps)), (a.state = l.memoizedState));
    try {
      a.componentWillUnmount();
    } catch (u) {
      C(l, t, u);
    }
  }
  function Cu(l, t) {
    try {
      var a = l.ref;
      if (a !== null) {
        switch (l.tag) {
          case 26:
          case 27:
          case 5:
            var u = l.stateNode;
            break;
          case 30:
            u = l.stateNode;
            break;
          default:
            u = l.stateNode;
        }
        typeof a == 'function' ? (l.refCleanup = a(u)) : (a.current = u);
      }
    } catch (e) {
      C(l, t, e);
    }
  }
  function nt(l, t) {
    var a = l.ref,
      u = l.refCleanup;
    if (a !== null)
      if (typeof u == 'function')
        try {
          u();
        } catch (e) {
          C(l, t, e);
        } finally {
          ((l.refCleanup = null),
            (l = l.alternate),
            l != null && (l.refCleanup = null));
        }
      else if (typeof a == 'function')
        try {
          a(null);
        } catch (e) {
          C(l, t, e);
        }
      else a.current = null;
  }
  function Ds(l) {
    var t = l.type,
      a = l.memoizedProps,
      u = l.stateNode;
    try {
      l: switch (t) {
        case 'button':
        case 'input':
        case 'select':
        case 'textarea':
          a.autoFocus && u.focus();
          break l;
        case 'img':
          a.src ? (u.src = a.src) : a.srcSet && (u.srcset = a.srcSet);
      }
    } catch (e) {
      C(l, l.return, e);
    }
  }
  function af(l, t, a) {
    try {
      var u = l.stateNode;
      (Y1(u, l.type, a, t), (u[Tl] = t));
    } catch (e) {
      C(l, l.return, e);
    }
  }
  function Os(l) {
    return (
      l.tag === 5 ||
      l.tag === 3 ||
      l.tag === 26 ||
      (l.tag === 27 && Wt(l.type)) ||
      l.tag === 4
    );
  }
  function uf(l) {
    l: for (;;) {
      for (; l.sibling === null; ) {
        if (l.return === null || Os(l.return)) return null;
        l = l.return;
      }
      for (
        l.sibling.return = l.return, l = l.sibling;
        l.tag !== 5 && l.tag !== 6 && l.tag !== 18;

      ) {
        if (
          (l.tag === 27 && Wt(l.type)) ||
          l.flags & 2 ||
          l.child === null ||
          l.tag === 4
        )
          continue l;
        ((l.child.return = l), (l = l.child));
      }
      if (!(l.flags & 2)) return l.stateNode;
    }
  }
  function ef(l, t, a) {
    var u = l.tag;
    if (u === 5 || u === 6)
      ((l = l.stateNode),
        t
          ? (a.nodeType === 9
              ? a.body
              : a.nodeName === 'HTML'
                ? a.ownerDocument.body
                : a
            ).insertBefore(l, t)
          : ((t =
              a.nodeType === 9
                ? a.body
                : a.nodeName === 'HTML'
                  ? a.ownerDocument.body
                  : a),
            t.appendChild(l),
            (a = a._reactRootContainer),
            a != null || t.onclick !== null || (t.onclick = gn)));
    else if (
      u !== 4 &&
      (u === 27 && Wt(l.type) && ((a = l.stateNode), (t = null)),
      (l = l.child),
      l !== null)
    )
      for (ef(l, t, a), l = l.sibling; l !== null; )
        (ef(l, t, a), (l = l.sibling));
  }
  function en(l, t, a) {
    var u = l.tag;
    if (u === 5 || u === 6)
      ((l = l.stateNode), t ? a.insertBefore(l, t) : a.appendChild(l));
    else if (
      u !== 4 &&
      (u === 27 && Wt(l.type) && (a = l.stateNode), (l = l.child), l !== null)
    )
      for (en(l, t, a), l = l.sibling; l !== null; )
        (en(l, t, a), (l = l.sibling));
  }
  function xs(l) {
    var t = l.stateNode,
      a = l.memoizedProps;
    try {
      for (var u = l.type, e = t.attributes; e.length; )
        t.removeAttributeNode(e[0]);
      (ol(t, u, a), (t[bl] = l), (t[Tl] = a));
    } catch (n) {
      C(l, l.return, n);
    }
  }
  var Mt = !1,
    tl = !1,
    nf = !1,
    Us = typeof WeakSet == 'function' ? WeakSet : Set,
    dl = null;
  function g1(l, t) {
    if (((l = l.containerInfo), (Hf = Mn), (l = Xi(l)), uc(l))) {
      if ('selectionStart' in l)
        var a = { start: l.selectionStart, end: l.selectionEnd };
      else
        l: {
          a = ((a = l.ownerDocument) && a.defaultView) || window;
          var u = a.getSelection && a.getSelection();
          if (u && u.rangeCount !== 0) {
            a = u.anchorNode;
            var e = u.anchorOffset,
              n = u.focusNode;
            u = u.focusOffset;
            try {
              (a.nodeType, n.nodeType);
            } catch {
              a = null;
              break l;
            }
            var c = 0,
              f = -1,
              i = -1,
              v = 0,
              g = 0,
              r = l,
              y = null;
            t: for (;;) {
              for (
                var m;
                r !== a || (e !== 0 && r.nodeType !== 3) || (f = c + e),
                  r !== n || (u !== 0 && r.nodeType !== 3) || (i = c + u),
                  r.nodeType === 3 && (c += r.nodeValue.length),
                  (m = r.firstChild) !== null;

              )
                ((y = r), (r = m));
              for (;;) {
                if (r === l) break t;
                if (
                  (y === a && ++v === e && (f = c),
                  y === n && ++g === u && (i = c),
                  (m = r.nextSibling) !== null)
                )
                  break;
                ((r = y), (y = r.parentNode));
              }
              r = m;
            }
            a = f === -1 || i === -1 ? null : { start: f, end: i };
          } else a = null;
        }
      a = a || { start: 0, end: 0 };
    } else a = null;
    for (
      _f = { focusedElem: l, selectionRange: a }, Mn = !1, dl = t;
      dl !== null;

    )
      if (
        ((t = dl), (l = t.child), (t.subtreeFlags & 1024) !== 0 && l !== null)
      )
        ((l.return = t), (dl = l));
      else
        for (; dl !== null; ) {
          switch (((t = dl), (n = t.alternate), (l = t.flags), t.tag)) {
            case 0:
              break;
            case 11:
            case 15:
              break;
            case 1:
              if ((l & 1024) !== 0 && n !== null) {
                ((l = void 0),
                  (a = t),
                  (e = n.memoizedProps),
                  (n = n.memoizedState),
                  (u = a.stateNode));
                try {
                  var x = ga(a.type, e, a.elementType === a.type);
                  ((l = u.getSnapshotBeforeUpdate(x, n)),
                    (u.__reactInternalSnapshotBeforeUpdate = l));
                } catch (D) {
                  C(a, a.return, D);
                }
              }
              break;
            case 3:
              if ((l & 1024) !== 0) {
                if (
                  ((l = t.stateNode.containerInfo), (a = l.nodeType), a === 9)
                )
                  pf(l);
                else if (a === 1)
                  switch (l.nodeName) {
                    case 'HEAD':
                    case 'HTML':
                    case 'BODY':
                      pf(l);
                      break;
                    default:
                      l.textContent = '';
                  }
              }
              break;
            case 5:
            case 26:
            case 27:
            case 6:
            case 4:
            case 17:
              break;
            default:
              if ((l & 1024) !== 0) throw Error(o(163));
          }
          if (((l = t.sibling), l !== null)) {
            ((l.return = t.return), (dl = l));
            break;
          }
          dl = t.return;
        }
  }
  function Ns(l, t, a) {
    var u = a.flags;
    switch (a.tag) {
      case 0:
      case 11:
      case 15:
        (Zt(l, a), u & 4 && Vu(5, a));
        break;
      case 1:
        if ((Zt(l, a), u & 4))
          if (((l = a.stateNode), t === null))
            try {
              l.componentDidMount();
            } catch (c) {
              C(a, a.return, c);
            }
          else {
            var e = ga(a.type, t.memoizedProps);
            t = t.memoizedState;
            try {
              l.componentDidUpdate(e, t, l.__reactInternalSnapshotBeforeUpdate);
            } catch (c) {
              C(a, a.return, c);
            }
          }
        (u & 64 && Ms(a), u & 512 && Cu(a, a.return));
        break;
      case 3:
        if ((Zt(l, a), u & 64 && ((l = a.updateQueue), l !== null))) {
          if (((t = null), a.child !== null))
            switch (a.child.tag) {
              case 27:
              case 5:
                t = a.child.stateNode;
                break;
              case 1:
                t = a.child.stateNode;
            }
          try {
            d0(l, t);
          } catch (c) {
            C(a, a.return, c);
          }
        }
        break;
      case 27:
        t === null && u & 4 && xs(a);
      case 26:
      case 5:
        (Zt(l, a), t === null && u & 4 && Ds(a), u & 512 && Cu(a, a.return));
        break;
      case 12:
        Zt(l, a);
        break;
      case 13:
        (Zt(l, a),
          u & 4 && Rs(l, a),
          u & 64 &&
            ((l = a.memoizedState),
            l !== null &&
              ((l = l.dehydrated),
              l !== null && ((a = D1.bind(null, a)), C1(l, a)))));
        break;
      case 22:
        if (((u = a.memoizedState !== null || Mt), !u)) {
          ((t = (t !== null && t.memoizedState !== null) || tl), (e = Mt));
          var n = tl;
          ((Mt = u),
            (tl = t) && !n ? Vt(l, a, (a.subtreeFlags & 8772) !== 0) : Zt(l, a),
            (Mt = e),
            (tl = n));
        }
        break;
      case 30:
        break;
      default:
        Zt(l, a);
    }
  }
  function Hs(l) {
    var t = l.alternate;
    (t !== null && ((l.alternate = null), Hs(t)),
      (l.child = null),
      (l.deletions = null),
      (l.sibling = null),
      l.tag === 5 && ((t = l.stateNode), t !== null && Gn(t)),
      (l.stateNode = null),
      (l.return = null),
      (l.dependencies = null),
      (l.memoizedProps = null),
      (l.memoizedState = null),
      (l.pendingProps = null),
      (l.stateNode = null),
      (l.updateQueue = null));
  }
  var w = null,
    Dl = !1;
  function Et(l, t, a) {
    for (a = a.child; a !== null; ) (_s(l, t, a), (a = a.sibling));
  }
  function _s(l, t, a) {
    if (xl && typeof xl.onCommitFiberUnmount == 'function')
      try {
        xl.onCommitFiberUnmount(du, a);
      } catch {}
    switch (a.tag) {
      case 26:
        (tl || nt(a, t),
          Et(l, t, a),
          a.memoizedState
            ? a.memoizedState.count--
            : a.stateNode && ((a = a.stateNode), a.parentNode.removeChild(a)));
        break;
      case 27:
        tl || nt(a, t);
        var u = w,
          e = Dl;
        (Wt(a.type) && ((w = a.stateNode), (Dl = !1)),
          Et(l, t, a),
          Iu(a.stateNode),
          (w = u),
          (Dl = e));
        break;
      case 5:
        tl || nt(a, t);
      case 6:
        if (
          ((u = w),
          (e = Dl),
          (w = null),
          Et(l, t, a),
          (w = u),
          (Dl = e),
          w !== null)
        )
          if (Dl)
            try {
              (w.nodeType === 9
                ? w.body
                : w.nodeName === 'HTML'
                  ? w.ownerDocument.body
                  : w
              ).removeChild(a.stateNode);
            } catch (n) {
              C(a, t, n);
            }
          else
            try {
              w.removeChild(a.stateNode);
            } catch (n) {
              C(a, t, n);
            }
        break;
      case 18:
        w !== null &&
          (Dl
            ? ((l = w),
              rd(
                l.nodeType === 9
                  ? l.body
                  : l.nodeName === 'HTML'
                    ? l.ownerDocument.body
                    : l,
                a.stateNode,
              ),
              ce(l))
            : rd(w, a.stateNode));
        break;
      case 4:
        ((u = w),
          (e = Dl),
          (w = a.stateNode.containerInfo),
          (Dl = !0),
          Et(l, t, a),
          (w = u),
          (Dl = e));
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        (tl || Qt(2, a, t), tl || Qt(4, a, t), Et(l, t, a));
        break;
      case 1:
        (tl ||
          (nt(a, t),
          (u = a.stateNode),
          typeof u.componentWillUnmount == 'function' && Es(a, t, u)),
          Et(l, t, a));
        break;
      case 21:
        Et(l, t, a);
        break;
      case 22:
        ((tl = (u = tl) || a.memoizedState !== null), Et(l, t, a), (tl = u));
        break;
      default:
        Et(l, t, a);
    }
  }
  function Rs(l, t) {
    if (
      t.memoizedState === null &&
      ((l = t.alternate),
      l !== null &&
        ((l = l.memoizedState), l !== null && ((l = l.dehydrated), l !== null)))
    )
      try {
        ce(l);
      } catch (a) {
        C(t, t.return, a);
      }
  }
  function b1(l) {
    switch (l.tag) {
      case 13:
      case 19:
        var t = l.stateNode;
        return (t === null && (t = l.stateNode = new Us()), t);
      case 22:
        return (
          (l = l.stateNode),
          (t = l._retryCache),
          t === null && (t = l._retryCache = new Us()),
          t
        );
      default:
        throw Error(o(435, l.tag));
    }
  }
  function cf(l, t) {
    var a = b1(l);
    t.forEach(function (u) {
      var e = O1.bind(null, l, u);
      a.has(u) || (a.add(u), u.then(e, e));
    });
  }
  function _l(l, t) {
    var a = t.deletions;
    if (a !== null)
      for (var u = 0; u < a.length; u++) {
        var e = a[u],
          n = l,
          c = t,
          f = c;
        l: for (; f !== null; ) {
          switch (f.tag) {
            case 27:
              if (Wt(f.type)) {
                ((w = f.stateNode), (Dl = !1));
                break l;
              }
              break;
            case 5:
              ((w = f.stateNode), (Dl = !1));
              break l;
            case 3:
            case 4:
              ((w = f.stateNode.containerInfo), (Dl = !0));
              break l;
          }
          f = f.return;
        }
        if (w === null) throw Error(o(160));
        (_s(n, c, e),
          (w = null),
          (Dl = !1),
          (n = e.alternate),
          n !== null && (n.return = null),
          (e.return = null));
      }
    if (t.subtreeFlags & 13878)
      for (t = t.child; t !== null; ) (qs(t, l), (t = t.sibling));
  }
  var Il = null;
  function qs(l, t) {
    var a = l.alternate,
      u = l.flags;
    switch (l.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        (_l(t, l),
          Rl(l),
          u & 4 && (Qt(3, l, l.return), Vu(3, l), Qt(5, l, l.return)));
        break;
      case 1:
        (_l(t, l),
          Rl(l),
          u & 512 && (tl || a === null || nt(a, a.return)),
          u & 64 &&
            Mt &&
            ((l = l.updateQueue),
            l !== null &&
              ((u = l.callbacks),
              u !== null &&
                ((a = l.shared.hiddenCallbacks),
                (l.shared.hiddenCallbacks = a === null ? u : a.concat(u))))));
        break;
      case 26:
        var e = Il;
        if (
          (_l(t, l),
          Rl(l),
          u & 512 && (tl || a === null || nt(a, a.return)),
          u & 4)
        ) {
          var n = a !== null ? a.memoizedState : null;
          if (((u = l.memoizedState), a === null))
            if (u === null)
              if (l.stateNode === null) {
                l: {
                  ((u = l.type),
                    (a = l.memoizedProps),
                    (e = e.ownerDocument || e));
                  t: switch (u) {
                    case 'title':
                      ((n = e.getElementsByTagName('title')[0]),
                        (!n ||
                          n[yu] ||
                          n[bl] ||
                          n.namespaceURI === 'http://www.w3.org/2000/svg' ||
                          n.hasAttribute('itemprop')) &&
                          ((n = e.createElement(u)),
                          e.head.insertBefore(
                            n,
                            e.querySelector('head > title'),
                          )),
                        ol(n, u, a),
                        (n[bl] = l),
                        il(n),
                        (u = n));
                      break l;
                    case 'link':
                      var c = xd('link', 'href', e).get(u + (a.href || ''));
                      if (c) {
                        for (var f = 0; f < c.length; f++)
                          if (
                            ((n = c[f]),
                            n.getAttribute('href') ===
                              (a.href == null || a.href === ''
                                ? null
                                : a.href) &&
                              n.getAttribute('rel') ===
                                (a.rel == null ? null : a.rel) &&
                              n.getAttribute('title') ===
                                (a.title == null ? null : a.title) &&
                              n.getAttribute('crossorigin') ===
                                (a.crossOrigin == null ? null : a.crossOrigin))
                          ) {
                            c.splice(f, 1);
                            break t;
                          }
                      }
                      ((n = e.createElement(u)),
                        ol(n, u, a),
                        e.head.appendChild(n));
                      break;
                    case 'meta':
                      if (
                        (c = xd('meta', 'content', e).get(
                          u + (a.content || ''),
                        ))
                      ) {
                        for (f = 0; f < c.length; f++)
                          if (
                            ((n = c[f]),
                            n.getAttribute('content') ===
                              (a.content == null ? null : '' + a.content) &&
                              n.getAttribute('name') ===
                                (a.name == null ? null : a.name) &&
                              n.getAttribute('property') ===
                                (a.property == null ? null : a.property) &&
                              n.getAttribute('http-equiv') ===
                                (a.httpEquiv == null ? null : a.httpEquiv) &&
                              n.getAttribute('charset') ===
                                (a.charSet == null ? null : a.charSet))
                          ) {
                            c.splice(f, 1);
                            break t;
                          }
                      }
                      ((n = e.createElement(u)),
                        ol(n, u, a),
                        e.head.appendChild(n));
                      break;
                    default:
                      throw Error(o(468, u));
                  }
                  ((n[bl] = l), il(n), (u = n));
                }
                l.stateNode = u;
              } else Ud(e, l.type, l.stateNode);
            else l.stateNode = Od(e, u, l.memoizedProps);
          else
            n !== u
              ? (n === null
                  ? a.stateNode !== null &&
                    ((a = a.stateNode), a.parentNode.removeChild(a))
                  : n.count--,
                u === null
                  ? Ud(e, l.type, l.stateNode)
                  : Od(e, u, l.memoizedProps))
              : u === null &&
                l.stateNode !== null &&
                af(l, l.memoizedProps, a.memoizedProps);
        }
        break;
      case 27:
        (_l(t, l),
          Rl(l),
          u & 512 && (tl || a === null || nt(a, a.return)),
          a !== null && u & 4 && af(l, l.memoizedProps, a.memoizedProps));
        break;
      case 5:
        if (
          (_l(t, l),
          Rl(l),
          u & 512 && (tl || a === null || nt(a, a.return)),
          l.flags & 32)
        ) {
          e = l.stateNode;
          try {
            Ha(e, '');
          } catch (m) {
            C(l, l.return, m);
          }
        }
        (u & 4 &&
          l.stateNode != null &&
          ((e = l.memoizedProps), af(l, e, a !== null ? a.memoizedProps : e)),
          u & 1024 && (nf = !0));
        break;
      case 6:
        if ((_l(t, l), Rl(l), u & 4)) {
          if (l.stateNode === null) throw Error(o(162));
          ((u = l.memoizedProps), (a = l.stateNode));
          try {
            a.nodeValue = u;
          } catch (m) {
            C(l, l.return, m);
          }
        }
        break;
      case 3:
        if (
          ((zn = null),
          (e = Il),
          (Il = Sn(t.containerInfo)),
          _l(t, l),
          (Il = e),
          Rl(l),
          u & 4 && a !== null && a.memoizedState.isDehydrated)
        )
          try {
            ce(t.containerInfo);
          } catch (m) {
            C(l, l.return, m);
          }
        nf && ((nf = !1), ps(l));
        break;
      case 4:
        ((u = Il),
          (Il = Sn(l.stateNode.containerInfo)),
          _l(t, l),
          Rl(l),
          (Il = u));
        break;
      case 12:
        (_l(t, l), Rl(l));
        break;
      case 13:
        (_l(t, l),
          Rl(l),
          l.child.flags & 8192 &&
            (l.memoizedState !== null) !=
              (a !== null && a.memoizedState !== null) &&
            (yf = at()),
          u & 4 &&
            ((u = l.updateQueue),
            u !== null && ((l.updateQueue = null), cf(l, u))));
        break;
      case 22:
        e = l.memoizedState !== null;
        var i = a !== null && a.memoizedState !== null,
          v = Mt,
          g = tl;
        if (
          ((Mt = v || e),
          (tl = g || i),
          _l(t, l),
          (tl = g),
          (Mt = v),
          Rl(l),
          u & 8192)
        )
          l: for (
            t = l.stateNode,
              t._visibility = e ? t._visibility & -2 : t._visibility | 1,
              e && (a === null || i || Mt || tl || ba(l)),
              a = null,
              t = l;
            ;

          ) {
            if (t.tag === 5 || t.tag === 26) {
              if (a === null) {
                i = a = t;
                try {
                  if (((n = i.stateNode), e))
                    ((c = n.style),
                      typeof c.setProperty == 'function'
                        ? c.setProperty('display', 'none', 'important')
                        : (c.display = 'none'));
                  else {
                    f = i.stateNode;
                    var r = i.memoizedProps.style,
                      y =
                        r != null && r.hasOwnProperty('display')
                          ? r.display
                          : null;
                    f.style.display =
                      y == null || typeof y == 'boolean' ? '' : ('' + y).trim();
                  }
                } catch (m) {
                  C(i, i.return, m);
                }
              }
            } else if (t.tag === 6) {
              if (a === null) {
                i = t;
                try {
                  i.stateNode.nodeValue = e ? '' : i.memoizedProps;
                } catch (m) {
                  C(i, i.return, m);
                }
              }
            } else if (
              ((t.tag !== 22 && t.tag !== 23) ||
                t.memoizedState === null ||
                t === l) &&
              t.child !== null
            ) {
              ((t.child.return = t), (t = t.child));
              continue;
            }
            if (t === l) break l;
            for (; t.sibling === null; ) {
              if (t.return === null || t.return === l) break l;
              (a === t && (a = null), (t = t.return));
            }
            (a === t && (a = null),
              (t.sibling.return = t.return),
              (t = t.sibling));
          }
        u & 4 &&
          ((u = l.updateQueue),
          u !== null &&
            ((a = u.retryQueue),
            a !== null && ((u.retryQueue = null), cf(l, a))));
        break;
      case 19:
        (_l(t, l),
          Rl(l),
          u & 4 &&
            ((u = l.updateQueue),
            u !== null && ((l.updateQueue = null), cf(l, u))));
        break;
      case 30:
        break;
      case 21:
        break;
      default:
        (_l(t, l), Rl(l));
    }
  }
  function Rl(l) {
    var t = l.flags;
    if (t & 2) {
      try {
        for (var a, u = l.return; u !== null; ) {
          if (Os(u)) {
            a = u;
            break;
          }
          u = u.return;
        }
        if (a == null) throw Error(o(160));
        switch (a.tag) {
          case 27:
            var e = a.stateNode,
              n = uf(l);
            en(l, n, e);
            break;
          case 5:
            var c = a.stateNode;
            a.flags & 32 && (Ha(c, ''), (a.flags &= -33));
            var f = uf(l);
            en(l, f, c);
            break;
          case 3:
          case 4:
            var i = a.stateNode.containerInfo,
              v = uf(l);
            ef(l, v, i);
            break;
          default:
            throw Error(o(161));
        }
      } catch (g) {
        C(l, l.return, g);
      }
      l.flags &= -3;
    }
    t & 4096 && (l.flags &= -4097);
  }
  function ps(l) {
    if (l.subtreeFlags & 1024)
      for (l = l.child; l !== null; ) {
        var t = l;
        (ps(t),
          t.tag === 5 && t.flags & 1024 && t.stateNode.reset(),
          (l = l.sibling));
      }
  }
  function Zt(l, t) {
    if (t.subtreeFlags & 8772)
      for (t = t.child; t !== null; ) (Ns(l, t.alternate, t), (t = t.sibling));
  }
  function ba(l) {
    for (l = l.child; l !== null; ) {
      var t = l;
      switch (t.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          (Qt(4, t, t.return), ba(t));
          break;
        case 1:
          nt(t, t.return);
          var a = t.stateNode;
          (typeof a.componentWillUnmount == 'function' && Es(t, t.return, a),
            ba(t));
          break;
        case 27:
          Iu(t.stateNode);
        case 26:
        case 5:
          (nt(t, t.return), ba(t));
          break;
        case 22:
          t.memoizedState === null && ba(t);
          break;
        case 30:
          ba(t);
          break;
        default:
          ba(t);
      }
      l = l.sibling;
    }
  }
  function Vt(l, t, a) {
    for (a = a && (t.subtreeFlags & 8772) !== 0, t = t.child; t !== null; ) {
      var u = t.alternate,
        e = l,
        n = t,
        c = n.flags;
      switch (n.tag) {
        case 0:
        case 11:
        case 15:
          (Vt(e, n, a), Vu(4, n));
          break;
        case 1:
          if (
            (Vt(e, n, a),
            (u = n),
            (e = u.stateNode),
            typeof e.componentDidMount == 'function')
          )
            try {
              e.componentDidMount();
            } catch (v) {
              C(u, u.return, v);
            }
          if (((u = n), (e = u.updateQueue), e !== null)) {
            var f = u.stateNode;
            try {
              var i = e.shared.hiddenCallbacks;
              if (i !== null)
                for (e.shared.hiddenCallbacks = null, e = 0; e < i.length; e++)
                  s0(i[e], f);
            } catch (v) {
              C(u, u.return, v);
            }
          }
          (a && c & 64 && Ms(n), Cu(n, n.return));
          break;
        case 27:
          xs(n);
        case 26:
        case 5:
          (Vt(e, n, a), a && u === null && c & 4 && Ds(n), Cu(n, n.return));
          break;
        case 12:
          Vt(e, n, a);
          break;
        case 13:
          (Vt(e, n, a), a && c & 4 && Rs(e, n));
          break;
        case 22:
          (n.memoizedState === null && Vt(e, n, a), Cu(n, n.return));
          break;
        case 30:
          break;
        default:
          Vt(e, n, a);
      }
      t = t.sibling;
    }
  }
  function ff(l, t) {
    var a = null;
    (l !== null &&
      l.memoizedState !== null &&
      l.memoizedState.cachePool !== null &&
      (a = l.memoizedState.cachePool.pool),
      (l = null),
      t.memoizedState !== null &&
        t.memoizedState.cachePool !== null &&
        (l = t.memoizedState.cachePool.pool),
      l !== a && (l != null && l.refCount++, a != null && Uu(a)));
  }
  function sf(l, t) {
    ((l = null),
      t.alternate !== null && (l = t.alternate.memoizedState.cache),
      (t = t.memoizedState.cache),
      t !== l && (t.refCount++, l != null && Uu(l)));
  }
  function ct(l, t, a, u) {
    if (t.subtreeFlags & 10256)
      for (t = t.child; t !== null; ) (Bs(l, t, a, u), (t = t.sibling));
  }
  function Bs(l, t, a, u) {
    var e = t.flags;
    switch (t.tag) {
      case 0:
      case 11:
      case 15:
        (ct(l, t, a, u), e & 2048 && Vu(9, t));
        break;
      case 1:
        ct(l, t, a, u);
        break;
      case 3:
        (ct(l, t, a, u),
          e & 2048 &&
            ((l = null),
            t.alternate !== null && (l = t.alternate.memoizedState.cache),
            (t = t.memoizedState.cache),
            t !== l && (t.refCount++, l != null && Uu(l))));
        break;
      case 12:
        if (e & 2048) {
          (ct(l, t, a, u), (l = t.stateNode));
          try {
            var n = t.memoizedProps,
              c = n.id,
              f = n.onPostCommit;
            typeof f == 'function' &&
              f(
                c,
                t.alternate === null ? 'mount' : 'update',
                l.passiveEffectDuration,
                -0,
              );
          } catch (i) {
            C(t, t.return, i);
          }
        } else ct(l, t, a, u);
        break;
      case 13:
        ct(l, t, a, u);
        break;
      case 23:
        break;
      case 22:
        ((n = t.stateNode),
          (c = t.alternate),
          t.memoizedState !== null
            ? n._visibility & 2
              ? ct(l, t, a, u)
              : Ku(l, t)
            : n._visibility & 2
              ? ct(l, t, a, u)
              : ((n._visibility |= 2),
                ka(l, t, a, u, (t.subtreeFlags & 10256) !== 0)),
          e & 2048 && ff(c, t));
        break;
      case 24:
        (ct(l, t, a, u), e & 2048 && sf(t.alternate, t));
        break;
      default:
        ct(l, t, a, u);
    }
  }
  function ka(l, t, a, u, e) {
    for (e = e && (t.subtreeFlags & 10256) !== 0, t = t.child; t !== null; ) {
      var n = l,
        c = t,
        f = a,
        i = u,
        v = c.flags;
      switch (c.tag) {
        case 0:
        case 11:
        case 15:
          (ka(n, c, f, i, e), Vu(8, c));
          break;
        case 23:
          break;
        case 22:
          var g = c.stateNode;
          (c.memoizedState !== null
            ? g._visibility & 2
              ? ka(n, c, f, i, e)
              : Ku(n, c)
            : ((g._visibility |= 2), ka(n, c, f, i, e)),
            e && v & 2048 && ff(c.alternate, c));
          break;
        case 24:
          (ka(n, c, f, i, e), e && v & 2048 && sf(c.alternate, c));
          break;
        default:
          ka(n, c, f, i, e);
      }
      t = t.sibling;
    }
  }
  function Ku(l, t) {
    if (t.subtreeFlags & 10256)
      for (t = t.child; t !== null; ) {
        var a = l,
          u = t,
          e = u.flags;
        switch (u.tag) {
          case 22:
            (Ku(a, u), e & 2048 && ff(u.alternate, u));
            break;
          case 24:
            (Ku(a, u), e & 2048 && sf(u.alternate, u));
            break;
          default:
            Ku(a, u);
        }
        t = t.sibling;
      }
  }
  var Lu = 8192;
  function $a(l) {
    if (l.subtreeFlags & Lu)
      for (l = l.child; l !== null; ) (Ys(l), (l = l.sibling));
  }
  function Ys(l) {
    switch (l.tag) {
      case 26:
        ($a(l),
          l.flags & Lu &&
            l.memoizedState !== null &&
            av(Il, l.memoizedState, l.memoizedProps));
        break;
      case 5:
        $a(l);
        break;
      case 3:
      case 4:
        var t = Il;
        ((Il = Sn(l.stateNode.containerInfo)), $a(l), (Il = t));
        break;
      case 22:
        l.memoizedState === null &&
          ((t = l.alternate),
          t !== null && t.memoizedState !== null
            ? ((t = Lu), (Lu = 16777216), $a(l), (Lu = t))
            : $a(l));
        break;
      default:
        $a(l);
    }
  }
  function js(l) {
    var t = l.alternate;
    if (t !== null && ((l = t.child), l !== null)) {
      t.child = null;
      do ((t = l.sibling), (l.sibling = null), (l = t));
      while (l !== null);
    }
  }
  function Ju(l) {
    var t = l.deletions;
    if ((l.flags & 16) !== 0) {
      if (t !== null)
        for (var a = 0; a < t.length; a++) {
          var u = t[a];
          ((dl = u), Xs(u, l));
        }
      js(l);
    }
    if (l.subtreeFlags & 10256)
      for (l = l.child; l !== null; ) (Gs(l), (l = l.sibling));
  }
  function Gs(l) {
    switch (l.tag) {
      case 0:
      case 11:
      case 15:
        (Ju(l), l.flags & 2048 && Qt(9, l, l.return));
        break;
      case 3:
        Ju(l);
        break;
      case 12:
        Ju(l);
        break;
      case 22:
        var t = l.stateNode;
        l.memoizedState !== null &&
        t._visibility & 2 &&
        (l.return === null || l.return.tag !== 13)
          ? ((t._visibility &= -3), nn(l))
          : Ju(l);
        break;
      default:
        Ju(l);
    }
  }
  function nn(l) {
    var t = l.deletions;
    if ((l.flags & 16) !== 0) {
      if (t !== null)
        for (var a = 0; a < t.length; a++) {
          var u = t[a];
          ((dl = u), Xs(u, l));
        }
      js(l);
    }
    for (l = l.child; l !== null; ) {
      switch (((t = l), t.tag)) {
        case 0:
        case 11:
        case 15:
          (Qt(8, t, t.return), nn(t));
          break;
        case 22:
          ((a = t.stateNode),
            a._visibility & 2 && ((a._visibility &= -3), nn(t)));
          break;
        default:
          nn(t);
      }
      l = l.sibling;
    }
  }
  function Xs(l, t) {
    for (; dl !== null; ) {
      var a = dl;
      switch (a.tag) {
        case 0:
        case 11:
        case 15:
          Qt(8, a, t);
          break;
        case 23:
        case 22:
          if (a.memoizedState !== null && a.memoizedState.cachePool !== null) {
            var u = a.memoizedState.cachePool.pool;
            u != null && u.refCount++;
          }
          break;
        case 24:
          Uu(a.memoizedState.cache);
      }
      if (((u = a.child), u !== null)) ((u.return = a), (dl = u));
      else
        l: for (a = l; dl !== null; ) {
          u = dl;
          var e = u.sibling,
            n = u.return;
          if ((Hs(u), u === a)) {
            dl = null;
            break l;
          }
          if (e !== null) {
            ((e.return = n), (dl = e));
            break l;
          }
          dl = n;
        }
    }
  }
  var S1 = {
      getCacheForType: function (l) {
        var t = Sl(nl),
          a = t.data.get(l);
        return (a === void 0 && ((a = l()), t.data.set(l, a)), a);
      },
    },
    r1 = typeof WeakMap == 'function' ? WeakMap : Map,
    Y = 0,
    K = null,
    _ = null,
    q = 0,
    j = 0,
    ql = null,
    Ct = !1,
    Fa = !1,
    df = !1,
    Dt = 0,
    I = 0,
    Kt = 0,
    Sa = 0,
    hf = 0,
    Jl = 0,
    Ia = 0,
    wu = null,
    Ol = null,
    vf = !1,
    yf = 0,
    cn = 1 / 0,
    fn = null,
    Lt = null,
    ml = 0,
    Jt = null,
    Pa = null,
    lu = 0,
    mf = 0,
    of = null,
    Qs = null,
    Wu = 0,
    gf = null;
  function pl() {
    if ((Y & 2) !== 0 && q !== 0) return q & -q;
    if (S.T !== null) {
      var l = Za;
      return l !== 0 ? l : Mf();
    }
    return ai();
  }
  function Zs() {
    Jl === 0 && (Jl = (q & 536870912) === 0 || B ? If() : 536870912);
    var l = Ll.current;
    return (l !== null && (l.flags |= 32), Jl);
  }
  function Bl(l, t, a) {
    (((l === K && (j === 2 || j === 9)) || l.cancelPendingCommit !== null) &&
      (tu(l, 0), wt(l, q, Jl, !1)),
      vu(l, a),
      ((Y & 2) === 0 || l !== K) &&
        (l === K && ((Y & 2) === 0 && (Sa |= a), I === 4 && wt(l, q, Jl, !1)),
        ft(l)));
  }
  function Vs(l, t, a) {
    if ((Y & 6) !== 0) throw Error(o(327));
    var u = (!a && (t & 124) === 0 && (t & l.expiredLanes) === 0) || hu(l, t),
      e = u ? T1(l, t) : rf(l, t, !0),
      n = u;
    do {
      if (e === 0) {
        Fa && !u && wt(l, t, 0, !1);
        break;
      } else {
        if (((a = l.current.alternate), n && !z1(a))) {
          ((e = rf(l, t, !1)), (n = !1));
          continue;
        }
        if (e === 2) {
          if (((n = t), l.errorRecoveryDisabledLanes & n)) var c = 0;
          else
            ((c = l.pendingLanes & -536870913),
              (c = c !== 0 ? c : c & 536870912 ? 536870912 : 0));
          if (c !== 0) {
            t = c;
            l: {
              var f = l;
              e = wu;
              var i = f.current.memoizedState.isDehydrated;
              if ((i && (tu(f, c).flags |= 256), (c = rf(f, c, !1)), c !== 2)) {
                if (df && !i) {
                  ((f.errorRecoveryDisabledLanes |= n), (Sa |= n), (e = 4));
                  break l;
                }
                ((n = Ol),
                  (Ol = e),
                  n !== null &&
                    (Ol === null ? (Ol = n) : Ol.push.apply(Ol, n)));
              }
              e = c;
            }
            if (((n = !1), e !== 2)) continue;
          }
        }
        if (e === 1) {
          (tu(l, 0), wt(l, t, 0, !0));
          break;
        }
        l: {
          switch (((u = l), (n = e), n)) {
            case 0:
            case 1:
              throw Error(o(345));
            case 4:
              if ((t & 4194048) !== t) break;
            case 6:
              wt(u, t, Jl, !Ct);
              break l;
            case 2:
              Ol = null;
              break;
            case 3:
            case 5:
              break;
            default:
              throw Error(o(329));
          }
          if ((t & 62914560) === t && ((e = yf + 300 - at()), 10 < e)) {
            if ((wt(u, t, Jl, !Ct), Se(u, 0, !0) !== 0)) break l;
            u.timeoutHandle = bd(
              Cs.bind(null, u, a, Ol, fn, vf, t, Jl, Sa, Ia, Ct, n, 2, -0, 0),
              e,
            );
            break l;
          }
          Cs(u, a, Ol, fn, vf, t, Jl, Sa, Ia, Ct, n, 0, -0, 0);
        }
      }
      break;
    } while (!0);
    ft(l);
  }
  function Cs(l, t, a, u, e, n, c, f, i, v, g, r, y, m) {
    if (
      ((l.timeoutHandle = -1),
      (r = t.subtreeFlags),
      (r & 8192 || (r & 16785408) === 16785408) &&
        ((te = { stylesheets: null, count: 0, unsuspend: tv }),
        Ys(t),
        (r = uv()),
        r !== null))
    ) {
      ((l.cancelPendingCommit = r(
        $s.bind(null, l, t, n, a, u, e, c, f, i, g, 1, y, m),
      )),
        wt(l, n, c, !v));
      return;
    }
    $s(l, t, n, a, u, e, c, f, i);
  }
  function z1(l) {
    for (var t = l; ; ) {
      var a = t.tag;
      if (
        (a === 0 || a === 11 || a === 15) &&
        t.flags & 16384 &&
        ((a = t.updateQueue), a !== null && ((a = a.stores), a !== null))
      )
        for (var u = 0; u < a.length; u++) {
          var e = a[u],
            n = e.getSnapshot;
          e = e.value;
          try {
            if (!Nl(n(), e)) return !1;
          } catch {
            return !1;
          }
        }
      if (((a = t.child), t.subtreeFlags & 16384 && a !== null))
        ((a.return = t), (t = a));
      else {
        if (t === l) break;
        for (; t.sibling === null; ) {
          if (t.return === null || t.return === l) return !0;
          t = t.return;
        }
        ((t.sibling.return = t.return), (t = t.sibling));
      }
    }
    return !0;
  }
  function wt(l, t, a, u) {
    ((t &= ~hf),
      (t &= ~Sa),
      (l.suspendedLanes |= t),
      (l.pingedLanes &= ~t),
      u && (l.warmLanes |= t),
      (u = l.expirationTimes));
    for (var e = t; 0 < e; ) {
      var n = 31 - Ul(e),
        c = 1 << n;
      ((u[n] = -1), (e &= ~c));
    }
    a !== 0 && li(l, a, t);
  }
  function sn() {
    return (Y & 6) === 0 ? (ku(0), !1) : !0;
  }
  function bf() {
    if (_ !== null) {
      if (j === 0) var l = _.return;
      else ((l = _), (bt = va = null), qc(l), (wa = null), (Xu = 0), (l = _));
      for (; l !== null; ) (Ts(l.alternate, l), (l = l.return));
      _ = null;
    }
  }
  function tu(l, t) {
    var a = l.timeoutHandle;
    (a !== -1 && ((l.timeoutHandle = -1), G1(a)),
      (a = l.cancelPendingCommit),
      a !== null && ((l.cancelPendingCommit = null), a()),
      bf(),
      (K = l),
      (_ = a = mt(l.current, null)),
      (q = t),
      (j = 0),
      (ql = null),
      (Ct = !1),
      (Fa = hu(l, t)),
      (df = !1),
      (Ia = Jl = hf = Sa = Kt = I = 0),
      (Ol = wu = null),
      (vf = !1),
      (t & 8) !== 0 && (t |= t & 32));
    var u = l.entangledLanes;
    if (u !== 0)
      for (l = l.entanglements, u &= t; 0 < u; ) {
        var e = 31 - Ul(u),
          n = 1 << e;
        ((t |= l[e]), (u &= ~n));
      }
    return ((Dt = t), He(), a);
  }
  function Ks(l, t) {
    ((N = null),
      (S.H = ke),
      t === Hu || t === Xe
        ? ((t = f0()), (j = 3))
        : t === e0
          ? ((t = f0()), (j = 4))
          : (j =
              t === is
                ? 8
                : t !== null &&
                    typeof t == 'object' &&
                    typeof t.then == 'function'
                  ? 6
                  : 1),
      (ql = t),
      _ === null && ((I = 1), ln(l, Zl(t, l.current))));
  }
  function Ls() {
    var l = S.H;
    return ((S.H = ke), l === null ? ke : l);
  }
  function Js() {
    var l = S.A;
    return ((S.A = S1), l);
  }
  function Sf() {
    ((I = 4),
      Ct || ((q & 4194048) !== q && Ll.current !== null) || (Fa = !0),
      ((Kt & 134217727) === 0 && (Sa & 134217727) === 0) ||
        K === null ||
        wt(K, q, Jl, !1));
  }
  function rf(l, t, a) {
    var u = Y;
    Y |= 2;
    var e = Ls(),
      n = Js();
    ((K !== l || q !== t) && ((fn = null), tu(l, t)), (t = !1));
    var c = I;
    l: do
      try {
        if (j !== 0 && _ !== null) {
          var f = _,
            i = ql;
          switch (j) {
            case 8:
              (bf(), (c = 6));
              break l;
            case 3:
            case 2:
            case 9:
            case 6:
              Ll.current === null && (t = !0);
              var v = j;
              if (((j = 0), (ql = null), au(l, f, i, v), a && Fa)) {
                c = 0;
                break l;
              }
              break;
            default:
              ((v = j), (j = 0), (ql = null), au(l, f, i, v));
          }
        }
        (A1(), (c = I));
        break;
      } catch (g) {
        Ks(l, g);
      }
    while (!0);
    return (
      t && l.shellSuspendCounter++,
      (bt = va = null),
      (Y = u),
      (S.H = e),
      (S.A = n),
      _ === null && ((K = null), (q = 0), He()),
      c
    );
  }
  function A1() {
    for (; _ !== null; ) ws(_);
  }
  function T1(l, t) {
    var a = Y;
    Y |= 2;
    var u = Ls(),
      e = Js();
    K !== l || q !== t
      ? ((fn = null), (cn = at() + 500), tu(l, t))
      : (Fa = hu(l, t));
    l: do
      try {
        if (j !== 0 && _ !== null) {
          t = _;
          var n = ql;
          t: switch (j) {
            case 1:
              ((j = 0), (ql = null), au(l, t, n, 1));
              break;
            case 2:
            case 9:
              if (n0(n)) {
                ((j = 0), (ql = null), Ws(t));
                break;
              }
              ((t = function () {
                ((j !== 2 && j !== 9) || K !== l || (j = 7), ft(l));
              }),
                n.then(t, t));
              break l;
            case 3:
              j = 7;
              break l;
            case 4:
              j = 5;
              break l;
            case 7:
              n0(n)
                ? ((j = 0), (ql = null), Ws(t))
                : ((j = 0), (ql = null), au(l, t, n, 7));
              break;
            case 5:
              var c = null;
              switch (_.tag) {
                case 26:
                  c = _.memoizedState;
                case 5:
                case 27:
                  var f = _;
                  if (!c || Nd(c)) {
                    ((j = 0), (ql = null));
                    var i = f.sibling;
                    if (i !== null) _ = i;
                    else {
                      var v = f.return;
                      v !== null ? ((_ = v), dn(v)) : (_ = null);
                    }
                    break t;
                  }
              }
              ((j = 0), (ql = null), au(l, t, n, 5));
              break;
            case 6:
              ((j = 0), (ql = null), au(l, t, n, 6));
              break;
            case 8:
              (bf(), (I = 6));
              break l;
            default:
              throw Error(o(462));
          }
        }
        M1();
        break;
      } catch (g) {
        Ks(l, g);
      }
    while (!0);
    return (
      (bt = va = null),
      (S.H = u),
      (S.A = e),
      (Y = a),
      _ !== null ? 0 : ((K = null), (q = 0), He(), I)
    );
  }
  function M1() {
    for (; _ !== null && !Ld(); ) ws(_);
  }
  function ws(l) {
    var t = zs(l.alternate, l, Dt);
    ((l.memoizedProps = l.pendingProps), t === null ? dn(l) : (_ = t));
  }
  function Ws(l) {
    var t = l,
      a = t.alternate;
    switch (t.tag) {
      case 15:
      case 0:
        t = ms(a, t, t.pendingProps, t.type, void 0, q);
        break;
      case 11:
        t = ms(a, t, t.pendingProps, t.type.render, t.ref, q);
        break;
      case 5:
        qc(t);
      default:
        (Ts(a, t), (t = _ = ki(t, Dt)), (t = zs(a, t, Dt)));
    }
    ((l.memoizedProps = l.pendingProps), t === null ? dn(l) : (_ = t));
  }
  function au(l, t, a, u) {
    ((bt = va = null), qc(t), (wa = null), (Xu = 0));
    var e = t.return;
    try {
      if (v1(l, e, t, a, q)) {
        ((I = 1), ln(l, Zl(a, l.current)), (_ = null));
        return;
      }
    } catch (n) {
      if (e !== null) throw ((_ = e), n);
      ((I = 1), ln(l, Zl(a, l.current)), (_ = null));
      return;
    }
    t.flags & 32768
      ? (B || u === 1
          ? (l = !0)
          : Fa || (q & 536870912) !== 0
            ? (l = !1)
            : ((Ct = l = !0),
              (u === 2 || u === 9 || u === 3 || u === 6) &&
                ((u = Ll.current),
                u !== null && u.tag === 13 && (u.flags |= 16384))),
        ks(t, l))
      : dn(t);
  }
  function dn(l) {
    var t = l;
    do {
      if ((t.flags & 32768) !== 0) {
        ks(t, Ct);
        return;
      }
      l = t.return;
      var a = m1(t.alternate, t, Dt);
      if (a !== null) {
        _ = a;
        return;
      }
      if (((t = t.sibling), t !== null)) {
        _ = t;
        return;
      }
      _ = t = l;
    } while (t !== null);
    I === 0 && (I = 5);
  }
  function ks(l, t) {
    do {
      var a = o1(l.alternate, l);
      if (a !== null) {
        ((a.flags &= 32767), (_ = a));
        return;
      }
      if (
        ((a = l.return),
        a !== null &&
          ((a.flags |= 32768), (a.subtreeFlags = 0), (a.deletions = null)),
        !t && ((l = l.sibling), l !== null))
      ) {
        _ = l;
        return;
      }
      _ = l = a;
    } while (l !== null);
    ((I = 6), (_ = null));
  }
  function $s(l, t, a, u, e, n, c, f, i) {
    l.cancelPendingCommit = null;
    do hn();
    while (ml !== 0);
    if ((Y & 6) !== 0) throw Error(o(327));
    if (t !== null) {
      if (t === l.current) throw Error(o(177));
      if (
        ((n = t.lanes | t.childLanes),
        (n |= ic),
        th(l, a, n, c, f, i),
        l === K && ((_ = K = null), (q = 0)),
        (Pa = t),
        (Jt = l),
        (lu = a),
        (mf = n),
        (of = e),
        (Qs = u),
        (t.subtreeFlags & 10256) !== 0 || (t.flags & 10256) !== 0
          ? ((l.callbackNode = null),
            (l.callbackPriority = 0),
            x1(oe, function () {
              return (td(), null);
            }))
          : ((l.callbackNode = null), (l.callbackPriority = 0)),
        (u = (t.flags & 13878) !== 0),
        (t.subtreeFlags & 13878) !== 0 || u)
      ) {
        ((u = S.T), (S.T = null), (e = A.p), (A.p = 2), (c = Y), (Y |= 4));
        try {
          g1(l, t, a);
        } finally {
          ((Y = c), (A.p = e), (S.T = u));
        }
      }
      ((ml = 1), Fs(), Is(), Ps());
    }
  }
  function Fs() {
    if (ml === 1) {
      ml = 0;
      var l = Jt,
        t = Pa,
        a = (t.flags & 13878) !== 0;
      if ((t.subtreeFlags & 13878) !== 0 || a) {
        ((a = S.T), (S.T = null));
        var u = A.p;
        A.p = 2;
        var e = Y;
        Y |= 4;
        try {
          qs(t, l);
          var n = _f,
            c = Xi(l.containerInfo),
            f = n.focusedElem,
            i = n.selectionRange;
          if (
            c !== f &&
            f &&
            f.ownerDocument &&
            Gi(f.ownerDocument.documentElement, f)
          ) {
            if (i !== null && uc(f)) {
              var v = i.start,
                g = i.end;
              if ((g === void 0 && (g = v), 'selectionStart' in f))
                ((f.selectionStart = v),
                  (f.selectionEnd = Math.min(g, f.value.length)));
              else {
                var r = f.ownerDocument || document,
                  y = (r && r.defaultView) || window;
                if (y.getSelection) {
                  var m = y.getSelection(),
                    x = f.textContent.length,
                    D = Math.min(i.start, x),
                    Z = i.end === void 0 ? D : Math.min(i.end, x);
                  !m.extend && D > Z && ((c = Z), (Z = D), (D = c));
                  var d = ji(f, D),
                    s = ji(f, Z);
                  if (
                    d &&
                    s &&
                    (m.rangeCount !== 1 ||
                      m.anchorNode !== d.node ||
                      m.anchorOffset !== d.offset ||
                      m.focusNode !== s.node ||
                      m.focusOffset !== s.offset)
                  ) {
                    var h = r.createRange();
                    (h.setStart(d.node, d.offset),
                      m.removeAllRanges(),
                      D > Z
                        ? (m.addRange(h), m.extend(s.node, s.offset))
                        : (h.setEnd(s.node, s.offset), m.addRange(h)));
                  }
                }
              }
            }
            for (r = [], m = f; (m = m.parentNode); )
              m.nodeType === 1 &&
                r.push({ element: m, left: m.scrollLeft, top: m.scrollTop });
            for (
              typeof f.focus == 'function' && f.focus(), f = 0;
              f < r.length;
              f++
            ) {
              var b = r[f];
              ((b.element.scrollLeft = b.left), (b.element.scrollTop = b.top));
            }
          }
          ((Mn = !!Hf), (_f = Hf = null));
        } finally {
          ((Y = e), (A.p = u), (S.T = a));
        }
      }
      ((l.current = t), (ml = 2));
    }
  }
  function Is() {
    if (ml === 2) {
      ml = 0;
      var l = Jt,
        t = Pa,
        a = (t.flags & 8772) !== 0;
      if ((t.subtreeFlags & 8772) !== 0 || a) {
        ((a = S.T), (S.T = null));
        var u = A.p;
        A.p = 2;
        var e = Y;
        Y |= 4;
        try {
          Ns(l, t.alternate, t);
        } finally {
          ((Y = e), (A.p = u), (S.T = a));
        }
      }
      ml = 3;
    }
  }
  function Ps() {
    if (ml === 4 || ml === 3) {
      ((ml = 0), Jd());
      var l = Jt,
        t = Pa,
        a = lu,
        u = Qs;
      (t.subtreeFlags & 10256) !== 0 || (t.flags & 10256) !== 0
        ? (ml = 5)
        : ((ml = 0), (Pa = Jt = null), ld(l, l.pendingLanes));
      var e = l.pendingLanes;
      if (
        (e === 0 && (Lt = null),
        Yn(a),
        (t = t.stateNode),
        xl && typeof xl.onCommitFiberRoot == 'function')
      )
        try {
          xl.onCommitFiberRoot(du, t, void 0, (t.current.flags & 128) === 128);
        } catch {}
      if (u !== null) {
        ((t = S.T), (e = A.p), (A.p = 2), (S.T = null));
        try {
          for (var n = l.onRecoverableError, c = 0; c < u.length; c++) {
            var f = u[c];
            n(f.value, { componentStack: f.stack });
          }
        } finally {
          ((S.T = t), (A.p = e));
        }
      }
      ((lu & 3) !== 0 && hn(),
        ft(l),
        (e = l.pendingLanes),
        (a & 4194090) !== 0 && (e & 42) !== 0
          ? l === gf
            ? Wu++
            : ((Wu = 0), (gf = l))
          : (Wu = 0),
        ku(0));
    }
  }
  function ld(l, t) {
    (l.pooledCacheLanes &= t) === 0 &&
      ((t = l.pooledCache), t != null && ((l.pooledCache = null), Uu(t)));
  }
  function hn(l) {
    return (Fs(), Is(), Ps(), td());
  }
  function td() {
    if (ml !== 5) return !1;
    var l = Jt,
      t = mf;
    mf = 0;
    var a = Yn(lu),
      u = S.T,
      e = A.p;
    try {
      ((A.p = 32 > a ? 32 : a), (S.T = null), (a = of), (of = null));
      var n = Jt,
        c = lu;
      if (((ml = 0), (Pa = Jt = null), (lu = 0), (Y & 6) !== 0))
        throw Error(o(331));
      var f = Y;
      if (
        ((Y |= 4),
        Gs(n.current),
        Bs(n, n.current, c, a),
        (Y = f),
        ku(0, !1),
        xl && typeof xl.onPostCommitFiberRoot == 'function')
      )
        try {
          xl.onPostCommitFiberRoot(du, n);
        } catch {}
      return !0;
    } finally {
      ((A.p = e), (S.T = u), ld(l, t));
    }
  }
  function ad(l, t, a) {
    ((t = Zl(a, t)),
      (t = wc(l.stateNode, t, 2)),
      (l = Yt(l, t, 2)),
      l !== null && (vu(l, 2), ft(l)));
  }
  function C(l, t, a) {
    if (l.tag === 3) ad(l, l, a);
    else
      for (; t !== null; ) {
        if (t.tag === 3) {
          ad(t, l, a);
          break;
        } else if (t.tag === 1) {
          var u = t.stateNode;
          if (
            typeof t.type.getDerivedStateFromError == 'function' ||
            (typeof u.componentDidCatch == 'function' &&
              (Lt === null || !Lt.has(u)))
          ) {
            ((l = Zl(a, l)),
              (a = cs(2)),
              (u = Yt(t, a, 2)),
              u !== null && (fs(a, u, t, l), vu(u, 2), ft(u)));
            break;
          }
        }
        t = t.return;
      }
  }
  function zf(l, t, a) {
    var u = l.pingCache;
    if (u === null) {
      u = l.pingCache = new r1();
      var e = new Set();
      u.set(t, e);
    } else ((e = u.get(t)), e === void 0 && ((e = new Set()), u.set(t, e)));
    e.has(a) ||
      ((df = !0), e.add(a), (l = E1.bind(null, l, t, a)), t.then(l, l));
  }
  function E1(l, t, a) {
    var u = l.pingCache;
    (u !== null && u.delete(t),
      (l.pingedLanes |= l.suspendedLanes & a),
      (l.warmLanes &= ~a),
      K === l &&
        (q & a) === a &&
        (I === 4 || (I === 3 && (q & 62914560) === q && 300 > at() - yf)
          ? (Y & 2) === 0 && tu(l, 0)
          : (hf |= a),
        Ia === q && (Ia = 0)),
      ft(l));
  }
  function ud(l, t) {
    (t === 0 && (t = Pf()), (l = ja(l, t)), l !== null && (vu(l, t), ft(l)));
  }
  function D1(l) {
    var t = l.memoizedState,
      a = 0;
    (t !== null && (a = t.retryLane), ud(l, a));
  }
  function O1(l, t) {
    var a = 0;
    switch (l.tag) {
      case 13:
        var u = l.stateNode,
          e = l.memoizedState;
        e !== null && (a = e.retryLane);
        break;
      case 19:
        u = l.stateNode;
        break;
      case 22:
        u = l.stateNode._retryCache;
        break;
      default:
        throw Error(o(314));
    }
    (u !== null && u.delete(t), ud(l, a));
  }
  function x1(l, t) {
    return Rn(l, t);
  }
  var vn = null,
    uu = null,
    Af = !1,
    yn = !1,
    Tf = !1,
    ra = 0;
  function ft(l) {
    (l !== uu &&
      l.next === null &&
      (uu === null ? (vn = uu = l) : (uu = uu.next = l)),
      (yn = !0),
      Af || ((Af = !0), N1()));
  }
  function ku(l, t) {
    if (!Tf && yn) {
      Tf = !0;
      do
        for (var a = !1, u = vn; u !== null; ) {
          if (l !== 0) {
            var e = u.pendingLanes;
            if (e === 0) var n = 0;
            else {
              var c = u.suspendedLanes,
                f = u.pingedLanes;
              ((n = (1 << (31 - Ul(42 | l) + 1)) - 1),
                (n &= e & ~(c & ~f)),
                (n = n & 201326741 ? (n & 201326741) | 1 : n ? n | 2 : 0));
            }
            n !== 0 && ((a = !0), fd(u, n));
          } else
            ((n = q),
              (n = Se(
                u,
                u === K ? n : 0,
                u.cancelPendingCommit !== null || u.timeoutHandle !== -1,
              )),
              (n & 3) === 0 || hu(u, n) || ((a = !0), fd(u, n)));
          u = u.next;
        }
      while (a);
      Tf = !1;
    }
  }
  function U1() {
    ed();
  }
  function ed() {
    yn = Af = !1;
    var l = 0;
    ra !== 0 && (j1() && (l = ra), (ra = 0));
    for (var t = at(), a = null, u = vn; u !== null; ) {
      var e = u.next,
        n = nd(u, t);
      (n === 0
        ? ((u.next = null),
          a === null ? (vn = e) : (a.next = e),
          e === null && (uu = a))
        : ((a = u), (l !== 0 || (n & 3) !== 0) && (yn = !0)),
        (u = e));
    }
    ku(l);
  }
  function nd(l, t) {
    for (
      var a = l.suspendedLanes,
        u = l.pingedLanes,
        e = l.expirationTimes,
        n = l.pendingLanes & -62914561;
      0 < n;

    ) {
      var c = 31 - Ul(n),
        f = 1 << c,
        i = e[c];
      (i === -1
        ? ((f & a) === 0 || (f & u) !== 0) && (e[c] = lh(f, t))
        : i <= t && (l.expiredLanes |= f),
        (n &= ~f));
    }
    if (
      ((t = K),
      (a = q),
      (a = Se(
        l,
        l === t ? a : 0,
        l.cancelPendingCommit !== null || l.timeoutHandle !== -1,
      )),
      (u = l.callbackNode),
      a === 0 ||
        (l === t && (j === 2 || j === 9)) ||
        l.cancelPendingCommit !== null)
    )
      return (
        u !== null && u !== null && qn(u),
        (l.callbackNode = null),
        (l.callbackPriority = 0)
      );
    if ((a & 3) === 0 || hu(l, a)) {
      if (((t = a & -a), t === l.callbackPriority)) return t;
      switch ((u !== null && qn(u), Yn(a))) {
        case 2:
        case 8:
          a = $f;
          break;
        case 32:
          a = oe;
          break;
        case 268435456:
          a = Ff;
          break;
        default:
          a = oe;
      }
      return (
        (u = cd.bind(null, l)),
        (a = Rn(a, u)),
        (l.callbackPriority = t),
        (l.callbackNode = a),
        t
      );
    }
    return (
      u !== null && u !== null && qn(u),
      (l.callbackPriority = 2),
      (l.callbackNode = null),
      2
    );
  }
  function cd(l, t) {
    if (ml !== 0 && ml !== 5)
      return ((l.callbackNode = null), (l.callbackPriority = 0), null);
    var a = l.callbackNode;
    if (hn() && l.callbackNode !== a) return null;
    var u = q;
    return (
      (u = Se(
        l,
        l === K ? u : 0,
        l.cancelPendingCommit !== null || l.timeoutHandle !== -1,
      )),
      u === 0
        ? null
        : (Vs(l, u, t),
          nd(l, at()),
          l.callbackNode != null && l.callbackNode === a
            ? cd.bind(null, l)
            : null)
    );
  }
  function fd(l, t) {
    if (hn()) return null;
    Vs(l, t, !0);
  }
  function N1() {
    X1(function () {
      (Y & 6) !== 0 ? Rn(kf, U1) : ed();
    });
  }
  function Mf() {
    return (ra === 0 && (ra = If()), ra);
  }
  function id(l) {
    return l == null || typeof l == 'symbol' || typeof l == 'boolean'
      ? null
      : typeof l == 'function'
        ? l
        : Me('' + l);
  }
  function sd(l, t) {
    var a = t.ownerDocument.createElement('input');
    return (
      (a.name = t.name),
      (a.value = t.value),
      l.id && a.setAttribute('form', l.id),
      t.parentNode.insertBefore(a, t),
      (l = new FormData(l)),
      a.parentNode.removeChild(a),
      l
    );
  }
  function H1(l, t, a, u, e) {
    if (t === 'submit' && a && a.stateNode === e) {
      var n = id((e[Tl] || null).action),
        c = u.submitter;
      c &&
        ((t = (t = c[Tl] || null)
          ? id(t.formAction)
          : c.getAttribute('formAction')),
        t !== null && ((n = t), (c = null)));
      var f = new xe('action', 'action', null, u, e);
      l.push({
        event: f,
        listeners: [
          {
            instance: null,
            listener: function () {
              if (u.defaultPrevented) {
                if (ra !== 0) {
                  var i = c ? sd(e, c) : new FormData(e);
                  Vc(
                    a,
                    { pending: !0, data: i, method: e.method, action: n },
                    null,
                    i,
                  );
                }
              } else
                typeof n == 'function' &&
                  (f.preventDefault(),
                  (i = c ? sd(e, c) : new FormData(e)),
                  Vc(
                    a,
                    { pending: !0, data: i, method: e.method, action: n },
                    n,
                    i,
                  ));
            },
            currentTarget: e,
          },
        ],
      });
    }
  }
  for (var Ef = 0; Ef < fc.length; Ef++) {
    var Df = fc[Ef],
      _1 = Df.toLowerCase(),
      R1 = Df[0].toUpperCase() + Df.slice(1);
    Fl(_1, 'on' + R1);
  }
  (Fl(Vi, 'onAnimationEnd'),
    Fl(Ci, 'onAnimationIteration'),
    Fl(Ki, 'onAnimationStart'),
    Fl('dblclick', 'onDoubleClick'),
    Fl('focusin', 'onFocus'),
    Fl('focusout', 'onBlur'),
    Fl(kh, 'onTransitionRun'),
    Fl($h, 'onTransitionStart'),
    Fl(Fh, 'onTransitionCancel'),
    Fl(Li, 'onTransitionEnd'),
    xa('onMouseEnter', ['mouseout', 'mouseover']),
    xa('onMouseLeave', ['mouseout', 'mouseover']),
    xa('onPointerEnter', ['pointerout', 'pointerover']),
    xa('onPointerLeave', ['pointerout', 'pointerover']),
    ua(
      'onChange',
      'change click focusin focusout input keydown keyup selectionchange'.split(
        ' ',
      ),
    ),
    ua(
      'onSelect',
      'focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange'.split(
        ' ',
      ),
    ),
    ua('onBeforeInput', ['compositionend', 'keypress', 'textInput', 'paste']),
    ua(
      'onCompositionEnd',
      'compositionend focusout keydown keypress keyup mousedown'.split(' '),
    ),
    ua(
      'onCompositionStart',
      'compositionstart focusout keydown keypress keyup mousedown'.split(' '),
    ),
    ua(
      'onCompositionUpdate',
      'compositionupdate focusout keydown keypress keyup mousedown'.split(' '),
    ));
  var $u =
      'abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting'.split(
        ' ',
      ),
    q1 = new Set(
      'beforetoggle cancel close invalid load scroll scrollend toggle'
        .split(' ')
        .concat($u),
    );
  function dd(l, t) {
    t = (t & 4) !== 0;
    for (var a = 0; a < l.length; a++) {
      var u = l[a],
        e = u.event;
      u = u.listeners;
      l: {
        var n = void 0;
        if (t)
          for (var c = u.length - 1; 0 <= c; c--) {
            var f = u[c],
              i = f.instance,
              v = f.currentTarget;
            if (((f = f.listener), i !== n && e.isPropagationStopped()))
              break l;
            ((n = f), (e.currentTarget = v));
            try {
              n(e);
            } catch (g) {
              Pe(g);
            }
            ((e.currentTarget = null), (n = i));
          }
        else
          for (c = 0; c < u.length; c++) {
            if (
              ((f = u[c]),
              (i = f.instance),
              (v = f.currentTarget),
              (f = f.listener),
              i !== n && e.isPropagationStopped())
            )
              break l;
            ((n = f), (e.currentTarget = v));
            try {
              n(e);
            } catch (g) {
              Pe(g);
            }
            ((e.currentTarget = null), (n = i));
          }
      }
    }
  }
  function R(l, t) {
    var a = t[jn];
    a === void 0 && (a = t[jn] = new Set());
    var u = l + '__bubble';
    a.has(u) || (hd(t, l, 2, !1), a.add(u));
  }
  function Of(l, t, a) {
    var u = 0;
    (t && (u |= 4), hd(a, l, u, t));
  }
  var mn = '_reactListening' + Math.random().toString(36).slice(2);
  function xf(l) {
    if (!l[mn]) {
      ((l[mn] = !0),
        ei.forEach(function (a) {
          a !== 'selectionchange' && (q1.has(a) || Of(a, !1, l), Of(a, !0, l));
        }));
      var t = l.nodeType === 9 ? l : l.ownerDocument;
      t === null || t[mn] || ((t[mn] = !0), Of('selectionchange', !1, t));
    }
  }
  function hd(l, t, a, u) {
    switch (Bd(t)) {
      case 2:
        var e = cv;
        break;
      case 8:
        e = fv;
        break;
      default:
        e = Zf;
    }
    ((a = e.bind(null, t, a, l)),
      (e = void 0),
      !Wn ||
        (t !== 'touchstart' && t !== 'touchmove' && t !== 'wheel') ||
        (e = !0),
      u
        ? e !== void 0
          ? l.addEventListener(t, a, { capture: !0, passive: e })
          : l.addEventListener(t, a, !0)
        : e !== void 0
          ? l.addEventListener(t, a, { passive: e })
          : l.addEventListener(t, a, !1));
  }
  function Uf(l, t, a, u, e) {
    var n = u;
    if ((t & 1) === 0 && (t & 2) === 0 && u !== null)
      l: for (;;) {
        if (u === null) return;
        var c = u.tag;
        if (c === 3 || c === 4) {
          var f = u.stateNode.containerInfo;
          if (f === e) break;
          if (c === 4)
            for (c = u.return; c !== null; ) {
              var i = c.tag;
              if ((i === 3 || i === 4) && c.stateNode.containerInfo === e)
                return;
              c = c.return;
            }
          for (; f !== null; ) {
            if (((c = Ea(f)), c === null)) return;
            if (((i = c.tag), i === 5 || i === 6 || i === 26 || i === 27)) {
              u = n = c;
              continue l;
            }
            f = f.parentNode;
          }
        }
        u = u.return;
      }
    Si(function () {
      var v = n,
        g = Jn(a),
        r = [];
      l: {
        var y = Ji.get(l);
        if (y !== void 0) {
          var m = xe,
            x = l;
          switch (l) {
            case 'keypress':
              if (De(a) === 0) break l;
            case 'keydown':
            case 'keyup':
              m = xh;
              break;
            case 'focusin':
              ((x = 'focus'), (m = In));
              break;
            case 'focusout':
              ((x = 'blur'), (m = In));
              break;
            case 'beforeblur':
            case 'afterblur':
              m = In;
              break;
            case 'click':
              if (a.button === 2) break l;
            case 'auxclick':
            case 'dblclick':
            case 'mousedown':
            case 'mousemove':
            case 'mouseup':
            case 'mouseout':
            case 'mouseover':
            case 'contextmenu':
              m = Ai;
              break;
            case 'drag':
            case 'dragend':
            case 'dragenter':
            case 'dragexit':
            case 'dragleave':
            case 'dragover':
            case 'dragstart':
            case 'drop':
              m = oh;
              break;
            case 'touchcancel':
            case 'touchend':
            case 'touchmove':
            case 'touchstart':
              m = Hh;
              break;
            case Vi:
            case Ci:
            case Ki:
              m = Sh;
              break;
            case Li:
              m = Rh;
              break;
            case 'scroll':
            case 'scrollend':
              m = yh;
              break;
            case 'wheel':
              m = ph;
              break;
            case 'copy':
            case 'cut':
            case 'paste':
              m = zh;
              break;
            case 'gotpointercapture':
            case 'lostpointercapture':
            case 'pointercancel':
            case 'pointerdown':
            case 'pointermove':
            case 'pointerout':
            case 'pointerover':
            case 'pointerup':
              m = Mi;
              break;
            case 'toggle':
            case 'beforetoggle':
              m = Yh;
          }
          var D = (t & 4) !== 0,
            Z = !D && (l === 'scroll' || l === 'scrollend'),
            d = D ? (y !== null ? y + 'Capture' : null) : y;
          D = [];
          for (var s = v, h; s !== null; ) {
            var b = s;
            if (
              ((h = b.stateNode),
              (b = b.tag),
              (b !== 5 && b !== 26 && b !== 27) ||
                h === null ||
                d === null ||
                ((b = ou(s, d)), b != null && D.push(Fu(s, b, h))),
              Z)
            )
              break;
            s = s.return;
          }
          0 < D.length &&
            ((y = new m(y, x, null, a, g)), r.push({ event: y, listeners: D }));
        }
      }
      if ((t & 7) === 0) {
        l: {
          if (
            ((y = l === 'mouseover' || l === 'pointerover'),
            (m = l === 'mouseout' || l === 'pointerout'),
            y &&
              a !== Ln &&
              (x = a.relatedTarget || a.fromElement) &&
              (Ea(x) || x[Ma]))
          )
            break l;
          if (
            (m || y) &&
            ((y =
              g.window === g
                ? g
                : (y = g.ownerDocument)
                  ? y.defaultView || y.parentWindow
                  : window),
            m
              ? ((x = a.relatedTarget || a.toElement),
                (m = v),
                (x = x ? Ea(x) : null),
                x !== null &&
                  ((Z = el(x)),
                  (D = x.tag),
                  x !== Z || (D !== 5 && D !== 27 && D !== 6)) &&
                  (x = null))
              : ((m = null), (x = v)),
            m !== x)
          ) {
            if (
              ((D = Ai),
              (b = 'onMouseLeave'),
              (d = 'onMouseEnter'),
              (s = 'mouse'),
              (l === 'pointerout' || l === 'pointerover') &&
                ((D = Mi),
                (b = 'onPointerLeave'),
                (d = 'onPointerEnter'),
                (s = 'pointer')),
              (Z = m == null ? y : mu(m)),
              (h = x == null ? y : mu(x)),
              (y = new D(b, s + 'leave', m, a, g)),
              (y.target = Z),
              (y.relatedTarget = h),
              (b = null),
              Ea(g) === v &&
                ((D = new D(d, s + 'enter', x, a, g)),
                (D.target = h),
                (D.relatedTarget = Z),
                (b = D)),
              (Z = b),
              m && x)
            )
              t: {
                for (D = m, d = x, s = 0, h = D; h; h = eu(h)) s++;
                for (h = 0, b = d; b; b = eu(b)) h++;
                for (; 0 < s - h; ) ((D = eu(D)), s--);
                for (; 0 < h - s; ) ((d = eu(d)), h--);
                for (; s--; ) {
                  if (D === d || (d !== null && D === d.alternate)) break t;
                  ((D = eu(D)), (d = eu(d)));
                }
                D = null;
              }
            else D = null;
            (m !== null && vd(r, y, m, D, !1),
              x !== null && Z !== null && vd(r, Z, x, D, !0));
          }
        }
        l: {
          if (
            ((y = v ? mu(v) : window),
            (m = y.nodeName && y.nodeName.toLowerCase()),
            m === 'select' || (m === 'input' && y.type === 'file'))
          )
            var T = _i;
          else if (Ni(y))
            if (Ri) T = Jh;
            else {
              T = Kh;
              var H = Ch;
            }
          else
            ((m = y.nodeName),
              !m ||
              m.toLowerCase() !== 'input' ||
              (y.type !== 'checkbox' && y.type !== 'radio')
                ? v && Kn(v.elementType) && (T = _i)
                : (T = Lh));
          if (T && (T = T(l, v))) {
            Hi(r, T, a, g);
            break l;
          }
          (H && H(l, y, v),
            l === 'focusout' &&
              v &&
              y.type === 'number' &&
              v.memoizedProps.value != null &&
              Cn(y, 'number', y.value));
        }
        switch (((H = v ? mu(v) : window), l)) {
          case 'focusin':
            (Ni(H) || H.contentEditable === 'true') &&
              ((pa = H), (ec = v), (Mu = null));
            break;
          case 'focusout':
            Mu = ec = pa = null;
            break;
          case 'mousedown':
            nc = !0;
            break;
          case 'contextmenu':
          case 'mouseup':
          case 'dragend':
            ((nc = !1), Qi(r, a, g));
            break;
          case 'selectionchange':
            if (Wh) break;
          case 'keydown':
          case 'keyup':
            Qi(r, a, g);
        }
        var M;
        if (lc)
          l: {
            switch (l) {
              case 'compositionstart':
                var O = 'onCompositionStart';
                break l;
              case 'compositionend':
                O = 'onCompositionEnd';
                break l;
              case 'compositionupdate':
                O = 'onCompositionUpdate';
                break l;
            }
            O = void 0;
          }
        else
          qa
            ? xi(l, a) && (O = 'onCompositionEnd')
            : l === 'keydown' &&
              a.keyCode === 229 &&
              (O = 'onCompositionStart');
        (O &&
          (Ei &&
            a.locale !== 'ko' &&
            (qa || O !== 'onCompositionStart'
              ? O === 'onCompositionEnd' && qa && (M = ri())
              : ((Rt = g),
                (kn = 'value' in Rt ? Rt.value : Rt.textContent),
                (qa = !0))),
          (H = on(v, O)),
          0 < H.length &&
            ((O = new Ti(O, l, null, a, g)),
            r.push({ event: O, listeners: H }),
            M ? (O.data = M) : ((M = Ui(a)), M !== null && (O.data = M)))),
          (M = Gh ? Xh(l, a) : Qh(l, a)) &&
            ((O = on(v, 'onBeforeInput')),
            0 < O.length &&
              ((H = new Ti('onBeforeInput', 'beforeinput', null, a, g)),
              r.push({ event: H, listeners: O }),
              (H.data = M))),
          H1(r, l, v, a, g));
      }
      dd(r, t);
    });
  }
  function Fu(l, t, a) {
    return { instance: l, listener: t, currentTarget: a };
  }
  function on(l, t) {
    for (var a = t + 'Capture', u = []; l !== null; ) {
      var e = l,
        n = e.stateNode;
      if (
        ((e = e.tag),
        (e !== 5 && e !== 26 && e !== 27) ||
          n === null ||
          ((e = ou(l, a)),
          e != null && u.unshift(Fu(l, e, n)),
          (e = ou(l, t)),
          e != null && u.push(Fu(l, e, n))),
        l.tag === 3)
      )
        return u;
      l = l.return;
    }
    return [];
  }
  function eu(l) {
    if (l === null) return null;
    do l = l.return;
    while (l && l.tag !== 5 && l.tag !== 27);
    return l || null;
  }
  function vd(l, t, a, u, e) {
    for (var n = t._reactName, c = []; a !== null && a !== u; ) {
      var f = a,
        i = f.alternate,
        v = f.stateNode;
      if (((f = f.tag), i !== null && i === u)) break;
      ((f !== 5 && f !== 26 && f !== 27) ||
        v === null ||
        ((i = v),
        e
          ? ((v = ou(a, n)), v != null && c.unshift(Fu(a, v, i)))
          : e || ((v = ou(a, n)), v != null && c.push(Fu(a, v, i)))),
        (a = a.return));
    }
    c.length !== 0 && l.push({ event: t, listeners: c });
  }
  var p1 = /\r\n?/g,
    B1 = /\u0000|\uFFFD/g;
  function yd(l) {
    return (typeof l == 'string' ? l : '' + l)
      .replace(
        p1,
        `
`,
      )
      .replace(B1, '');
  }
  function md(l, t) {
    return ((t = yd(t)), yd(l) === t);
  }
  function gn() {}
  function Q(l, t, a, u, e, n) {
    switch (a) {
      case 'children':
        typeof u == 'string'
          ? t === 'body' || (t === 'textarea' && u === '') || Ha(l, u)
          : (typeof u == 'number' || typeof u == 'bigint') &&
            t !== 'body' &&
            Ha(l, '' + u);
        break;
      case 'className':
        ze(l, 'class', u);
        break;
      case 'tabIndex':
        ze(l, 'tabindex', u);
        break;
      case 'dir':
      case 'role':
      case 'viewBox':
      case 'width':
      case 'height':
        ze(l, a, u);
        break;
      case 'style':
        gi(l, u, n);
        break;
      case 'data':
        if (t !== 'object') {
          ze(l, 'data', u);
          break;
        }
      case 'src':
      case 'href':
        if (u === '' && (t !== 'a' || a !== 'href')) {
          l.removeAttribute(a);
          break;
        }
        if (
          u == null ||
          typeof u == 'function' ||
          typeof u == 'symbol' ||
          typeof u == 'boolean'
        ) {
          l.removeAttribute(a);
          break;
        }
        ((u = Me('' + u)), l.setAttribute(a, u));
        break;
      case 'action':
      case 'formAction':
        if (typeof u == 'function') {
          l.setAttribute(
            a,
            "javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')",
          );
          break;
        } else
          typeof n == 'function' &&
            (a === 'formAction'
              ? (t !== 'input' && Q(l, t, 'name', e.name, e, null),
                Q(l, t, 'formEncType', e.formEncType, e, null),
                Q(l, t, 'formMethod', e.formMethod, e, null),
                Q(l, t, 'formTarget', e.formTarget, e, null))
              : (Q(l, t, 'encType', e.encType, e, null),
                Q(l, t, 'method', e.method, e, null),
                Q(l, t, 'target', e.target, e, null)));
        if (u == null || typeof u == 'symbol' || typeof u == 'boolean') {
          l.removeAttribute(a);
          break;
        }
        ((u = Me('' + u)), l.setAttribute(a, u));
        break;
      case 'onClick':
        u != null && (l.onclick = gn);
        break;
      case 'onScroll':
        u != null && R('scroll', l);
        break;
      case 'onScrollEnd':
        u != null && R('scrollend', l);
        break;
      case 'dangerouslySetInnerHTML':
        if (u != null) {
          if (typeof u != 'object' || !('__html' in u)) throw Error(o(61));
          if (((a = u.__html), a != null)) {
            if (e.children != null) throw Error(o(60));
            l.innerHTML = a;
          }
        }
        break;
      case 'multiple':
        l.multiple = u && typeof u != 'function' && typeof u != 'symbol';
        break;
      case 'muted':
        l.muted = u && typeof u != 'function' && typeof u != 'symbol';
        break;
      case 'suppressContentEditableWarning':
      case 'suppressHydrationWarning':
      case 'defaultValue':
      case 'defaultChecked':
      case 'innerHTML':
      case 'ref':
        break;
      case 'autoFocus':
        break;
      case 'xlinkHref':
        if (
          u == null ||
          typeof u == 'function' ||
          typeof u == 'boolean' ||
          typeof u == 'symbol'
        ) {
          l.removeAttribute('xlink:href');
          break;
        }
        ((a = Me('' + u)),
          l.setAttributeNS('http://www.w3.org/1999/xlink', 'xlink:href', a));
        break;
      case 'contentEditable':
      case 'spellCheck':
      case 'draggable':
      case 'value':
      case 'autoReverse':
      case 'externalResourcesRequired':
      case 'focusable':
      case 'preserveAlpha':
        u != null && typeof u != 'function' && typeof u != 'symbol'
          ? l.setAttribute(a, '' + u)
          : l.removeAttribute(a);
        break;
      case 'inert':
      case 'allowFullScreen':
      case 'async':
      case 'autoPlay':
      case 'controls':
      case 'default':
      case 'defer':
      case 'disabled':
      case 'disablePictureInPicture':
      case 'disableRemotePlayback':
      case 'formNoValidate':
      case 'hidden':
      case 'loop':
      case 'noModule':
      case 'noValidate':
      case 'open':
      case 'playsInline':
      case 'readOnly':
      case 'required':
      case 'reversed':
      case 'scoped':
      case 'seamless':
      case 'itemScope':
        u && typeof u != 'function' && typeof u != 'symbol'
          ? l.setAttribute(a, '')
          : l.removeAttribute(a);
        break;
      case 'capture':
      case 'download':
        u === !0
          ? l.setAttribute(a, '')
          : u !== !1 &&
              u != null &&
              typeof u != 'function' &&
              typeof u != 'symbol'
            ? l.setAttribute(a, u)
            : l.removeAttribute(a);
        break;
      case 'cols':
      case 'rows':
      case 'size':
      case 'span':
        u != null &&
        typeof u != 'function' &&
        typeof u != 'symbol' &&
        !isNaN(u) &&
        1 <= u
          ? l.setAttribute(a, u)
          : l.removeAttribute(a);
        break;
      case 'rowSpan':
      case 'start':
        u == null || typeof u == 'function' || typeof u == 'symbol' || isNaN(u)
          ? l.removeAttribute(a)
          : l.setAttribute(a, u);
        break;
      case 'popover':
        (R('beforetoggle', l), R('toggle', l), re(l, 'popover', u));
        break;
      case 'xlinkActuate':
        vt(l, 'http://www.w3.org/1999/xlink', 'xlink:actuate', u);
        break;
      case 'xlinkArcrole':
        vt(l, 'http://www.w3.org/1999/xlink', 'xlink:arcrole', u);
        break;
      case 'xlinkRole':
        vt(l, 'http://www.w3.org/1999/xlink', 'xlink:role', u);
        break;
      case 'xlinkShow':
        vt(l, 'http://www.w3.org/1999/xlink', 'xlink:show', u);
        break;
      case 'xlinkTitle':
        vt(l, 'http://www.w3.org/1999/xlink', 'xlink:title', u);
        break;
      case 'xlinkType':
        vt(l, 'http://www.w3.org/1999/xlink', 'xlink:type', u);
        break;
      case 'xmlBase':
        vt(l, 'http://www.w3.org/XML/1998/namespace', 'xml:base', u);
        break;
      case 'xmlLang':
        vt(l, 'http://www.w3.org/XML/1998/namespace', 'xml:lang', u);
        break;
      case 'xmlSpace':
        vt(l, 'http://www.w3.org/XML/1998/namespace', 'xml:space', u);
        break;
      case 'is':
        re(l, 'is', u);
        break;
      case 'innerText':
      case 'textContent':
        break;
      default:
        (!(2 < a.length) ||
          (a[0] !== 'o' && a[0] !== 'O') ||
          (a[1] !== 'n' && a[1] !== 'N')) &&
          ((a = hh.get(a) || a), re(l, a, u));
    }
  }
  function Nf(l, t, a, u, e, n) {
    switch (a) {
      case 'style':
        gi(l, u, n);
        break;
      case 'dangerouslySetInnerHTML':
        if (u != null) {
          if (typeof u != 'object' || !('__html' in u)) throw Error(o(61));
          if (((a = u.__html), a != null)) {
            if (e.children != null) throw Error(o(60));
            l.innerHTML = a;
          }
        }
        break;
      case 'children':
        typeof u == 'string'
          ? Ha(l, u)
          : (typeof u == 'number' || typeof u == 'bigint') && Ha(l, '' + u);
        break;
      case 'onScroll':
        u != null && R('scroll', l);
        break;
      case 'onScrollEnd':
        u != null && R('scrollend', l);
        break;
      case 'onClick':
        u != null && (l.onclick = gn);
        break;
      case 'suppressContentEditableWarning':
      case 'suppressHydrationWarning':
      case 'innerHTML':
      case 'ref':
        break;
      case 'innerText':
      case 'textContent':
        break;
      default:
        if (!ni.hasOwnProperty(a))
          l: {
            if (
              a[0] === 'o' &&
              a[1] === 'n' &&
              ((e = a.endsWith('Capture')),
              (t = a.slice(2, e ? a.length - 7 : void 0)),
              (n = l[Tl] || null),
              (n = n != null ? n[a] : null),
              typeof n == 'function' && l.removeEventListener(t, n, e),
              typeof u == 'function')
            ) {
              (typeof n != 'function' &&
                n !== null &&
                (a in l
                  ? (l[a] = null)
                  : l.hasAttribute(a) && l.removeAttribute(a)),
                l.addEventListener(t, u, e));
              break l;
            }
            a in l
              ? (l[a] = u)
              : u === !0
                ? l.setAttribute(a, '')
                : re(l, a, u);
          }
    }
  }
  function ol(l, t, a) {
    switch (t) {
      case 'div':
      case 'span':
      case 'svg':
      case 'path':
      case 'a':
      case 'g':
      case 'p':
      case 'li':
        break;
      case 'img':
        (R('error', l), R('load', l));
        var u = !1,
          e = !1,
          n;
        for (n in a)
          if (a.hasOwnProperty(n)) {
            var c = a[n];
            if (c != null)
              switch (n) {
                case 'src':
                  u = !0;
                  break;
                case 'srcSet':
                  e = !0;
                  break;
                case 'children':
                case 'dangerouslySetInnerHTML':
                  throw Error(o(137, t));
                default:
                  Q(l, t, n, c, a, null);
              }
          }
        (e && Q(l, t, 'srcSet', a.srcSet, a, null),
          u && Q(l, t, 'src', a.src, a, null));
        return;
      case 'input':
        R('invalid', l);
        var f = (n = c = e = null),
          i = null,
          v = null;
        for (u in a)
          if (a.hasOwnProperty(u)) {
            var g = a[u];
            if (g != null)
              switch (u) {
                case 'name':
                  e = g;
                  break;
                case 'type':
                  c = g;
                  break;
                case 'checked':
                  i = g;
                  break;
                case 'defaultChecked':
                  v = g;
                  break;
                case 'value':
                  n = g;
                  break;
                case 'defaultValue':
                  f = g;
                  break;
                case 'children':
                case 'dangerouslySetInnerHTML':
                  if (g != null) throw Error(o(137, t));
                  break;
                default:
                  Q(l, t, u, g, a, null);
              }
          }
        (vi(l, n, f, i, v, c, e, !1), Ae(l));
        return;
      case 'select':
        (R('invalid', l), (u = c = n = null));
        for (e in a)
          if (a.hasOwnProperty(e) && ((f = a[e]), f != null))
            switch (e) {
              case 'value':
                n = f;
                break;
              case 'defaultValue':
                c = f;
                break;
              case 'multiple':
                u = f;
              default:
                Q(l, t, e, f, a, null);
            }
        ((t = n),
          (a = c),
          (l.multiple = !!u),
          t != null ? Na(l, !!u, t, !1) : a != null && Na(l, !!u, a, !0));
        return;
      case 'textarea':
        (R('invalid', l), (n = e = u = null));
        for (c in a)
          if (a.hasOwnProperty(c) && ((f = a[c]), f != null))
            switch (c) {
              case 'value':
                u = f;
                break;
              case 'defaultValue':
                e = f;
                break;
              case 'children':
                n = f;
                break;
              case 'dangerouslySetInnerHTML':
                if (f != null) throw Error(o(91));
                break;
              default:
                Q(l, t, c, f, a, null);
            }
        (mi(l, u, e, n), Ae(l));
        return;
      case 'option':
        for (i in a)
          if (a.hasOwnProperty(i) && ((u = a[i]), u != null))
            switch (i) {
              case 'selected':
                l.selected =
                  u && typeof u != 'function' && typeof u != 'symbol';
                break;
              default:
                Q(l, t, i, u, a, null);
            }
        return;
      case 'dialog':
        (R('beforetoggle', l), R('toggle', l), R('cancel', l), R('close', l));
        break;
      case 'iframe':
      case 'object':
        R('load', l);
        break;
      case 'video':
      case 'audio':
        for (u = 0; u < $u.length; u++) R($u[u], l);
        break;
      case 'image':
        (R('error', l), R('load', l));
        break;
      case 'details':
        R('toggle', l);
        break;
      case 'embed':
      case 'source':
      case 'link':
        (R('error', l), R('load', l));
      case 'area':
      case 'base':
      case 'br':
      case 'col':
      case 'hr':
      case 'keygen':
      case 'meta':
      case 'param':
      case 'track':
      case 'wbr':
      case 'menuitem':
        for (v in a)
          if (a.hasOwnProperty(v) && ((u = a[v]), u != null))
            switch (v) {
              case 'children':
              case 'dangerouslySetInnerHTML':
                throw Error(o(137, t));
              default:
                Q(l, t, v, u, a, null);
            }
        return;
      default:
        if (Kn(t)) {
          for (g in a)
            a.hasOwnProperty(g) &&
              ((u = a[g]), u !== void 0 && Nf(l, t, g, u, a, void 0));
          return;
        }
    }
    for (f in a)
      a.hasOwnProperty(f) && ((u = a[f]), u != null && Q(l, t, f, u, a, null));
  }
  function Y1(l, t, a, u) {
    switch (t) {
      case 'div':
      case 'span':
      case 'svg':
      case 'path':
      case 'a':
      case 'g':
      case 'p':
      case 'li':
        break;
      case 'input':
        var e = null,
          n = null,
          c = null,
          f = null,
          i = null,
          v = null,
          g = null;
        for (m in a) {
          var r = a[m];
          if (a.hasOwnProperty(m) && r != null)
            switch (m) {
              case 'checked':
                break;
              case 'value':
                break;
              case 'defaultValue':
                i = r;
              default:
                u.hasOwnProperty(m) || Q(l, t, m, null, u, r);
            }
        }
        for (var y in u) {
          var m = u[y];
          if (((r = a[y]), u.hasOwnProperty(y) && (m != null || r != null)))
            switch (y) {
              case 'type':
                n = m;
                break;
              case 'name':
                e = m;
                break;
              case 'checked':
                v = m;
                break;
              case 'defaultChecked':
                g = m;
                break;
              case 'value':
                c = m;
                break;
              case 'defaultValue':
                f = m;
                break;
              case 'children':
              case 'dangerouslySetInnerHTML':
                if (m != null) throw Error(o(137, t));
                break;
              default:
                m !== r && Q(l, t, y, m, u, r);
            }
        }
        Vn(l, c, f, i, v, g, n, e);
        return;
      case 'select':
        m = c = f = y = null;
        for (n in a)
          if (((i = a[n]), a.hasOwnProperty(n) && i != null))
            switch (n) {
              case 'value':
                break;
              case 'multiple':
                m = i;
              default:
                u.hasOwnProperty(n) || Q(l, t, n, null, u, i);
            }
        for (e in u)
          if (
            ((n = u[e]),
            (i = a[e]),
            u.hasOwnProperty(e) && (n != null || i != null))
          )
            switch (e) {
              case 'value':
                y = n;
                break;
              case 'defaultValue':
                f = n;
                break;
              case 'multiple':
                c = n;
              default:
                n !== i && Q(l, t, e, n, u, i);
            }
        ((t = f),
          (a = c),
          (u = m),
          y != null
            ? Na(l, !!a, y, !1)
            : !!u != !!a &&
              (t != null ? Na(l, !!a, t, !0) : Na(l, !!a, a ? [] : '', !1)));
        return;
      case 'textarea':
        m = y = null;
        for (f in a)
          if (
            ((e = a[f]),
            a.hasOwnProperty(f) && e != null && !u.hasOwnProperty(f))
          )
            switch (f) {
              case 'value':
                break;
              case 'children':
                break;
              default:
                Q(l, t, f, null, u, e);
            }
        for (c in u)
          if (
            ((e = u[c]),
            (n = a[c]),
            u.hasOwnProperty(c) && (e != null || n != null))
          )
            switch (c) {
              case 'value':
                y = e;
                break;
              case 'defaultValue':
                m = e;
                break;
              case 'children':
                break;
              case 'dangerouslySetInnerHTML':
                if (e != null) throw Error(o(91));
                break;
              default:
                e !== n && Q(l, t, c, e, u, n);
            }
        yi(l, y, m);
        return;
      case 'option':
        for (var x in a)
          if (
            ((y = a[x]),
            a.hasOwnProperty(x) && y != null && !u.hasOwnProperty(x))
          )
            switch (x) {
              case 'selected':
                l.selected = !1;
                break;
              default:
                Q(l, t, x, null, u, y);
            }
        for (i in u)
          if (
            ((y = u[i]),
            (m = a[i]),
            u.hasOwnProperty(i) && y !== m && (y != null || m != null))
          )
            switch (i) {
              case 'selected':
                l.selected =
                  y && typeof y != 'function' && typeof y != 'symbol';
                break;
              default:
                Q(l, t, i, y, u, m);
            }
        return;
      case 'img':
      case 'link':
      case 'area':
      case 'base':
      case 'br':
      case 'col':
      case 'embed':
      case 'hr':
      case 'keygen':
      case 'meta':
      case 'param':
      case 'source':
      case 'track':
      case 'wbr':
      case 'menuitem':
        for (var D in a)
          ((y = a[D]),
            a.hasOwnProperty(D) &&
              y != null &&
              !u.hasOwnProperty(D) &&
              Q(l, t, D, null, u, y));
        for (v in u)
          if (
            ((y = u[v]),
            (m = a[v]),
            u.hasOwnProperty(v) && y !== m && (y != null || m != null))
          )
            switch (v) {
              case 'children':
              case 'dangerouslySetInnerHTML':
                if (y != null) throw Error(o(137, t));
                break;
              default:
                Q(l, t, v, y, u, m);
            }
        return;
      default:
        if (Kn(t)) {
          for (var Z in a)
            ((y = a[Z]),
              a.hasOwnProperty(Z) &&
                y !== void 0 &&
                !u.hasOwnProperty(Z) &&
                Nf(l, t, Z, void 0, u, y));
          for (g in u)
            ((y = u[g]),
              (m = a[g]),
              !u.hasOwnProperty(g) ||
                y === m ||
                (y === void 0 && m === void 0) ||
                Nf(l, t, g, y, u, m));
          return;
        }
    }
    for (var d in a)
      ((y = a[d]),
        a.hasOwnProperty(d) &&
          y != null &&
          !u.hasOwnProperty(d) &&
          Q(l, t, d, null, u, y));
    for (r in u)
      ((y = u[r]),
        (m = a[r]),
        !u.hasOwnProperty(r) ||
          y === m ||
          (y == null && m == null) ||
          Q(l, t, r, y, u, m));
  }
  var Hf = null,
    _f = null;
  function bn(l) {
    return l.nodeType === 9 ? l : l.ownerDocument;
  }
  function od(l) {
    switch (l) {
      case 'http://www.w3.org/2000/svg':
        return 1;
      case 'http://www.w3.org/1998/Math/MathML':
        return 2;
      default:
        return 0;
    }
  }
  function gd(l, t) {
    if (l === 0)
      switch (t) {
        case 'svg':
          return 1;
        case 'math':
          return 2;
        default:
          return 0;
      }
    return l === 1 && t === 'foreignObject' ? 0 : l;
  }
  function Rf(l, t) {
    return (
      l === 'textarea' ||
      l === 'noscript' ||
      typeof t.children == 'string' ||
      typeof t.children == 'number' ||
      typeof t.children == 'bigint' ||
      (typeof t.dangerouslySetInnerHTML == 'object' &&
        t.dangerouslySetInnerHTML !== null &&
        t.dangerouslySetInnerHTML.__html != null)
    );
  }
  var qf = null;
  function j1() {
    var l = window.event;
    return l && l.type === 'popstate'
      ? l === qf
        ? !1
        : ((qf = l), !0)
      : ((qf = null), !1);
  }
  var bd = typeof setTimeout == 'function' ? setTimeout : void 0,
    G1 = typeof clearTimeout == 'function' ? clearTimeout : void 0,
    Sd = typeof Promise == 'function' ? Promise : void 0,
    X1 =
      typeof queueMicrotask == 'function'
        ? queueMicrotask
        : typeof Sd < 'u'
          ? function (l) {
              return Sd.resolve(null).then(l).catch(Q1);
            }
          : bd;
  function Q1(l) {
    setTimeout(function () {
      throw l;
    });
  }
  function Wt(l) {
    return l === 'head';
  }
  function rd(l, t) {
    var a = t,
      u = 0,
      e = 0;
    do {
      var n = a.nextSibling;
      if ((l.removeChild(a), n && n.nodeType === 8))
        if (((a = n.data), a === '/$')) {
          if (0 < u && 8 > u) {
            a = u;
            var c = l.ownerDocument;
            if ((a & 1 && Iu(c.documentElement), a & 2 && Iu(c.body), a & 4))
              for (a = c.head, Iu(a), c = a.firstChild; c; ) {
                var f = c.nextSibling,
                  i = c.nodeName;
                (c[yu] ||
                  i === 'SCRIPT' ||
                  i === 'STYLE' ||
                  (i === 'LINK' && c.rel.toLowerCase() === 'stylesheet') ||
                  a.removeChild(c),
                  (c = f));
              }
          }
          if (e === 0) {
            (l.removeChild(n), ce(t));
            return;
          }
          e--;
        } else
          a === '$' || a === '$?' || a === '$!'
            ? e++
            : (u = a.charCodeAt(0) - 48);
      else u = 0;
      a = n;
    } while (a);
    ce(t);
  }
  function pf(l) {
    var t = l.firstChild;
    for (t && t.nodeType === 10 && (t = t.nextSibling); t; ) {
      var a = t;
      switch (((t = t.nextSibling), a.nodeName)) {
        case 'HTML':
        case 'HEAD':
        case 'BODY':
          (pf(a), Gn(a));
          continue;
        case 'SCRIPT':
        case 'STYLE':
          continue;
        case 'LINK':
          if (a.rel.toLowerCase() === 'stylesheet') continue;
      }
      l.removeChild(a);
    }
  }
  function Z1(l, t, a, u) {
    for (; l.nodeType === 1; ) {
      var e = a;
      if (l.nodeName.toLowerCase() !== t.toLowerCase()) {
        if (!u && (l.nodeName !== 'INPUT' || l.type !== 'hidden')) break;
      } else if (u) {
        if (!l[yu])
          switch (t) {
            case 'meta':
              if (!l.hasAttribute('itemprop')) break;
              return l;
            case 'link':
              if (
                ((n = l.getAttribute('rel')),
                n === 'stylesheet' && l.hasAttribute('data-precedence'))
              )
                break;
              if (
                n !== e.rel ||
                l.getAttribute('href') !==
                  (e.href == null || e.href === '' ? null : e.href) ||
                l.getAttribute('crossorigin') !==
                  (e.crossOrigin == null ? null : e.crossOrigin) ||
                l.getAttribute('title') !== (e.title == null ? null : e.title)
              )
                break;
              return l;
            case 'style':
              if (l.hasAttribute('data-precedence')) break;
              return l;
            case 'script':
              if (
                ((n = l.getAttribute('src')),
                (n !== (e.src == null ? null : e.src) ||
                  l.getAttribute('type') !== (e.type == null ? null : e.type) ||
                  l.getAttribute('crossorigin') !==
                    (e.crossOrigin == null ? null : e.crossOrigin)) &&
                  n &&
                  l.hasAttribute('async') &&
                  !l.hasAttribute('itemprop'))
              )
                break;
              return l;
            default:
              return l;
          }
      } else if (t === 'input' && l.type === 'hidden') {
        var n = e.name == null ? null : '' + e.name;
        if (e.type === 'hidden' && l.getAttribute('name') === n) return l;
      } else return l;
      if (((l = Pl(l.nextSibling)), l === null)) break;
    }
    return null;
  }
  function V1(l, t, a) {
    if (t === '') return null;
    for (; l.nodeType !== 3; )
      if (
        ((l.nodeType !== 1 || l.nodeName !== 'INPUT' || l.type !== 'hidden') &&
          !a) ||
        ((l = Pl(l.nextSibling)), l === null)
      )
        return null;
    return l;
  }
  function Bf(l) {
    return (
      l.data === '$!' ||
      (l.data === '$?' && l.ownerDocument.readyState === 'complete')
    );
  }
  function C1(l, t) {
    var a = l.ownerDocument;
    if (l.data !== '$?' || a.readyState === 'complete') t();
    else {
      var u = function () {
        (t(), a.removeEventListener('DOMContentLoaded', u));
      };
      (a.addEventListener('DOMContentLoaded', u), (l._reactRetry = u));
    }
  }
  function Pl(l) {
    for (; l != null; l = l.nextSibling) {
      var t = l.nodeType;
      if (t === 1 || t === 3) break;
      if (t === 8) {
        if (
          ((t = l.data),
          t === '$' || t === '$!' || t === '$?' || t === 'F!' || t === 'F')
        )
          break;
        if (t === '/$') return null;
      }
    }
    return l;
  }
  var Yf = null;
  function zd(l) {
    l = l.previousSibling;
    for (var t = 0; l; ) {
      if (l.nodeType === 8) {
        var a = l.data;
        if (a === '$' || a === '$!' || a === '$?') {
          if (t === 0) return l;
          t--;
        } else a === '/$' && t++;
      }
      l = l.previousSibling;
    }
    return null;
  }
  function Ad(l, t, a) {
    switch (((t = bn(a)), l)) {
      case 'html':
        if (((l = t.documentElement), !l)) throw Error(o(452));
        return l;
      case 'head':
        if (((l = t.head), !l)) throw Error(o(453));
        return l;
      case 'body':
        if (((l = t.body), !l)) throw Error(o(454));
        return l;
      default:
        throw Error(o(451));
    }
  }
  function Iu(l) {
    for (var t = l.attributes; t.length; ) l.removeAttributeNode(t[0]);
    Gn(l);
  }
  var wl = new Map(),
    Td = new Set();
  function Sn(l) {
    return typeof l.getRootNode == 'function'
      ? l.getRootNode()
      : l.nodeType === 9
        ? l
        : l.ownerDocument;
  }
  var Ot = A.d;
  A.d = { f: K1, r: L1, D: J1, C: w1, L: W1, m: k1, X: F1, S: $1, M: I1 };
  function K1() {
    var l = Ot.f(),
      t = sn();
    return l || t;
  }
  function L1(l) {
    var t = Da(l);
    t !== null && t.tag === 5 && t.type === 'form' ? V0(t) : Ot.r(l);
  }
  var nu = typeof document > 'u' ? null : document;
  function Md(l, t, a) {
    var u = nu;
    if (u && typeof t == 'string' && t) {
      var e = Ql(t);
      ((e = 'link[rel="' + l + '"][href="' + e + '"]'),
        typeof a == 'string' && (e += '[crossorigin="' + a + '"]'),
        Td.has(e) ||
          (Td.add(e),
          (l = { rel: l, crossOrigin: a, href: t }),
          u.querySelector(e) === null &&
            ((t = u.createElement('link')),
            ol(t, 'link', l),
            il(t),
            u.head.appendChild(t))));
    }
  }
  function J1(l) {
    (Ot.D(l), Md('dns-prefetch', l, null));
  }
  function w1(l, t) {
    (Ot.C(l, t), Md('preconnect', l, t));
  }
  function W1(l, t, a) {
    Ot.L(l, t, a);
    var u = nu;
    if (u && l && t) {
      var e = 'link[rel="preload"][as="' + Ql(t) + '"]';
      t === 'image' && a && a.imageSrcSet
        ? ((e += '[imagesrcset="' + Ql(a.imageSrcSet) + '"]'),
          typeof a.imageSizes == 'string' &&
            (e += '[imagesizes="' + Ql(a.imageSizes) + '"]'))
        : (e += '[href="' + Ql(l) + '"]');
      var n = e;
      switch (t) {
        case 'style':
          n = cu(l);
          break;
        case 'script':
          n = fu(l);
      }
      wl.has(n) ||
        ((l = V(
          {
            rel: 'preload',
            href: t === 'image' && a && a.imageSrcSet ? void 0 : l,
            as: t,
          },
          a,
        )),
        wl.set(n, l),
        u.querySelector(e) !== null ||
          (t === 'style' && u.querySelector(Pu(n))) ||
          (t === 'script' && u.querySelector(le(n))) ||
          ((t = u.createElement('link')),
          ol(t, 'link', l),
          il(t),
          u.head.appendChild(t)));
    }
  }
  function k1(l, t) {
    Ot.m(l, t);
    var a = nu;
    if (a && l) {
      var u = t && typeof t.as == 'string' ? t.as : 'script',
        e =
          'link[rel="modulepreload"][as="' + Ql(u) + '"][href="' + Ql(l) + '"]',
        n = e;
      switch (u) {
        case 'audioworklet':
        case 'paintworklet':
        case 'serviceworker':
        case 'sharedworker':
        case 'worker':
        case 'script':
          n = fu(l);
      }
      if (
        !wl.has(n) &&
        ((l = V({ rel: 'modulepreload', href: l }, t)),
        wl.set(n, l),
        a.querySelector(e) === null)
      ) {
        switch (u) {
          case 'audioworklet':
          case 'paintworklet':
          case 'serviceworker':
          case 'sharedworker':
          case 'worker':
          case 'script':
            if (a.querySelector(le(n))) return;
        }
        ((u = a.createElement('link')),
          ol(u, 'link', l),
          il(u),
          a.head.appendChild(u));
      }
    }
  }
  function $1(l, t, a) {
    Ot.S(l, t, a);
    var u = nu;
    if (u && l) {
      var e = Oa(u).hoistableStyles,
        n = cu(l);
      t = t || 'default';
      var c = e.get(n);
      if (!c) {
        var f = { loading: 0, preload: null };
        if ((c = u.querySelector(Pu(n)))) f.loading = 5;
        else {
          ((l = V({ rel: 'stylesheet', href: l, 'data-precedence': t }, a)),
            (a = wl.get(n)) && jf(l, a));
          var i = (c = u.createElement('link'));
          (il(i),
            ol(i, 'link', l),
            (i._p = new Promise(function (v, g) {
              ((i.onload = v), (i.onerror = g));
            })),
            i.addEventListener('load', function () {
              f.loading |= 1;
            }),
            i.addEventListener('error', function () {
              f.loading |= 2;
            }),
            (f.loading |= 4),
            rn(c, t, u));
        }
        ((c = { type: 'stylesheet', instance: c, count: 1, state: f }),
          e.set(n, c));
      }
    }
  }
  function F1(l, t) {
    Ot.X(l, t);
    var a = nu;
    if (a && l) {
      var u = Oa(a).hoistableScripts,
        e = fu(l),
        n = u.get(e);
      n ||
        ((n = a.querySelector(le(e))),
        n ||
          ((l = V({ src: l, async: !0 }, t)),
          (t = wl.get(e)) && Gf(l, t),
          (n = a.createElement('script')),
          il(n),
          ol(n, 'link', l),
          a.head.appendChild(n)),
        (n = { type: 'script', instance: n, count: 1, state: null }),
        u.set(e, n));
    }
  }
  function I1(l, t) {
    Ot.M(l, t);
    var a = nu;
    if (a && l) {
      var u = Oa(a).hoistableScripts,
        e = fu(l),
        n = u.get(e);
      n ||
        ((n = a.querySelector(le(e))),
        n ||
          ((l = V({ src: l, async: !0, type: 'module' }, t)),
          (t = wl.get(e)) && Gf(l, t),
          (n = a.createElement('script')),
          il(n),
          ol(n, 'link', l),
          a.head.appendChild(n)),
        (n = { type: 'script', instance: n, count: 1, state: null }),
        u.set(e, n));
    }
  }
  function Ed(l, t, a, u) {
    var e = (e = Nt.current) ? Sn(e) : null;
    if (!e) throw Error(o(446));
    switch (l) {
      case 'meta':
      case 'title':
        return null;
      case 'style':
        return typeof a.precedence == 'string' && typeof a.href == 'string'
          ? ((t = cu(a.href)),
            (a = Oa(e).hoistableStyles),
            (u = a.get(t)),
            u ||
              ((u = { type: 'style', instance: null, count: 0, state: null }),
              a.set(t, u)),
            u)
          : { type: 'void', instance: null, count: 0, state: null };
      case 'link':
        if (
          a.rel === 'stylesheet' &&
          typeof a.href == 'string' &&
          typeof a.precedence == 'string'
        ) {
          l = cu(a.href);
          var n = Oa(e).hoistableStyles,
            c = n.get(l);
          if (
            (c ||
              ((e = e.ownerDocument || e),
              (c = {
                type: 'stylesheet',
                instance: null,
                count: 0,
                state: { loading: 0, preload: null },
              }),
              n.set(l, c),
              (n = e.querySelector(Pu(l))) &&
                !n._p &&
                ((c.instance = n), (c.state.loading = 5)),
              wl.has(l) ||
                ((a = {
                  rel: 'preload',
                  as: 'style',
                  href: a.href,
                  crossOrigin: a.crossOrigin,
                  integrity: a.integrity,
                  media: a.media,
                  hrefLang: a.hrefLang,
                  referrerPolicy: a.referrerPolicy,
                }),
                wl.set(l, a),
                n || P1(e, l, a, c.state))),
            t && u === null)
          )
            throw Error(o(528, ''));
          return c;
        }
        if (t && u !== null) throw Error(o(529, ''));
        return null;
      case 'script':
        return (
          (t = a.async),
          (a = a.src),
          typeof a == 'string' &&
          t &&
          typeof t != 'function' &&
          typeof t != 'symbol'
            ? ((t = fu(a)),
              (a = Oa(e).hoistableScripts),
              (u = a.get(t)),
              u ||
                ((u = {
                  type: 'script',
                  instance: null,
                  count: 0,
                  state: null,
                }),
                a.set(t, u)),
              u)
            : { type: 'void', instance: null, count: 0, state: null }
        );
      default:
        throw Error(o(444, l));
    }
  }
  function cu(l) {
    return 'href="' + Ql(l) + '"';
  }
  function Pu(l) {
    return 'link[rel="stylesheet"][' + l + ']';
  }
  function Dd(l) {
    return V({}, l, { 'data-precedence': l.precedence, precedence: null });
  }
  function P1(l, t, a, u) {
    l.querySelector('link[rel="preload"][as="style"][' + t + ']')
      ? (u.loading = 1)
      : ((t = l.createElement('link')),
        (u.preload = t),
        t.addEventListener('load', function () {
          return (u.loading |= 1);
        }),
        t.addEventListener('error', function () {
          return (u.loading |= 2);
        }),
        ol(t, 'link', a),
        il(t),
        l.head.appendChild(t));
  }
  function fu(l) {
    return '[src="' + Ql(l) + '"]';
  }
  function le(l) {
    return 'script[async]' + l;
  }
  function Od(l, t, a) {
    if ((t.count++, t.instance === null))
      switch (t.type) {
        case 'style':
          var u = l.querySelector('style[data-href~="' + Ql(a.href) + '"]');
          if (u) return ((t.instance = u), il(u), u);
          var e = V({}, a, {
            'data-href': a.href,
            'data-precedence': a.precedence,
            href: null,
            precedence: null,
          });
          return (
            (u = (l.ownerDocument || l).createElement('style')),
            il(u),
            ol(u, 'style', e),
            rn(u, a.precedence, l),
            (t.instance = u)
          );
        case 'stylesheet':
          e = cu(a.href);
          var n = l.querySelector(Pu(e));
          if (n) return ((t.state.loading |= 4), (t.instance = n), il(n), n);
          ((u = Dd(a)),
            (e = wl.get(e)) && jf(u, e),
            (n = (l.ownerDocument || l).createElement('link')),
            il(n));
          var c = n;
          return (
            (c._p = new Promise(function (f, i) {
              ((c.onload = f), (c.onerror = i));
            })),
            ol(n, 'link', u),
            (t.state.loading |= 4),
            rn(n, a.precedence, l),
            (t.instance = n)
          );
        case 'script':
          return (
            (n = fu(a.src)),
            (e = l.querySelector(le(n)))
              ? ((t.instance = e), il(e), e)
              : ((u = a),
                (e = wl.get(n)) && ((u = V({}, a)), Gf(u, e)),
                (l = l.ownerDocument || l),
                (e = l.createElement('script')),
                il(e),
                ol(e, 'link', u),
                l.head.appendChild(e),
                (t.instance = e))
          );
        case 'void':
          return null;
        default:
          throw Error(o(443, t.type));
      }
    else
      t.type === 'stylesheet' &&
        (t.state.loading & 4) === 0 &&
        ((u = t.instance), (t.state.loading |= 4), rn(u, a.precedence, l));
    return t.instance;
  }
  function rn(l, t, a) {
    for (
      var u = a.querySelectorAll(
          'link[rel="stylesheet"][data-precedence],style[data-precedence]',
        ),
        e = u.length ? u[u.length - 1] : null,
        n = e,
        c = 0;
      c < u.length;
      c++
    ) {
      var f = u[c];
      if (f.dataset.precedence === t) n = f;
      else if (n !== e) break;
    }
    n
      ? n.parentNode.insertBefore(l, n.nextSibling)
      : ((t = a.nodeType === 9 ? a.head : a), t.insertBefore(l, t.firstChild));
  }
  function jf(l, t) {
    (l.crossOrigin == null && (l.crossOrigin = t.crossOrigin),
      l.referrerPolicy == null && (l.referrerPolicy = t.referrerPolicy),
      l.title == null && (l.title = t.title));
  }
  function Gf(l, t) {
    (l.crossOrigin == null && (l.crossOrigin = t.crossOrigin),
      l.referrerPolicy == null && (l.referrerPolicy = t.referrerPolicy),
      l.integrity == null && (l.integrity = t.integrity));
  }
  var zn = null;
  function xd(l, t, a) {
    if (zn === null) {
      var u = new Map(),
        e = (zn = new Map());
      e.set(a, u);
    } else ((e = zn), (u = e.get(a)), u || ((u = new Map()), e.set(a, u)));
    if (u.has(l)) return u;
    for (
      u.set(l, null), a = a.getElementsByTagName(l), e = 0;
      e < a.length;
      e++
    ) {
      var n = a[e];
      if (
        !(
          n[yu] ||
          n[bl] ||
          (l === 'link' && n.getAttribute('rel') === 'stylesheet')
        ) &&
        n.namespaceURI !== 'http://www.w3.org/2000/svg'
      ) {
        var c = n.getAttribute(t) || '';
        c = l + c;
        var f = u.get(c);
        f ? f.push(n) : u.set(c, [n]);
      }
    }
    return u;
  }
  function Ud(l, t, a) {
    ((l = l.ownerDocument || l),
      l.head.insertBefore(
        a,
        t === 'title' ? l.querySelector('head > title') : null,
      ));
  }
  function lv(l, t, a) {
    if (a === 1 || t.itemProp != null) return !1;
    switch (l) {
      case 'meta':
      case 'title':
        return !0;
      case 'style':
        if (
          typeof t.precedence != 'string' ||
          typeof t.href != 'string' ||
          t.href === ''
        )
          break;
        return !0;
      case 'link':
        if (
          typeof t.rel != 'string' ||
          typeof t.href != 'string' ||
          t.href === '' ||
          t.onLoad ||
          t.onError
        )
          break;
        switch (t.rel) {
          case 'stylesheet':
            return (
              (l = t.disabled),
              typeof t.precedence == 'string' && l == null
            );
          default:
            return !0;
        }
      case 'script':
        if (
          t.async &&
          typeof t.async != 'function' &&
          typeof t.async != 'symbol' &&
          !t.onLoad &&
          !t.onError &&
          t.src &&
          typeof t.src == 'string'
        )
          return !0;
    }
    return !1;
  }
  function Nd(l) {
    return !(l.type === 'stylesheet' && (l.state.loading & 3) === 0);
  }
  var te = null;
  function tv() {}
  function av(l, t, a) {
    if (te === null) throw Error(o(475));
    var u = te;
    if (
      t.type === 'stylesheet' &&
      (typeof a.media != 'string' || matchMedia(a.media).matches !== !1) &&
      (t.state.loading & 4) === 0
    ) {
      if (t.instance === null) {
        var e = cu(a.href),
          n = l.querySelector(Pu(e));
        if (n) {
          ((l = n._p),
            l !== null &&
              typeof l == 'object' &&
              typeof l.then == 'function' &&
              (u.count++, (u = An.bind(u)), l.then(u, u)),
            (t.state.loading |= 4),
            (t.instance = n),
            il(n));
          return;
        }
        ((n = l.ownerDocument || l),
          (a = Dd(a)),
          (e = wl.get(e)) && jf(a, e),
          (n = n.createElement('link')),
          il(n));
        var c = n;
        ((c._p = new Promise(function (f, i) {
          ((c.onload = f), (c.onerror = i));
        })),
          ol(n, 'link', a),
          (t.instance = n));
      }
      (u.stylesheets === null && (u.stylesheets = new Map()),
        u.stylesheets.set(t, l),
        (l = t.state.preload) &&
          (t.state.loading & 3) === 0 &&
          (u.count++,
          (t = An.bind(u)),
          l.addEventListener('load', t),
          l.addEventListener('error', t)));
    }
  }
  function uv() {
    if (te === null) throw Error(o(475));
    var l = te;
    return (
      l.stylesheets && l.count === 0 && Xf(l, l.stylesheets),
      0 < l.count
        ? function (t) {
            var a = setTimeout(function () {
              if ((l.stylesheets && Xf(l, l.stylesheets), l.unsuspend)) {
                var u = l.unsuspend;
                ((l.unsuspend = null), u());
              }
            }, 6e4);
            return (
              (l.unsuspend = t),
              function () {
                ((l.unsuspend = null), clearTimeout(a));
              }
            );
          }
        : null
    );
  }
  function An() {
    if ((this.count--, this.count === 0)) {
      if (this.stylesheets) Xf(this, this.stylesheets);
      else if (this.unsuspend) {
        var l = this.unsuspend;
        ((this.unsuspend = null), l());
      }
    }
  }
  var Tn = null;
  function Xf(l, t) {
    ((l.stylesheets = null),
      l.unsuspend !== null &&
        (l.count++,
        (Tn = new Map()),
        t.forEach(ev, l),
        (Tn = null),
        An.call(l)));
  }
  function ev(l, t) {
    if (!(t.state.loading & 4)) {
      var a = Tn.get(l);
      if (a) var u = a.get(null);
      else {
        ((a = new Map()), Tn.set(l, a));
        for (
          var e = l.querySelectorAll(
              'link[data-precedence],style[data-precedence]',
            ),
            n = 0;
          n < e.length;
          n++
        ) {
          var c = e[n];
          (c.nodeName === 'LINK' || c.getAttribute('media') !== 'not all') &&
            (a.set(c.dataset.precedence, c), (u = c));
        }
        u && a.set(null, u);
      }
      ((e = t.instance),
        (c = e.getAttribute('data-precedence')),
        (n = a.get(c) || u),
        n === u && a.set(null, e),
        a.set(c, e),
        this.count++,
        (u = An.bind(this)),
        e.addEventListener('load', u),
        e.addEventListener('error', u),
        n
          ? n.parentNode.insertBefore(e, n.nextSibling)
          : ((l = l.nodeType === 9 ? l.head : l),
            l.insertBefore(e, l.firstChild)),
        (t.state.loading |= 4));
    }
  }
  var ae = {
    $$typeof: jl,
    Provider: null,
    Consumer: null,
    _currentValue: U,
    _currentValue2: U,
    _threadCount: 0,
  };
  function nv(l, t, a, u, e, n, c, f) {
    ((this.tag = 1),
      (this.containerInfo = l),
      (this.pingCache = this.current = this.pendingChildren = null),
      (this.timeoutHandle = -1),
      (this.callbackNode =
        this.next =
        this.pendingContext =
        this.context =
        this.cancelPendingCommit =
          null),
      (this.callbackPriority = 0),
      (this.expirationTimes = pn(-1)),
      (this.entangledLanes =
        this.shellSuspendCounter =
        this.errorRecoveryDisabledLanes =
        this.expiredLanes =
        this.warmLanes =
        this.pingedLanes =
        this.suspendedLanes =
        this.pendingLanes =
          0),
      (this.entanglements = pn(0)),
      (this.hiddenUpdates = pn(null)),
      (this.identifierPrefix = u),
      (this.onUncaughtError = e),
      (this.onCaughtError = n),
      (this.onRecoverableError = c),
      (this.pooledCache = null),
      (this.pooledCacheLanes = 0),
      (this.formState = f),
      (this.incompleteTransitions = new Map()));
  }
  function Hd(l, t, a, u, e, n, c, f, i, v, g, r) {
    return (
      (l = new nv(l, t, a, c, f, i, v, r)),
      (t = 1),
      n === !0 && (t |= 24),
      (n = Hl(3, null, null, t)),
      (l.current = n),
      (n.stateNode = l),
      (t = rc()),
      t.refCount++,
      (l.pooledCache = t),
      t.refCount++,
      (n.memoizedState = { element: u, isDehydrated: a, cache: t }),
      Mc(n),
      l
    );
  }
  function _d(l) {
    return l ? ((l = Ga), l) : Ga;
  }
  function Rd(l, t, a, u, e, n) {
    ((e = _d(e)),
      u.context === null ? (u.context = e) : (u.pendingContext = e),
      (u = Bt(t)),
      (u.payload = { element: a }),
      (n = n === void 0 ? null : n),
      n !== null && (u.callback = n),
      (a = Yt(l, u, t)),
      a !== null && (Bl(a, l, t), Ru(a, l, t)));
  }
  function qd(l, t) {
    if (((l = l.memoizedState), l !== null && l.dehydrated !== null)) {
      var a = l.retryLane;
      l.retryLane = a !== 0 && a < t ? a : t;
    }
  }
  function Qf(l, t) {
    (qd(l, t), (l = l.alternate) && qd(l, t));
  }
  function pd(l) {
    if (l.tag === 13) {
      var t = ja(l, 67108864);
      (t !== null && Bl(t, l, 67108864), Qf(l, 67108864));
    }
  }
  var Mn = !0;
  function cv(l, t, a, u) {
    var e = S.T;
    S.T = null;
    var n = A.p;
    try {
      ((A.p = 2), Zf(l, t, a, u));
    } finally {
      ((A.p = n), (S.T = e));
    }
  }
  function fv(l, t, a, u) {
    var e = S.T;
    S.T = null;
    var n = A.p;
    try {
      ((A.p = 8), Zf(l, t, a, u));
    } finally {
      ((A.p = n), (S.T = e));
    }
  }
  function Zf(l, t, a, u) {
    if (Mn) {
      var e = Vf(u);
      if (e === null) (Uf(l, t, u, En, a), Yd(l, u));
      else if (sv(e, l, t, a, u)) u.stopPropagation();
      else if ((Yd(l, u), t & 4 && -1 < iv.indexOf(l))) {
        for (; e !== null; ) {
          var n = Da(e);
          if (n !== null)
            switch (n.tag) {
              case 3:
                if (((n = n.stateNode), n.current.memoizedState.isDehydrated)) {
                  var c = aa(n.pendingLanes);
                  if (c !== 0) {
                    var f = n;
                    for (f.pendingLanes |= 2, f.entangledLanes |= 2; c; ) {
                      var i = 1 << (31 - Ul(c));
                      ((f.entanglements[1] |= i), (c &= ~i));
                    }
                    (ft(n), (Y & 6) === 0 && ((cn = at() + 500), ku(0)));
                  }
                }
                break;
              case 13:
                ((f = ja(n, 2)), f !== null && Bl(f, n, 2), sn(), Qf(n, 2));
            }
          if (((n = Vf(u)), n === null && Uf(l, t, u, En, a), n === e)) break;
          e = n;
        }
        e !== null && u.stopPropagation();
      } else Uf(l, t, u, null, a);
    }
  }
  function Vf(l) {
    return ((l = Jn(l)), Cf(l));
  }
  var En = null;
  function Cf(l) {
    if (((En = null), (l = Ea(l)), l !== null)) {
      var t = el(l);
      if (t === null) l = null;
      else {
        var a = t.tag;
        if (a === 13) {
          if (((l = it(t)), l !== null)) return l;
          l = null;
        } else if (a === 3) {
          if (t.stateNode.current.memoizedState.isDehydrated)
            return t.tag === 3 ? t.stateNode.containerInfo : null;
          l = null;
        } else t !== l && (l = null);
      }
    }
    return ((En = l), null);
  }
  function Bd(l) {
    switch (l) {
      case 'beforetoggle':
      case 'cancel':
      case 'click':
      case 'close':
      case 'contextmenu':
      case 'copy':
      case 'cut':
      case 'auxclick':
      case 'dblclick':
      case 'dragend':
      case 'dragstart':
      case 'drop':
      case 'focusin':
      case 'focusout':
      case 'input':
      case 'invalid':
      case 'keydown':
      case 'keypress':
      case 'keyup':
      case 'mousedown':
      case 'mouseup':
      case 'paste':
      case 'pause':
      case 'play':
      case 'pointercancel':
      case 'pointerdown':
      case 'pointerup':
      case 'ratechange':
      case 'reset':
      case 'resize':
      case 'seeked':
      case 'submit':
      case 'toggle':
      case 'touchcancel':
      case 'touchend':
      case 'touchstart':
      case 'volumechange':
      case 'change':
      case 'selectionchange':
      case 'textInput':
      case 'compositionstart':
      case 'compositionend':
      case 'compositionupdate':
      case 'beforeblur':
      case 'afterblur':
      case 'beforeinput':
      case 'blur':
      case 'fullscreenchange':
      case 'focus':
      case 'hashchange':
      case 'popstate':
      case 'select':
      case 'selectstart':
        return 2;
      case 'drag':
      case 'dragenter':
      case 'dragexit':
      case 'dragleave':
      case 'dragover':
      case 'mousemove':
      case 'mouseout':
      case 'mouseover':
      case 'pointermove':
      case 'pointerout':
      case 'pointerover':
      case 'scroll':
      case 'touchmove':
      case 'wheel':
      case 'mouseenter':
      case 'mouseleave':
      case 'pointerenter':
      case 'pointerleave':
        return 8;
      case 'message':
        switch (wd()) {
          case kf:
            return 2;
          case $f:
            return 8;
          case oe:
          case Wd:
            return 32;
          case Ff:
            return 268435456;
          default:
            return 32;
        }
      default:
        return 32;
    }
  }
  var Kf = !1,
    kt = null,
    $t = null,
    Ft = null,
    ue = new Map(),
    ee = new Map(),
    It = [],
    iv =
      'mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset'.split(
        ' ',
      );
  function Yd(l, t) {
    switch (l) {
      case 'focusin':
      case 'focusout':
        kt = null;
        break;
      case 'dragenter':
      case 'dragleave':
        $t = null;
        break;
      case 'mouseover':
      case 'mouseout':
        Ft = null;
        break;
      case 'pointerover':
      case 'pointerout':
        ue.delete(t.pointerId);
        break;
      case 'gotpointercapture':
      case 'lostpointercapture':
        ee.delete(t.pointerId);
    }
  }
  function ne(l, t, a, u, e, n) {
    return l === null || l.nativeEvent !== n
      ? ((l = {
          blockedOn: t,
          domEventName: a,
          eventSystemFlags: u,
          nativeEvent: n,
          targetContainers: [e],
        }),
        t !== null && ((t = Da(t)), t !== null && pd(t)),
        l)
      : ((l.eventSystemFlags |= u),
        (t = l.targetContainers),
        e !== null && t.indexOf(e) === -1 && t.push(e),
        l);
  }
  function sv(l, t, a, u, e) {
    switch (t) {
      case 'focusin':
        return ((kt = ne(kt, l, t, a, u, e)), !0);
      case 'dragenter':
        return (($t = ne($t, l, t, a, u, e)), !0);
      case 'mouseover':
        return ((Ft = ne(Ft, l, t, a, u, e)), !0);
      case 'pointerover':
        var n = e.pointerId;
        return (ue.set(n, ne(ue.get(n) || null, l, t, a, u, e)), !0);
      case 'gotpointercapture':
        return (
          (n = e.pointerId),
          ee.set(n, ne(ee.get(n) || null, l, t, a, u, e)),
          !0
        );
    }
    return !1;
  }
  function jd(l) {
    var t = Ea(l.target);
    if (t !== null) {
      var a = el(t);
      if (a !== null) {
        if (((t = a.tag), t === 13)) {
          if (((t = it(a)), t !== null)) {
            ((l.blockedOn = t),
              ah(l.priority, function () {
                if (a.tag === 13) {
                  var u = pl();
                  u = Bn(u);
                  var e = ja(a, u);
                  (e !== null && Bl(e, a, u), Qf(a, u));
                }
              }));
            return;
          }
        } else if (t === 3 && a.stateNode.current.memoizedState.isDehydrated) {
          l.blockedOn = a.tag === 3 ? a.stateNode.containerInfo : null;
          return;
        }
      }
    }
    l.blockedOn = null;
  }
  function Dn(l) {
    if (l.blockedOn !== null) return !1;
    for (var t = l.targetContainers; 0 < t.length; ) {
      var a = Vf(l.nativeEvent);
      if (a === null) {
        a = l.nativeEvent;
        var u = new a.constructor(a.type, a);
        ((Ln = u), a.target.dispatchEvent(u), (Ln = null));
      } else return ((t = Da(a)), t !== null && pd(t), (l.blockedOn = a), !1);
      t.shift();
    }
    return !0;
  }
  function Gd(l, t, a) {
    Dn(l) && a.delete(t);
  }
  function dv() {
    ((Kf = !1),
      kt !== null && Dn(kt) && (kt = null),
      $t !== null && Dn($t) && ($t = null),
      Ft !== null && Dn(Ft) && (Ft = null),
      ue.forEach(Gd),
      ee.forEach(Gd));
  }
  function On(l, t) {
    l.blockedOn === t &&
      ((l.blockedOn = null),
      Kf ||
        ((Kf = !0),
        E.unstable_scheduleCallback(E.unstable_NormalPriority, dv)));
  }
  var xn = null;
  function Xd(l) {
    xn !== l &&
      ((xn = l),
      E.unstable_scheduleCallback(E.unstable_NormalPriority, function () {
        xn === l && (xn = null);
        for (var t = 0; t < l.length; t += 3) {
          var a = l[t],
            u = l[t + 1],
            e = l[t + 2];
          if (typeof u != 'function') {
            if (Cf(u || a) === null) continue;
            break;
          }
          var n = Da(a);
          n !== null &&
            (l.splice(t, 3),
            (t -= 3),
            Vc(n, { pending: !0, data: e, method: a.method, action: u }, u, e));
        }
      }));
  }
  function ce(l) {
    function t(i) {
      return On(i, l);
    }
    (kt !== null && On(kt, l),
      $t !== null && On($t, l),
      Ft !== null && On(Ft, l),
      ue.forEach(t),
      ee.forEach(t));
    for (var a = 0; a < It.length; a++) {
      var u = It[a];
      u.blockedOn === l && (u.blockedOn = null);
    }
    for (; 0 < It.length && ((a = It[0]), a.blockedOn === null); )
      (jd(a), a.blockedOn === null && It.shift());
    if (((a = (l.ownerDocument || l).$$reactFormReplay), a != null))
      for (u = 0; u < a.length; u += 3) {
        var e = a[u],
          n = a[u + 1],
          c = e[Tl] || null;
        if (typeof n == 'function') c || Xd(a);
        else if (c) {
          var f = null;
          if (n && n.hasAttribute('formAction')) {
            if (((e = n), (c = n[Tl] || null))) f = c.formAction;
            else if (Cf(e) !== null) continue;
          } else f = c.action;
          (typeof f == 'function' ? (a[u + 1] = f) : (a.splice(u, 3), (u -= 3)),
            Xd(a));
        }
      }
  }
  function Lf(l) {
    this._internalRoot = l;
  }
  ((Un.prototype.render = Lf.prototype.render =
    function (l) {
      var t = this._internalRoot;
      if (t === null) throw Error(o(409));
      var a = t.current,
        u = pl();
      Rd(a, u, l, t, null, null);
    }),
    (Un.prototype.unmount = Lf.prototype.unmount =
      function () {
        var l = this._internalRoot;
        if (l !== null) {
          this._internalRoot = null;
          var t = l.containerInfo;
          (Rd(l.current, 2, null, l, null, null), sn(), (t[Ma] = null));
        }
      }));
  function Un(l) {
    this._internalRoot = l;
  }
  Un.prototype.unstable_scheduleHydration = function (l) {
    if (l) {
      var t = ai();
      l = { blockedOn: null, target: l, priority: t };
      for (var a = 0; a < It.length && t !== 0 && t < It[a].priority; a++);
      (It.splice(a, 0, l), a === 0 && jd(l));
    }
  };
  var Qd = vl.version;
  if (Qd !== '19.1.0') throw Error(o(527, Qd, '19.1.0'));
  A.findDOMNode = function (l) {
    var t = l._reactInternals;
    if (t === void 0)
      throw typeof l.render == 'function'
        ? Error(o(188))
        : ((l = Object.keys(l).join(',')), Error(o(268, l)));
    return (
      (l = Wl(t)),
      (l = l !== null ? kl(l) : null),
      (l = l === null ? null : l.stateNode),
      l
    );
  };
  var hv = {
    bundleType: 0,
    version: '19.1.0',
    rendererPackageName: 'react-dom',
    currentDispatcherRef: S,
    reconcilerVersion: '19.1.0',
  };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < 'u') {
    var Nn = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!Nn.isDisabled && Nn.supportsFiber)
      try {
        ((du = Nn.inject(hv)), (xl = Nn));
      } catch {}
  }
  return (
    (fe.createRoot = function (l, t) {
      if (!W(l)) throw Error(o(299));
      var a = !1,
        u = '',
        e = as,
        n = us,
        c = es,
        f = null;
      return (
        t != null &&
          (t.unstable_strictMode === !0 && (a = !0),
          t.identifierPrefix !== void 0 && (u = t.identifierPrefix),
          t.onUncaughtError !== void 0 && (e = t.onUncaughtError),
          t.onCaughtError !== void 0 && (n = t.onCaughtError),
          t.onRecoverableError !== void 0 && (c = t.onRecoverableError),
          t.unstable_transitionCallbacks !== void 0 &&
            (f = t.unstable_transitionCallbacks)),
        (t = Hd(l, 1, !1, null, null, a, u, e, n, c, f, null)),
        (l[Ma] = t.current),
        xf(l),
        new Lf(t)
      );
    }),
    (fe.hydrateRoot = function (l, t, a) {
      if (!W(l)) throw Error(o(299));
      var u = !1,
        e = '',
        n = as,
        c = us,
        f = es,
        i = null,
        v = null;
      return (
        a != null &&
          (a.unstable_strictMode === !0 && (u = !0),
          a.identifierPrefix !== void 0 && (e = a.identifierPrefix),
          a.onUncaughtError !== void 0 && (n = a.onUncaughtError),
          a.onCaughtError !== void 0 && (c = a.onCaughtError),
          a.onRecoverableError !== void 0 && (f = a.onRecoverableError),
          a.unstable_transitionCallbacks !== void 0 &&
            (i = a.unstable_transitionCallbacks),
          a.formState !== void 0 && (v = a.formState)),
        (t = Hd(l, 1, !0, t, a ?? null, u, e, n, c, f, i, v)),
        (t.context = _d(null)),
        (a = t.current),
        (u = pl()),
        (u = Bn(u)),
        (e = Bt(u)),
        (e.callback = null),
        Yt(a, e, u),
        (a = u),
        (t.current.lanes = a),
        vu(t, a),
        ft(t),
        (l[Ma] = t.current),
        xf(l),
        new Un(t)
      );
    }),
    (fe.version = '19.1.0'),
    fe
  );
}
var Kd;
function Av() {
  if (Kd) return Jf.exports;
  Kd = 1;
  function E() {
    if (
      !(
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > 'u' ||
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != 'function'
      )
    )
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(E);
      } catch (vl) {
        console.error(vl);
      }
  }
  return (E(), (Jf.exports = zv()), Jf.exports);
}
var Tv = Av();
const Mv = bv(Tv);
function Ev() {
  const [E, vl] = yv.useState('landing'),
    gl = { displayName: 'Epic Adventurer' };
  return z.jsxs('div', {
    className: 'min-h-screen relative',
    children: [
      z.jsx('div', {
        className: 'absolute inset-0',
        style: {
          backgroundImage: 'url(/images/twin_dragon.png)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundColor: 'rgb(88, 28, 135)',
        },
      }),
      z.jsx('div', {
        className: 'absolute inset-0',
        style: {
          background:
            'linear-gradient(to bottom right, rgba(147, 51, 234, 0.4), rgba(126, 34, 206, 0.35), rgba(79, 70, 229, 0.4))',
        },
      }),
      z.jsxs('div', {
        className: 'relative z-10',
        children: [
          z.jsx('header', {
            style: {
              backgroundColor: 'rgba(0, 0, 0, 0.2)',
              backdropFilter: 'blur(4px)',
              borderBottom: '1px solid rgba(168, 85, 247, 0.2)',
            },
            children: z.jsxs('div', {
              className:
                'container mx-auto px-4 py-4 flex justify-between items-center',
              children: [
                z.jsxs('div', {
                  className: 'flex items-center space-x-2',
                  children: [
                    z.jsx('span', { className: 'text-2xl', children: '🎲' }),
                    z.jsx('h1', {
                      style: {
                        fontSize: '1.25rem',
                        fontWeight: 'bold',
                        color: 'white',
                      },
                      children: 'WorldArchitect.AI',
                    }),
                  ],
                }),
                z.jsxs('div', {
                  className: 'flex items-center space-x-4',
                  children: [
                    z.jsxs('span', {
                      style: { color: 'rgb(233, 213, 255)' },
                      children: ['Welcome, ', gl.displayName],
                    }),
                    z.jsx('div', {
                      className:
                        'rounded-full flex items-center justify-center',
                      style: {
                        width: '32px',
                        height: '32px',
                        backgroundColor: 'rgb(147, 51, 234)',
                      },
                      children: z.jsx('span', {
                        style: { color: 'white', fontSize: '0.875rem' },
                        children: 'EA',
                      }),
                    }),
                  ],
                }),
              ],
            }),
          }),
          z.jsxs('main', {
            className: 'container mx-auto px-4 py-8',
            children: [
              E === 'landing' &&
                z.jsxs('div', {
                  className: 'text-center',
                  children: [
                    z.jsx('h1', {
                      style: {
                        fontSize: '3.75rem',
                        fontWeight: 'bold',
                        color: 'white',
                        marginBottom: '1rem',
                      },
                      children: 'Welcome to WorldArchitect.AI',
                    }),
                    z.jsx('p', {
                      style: {
                        fontSize: '1.25rem',
                        color: 'rgb(233, 213, 255)',
                        marginBottom: '2rem',
                      },
                      children: 'Your AI-powered D&D Game Master awaits',
                    }),
                    z.jsxs('div', {
                      className:
                        'grid md:grid-cols-3 gap-6 max-w-4xl mx-auto mb-8',
                      children: [
                        z.jsxs('div', {
                          style: {
                            backgroundColor: 'rgba(255, 255, 255, 0.1)',
                            backdropFilter: 'blur(4px)',
                            borderRadius: '0.5rem',
                            padding: '1.5rem',
                            border: '1px solid rgba(168, 85, 247, 0.2)',
                          },
                          children: [
                            z.jsx('div', {
                              style: {
                                fontSize: '1.875rem',
                                marginBottom: '0.5rem',
                              },
                              children: '🤖',
                            }),
                            z.jsx('h3', {
                              style: {
                                fontSize: '1.125rem',
                                fontWeight: '600',
                                color: 'white',
                                marginBottom: '0.5rem',
                              },
                              children: 'AI Game Master',
                            }),
                            z.jsx('p', {
                              style: { color: 'rgb(233, 213, 255)' },
                              children:
                                'Intelligent storytelling that adapts to your choices',
                            }),
                          ],
                        }),
                        z.jsxs('div', {
                          style: {
                            backgroundColor: 'rgba(255, 255, 255, 0.1)',
                            backdropFilter: 'blur(4px)',
                            borderRadius: '0.5rem',
                            padding: '1.5rem',
                            border: '1px solid rgba(168, 85, 247, 0.2)',
                          },
                          children: [
                            z.jsx('div', {
                              style: {
                                fontSize: '1.875rem',
                                marginBottom: '0.5rem',
                              },
                              children: '📚',
                            }),
                            z.jsx('h3', {
                              style: {
                                fontSize: '1.125rem',
                                fontWeight: '600',
                                color: 'white',
                                marginBottom: '0.5rem',
                              },
                              children: 'Rich Storytelling',
                            }),
                            z.jsx('p', {
                              style: { color: 'rgb(233, 213, 255)' },
                              children:
                                'Immersive narratives with dynamic world-building',
                            }),
                          ],
                        }),
                        z.jsxs('div', {
                          style: {
                            backgroundColor: 'rgba(255, 255, 255, 0.1)',
                            backdropFilter: 'blur(4px)',
                            borderRadius: '0.5rem',
                            padding: '1.5rem',
                            border: '1px solid rgba(168, 85, 247, 0.2)',
                          },
                          children: [
                            z.jsx('div', {
                              style: {
                                fontSize: '1.875rem',
                                marginBottom: '0.5rem',
                              },
                              children: '🌍',
                            }),
                            z.jsx('h3', {
                              style: {
                                fontSize: '1.125rem',
                                fontWeight: '600',
                                color: 'white',
                                marginBottom: '0.5rem',
                              },
                              children: 'Dynamic World',
                            }),
                            z.jsx('p', {
                              style: { color: 'rgb(233, 213, 255)' },
                              children:
                                'Living worlds that evolve with your adventures',
                            }),
                          ],
                        }),
                      ],
                    }),
                    z.jsx('button', {
                      onClick: () => vl('campaigns'),
                      style: {
                        background:
                          'linear-gradient(to right, rgb(147, 51, 234), rgb(219, 39, 119))',
                        color: 'white',
                        padding: '0.75rem 2rem',
                        borderRadius: '0.5rem',
                        fontWeight: '600',
                        border: 'none',
                        cursor: 'pointer',
                        fontSize: '1.125rem',
                        transition: 'all 0.3s',
                      },
                      onMouseEnter: (o) => {
                        ((o.currentTarget.style.transform = 'scale(1.05)'),
                          (o.currentTarget.style.boxShadow =
                            '0 10px 20px rgba(0,0,0,0.2)'));
                      },
                      onMouseLeave: (o) => {
                        ((o.currentTarget.style.transform = 'scale(1)'),
                          (o.currentTarget.style.boxShadow = 'none'));
                      },
                      children: '✨ Start Your Adventure ✨',
                    }),
                  ],
                }),
              E === 'campaigns' &&
                z.jsxs('div', {
                  children: [
                    z.jsxs('div', {
                      className: 'flex justify-between items-center mb-6',
                      children: [
                        z.jsx('h2', {
                          style: {
                            fontSize: '1.875rem',
                            fontWeight: 'bold',
                            color: 'white',
                          },
                          children: 'Your Campaigns',
                        }),
                        z.jsx('button', {
                          onClick: () => vl('landing'),
                          style: {
                            color: 'rgb(216, 180, 254)',
                            cursor: 'pointer',
                            background: 'none',
                            border: 'none',
                          },
                          onMouseEnter: (o) =>
                            (o.currentTarget.style.color = 'white'),
                          onMouseLeave: (o) =>
                            (o.currentTarget.style.color =
                              'rgb(216, 180, 254)'),
                          children: '← Back',
                        }),
                      ],
                    }),
                    z.jsxs('div', {
                      className: 'grid md:grid-cols-2 lg:grid-cols-3 gap-6',
                      children: [
                        z.jsxs('div', {
                          style: {
                            backgroundColor: 'rgba(255, 255, 255, 0.1)',
                            backdropFilter: 'blur(4px)',
                            borderRadius: '0.5rem',
                            padding: '1.5rem',
                            border: '1px solid rgba(168, 85, 247, 0.2)',
                            cursor: 'pointer',
                            transition: 'all 0.3s',
                          },
                          onMouseEnter: (o) =>
                            (o.currentTarget.style.borderColor =
                              'rgba(168, 85, 247, 0.4)'),
                          onMouseLeave: (o) =>
                            (o.currentTarget.style.borderColor =
                              'rgba(168, 85, 247, 0.2)'),
                          onClick: () => vl('gameplay'),
                          children: [
                            z.jsxs('div', {
                              className:
                                'flex justify-between items-start mb-4',
                              children: [
                                z.jsx('h3', {
                                  className: 'text-lg font-semibold text-white',
                                  children: "The Dragon's Hoard",
                                }),
                                z.jsx('span', {
                                  className:
                                    'bg-green-500 text-white text-xs px-2 py-1 rounded',
                                  children: 'Active',
                                }),
                              ],
                            }),
                            z.jsx('p', {
                              className: 'text-purple-200 text-sm mb-4',
                              children:
                                'A classic quest to reclaim an ancient treasure from a fearsome dragon.',
                            }),
                            z.jsxs('div', {
                              className:
                                'flex justify-between text-sm text-purple-300',
                              children: [
                                z.jsx('span', { children: '3/5 Players' }),
                                z.jsx('span', { children: '2 hours ago' }),
                              ],
                            }),
                          ],
                        }),
                        z.jsx('div', {
                          className:
                            'bg-white/5 backdrop-blur-sm rounded-lg p-6 border-2 border-dashed border-purple-500/40 hover:border-purple-400/60 transition-colors cursor-pointer flex items-center justify-center',
                          children: z.jsxs('div', {
                            className: 'text-center',
                            children: [
                              z.jsx('div', {
                                className: 'text-4xl text-purple-400 mb-2',
                                children: '+',
                              }),
                              z.jsx('p', {
                                className: 'text-purple-300',
                                children: 'Create New Campaign',
                              }),
                            ],
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
              E === 'gameplay' &&
                z.jsxs('div', {
                  children: [
                    z.jsxs('div', {
                      className: 'flex justify-between items-center mb-6',
                      children: [
                        z.jsx('h2', {
                          className: 'text-3xl font-bold text-white',
                          children: "The Dragon's Hoard",
                        }),
                        z.jsx('button', {
                          onClick: () => vl('campaigns'),
                          className: 'text-purple-300 hover:text-white',
                          children: '← Back to Campaigns',
                        }),
                      ],
                    }),
                    z.jsxs('div', {
                      className:
                        'bg-white/10 backdrop-blur-sm rounded-lg border border-purple-500/20 h-96 flex flex-col',
                      children: [
                        z.jsx('div', {
                          className: 'flex-1 p-4 overflow-y-auto',
                          children: z.jsxs('div', {
                            className: 'space-y-4',
                            children: [
                              z.jsxs('div', {
                                className:
                                  'bg-purple-600/20 rounded-lg p-3 max-w-md',
                                children: [
                                  z.jsx('div', {
                                    className: 'text-purple-300 text-xs mb-1',
                                    children: 'Game Master',
                                  }),
                                  z.jsx('p', {
                                    className: 'text-white',
                                    children:
                                      "Welcome back, brave adventurer! You stand before the ancient dragon's lair. The massive entrance is carved into the mountainside, with intricate draconic runes glowing faintly around the archway...",
                                  }),
                                ],
                              }),
                              z.jsxs('div', {
                                className:
                                  'bg-blue-600/20 rounded-lg p-3 max-w-md ml-auto',
                                children: [
                                  z.jsx('div', {
                                    className: 'text-blue-300 text-xs mb-1',
                                    children: 'You',
                                  }),
                                  z.jsx('p', {
                                    className: 'text-white',
                                    children:
                                      'I examine the runes closely, looking for any clues about their meaning or potential traps.',
                                  }),
                                ],
                              }),
                              z.jsxs('div', {
                                className:
                                  'bg-purple-600/20 rounded-lg p-3 max-w-md',
                                children: [
                                  z.jsx('div', {
                                    className: 'text-purple-300 text-xs mb-1',
                                    children: 'Game Master',
                                  }),
                                  z.jsx('p', {
                                    className: 'text-white',
                                    children:
                                      'Roll for Investigation... You notice the runes seem to be a warning about "those who seek without honor." What would you like to do?',
                                  }),
                                  z.jsxs('div', {
                                    className: 'mt-3 flex flex-wrap gap-2',
                                    children: [
                                      z.jsx('button', {
                                        className:
                                          'bg-purple-500 hover:bg-purple-600 text-white text-sm px-3 py-1 rounded',
                                        children: 'Proceed cautiously',
                                      }),
                                      z.jsx('button', {
                                        className:
                                          'bg-purple-500 hover:bg-purple-600 text-white text-sm px-3 py-1 rounded',
                                        children: 'Cast Detect Magic',
                                      }),
                                      z.jsx('button', {
                                        className:
                                          'bg-purple-500 hover:bg-purple-600 text-white text-sm px-3 py-1 rounded',
                                        children: 'Turn back',
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                        }),
                        z.jsxs('div', {
                          className: 'border-t border-purple-500/20 p-4',
                          children: [
                            z.jsxs('div', {
                              className: 'flex space-x-2',
                              children: [
                                z.jsx('input', {
                                  type: 'text',
                                  placeholder: 'Describe your action...',
                                  className:
                                    'flex-1 bg-white/10 border border-purple-500/20 rounded-lg px-4 py-2 text-white placeholder-purple-300 focus:outline-none focus:border-purple-400',
                                }),
                                z.jsx('button', {
                                  className:
                                    'bg-purple-600 hover:bg-purple-700 text-white px-6 py-2 rounded-lg',
                                  children: 'Send',
                                }),
                              ],
                            }),
                            z.jsxs('div', {
                              className: 'flex justify-between mt-2 text-sm',
                              children: [
                                z.jsx('button', {
                                  className: 'text-purple-300 hover:text-white',
                                  children: 'Character Mode',
                                }),
                                z.jsx('button', {
                                  className: 'text-purple-300 hover:text-white',
                                  children: '🎲 Roll Dice',
                                }),
                              ],
                            }),
                          ],
                        }),
                      ],
                    }),
                  ],
                }),
            ],
          }),
        ],
      }),
    ],
  });
}
Mv.createRoot(document.getElementById('root')).render(
  z.jsx(mv.StrictMode, { children: z.jsx(Ev, {}) }),
);
