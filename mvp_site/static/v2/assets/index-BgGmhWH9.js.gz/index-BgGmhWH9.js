import { r as On, j as h, R as rv } from './ui-CbO0uvlw.js';
import { r as yv, a as ov, g as bv } from './vendor-DJG_os-6.js';
(function () {
  const il = document.createElement('link').relList;
  if (il && il.supports && il.supports('modulepreload')) return;
  for (const J of document.querySelectorAll('link[rel="modulepreload"]')) b(J);
  new MutationObserver((J) => {
    for (const j of J)
      if (j.type === 'childList')
        for (const El of j.addedNodes)
          El.tagName === 'LINK' && El.rel === 'modulepreload' && b(El);
  }).observe(document, { childList: !0, subtree: !0 });
  function fl(J) {
    const j = {};
    return (
      J.integrity && (j.integrity = J.integrity),
      J.referrerPolicy && (j.referrerPolicy = J.referrerPolicy),
      J.crossOrigin === 'use-credentials'
        ? (j.credentials = 'include')
        : J.crossOrigin === 'anonymous'
          ? (j.credentials = 'omit')
          : (j.credentials = 'same-origin'),
      j
    );
  }
  function b(J) {
    if (J.ep) return;
    J.ep = !0;
    const j = fl(J);
    fetch(J.href, j);
  }
})();
var Ji = { exports: {} },
  fe = {},
  wi = { exports: {} },
  Wi = {};
/**
 * @license React
 * scheduler.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Vd;
function gv() {
  return (
    Vd ||
      ((Vd = 1),
      (function (A) {
        function il(x, p) {
          var D = x.length;
          x.push(p);
          l: for (; 0 < D; ) {
            var w = (D - 1) >>> 1,
              W = x[w];
            if (0 < J(W, p)) ((x[w] = p), (x[D] = W), (D = w));
            else break l;
          }
        }
        function fl(x) {
          return x.length === 0 ? null : x[0];
        }
        function b(x) {
          if (x.length === 0) return null;
          var p = x[0],
            D = x.pop();
          if (D !== p) {
            x[0] = D;
            l: for (var w = 0, W = x.length, xl = W >>> 1; w < xl; ) {
              var $ = 2 * (w + 1) - 1,
                X = x[$],
                sl = $ + 1,
                at = x[sl];
              if (0 > J(X, D))
                sl < W && 0 > J(at, X)
                  ? ((x[w] = at), (x[sl] = D), (w = sl))
                  : ((x[w] = X), (x[$] = D), (w = $));
              else if (sl < W && 0 > J(at, D))
                ((x[w] = at), (x[sl] = D), (w = sl));
              else break l;
            }
          }
          return p;
        }
        function J(x, p) {
          var D = x.sortIndex - p.sortIndex;
          return D !== 0 ? D : x.id - p.id;
        }
        if (
          ((A.unstable_now = void 0),
          typeof performance == 'object' &&
            typeof performance.now == 'function')
        ) {
          var j = performance;
          A.unstable_now = function () {
            return j.now();
          };
        } else {
          var El = Date,
            Sa = El.now();
          A.unstable_now = function () {
            return El.now() - Sa;
          };
        }
        var kl = [],
          $l = [],
          C = 1,
          pl = null,
          ll = 3,
          st = !1,
          Yl = !1,
          Et = !1,
          la = !1,
          se = typeof setTimeout == 'function' ? setTimeout : null,
          su = typeof clearTimeout == 'function' ? clearTimeout : null,
          Gl = typeof setImmediate < 'u' ? setImmediate : null;
        function Dt(x) {
          for (var p = fl($l); p !== null; ) {
            if (p.callback === null) b($l);
            else if (p.startTime <= x)
              (b($l), (p.sortIndex = p.expirationTime), il(kl, p));
            else break;
            p = fl($l);
          }
        }
        function ta(x) {
          if (((Et = !1), Dt(x), !Yl))
            if (fl(kl) !== null) ((Yl = !0), tt || ((tt = !0), Xl()));
            else {
              var p = fl($l);
              p !== null && ht(ta, p.startTime - x);
            }
        }
        var tt = !1,
          dt = -1,
          Fl = 5,
          pa = -1;
        function de() {
          return la ? !0 : !(A.unstable_now() - pa < Fl);
        }
        function za() {
          if (((la = !1), tt)) {
            var x = A.unstable_now();
            pa = x;
            var p = !0;
            try {
              l: {
                ((Yl = !1), Et && ((Et = !1), su(dt), (dt = -1)), (st = !0));
                var D = ll;
                try {
                  t: {
                    for (
                      Dt(x), pl = fl(kl);
                      pl !== null && !(pl.expirationTime > x && de());

                    ) {
                      var w = pl.callback;
                      if (typeof w == 'function') {
                        ((pl.callback = null), (ll = pl.priorityLevel));
                        var W = w(pl.expirationTime <= x);
                        if (((x = A.unstable_now()), typeof W == 'function')) {
                          ((pl.callback = W), Dt(x), (p = !0));
                          break t;
                        }
                        (pl === fl(kl) && b(kl), Dt(x));
                      } else b(kl);
                      pl = fl(kl);
                    }
                    if (pl !== null) p = !0;
                    else {
                      var xl = fl($l);
                      (xl !== null && ht(ta, xl.startTime - x), (p = !1));
                    }
                  }
                  break l;
                } finally {
                  ((pl = null), (ll = D), (st = !1));
                }
                p = void 0;
              }
            } finally {
              p ? Xl() : (tt = !1);
            }
          }
        }
        var Xl;
        if (typeof Gl == 'function')
          Xl = function () {
            Gl(za);
          };
        else if (typeof MessageChannel < 'u') {
          var he = new MessageChannel(),
            du = he.port2;
          ((he.port1.onmessage = za),
            (Xl = function () {
              du.postMessage(null);
            }));
        } else
          Xl = function () {
            se(za, 0);
          };
        function ht(x, p) {
          dt = se(function () {
            x(A.unstable_now());
          }, p);
        }
        ((A.unstable_IdlePriority = 5),
          (A.unstable_ImmediatePriority = 1),
          (A.unstable_LowPriority = 4),
          (A.unstable_NormalPriority = 3),
          (A.unstable_Profiling = null),
          (A.unstable_UserBlockingPriority = 2),
          (A.unstable_cancelCallback = function (x) {
            x.callback = null;
          }),
          (A.unstable_forceFrameRate = function (x) {
            0 > x || 125 < x
              ? console.error(
                  'forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported',
                )
              : (Fl = 0 < x ? Math.floor(1e3 / x) : 5);
          }),
          (A.unstable_getCurrentPriorityLevel = function () {
            return ll;
          }),
          (A.unstable_next = function (x) {
            switch (ll) {
              case 1:
              case 2:
              case 3:
                var p = 3;
                break;
              default:
                p = ll;
            }
            var D = ll;
            ll = p;
            try {
              return x();
            } finally {
              ll = D;
            }
          }),
          (A.unstable_requestPaint = function () {
            la = !0;
          }),
          (A.unstable_runWithPriority = function (x, p) {
            switch (x) {
              case 1:
              case 2:
              case 3:
              case 4:
              case 5:
                break;
              default:
                x = 3;
            }
            var D = ll;
            ll = x;
            try {
              return p();
            } finally {
              ll = D;
            }
          }),
          (A.unstable_scheduleCallback = function (x, p, D) {
            var w = A.unstable_now();
            switch (
              (typeof D == 'object' && D !== null
                ? ((D = D.delay),
                  (D = typeof D == 'number' && 0 < D ? w + D : w))
                : (D = w),
              x)
            ) {
              case 1:
                var W = -1;
                break;
              case 2:
                W = 250;
                break;
              case 5:
                W = 1073741823;
                break;
              case 4:
                W = 1e4;
                break;
              default:
                W = 5e3;
            }
            return (
              (W = D + W),
              (x = {
                id: C++,
                callback: p,
                priorityLevel: x,
                startTime: D,
                expirationTime: W,
                sortIndex: -1,
              }),
              D > w
                ? ((x.sortIndex = D),
                  il($l, x),
                  fl(kl) === null &&
                    x === fl($l) &&
                    (Et ? (su(dt), (dt = -1)) : (Et = !0), ht(ta, D - w)))
                : ((x.sortIndex = W),
                  il(kl, x),
                  Yl || st || ((Yl = !0), tt || ((tt = !0), Xl()))),
              x
            );
          }),
          (A.unstable_shouldYield = de),
          (A.unstable_wrapCallback = function (x) {
            var p = ll;
            return function () {
              var D = ll;
              ll = p;
              try {
                return x.apply(this, arguments);
              } finally {
                ll = D;
              }
            };
          }));
      })(Wi)),
    Wi
  );
}
var Cd;
function xv() {
  return (Cd || ((Cd = 1), (wi.exports = gv())), wi.exports);
}
/**
 * @license React
 * react-dom-client.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Kd;
function Sv() {
  if (Kd) return fe;
  Kd = 1;
  var A = xv(),
    il = yv(),
    fl = ov();
  function b(l) {
    var t = 'https://react.dev/errors/' + l;
    if (1 < arguments.length) {
      t += '?args[]=' + encodeURIComponent(arguments[1]);
      for (var a = 2; a < arguments.length; a++)
        t += '&args[]=' + encodeURIComponent(arguments[a]);
    }
    return (
      'Minified React error #' +
      l +
      '; visit ' +
      t +
      ' for the full message or use the non-minified dev environment for full errors and additional helpful warnings.'
    );
  }
  function J(l) {
    return !(!l || (l.nodeType !== 1 && l.nodeType !== 9 && l.nodeType !== 11));
  }
  function j(l) {
    var t = l,
      a = l;
    if (l.alternate) for (; t.return; ) t = t.return;
    else {
      l = t;
      do ((t = l), (t.flags & 4098) !== 0 && (a = t.return), (l = t.return));
      while (l);
    }
    return t.tag === 3 ? a : null;
  }
  function El(l) {
    if (l.tag === 13) {
      var t = l.memoizedState;
      if (
        (t === null && ((l = l.alternate), l !== null && (t = l.memoizedState)),
        t !== null)
      )
        return t.dehydrated;
    }
    return null;
  }
  function Sa(l) {
    if (j(l) !== l) throw Error(b(188));
  }
  function kl(l) {
    var t = l.alternate;
    if (!t) {
      if (((t = j(l)), t === null)) throw Error(b(188));
      return t !== l ? null : l;
    }
    for (var a = l, u = t; ; ) {
      var e = a.return;
      if (e === null) break;
      var n = e.alternate;
      if (n === null) {
        if (((u = e.return), u !== null)) {
          a = u;
          continue;
        }
        break;
      }
      if (e.child === n.child) {
        for (n = e.child; n; ) {
          if (n === a) return (Sa(e), l);
          if (n === u) return (Sa(e), t);
          n = n.sibling;
        }
        throw Error(b(188));
      }
      if (a.return !== u.return) ((a = e), (u = n));
      else {
        for (var c = !1, i = e.child; i; ) {
          if (i === a) {
            ((c = !0), (a = e), (u = n));
            break;
          }
          if (i === u) {
            ((c = !0), (u = e), (a = n));
            break;
          }
          i = i.sibling;
        }
        if (!c) {
          for (i = n.child; i; ) {
            if (i === a) {
              ((c = !0), (a = n), (u = e));
              break;
            }
            if (i === u) {
              ((c = !0), (u = n), (a = e));
              break;
            }
            i = i.sibling;
          }
          if (!c) throw Error(b(189));
        }
      }
      if (a.alternate !== u) throw Error(b(190));
    }
    if (a.tag !== 3) throw Error(b(188));
    return a.stateNode.current === a ? l : t;
  }
  function $l(l) {
    var t = l.tag;
    if (t === 5 || t === 26 || t === 27 || t === 6) return l;
    for (l = l.child; l !== null; ) {
      if (((t = $l(l)), t !== null)) return t;
      l = l.sibling;
    }
    return null;
  }
  var C = Object.assign,
    pl = Symbol.for('react.element'),
    ll = Symbol.for('react.transitional.element'),
    st = Symbol.for('react.portal'),
    Yl = Symbol.for('react.fragment'),
    Et = Symbol.for('react.strict_mode'),
    la = Symbol.for('react.profiler'),
    se = Symbol.for('react.provider'),
    su = Symbol.for('react.consumer'),
    Gl = Symbol.for('react.context'),
    Dt = Symbol.for('react.forward_ref'),
    ta = Symbol.for('react.suspense'),
    tt = Symbol.for('react.suspense_list'),
    dt = Symbol.for('react.memo'),
    Fl = Symbol.for('react.lazy'),
    pa = Symbol.for('react.activity'),
    de = Symbol.for('react.memo_cache_sentinel'),
    za = Symbol.iterator;
  function Xl(l) {
    return l === null || typeof l != 'object'
      ? null
      : ((l = (za && l[za]) || l['@@iterator']),
        typeof l == 'function' ? l : null);
  }
  var he = Symbol.for('react.client.reference');
  function du(l) {
    if (l == null) return null;
    if (typeof l == 'function')
      return l.$$typeof === he ? null : l.displayName || l.name || null;
    if (typeof l == 'string') return l;
    switch (l) {
      case Yl:
        return 'Fragment';
      case la:
        return 'Profiler';
      case Et:
        return 'StrictMode';
      case ta:
        return 'Suspense';
      case tt:
        return 'SuspenseList';
      case pa:
        return 'Activity';
    }
    if (typeof l == 'object')
      switch (l.$$typeof) {
        case st:
          return 'Portal';
        case Gl:
          return (l.displayName || 'Context') + '.Provider';
        case su:
          return (l._context.displayName || 'Context') + '.Consumer';
        case Dt:
          var t = l.render;
          return (
            (l = l.displayName),
            l ||
              ((l = t.displayName || t.name || ''),
              (l = l !== '' ? 'ForwardRef(' + l + ')' : 'ForwardRef')),
            l
          );
        case dt:
          return (
            (t = l.displayName || null),
            t !== null ? t : du(l.type) || 'Memo'
          );
        case Fl:
          ((t = l._payload), (l = l._init));
          try {
            return du(l(t));
          } catch {}
      }
    return null;
  }
  var ht = Array.isArray,
    x = il.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
    p = fl.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
    D = { pending: !1, data: null, method: null, action: null },
    w = [],
    W = -1;
  function xl(l) {
    return { current: l };
  }
  function $(l) {
    0 > W || ((l.current = w[W]), (w[W] = null), W--);
  }
  function X(l, t) {
    (W++, (w[W] = l.current), (l.current = t));
  }
  var sl = xl(null),
    at = xl(null),
    jt = xl(null),
    me = xl(null);
  function ve(l, t) {
    switch ((X(jt, t), X(at, l), X(sl, null), t.nodeType)) {
      case 9:
      case 11:
        l = (l = t.documentElement) && (l = l.namespaceURI) ? od(l) : 0;
        break;
      default:
        if (((l = t.tagName), (t = t.namespaceURI)))
          ((t = od(t)), (l = bd(t, l)));
        else
          switch (l) {
            case 'svg':
              l = 1;
              break;
            case 'math':
              l = 2;
              break;
            default:
              l = 0;
          }
    }
    ($(sl), X(sl, l));
  }
  function Na() {
    ($(sl), $(at), $(jt));
  }
  function Un(l) {
    l.memoizedState !== null && X(me, l);
    var t = sl.current,
      a = bd(t, l.type);
    t !== a && (X(at, l), X(sl, a));
  }
  function re(l) {
    (at.current === l && ($(sl), $(at)),
      me.current === l && ($(me), (ue._currentValue = D)));
  }
  var Hn = Object.prototype.hasOwnProperty,
    _n = A.unstable_scheduleCallback,
    qn = A.unstable_cancelCallback,
    Jd = A.unstable_shouldYield,
    wd = A.unstable_requestPaint,
    ut = A.unstable_now,
    Wd = A.unstable_getCurrentPriorityLevel,
    ki = A.unstable_ImmediatePriority,
    $i = A.unstable_UserBlockingPriority,
    ye = A.unstable_NormalPriority,
    kd = A.unstable_LowPriority,
    Fi = A.unstable_IdlePriority,
    $d = A.log,
    Fd = A.unstable_setDisableYieldValue,
    hu = null,
    Dl = null;
  function Ot(l) {
    if (
      (typeof $d == 'function' && Fd(l),
      Dl && typeof Dl.setStrictMode == 'function')
    )
      try {
        Dl.setStrictMode(hu, l);
      } catch {}
  }
  var jl = Math.clz32 ? Math.clz32 : lh,
    Id = Math.log,
    Pd = Math.LN2;
  function lh(l) {
    return ((l >>>= 0), l === 0 ? 32 : (31 - ((Id(l) / Pd) | 0)) | 0);
  }
  var oe = 256,
    be = 4194304;
  function aa(l) {
    var t = l & 42;
    if (t !== 0) return t;
    switch (l & -l) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
        return 64;
      case 128:
        return 128;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return l & 4194048;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return l & 62914560;
      case 67108864:
        return 67108864;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 0;
      default:
        return l;
    }
  }
  function ge(l, t, a) {
    var u = l.pendingLanes;
    if (u === 0) return 0;
    var e = 0,
      n = l.suspendedLanes,
      c = l.pingedLanes;
    l = l.warmLanes;
    var i = u & 134217727;
    return (
      i !== 0
        ? ((u = i & ~n),
          u !== 0
            ? (e = aa(u))
            : ((c &= i),
              c !== 0
                ? (e = aa(c))
                : a || ((a = i & ~l), a !== 0 && (e = aa(a)))))
        : ((i = u & ~n),
          i !== 0
            ? (e = aa(i))
            : c !== 0
              ? (e = aa(c))
              : a || ((a = u & ~l), a !== 0 && (e = aa(a)))),
      e === 0
        ? 0
        : t !== 0 &&
            t !== e &&
            (t & n) === 0 &&
            ((n = e & -e),
            (a = t & -t),
            n >= a || (n === 32 && (a & 4194048) !== 0))
          ? t
          : e
    );
  }
  function mu(l, t) {
    return (l.pendingLanes & ~(l.suspendedLanes & ~l.pingedLanes) & t) === 0;
  }
  function th(l, t) {
    switch (l) {
      case 1:
      case 2:
      case 4:
      case 8:
      case 64:
        return t + 250;
      case 16:
      case 32:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return t + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return -1;
      case 67108864:
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function Ii() {
    var l = oe;
    return ((oe <<= 1), (oe & 4194048) === 0 && (oe = 256), l);
  }
  function Pi() {
    var l = be;
    return ((be <<= 1), (be & 62914560) === 0 && (be = 4194304), l);
  }
  function Rn(l) {
    for (var t = [], a = 0; 31 > a; a++) t.push(l);
    return t;
  }
  function vu(l, t) {
    ((l.pendingLanes |= t),
      t !== 268435456 &&
        ((l.suspendedLanes = 0), (l.pingedLanes = 0), (l.warmLanes = 0)));
  }
  function ah(l, t, a, u, e, n) {
    var c = l.pendingLanes;
    ((l.pendingLanes = a),
      (l.suspendedLanes = 0),
      (l.pingedLanes = 0),
      (l.warmLanes = 0),
      (l.expiredLanes &= a),
      (l.entangledLanes &= a),
      (l.errorRecoveryDisabledLanes &= a),
      (l.shellSuspendCounter = 0));
    var i = l.entanglements,
      f = l.expirationTimes,
      v = l.hiddenUpdates;
    for (a = c & ~a; 0 < a; ) {
      var o = 31 - jl(a),
        S = 1 << o;
      ((i[o] = 0), (f[o] = -1));
      var r = v[o];
      if (r !== null)
        for (v[o] = null, o = 0; o < r.length; o++) {
          var y = r[o];
          y !== null && (y.lane &= -536870913);
        }
      a &= ~S;
    }
    (u !== 0 && lf(l, u, 0),
      n !== 0 && e === 0 && l.tag !== 0 && (l.suspendedLanes |= n & ~(c & ~t)));
  }
  function lf(l, t, a) {
    ((l.pendingLanes |= t), (l.suspendedLanes &= ~t));
    var u = 31 - jl(t);
    ((l.entangledLanes |= t),
      (l.entanglements[u] = l.entanglements[u] | 1073741824 | (a & 4194090)));
  }
  function tf(l, t) {
    var a = (l.entangledLanes |= t);
    for (l = l.entanglements; a; ) {
      var u = 31 - jl(a),
        e = 1 << u;
      ((e & t) | (l[u] & t) && (l[u] |= t), (a &= ~e));
    }
  }
  function Bn(l) {
    switch (l) {
      case 2:
        l = 1;
        break;
      case 8:
        l = 4;
        break;
      case 32:
        l = 16;
        break;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        l = 128;
        break;
      case 268435456:
        l = 134217728;
        break;
      default:
        l = 0;
    }
    return l;
  }
  function Yn(l) {
    return (
      (l &= -l),
      2 < l ? (8 < l ? ((l & 134217727) !== 0 ? 32 : 268435456) : 8) : 2
    );
  }
  function af() {
    var l = p.p;
    return l !== 0 ? l : ((l = window.event), l === void 0 ? 32 : Bd(l.type));
  }
  function uh(l, t) {
    var a = p.p;
    try {
      return ((p.p = l), t());
    } finally {
      p.p = a;
    }
  }
  var Ut = Math.random().toString(36).slice(2),
    bl = '__reactFiber$' + Ut,
    zl = '__reactProps$' + Ut,
    Aa = '__reactContainer$' + Ut,
    Gn = '__reactEvents$' + Ut,
    eh = '__reactListeners$' + Ut,
    nh = '__reactHandles$' + Ut,
    uf = '__reactResources$' + Ut,
    ru = '__reactMarker$' + Ut;
  function Xn(l) {
    (delete l[bl], delete l[zl], delete l[Gn], delete l[eh], delete l[nh]);
  }
  function Ta(l) {
    var t = l[bl];
    if (t) return t;
    for (var a = l.parentNode; a; ) {
      if ((t = a[Aa] || a[bl])) {
        if (
          ((a = t.alternate),
          t.child !== null || (a !== null && a.child !== null))
        )
          for (l = pd(l); l !== null; ) {
            if ((a = l[bl])) return a;
            l = pd(l);
          }
        return t;
      }
      ((l = a), (a = l.parentNode));
    }
    return null;
  }
  function Ma(l) {
    if ((l = l[bl] || l[Aa])) {
      var t = l.tag;
      if (t === 5 || t === 6 || t === 13 || t === 26 || t === 27 || t === 3)
        return l;
    }
    return null;
  }
  function yu(l) {
    var t = l.tag;
    if (t === 5 || t === 26 || t === 27 || t === 6) return l.stateNode;
    throw Error(b(33));
  }
  function Ea(l) {
    var t = l[uf];
    return (
      t ||
        (t = l[uf] =
          { hoistableStyles: new Map(), hoistableScripts: new Map() }),
      t
    );
  }
  function dl(l) {
    l[ru] = !0;
  }
  var ef = new Set(),
    nf = {};
  function ua(l, t) {
    (Da(l, t), Da(l + 'Capture', t));
  }
  function Da(l, t) {
    for (nf[l] = t, l = 0; l < t.length; l++) ef.add(t[l]);
  }
  var ch = RegExp(
      '^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$',
    ),
    cf = {},
    ff = {};
  function ih(l) {
    return Hn.call(ff, l)
      ? !0
      : Hn.call(cf, l)
        ? !1
        : ch.test(l)
          ? (ff[l] = !0)
          : ((cf[l] = !0), !1);
  }
  function xe(l, t, a) {
    if (ih(t))
      if (a === null) l.removeAttribute(t);
      else {
        switch (typeof a) {
          case 'undefined':
          case 'function':
          case 'symbol':
            l.removeAttribute(t);
            return;
          case 'boolean':
            var u = t.toLowerCase().slice(0, 5);
            if (u !== 'data-' && u !== 'aria-') {
              l.removeAttribute(t);
              return;
            }
        }
        l.setAttribute(t, '' + a);
      }
  }
  function Se(l, t, a) {
    if (a === null) l.removeAttribute(t);
    else {
      switch (typeof a) {
        case 'undefined':
        case 'function':
        case 'symbol':
        case 'boolean':
          l.removeAttribute(t);
          return;
      }
      l.setAttribute(t, '' + a);
    }
  }
  function mt(l, t, a, u) {
    if (u === null) l.removeAttribute(a);
    else {
      switch (typeof u) {
        case 'undefined':
        case 'function':
        case 'symbol':
        case 'boolean':
          l.removeAttribute(a);
          return;
      }
      l.setAttributeNS(t, a, '' + u);
    }
  }
  var Qn, sf;
  function ja(l) {
    if (Qn === void 0)
      try {
        throw Error();
      } catch (a) {
        var t = a.stack.trim().match(/\n( *(at )?)/);
        ((Qn = (t && t[1]) || ''),
          (sf =
            -1 <
            a.stack.indexOf(`
    at`)
              ? ' (<anonymous>)'
              : -1 < a.stack.indexOf('@')
                ? '@unknown:0:0'
                : ''));
      }
    return (
      `
` +
      Qn +
      l +
      sf
    );
  }
  var Zn = !1;
  function Vn(l, t) {
    if (!l || Zn) return '';
    Zn = !0;
    var a = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      var u = {
        DetermineComponentFrameRoot: function () {
          try {
            if (t) {
              var S = function () {
                throw Error();
              };
              if (
                (Object.defineProperty(S.prototype, 'props', {
                  set: function () {
                    throw Error();
                  },
                }),
                typeof Reflect == 'object' && Reflect.construct)
              ) {
                try {
                  Reflect.construct(S, []);
                } catch (y) {
                  var r = y;
                }
                Reflect.construct(l, [], S);
              } else {
                try {
                  S.call();
                } catch (y) {
                  r = y;
                }
                l.call(S.prototype);
              }
            } else {
              try {
                throw Error();
              } catch (y) {
                r = y;
              }
              (S = l()) &&
                typeof S.catch == 'function' &&
                S.catch(function () {});
            }
          } catch (y) {
            if (y && r && typeof y.stack == 'string') return [y.stack, r.stack];
          }
          return [null, null];
        },
      };
      u.DetermineComponentFrameRoot.displayName = 'DetermineComponentFrameRoot';
      var e = Object.getOwnPropertyDescriptor(
        u.DetermineComponentFrameRoot,
        'name',
      );
      e &&
        e.configurable &&
        Object.defineProperty(u.DetermineComponentFrameRoot, 'name', {
          value: 'DetermineComponentFrameRoot',
        });
      var n = u.DetermineComponentFrameRoot(),
        c = n[0],
        i = n[1];
      if (c && i) {
        var f = c.split(`
`),
          v = i.split(`
`);
        for (
          e = u = 0;
          u < f.length && !f[u].includes('DetermineComponentFrameRoot');

        )
          u++;
        for (; e < v.length && !v[e].includes('DetermineComponentFrameRoot'); )
          e++;
        if (u === f.length || e === v.length)
          for (
            u = f.length - 1, e = v.length - 1;
            1 <= u && 0 <= e && f[u] !== v[e];

          )
            e--;
        for (; 1 <= u && 0 <= e; u--, e--)
          if (f[u] !== v[e]) {
            if (u !== 1 || e !== 1)
              do
                if ((u--, e--, 0 > e || f[u] !== v[e])) {
                  var o =
                    `
` + f[u].replace(' at new ', ' at ');
                  return (
                    l.displayName &&
                      o.includes('<anonymous>') &&
                      (o = o.replace('<anonymous>', l.displayName)),
                    o
                  );
                }
              while (1 <= u && 0 <= e);
            break;
          }
      }
    } finally {
      ((Zn = !1), (Error.prepareStackTrace = a));
    }
    return (a = l ? l.displayName || l.name : '') ? ja(a) : '';
  }
  function fh(l) {
    switch (l.tag) {
      case 26:
      case 27:
      case 5:
        return ja(l.type);
      case 16:
        return ja('Lazy');
      case 13:
        return ja('Suspense');
      case 19:
        return ja('SuspenseList');
      case 0:
      case 15:
        return Vn(l.type, !1);
      case 11:
        return Vn(l.type.render, !1);
      case 1:
        return Vn(l.type, !0);
      case 31:
        return ja('Activity');
      default:
        return '';
    }
  }
  function df(l) {
    try {
      var t = '';
      do ((t += fh(l)), (l = l.return));
      while (l);
      return t;
    } catch (a) {
      return (
        `
Error generating stack: ` +
        a.message +
        `
` +
        a.stack
      );
    }
  }
  function Ql(l) {
    switch (typeof l) {
      case 'bigint':
      case 'boolean':
      case 'number':
      case 'string':
      case 'undefined':
        return l;
      case 'object':
        return l;
      default:
        return '';
    }
  }
  function hf(l) {
    var t = l.type;
    return (
      (l = l.nodeName) &&
      l.toLowerCase() === 'input' &&
      (t === 'checkbox' || t === 'radio')
    );
  }
  function sh(l) {
    var t = hf(l) ? 'checked' : 'value',
      a = Object.getOwnPropertyDescriptor(l.constructor.prototype, t),
      u = '' + l[t];
    if (
      !l.hasOwnProperty(t) &&
      typeof a < 'u' &&
      typeof a.get == 'function' &&
      typeof a.set == 'function'
    ) {
      var e = a.get,
        n = a.set;
      return (
        Object.defineProperty(l, t, {
          configurable: !0,
          get: function () {
            return e.call(this);
          },
          set: function (c) {
            ((u = '' + c), n.call(this, c));
          },
        }),
        Object.defineProperty(l, t, { enumerable: a.enumerable }),
        {
          getValue: function () {
            return u;
          },
          setValue: function (c) {
            u = '' + c;
          },
          stopTracking: function () {
            ((l._valueTracker = null), delete l[t]);
          },
        }
      );
    }
  }
  function pe(l) {
    l._valueTracker || (l._valueTracker = sh(l));
  }
  function mf(l) {
    if (!l) return !1;
    var t = l._valueTracker;
    if (!t) return !0;
    var a = t.getValue(),
      u = '';
    return (
      l && (u = hf(l) ? (l.checked ? 'true' : 'false') : l.value),
      (l = u),
      l !== a ? (t.setValue(l), !0) : !1
    );
  }
  function ze(l) {
    if (
      ((l = l || (typeof document < 'u' ? document : void 0)), typeof l > 'u')
    )
      return null;
    try {
      return l.activeElement || l.body;
    } catch {
      return l.body;
    }
  }
  var dh = /[\n"\\]/g;
  function Zl(l) {
    return l.replace(dh, function (t) {
      return '\\' + t.charCodeAt(0).toString(16) + ' ';
    });
  }
  function Cn(l, t, a, u, e, n, c, i) {
    ((l.name = ''),
      c != null &&
      typeof c != 'function' &&
      typeof c != 'symbol' &&
      typeof c != 'boolean'
        ? (l.type = c)
        : l.removeAttribute('type'),
      t != null
        ? c === 'number'
          ? ((t === 0 && l.value === '') || l.value != t) &&
            (l.value = '' + Ql(t))
          : l.value !== '' + Ql(t) && (l.value = '' + Ql(t))
        : (c !== 'submit' && c !== 'reset') || l.removeAttribute('value'),
      t != null
        ? Kn(l, c, Ql(t))
        : a != null
          ? Kn(l, c, Ql(a))
          : u != null && l.removeAttribute('value'),
      e == null && n != null && (l.defaultChecked = !!n),
      e != null &&
        (l.checked = e && typeof e != 'function' && typeof e != 'symbol'),
      i != null &&
      typeof i != 'function' &&
      typeof i != 'symbol' &&
      typeof i != 'boolean'
        ? (l.name = '' + Ql(i))
        : l.removeAttribute('name'));
  }
  function vf(l, t, a, u, e, n, c, i) {
    if (
      (n != null &&
        typeof n != 'function' &&
        typeof n != 'symbol' &&
        typeof n != 'boolean' &&
        (l.type = n),
      t != null || a != null)
    ) {
      if (!((n !== 'submit' && n !== 'reset') || t != null)) return;
      ((a = a != null ? '' + Ql(a) : ''),
        (t = t != null ? '' + Ql(t) : a),
        i || t === l.value || (l.value = t),
        (l.defaultValue = t));
    }
    ((u = u ?? e),
      (u = typeof u != 'function' && typeof u != 'symbol' && !!u),
      (l.checked = i ? l.checked : !!u),
      (l.defaultChecked = !!u),
      c != null &&
        typeof c != 'function' &&
        typeof c != 'symbol' &&
        typeof c != 'boolean' &&
        (l.name = c));
  }
  function Kn(l, t, a) {
    (t === 'number' && ze(l.ownerDocument) === l) ||
      l.defaultValue === '' + a ||
      (l.defaultValue = '' + a);
  }
  function Oa(l, t, a, u) {
    if (((l = l.options), t)) {
      t = {};
      for (var e = 0; e < a.length; e++) t['$' + a[e]] = !0;
      for (a = 0; a < l.length; a++)
        ((e = t.hasOwnProperty('$' + l[a].value)),
          l[a].selected !== e && (l[a].selected = e),
          e && u && (l[a].defaultSelected = !0));
    } else {
      for (a = '' + Ql(a), t = null, e = 0; e < l.length; e++) {
        if (l[e].value === a) {
          ((l[e].selected = !0), u && (l[e].defaultSelected = !0));
          return;
        }
        t !== null || l[e].disabled || (t = l[e]);
      }
      t !== null && (t.selected = !0);
    }
  }
  function rf(l, t, a) {
    if (
      t != null &&
      ((t = '' + Ql(t)), t !== l.value && (l.value = t), a == null)
    ) {
      l.defaultValue !== t && (l.defaultValue = t);
      return;
    }
    l.defaultValue = a != null ? '' + Ql(a) : '';
  }
  function yf(l, t, a, u) {
    if (t == null) {
      if (u != null) {
        if (a != null) throw Error(b(92));
        if (ht(u)) {
          if (1 < u.length) throw Error(b(93));
          u = u[0];
        }
        a = u;
      }
      (a == null && (a = ''), (t = a));
    }
    ((a = Ql(t)),
      (l.defaultValue = a),
      (u = l.textContent),
      u === a && u !== '' && u !== null && (l.value = u));
  }
  function Ua(l, t) {
    if (t) {
      var a = l.firstChild;
      if (a && a === l.lastChild && a.nodeType === 3) {
        a.nodeValue = t;
        return;
      }
    }
    l.textContent = t;
  }
  var hh = new Set(
    'animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp'.split(
      ' ',
    ),
  );
  function of(l, t, a) {
    var u = t.indexOf('--') === 0;
    a == null || typeof a == 'boolean' || a === ''
      ? u
        ? l.setProperty(t, '')
        : t === 'float'
          ? (l.cssFloat = '')
          : (l[t] = '')
      : u
        ? l.setProperty(t, a)
        : typeof a != 'number' || a === 0 || hh.has(t)
          ? t === 'float'
            ? (l.cssFloat = a)
            : (l[t] = ('' + a).trim())
          : (l[t] = a + 'px');
  }
  function bf(l, t, a) {
    if (t != null && typeof t != 'object') throw Error(b(62));
    if (((l = l.style), a != null)) {
      for (var u in a)
        !a.hasOwnProperty(u) ||
          (t != null && t.hasOwnProperty(u)) ||
          (u.indexOf('--') === 0
            ? l.setProperty(u, '')
            : u === 'float'
              ? (l.cssFloat = '')
              : (l[u] = ''));
      for (var e in t)
        ((u = t[e]), t.hasOwnProperty(e) && a[e] !== u && of(l, e, u));
    } else for (var n in t) t.hasOwnProperty(n) && of(l, n, t[n]);
  }
  function Ln(l) {
    if (l.indexOf('-') === -1) return !1;
    switch (l) {
      case 'annotation-xml':
      case 'color-profile':
      case 'font-face':
      case 'font-face-src':
      case 'font-face-uri':
      case 'font-face-format':
      case 'font-face-name':
      case 'missing-glyph':
        return !1;
      default:
        return !0;
    }
  }
  var mh = new Map([
      ['acceptCharset', 'accept-charset'],
      ['htmlFor', 'for'],
      ['httpEquiv', 'http-equiv'],
      ['crossOrigin', 'crossorigin'],
      ['accentHeight', 'accent-height'],
      ['alignmentBaseline', 'alignment-baseline'],
      ['arabicForm', 'arabic-form'],
      ['baselineShift', 'baseline-shift'],
      ['capHeight', 'cap-height'],
      ['clipPath', 'clip-path'],
      ['clipRule', 'clip-rule'],
      ['colorInterpolation', 'color-interpolation'],
      ['colorInterpolationFilters', 'color-interpolation-filters'],
      ['colorProfile', 'color-profile'],
      ['colorRendering', 'color-rendering'],
      ['dominantBaseline', 'dominant-baseline'],
      ['enableBackground', 'enable-background'],
      ['fillOpacity', 'fill-opacity'],
      ['fillRule', 'fill-rule'],
      ['floodColor', 'flood-color'],
      ['floodOpacity', 'flood-opacity'],
      ['fontFamily', 'font-family'],
      ['fontSize', 'font-size'],
      ['fontSizeAdjust', 'font-size-adjust'],
      ['fontStretch', 'font-stretch'],
      ['fontStyle', 'font-style'],
      ['fontVariant', 'font-variant'],
      ['fontWeight', 'font-weight'],
      ['glyphName', 'glyph-name'],
      ['glyphOrientationHorizontal', 'glyph-orientation-horizontal'],
      ['glyphOrientationVertical', 'glyph-orientation-vertical'],
      ['horizAdvX', 'horiz-adv-x'],
      ['horizOriginX', 'horiz-origin-x'],
      ['imageRendering', 'image-rendering'],
      ['letterSpacing', 'letter-spacing'],
      ['lightingColor', 'lighting-color'],
      ['markerEnd', 'marker-end'],
      ['markerMid', 'marker-mid'],
      ['markerStart', 'marker-start'],
      ['overlinePosition', 'overline-position'],
      ['overlineThickness', 'overline-thickness'],
      ['paintOrder', 'paint-order'],
      ['panose-1', 'panose-1'],
      ['pointerEvents', 'pointer-events'],
      ['renderingIntent', 'rendering-intent'],
      ['shapeRendering', 'shape-rendering'],
      ['stopColor', 'stop-color'],
      ['stopOpacity', 'stop-opacity'],
      ['strikethroughPosition', 'strikethrough-position'],
      ['strikethroughThickness', 'strikethrough-thickness'],
      ['strokeDasharray', 'stroke-dasharray'],
      ['strokeDashoffset', 'stroke-dashoffset'],
      ['strokeLinecap', 'stroke-linecap'],
      ['strokeLinejoin', 'stroke-linejoin'],
      ['strokeMiterlimit', 'stroke-miterlimit'],
      ['strokeOpacity', 'stroke-opacity'],
      ['strokeWidth', 'stroke-width'],
      ['textAnchor', 'text-anchor'],
      ['textDecoration', 'text-decoration'],
      ['textRendering', 'text-rendering'],
      ['transformOrigin', 'transform-origin'],
      ['underlinePosition', 'underline-position'],
      ['underlineThickness', 'underline-thickness'],
      ['unicodeBidi', 'unicode-bidi'],
      ['unicodeRange', 'unicode-range'],
      ['unitsPerEm', 'units-per-em'],
      ['vAlphabetic', 'v-alphabetic'],
      ['vHanging', 'v-hanging'],
      ['vIdeographic', 'v-ideographic'],
      ['vMathematical', 'v-mathematical'],
      ['vectorEffect', 'vector-effect'],
      ['vertAdvY', 'vert-adv-y'],
      ['vertOriginX', 'vert-origin-x'],
      ['vertOriginY', 'vert-origin-y'],
      ['wordSpacing', 'word-spacing'],
      ['writingMode', 'writing-mode'],
      ['xmlnsXlink', 'xmlns:xlink'],
      ['xHeight', 'x-height'],
    ]),
    vh =
      /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
  function Ne(l) {
    return vh.test('' + l)
      ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')"
      : l;
  }
  var Jn = null;
  function wn(l) {
    return (
      (l = l.target || l.srcElement || window),
      l.correspondingUseElement && (l = l.correspondingUseElement),
      l.nodeType === 3 ? l.parentNode : l
    );
  }
  var Ha = null,
    _a = null;
  function gf(l) {
    var t = Ma(l);
    if (t && (l = t.stateNode)) {
      var a = l[zl] || null;
      l: switch (((l = t.stateNode), t.type)) {
        case 'input':
          if (
            (Cn(
              l,
              a.value,
              a.defaultValue,
              a.defaultValue,
              a.checked,
              a.defaultChecked,
              a.type,
              a.name,
            ),
            (t = a.name),
            a.type === 'radio' && t != null)
          ) {
            for (a = l; a.parentNode; ) a = a.parentNode;
            for (
              a = a.querySelectorAll(
                'input[name="' + Zl('' + t) + '"][type="radio"]',
              ),
                t = 0;
              t < a.length;
              t++
            ) {
              var u = a[t];
              if (u !== l && u.form === l.form) {
                var e = u[zl] || null;
                if (!e) throw Error(b(90));
                Cn(
                  u,
                  e.value,
                  e.defaultValue,
                  e.defaultValue,
                  e.checked,
                  e.defaultChecked,
                  e.type,
                  e.name,
                );
              }
            }
            for (t = 0; t < a.length; t++)
              ((u = a[t]), u.form === l.form && mf(u));
          }
          break l;
        case 'textarea':
          rf(l, a.value, a.defaultValue);
          break l;
        case 'select':
          ((t = a.value), t != null && Oa(l, !!a.multiple, t, !1));
      }
    }
  }
  var Wn = !1;
  function xf(l, t, a) {
    if (Wn) return l(t, a);
    Wn = !0;
    try {
      var u = l(t);
      return u;
    } finally {
      if (
        ((Wn = !1),
        (Ha !== null || _a !== null) &&
          (sn(), Ha && ((t = Ha), (l = _a), (_a = Ha = null), gf(t), l)))
      )
        for (t = 0; t < l.length; t++) gf(l[t]);
    }
  }
  function ou(l, t) {
    var a = l.stateNode;
    if (a === null) return null;
    var u = a[zl] || null;
    if (u === null) return null;
    a = u[t];
    l: switch (t) {
      case 'onClick':
      case 'onClickCapture':
      case 'onDoubleClick':
      case 'onDoubleClickCapture':
      case 'onMouseDown':
      case 'onMouseDownCapture':
      case 'onMouseMove':
      case 'onMouseMoveCapture':
      case 'onMouseUp':
      case 'onMouseUpCapture':
      case 'onMouseEnter':
        ((u = !u.disabled) ||
          ((l = l.type),
          (u = !(
            l === 'button' ||
            l === 'input' ||
            l === 'select' ||
            l === 'textarea'
          ))),
          (l = !u));
        break l;
      default:
        l = !1;
    }
    if (l) return null;
    if (a && typeof a != 'function') throw Error(b(231, t, typeof a));
    return a;
  }
  var vt = !(
      typeof window > 'u' ||
      typeof window.document > 'u' ||
      typeof window.document.createElement > 'u'
    ),
    kn = !1;
  if (vt)
    try {
      var bu = {};
      (Object.defineProperty(bu, 'passive', {
        get: function () {
          kn = !0;
        },
      }),
        window.addEventListener('test', bu, bu),
        window.removeEventListener('test', bu, bu));
    } catch {
      kn = !1;
    }
  var Ht = null,
    $n = null,
    Ae = null;
  function Sf() {
    if (Ae) return Ae;
    var l,
      t = $n,
      a = t.length,
      u,
      e = 'value' in Ht ? Ht.value : Ht.textContent,
      n = e.length;
    for (l = 0; l < a && t[l] === e[l]; l++);
    var c = a - l;
    for (u = 1; u <= c && t[a - u] === e[n - u]; u++);
    return (Ae = e.slice(l, 1 < u ? 1 - u : void 0));
  }
  function Te(l) {
    var t = l.keyCode;
    return (
      'charCode' in l
        ? ((l = l.charCode), l === 0 && t === 13 && (l = 13))
        : (l = t),
      l === 10 && (l = 13),
      32 <= l || l === 13 ? l : 0
    );
  }
  function Me() {
    return !0;
  }
  function pf() {
    return !1;
  }
  function Nl(l) {
    function t(a, u, e, n, c) {
      ((this._reactName = a),
        (this._targetInst = e),
        (this.type = u),
        (this.nativeEvent = n),
        (this.target = c),
        (this.currentTarget = null));
      for (var i in l)
        l.hasOwnProperty(i) && ((a = l[i]), (this[i] = a ? a(n) : n[i]));
      return (
        (this.isDefaultPrevented = (
          n.defaultPrevented != null ? n.defaultPrevented : n.returnValue === !1
        )
          ? Me
          : pf),
        (this.isPropagationStopped = pf),
        this
      );
    }
    return (
      C(t.prototype, {
        preventDefault: function () {
          this.defaultPrevented = !0;
          var a = this.nativeEvent;
          a &&
            (a.preventDefault
              ? a.preventDefault()
              : typeof a.returnValue != 'unknown' && (a.returnValue = !1),
            (this.isDefaultPrevented = Me));
        },
        stopPropagation: function () {
          var a = this.nativeEvent;
          a &&
            (a.stopPropagation
              ? a.stopPropagation()
              : typeof a.cancelBubble != 'unknown' && (a.cancelBubble = !0),
            (this.isPropagationStopped = Me));
        },
        persist: function () {},
        isPersistent: Me,
      }),
      t
    );
  }
  var ea = {
      eventPhase: 0,
      bubbles: 0,
      cancelable: 0,
      timeStamp: function (l) {
        return l.timeStamp || Date.now();
      },
      defaultPrevented: 0,
      isTrusted: 0,
    },
    Ee = Nl(ea),
    gu = C({}, ea, { view: 0, detail: 0 }),
    rh = Nl(gu),
    Fn,
    In,
    xu,
    De = C({}, gu, {
      screenX: 0,
      screenY: 0,
      clientX: 0,
      clientY: 0,
      pageX: 0,
      pageY: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      getModifierState: lc,
      button: 0,
      buttons: 0,
      relatedTarget: function (l) {
        return l.relatedTarget === void 0
          ? l.fromElement === l.srcElement
            ? l.toElement
            : l.fromElement
          : l.relatedTarget;
      },
      movementX: function (l) {
        return 'movementX' in l
          ? l.movementX
          : (l !== xu &&
              (xu && l.type === 'mousemove'
                ? ((Fn = l.screenX - xu.screenX), (In = l.screenY - xu.screenY))
                : (In = Fn = 0),
              (xu = l)),
            Fn);
      },
      movementY: function (l) {
        return 'movementY' in l ? l.movementY : In;
      },
    }),
    zf = Nl(De),
    yh = C({}, De, { dataTransfer: 0 }),
    oh = Nl(yh),
    bh = C({}, gu, { relatedTarget: 0 }),
    Pn = Nl(bh),
    gh = C({}, ea, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }),
    xh = Nl(gh),
    Sh = C({}, ea, {
      clipboardData: function (l) {
        return 'clipboardData' in l ? l.clipboardData : window.clipboardData;
      },
    }),
    ph = Nl(Sh),
    zh = C({}, ea, { data: 0 }),
    Nf = Nl(zh),
    Nh = {
      Esc: 'Escape',
      Spacebar: ' ',
      Left: 'ArrowLeft',
      Up: 'ArrowUp',
      Right: 'ArrowRight',
      Down: 'ArrowDown',
      Del: 'Delete',
      Win: 'OS',
      Menu: 'ContextMenu',
      Apps: 'ContextMenu',
      Scroll: 'ScrollLock',
      MozPrintableKey: 'Unidentified',
    },
    Ah = {
      8: 'Backspace',
      9: 'Tab',
      12: 'Clear',
      13: 'Enter',
      16: 'Shift',
      17: 'Control',
      18: 'Alt',
      19: 'Pause',
      20: 'CapsLock',
      27: 'Escape',
      32: ' ',
      33: 'PageUp',
      34: 'PageDown',
      35: 'End',
      36: 'Home',
      37: 'ArrowLeft',
      38: 'ArrowUp',
      39: 'ArrowRight',
      40: 'ArrowDown',
      45: 'Insert',
      46: 'Delete',
      112: 'F1',
      113: 'F2',
      114: 'F3',
      115: 'F4',
      116: 'F5',
      117: 'F6',
      118: 'F7',
      119: 'F8',
      120: 'F9',
      121: 'F10',
      122: 'F11',
      123: 'F12',
      144: 'NumLock',
      145: 'ScrollLock',
      224: 'Meta',
    },
    Th = {
      Alt: 'altKey',
      Control: 'ctrlKey',
      Meta: 'metaKey',
      Shift: 'shiftKey',
    };
  function Mh(l) {
    var t = this.nativeEvent;
    return t.getModifierState
      ? t.getModifierState(l)
      : (l = Th[l])
        ? !!t[l]
        : !1;
  }
  function lc() {
    return Mh;
  }
  var Eh = C({}, gu, {
      key: function (l) {
        if (l.key) {
          var t = Nh[l.key] || l.key;
          if (t !== 'Unidentified') return t;
        }
        return l.type === 'keypress'
          ? ((l = Te(l)), l === 13 ? 'Enter' : String.fromCharCode(l))
          : l.type === 'keydown' || l.type === 'keyup'
            ? Ah[l.keyCode] || 'Unidentified'
            : '';
      },
      code: 0,
      location: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      repeat: 0,
      locale: 0,
      getModifierState: lc,
      charCode: function (l) {
        return l.type === 'keypress' ? Te(l) : 0;
      },
      keyCode: function (l) {
        return l.type === 'keydown' || l.type === 'keyup' ? l.keyCode : 0;
      },
      which: function (l) {
        return l.type === 'keypress'
          ? Te(l)
          : l.type === 'keydown' || l.type === 'keyup'
            ? l.keyCode
            : 0;
      },
    }),
    Dh = Nl(Eh),
    jh = C({}, De, {
      pointerId: 0,
      width: 0,
      height: 0,
      pressure: 0,
      tangentialPressure: 0,
      tiltX: 0,
      tiltY: 0,
      twist: 0,
      pointerType: 0,
      isPrimary: 0,
    }),
    Af = Nl(jh),
    Oh = C({}, gu, {
      touches: 0,
      targetTouches: 0,
      changedTouches: 0,
      altKey: 0,
      metaKey: 0,
      ctrlKey: 0,
      shiftKey: 0,
      getModifierState: lc,
    }),
    Uh = Nl(Oh),
    Hh = C({}, ea, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }),
    _h = Nl(Hh),
    qh = C({}, De, {
      deltaX: function (l) {
        return 'deltaX' in l
          ? l.deltaX
          : 'wheelDeltaX' in l
            ? -l.wheelDeltaX
            : 0;
      },
      deltaY: function (l) {
        return 'deltaY' in l
          ? l.deltaY
          : 'wheelDeltaY' in l
            ? -l.wheelDeltaY
            : 'wheelDelta' in l
              ? -l.wheelDelta
              : 0;
      },
      deltaZ: 0,
      deltaMode: 0,
    }),
    Rh = Nl(qh),
    Bh = C({}, ea, { newState: 0, oldState: 0 }),
    Yh = Nl(Bh),
    Gh = [9, 13, 27, 32],
    tc = vt && 'CompositionEvent' in window,
    Su = null;
  vt && 'documentMode' in document && (Su = document.documentMode);
  var Xh = vt && 'TextEvent' in window && !Su,
    Tf = vt && (!tc || (Su && 8 < Su && 11 >= Su)),
    Mf = ' ',
    Ef = !1;
  function Df(l, t) {
    switch (l) {
      case 'keyup':
        return Gh.indexOf(t.keyCode) !== -1;
      case 'keydown':
        return t.keyCode !== 229;
      case 'keypress':
      case 'mousedown':
      case 'focusout':
        return !0;
      default:
        return !1;
    }
  }
  function jf(l) {
    return (
      (l = l.detail),
      typeof l == 'object' && 'data' in l ? l.data : null
    );
  }
  var qa = !1;
  function Qh(l, t) {
    switch (l) {
      case 'compositionend':
        return jf(t);
      case 'keypress':
        return t.which !== 32 ? null : ((Ef = !0), Mf);
      case 'textInput':
        return ((l = t.data), l === Mf && Ef ? null : l);
      default:
        return null;
    }
  }
  function Zh(l, t) {
    if (qa)
      return l === 'compositionend' || (!tc && Df(l, t))
        ? ((l = Sf()), (Ae = $n = Ht = null), (qa = !1), l)
        : null;
    switch (l) {
      case 'paste':
        return null;
      case 'keypress':
        if (!(t.ctrlKey || t.altKey || t.metaKey) || (t.ctrlKey && t.altKey)) {
          if (t.char && 1 < t.char.length) return t.char;
          if (t.which) return String.fromCharCode(t.which);
        }
        return null;
      case 'compositionend':
        return Tf && t.locale !== 'ko' ? null : t.data;
      default:
        return null;
    }
  }
  var Vh = {
    color: !0,
    date: !0,
    datetime: !0,
    'datetime-local': !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0,
  };
  function Of(l) {
    var t = l && l.nodeName && l.nodeName.toLowerCase();
    return t === 'input' ? !!Vh[l.type] : t === 'textarea';
  }
  function Uf(l, t, a, u) {
    (Ha ? (_a ? _a.push(u) : (_a = [u])) : (Ha = u),
      (t = yn(t, 'onChange')),
      0 < t.length &&
        ((a = new Ee('onChange', 'change', null, a, u)),
        l.push({ event: a, listeners: t })));
  }
  var pu = null,
    zu = null;
  function Ch(l) {
    hd(l, 0);
  }
  function je(l) {
    var t = yu(l);
    if (mf(t)) return l;
  }
  function Hf(l, t) {
    if (l === 'change') return t;
  }
  var _f = !1;
  if (vt) {
    var ac;
    if (vt) {
      var uc = 'oninput' in document;
      if (!uc) {
        var qf = document.createElement('div');
        (qf.setAttribute('oninput', 'return;'),
          (uc = typeof qf.oninput == 'function'));
      }
      ac = uc;
    } else ac = !1;
    _f = ac && (!document.documentMode || 9 < document.documentMode);
  }
  function Rf() {
    pu && (pu.detachEvent('onpropertychange', Bf), (zu = pu = null));
  }
  function Bf(l) {
    if (l.propertyName === 'value' && je(zu)) {
      var t = [];
      (Uf(t, zu, l, wn(l)), xf(Ch, t));
    }
  }
  function Kh(l, t, a) {
    l === 'focusin'
      ? (Rf(), (pu = t), (zu = a), pu.attachEvent('onpropertychange', Bf))
      : l === 'focusout' && Rf();
  }
  function Lh(l) {
    if (l === 'selectionchange' || l === 'keyup' || l === 'keydown')
      return je(zu);
  }
  function Jh(l, t) {
    if (l === 'click') return je(t);
  }
  function wh(l, t) {
    if (l === 'input' || l === 'change') return je(t);
  }
  function Wh(l, t) {
    return (l === t && (l !== 0 || 1 / l === 1 / t)) || (l !== l && t !== t);
  }
  var Ol = typeof Object.is == 'function' ? Object.is : Wh;
  function Nu(l, t) {
    if (Ol(l, t)) return !0;
    if (
      typeof l != 'object' ||
      l === null ||
      typeof t != 'object' ||
      t === null
    )
      return !1;
    var a = Object.keys(l),
      u = Object.keys(t);
    if (a.length !== u.length) return !1;
    for (u = 0; u < a.length; u++) {
      var e = a[u];
      if (!Hn.call(t, e) || !Ol(l[e], t[e])) return !1;
    }
    return !0;
  }
  function Yf(l) {
    for (; l && l.firstChild; ) l = l.firstChild;
    return l;
  }
  function Gf(l, t) {
    var a = Yf(l);
    l = 0;
    for (var u; a; ) {
      if (a.nodeType === 3) {
        if (((u = l + a.textContent.length), l <= t && u >= t))
          return { node: a, offset: t - l };
        l = u;
      }
      l: {
        for (; a; ) {
          if (a.nextSibling) {
            a = a.nextSibling;
            break l;
          }
          a = a.parentNode;
        }
        a = void 0;
      }
      a = Yf(a);
    }
  }
  function Xf(l, t) {
    return l && t
      ? l === t
        ? !0
        : l && l.nodeType === 3
          ? !1
          : t && t.nodeType === 3
            ? Xf(l, t.parentNode)
            : 'contains' in l
              ? l.contains(t)
              : l.compareDocumentPosition
                ? !!(l.compareDocumentPosition(t) & 16)
                : !1
      : !1;
  }
  function Qf(l) {
    l =
      l != null &&
      l.ownerDocument != null &&
      l.ownerDocument.defaultView != null
        ? l.ownerDocument.defaultView
        : window;
    for (var t = ze(l.document); t instanceof l.HTMLIFrameElement; ) {
      try {
        var a = typeof t.contentWindow.location.href == 'string';
      } catch {
        a = !1;
      }
      if (a) l = t.contentWindow;
      else break;
      t = ze(l.document);
    }
    return t;
  }
  function ec(l) {
    var t = l && l.nodeName && l.nodeName.toLowerCase();
    return (
      t &&
      ((t === 'input' &&
        (l.type === 'text' ||
          l.type === 'search' ||
          l.type === 'tel' ||
          l.type === 'url' ||
          l.type === 'password')) ||
        t === 'textarea' ||
        l.contentEditable === 'true')
    );
  }
  var kh = vt && 'documentMode' in document && 11 >= document.documentMode,
    Ra = null,
    nc = null,
    Au = null,
    cc = !1;
  function Zf(l, t, a) {
    var u =
      a.window === a ? a.document : a.nodeType === 9 ? a : a.ownerDocument;
    cc ||
      Ra == null ||
      Ra !== ze(u) ||
      ((u = Ra),
      'selectionStart' in u && ec(u)
        ? (u = { start: u.selectionStart, end: u.selectionEnd })
        : ((u = (
            (u.ownerDocument && u.ownerDocument.defaultView) ||
            window
          ).getSelection()),
          (u = {
            anchorNode: u.anchorNode,
            anchorOffset: u.anchorOffset,
            focusNode: u.focusNode,
            focusOffset: u.focusOffset,
          })),
      (Au && Nu(Au, u)) ||
        ((Au = u),
        (u = yn(nc, 'onSelect')),
        0 < u.length &&
          ((t = new Ee('onSelect', 'select', null, t, a)),
          l.push({ event: t, listeners: u }),
          (t.target = Ra))));
  }
  function na(l, t) {
    var a = {};
    return (
      (a[l.toLowerCase()] = t.toLowerCase()),
      (a['Webkit' + l] = 'webkit' + t),
      (a['Moz' + l] = 'moz' + t),
      a
    );
  }
  var Ba = {
      animationend: na('Animation', 'AnimationEnd'),
      animationiteration: na('Animation', 'AnimationIteration'),
      animationstart: na('Animation', 'AnimationStart'),
      transitionrun: na('Transition', 'TransitionRun'),
      transitionstart: na('Transition', 'TransitionStart'),
      transitioncancel: na('Transition', 'TransitionCancel'),
      transitionend: na('Transition', 'TransitionEnd'),
    },
    ic = {},
    Vf = {};
  vt &&
    ((Vf = document.createElement('div').style),
    'AnimationEvent' in window ||
      (delete Ba.animationend.animation,
      delete Ba.animationiteration.animation,
      delete Ba.animationstart.animation),
    'TransitionEvent' in window || delete Ba.transitionend.transition);
  function ca(l) {
    if (ic[l]) return ic[l];
    if (!Ba[l]) return l;
    var t = Ba[l],
      a;
    for (a in t) if (t.hasOwnProperty(a) && a in Vf) return (ic[l] = t[a]);
    return l;
  }
  var Cf = ca('animationend'),
    Kf = ca('animationiteration'),
    Lf = ca('animationstart'),
    $h = ca('transitionrun'),
    Fh = ca('transitionstart'),
    Ih = ca('transitioncancel'),
    Jf = ca('transitionend'),
    wf = new Map(),
    fc =
      'abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel'.split(
        ' ',
      );
  fc.push('scrollEnd');
  function Il(l, t) {
    (wf.set(l, t), ua(t, [l]));
  }
  var Wf = new WeakMap();
  function Vl(l, t) {
    if (typeof l == 'object' && l !== null) {
      var a = Wf.get(l);
      return a !== void 0
        ? a
        : ((t = { value: l, source: t, stack: df(t) }), Wf.set(l, t), t);
    }
    return { value: l, source: t, stack: df(t) };
  }
  var Cl = [],
    Ya = 0,
    sc = 0;
  function Oe() {
    for (var l = Ya, t = (sc = Ya = 0); t < l; ) {
      var a = Cl[t];
      Cl[t++] = null;
      var u = Cl[t];
      Cl[t++] = null;
      var e = Cl[t];
      Cl[t++] = null;
      var n = Cl[t];
      if (((Cl[t++] = null), u !== null && e !== null)) {
        var c = u.pending;
        (c === null ? (e.next = e) : ((e.next = c.next), (c.next = e)),
          (u.pending = e));
      }
      n !== 0 && kf(a, e, n);
    }
  }
  function Ue(l, t, a, u) {
    ((Cl[Ya++] = l),
      (Cl[Ya++] = t),
      (Cl[Ya++] = a),
      (Cl[Ya++] = u),
      (sc |= u),
      (l.lanes |= u),
      (l = l.alternate),
      l !== null && (l.lanes |= u));
  }
  function dc(l, t, a, u) {
    return (Ue(l, t, a, u), He(l));
  }
  function Ga(l, t) {
    return (Ue(l, null, null, t), He(l));
  }
  function kf(l, t, a) {
    l.lanes |= a;
    var u = l.alternate;
    u !== null && (u.lanes |= a);
    for (var e = !1, n = l.return; n !== null; )
      ((n.childLanes |= a),
        (u = n.alternate),
        u !== null && (u.childLanes |= a),
        n.tag === 22 &&
          ((l = n.stateNode), l === null || l._visibility & 1 || (e = !0)),
        (l = n),
        (n = n.return));
    return l.tag === 3
      ? ((n = l.stateNode),
        e &&
          t !== null &&
          ((e = 31 - jl(a)),
          (l = n.hiddenUpdates),
          (u = l[e]),
          u === null ? (l[e] = [t]) : u.push(t),
          (t.lane = a | 536870912)),
        n)
      : null;
  }
  function He(l) {
    if (50 < ku) throw ((ku = 0), (oi = null), Error(b(185)));
    for (var t = l.return; t !== null; ) ((l = t), (t = l.return));
    return l.tag === 3 ? l.stateNode : null;
  }
  var Xa = {};
  function Ph(l, t, a, u) {
    ((this.tag = l),
      (this.key = a),
      (this.sibling =
        this.child =
        this.return =
        this.stateNode =
        this.type =
        this.elementType =
          null),
      (this.index = 0),
      (this.refCleanup = this.ref = null),
      (this.pendingProps = t),
      (this.dependencies =
        this.memoizedState =
        this.updateQueue =
        this.memoizedProps =
          null),
      (this.mode = u),
      (this.subtreeFlags = this.flags = 0),
      (this.deletions = null),
      (this.childLanes = this.lanes = 0),
      (this.alternate = null));
  }
  function Ul(l, t, a, u) {
    return new Ph(l, t, a, u);
  }
  function hc(l) {
    return ((l = l.prototype), !(!l || !l.isReactComponent));
  }
  function rt(l, t) {
    var a = l.alternate;
    return (
      a === null
        ? ((a = Ul(l.tag, t, l.key, l.mode)),
          (a.elementType = l.elementType),
          (a.type = l.type),
          (a.stateNode = l.stateNode),
          (a.alternate = l),
          (l.alternate = a))
        : ((a.pendingProps = t),
          (a.type = l.type),
          (a.flags = 0),
          (a.subtreeFlags = 0),
          (a.deletions = null)),
      (a.flags = l.flags & 65011712),
      (a.childLanes = l.childLanes),
      (a.lanes = l.lanes),
      (a.child = l.child),
      (a.memoizedProps = l.memoizedProps),
      (a.memoizedState = l.memoizedState),
      (a.updateQueue = l.updateQueue),
      (t = l.dependencies),
      (a.dependencies =
        t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }),
      (a.sibling = l.sibling),
      (a.index = l.index),
      (a.ref = l.ref),
      (a.refCleanup = l.refCleanup),
      a
    );
  }
  function $f(l, t) {
    l.flags &= 65011714;
    var a = l.alternate;
    return (
      a === null
        ? ((l.childLanes = 0),
          (l.lanes = t),
          (l.child = null),
          (l.subtreeFlags = 0),
          (l.memoizedProps = null),
          (l.memoizedState = null),
          (l.updateQueue = null),
          (l.dependencies = null),
          (l.stateNode = null))
        : ((l.childLanes = a.childLanes),
          (l.lanes = a.lanes),
          (l.child = a.child),
          (l.subtreeFlags = 0),
          (l.deletions = null),
          (l.memoizedProps = a.memoizedProps),
          (l.memoizedState = a.memoizedState),
          (l.updateQueue = a.updateQueue),
          (l.type = a.type),
          (t = a.dependencies),
          (l.dependencies =
            t === null
              ? null
              : { lanes: t.lanes, firstContext: t.firstContext })),
      l
    );
  }
  function _e(l, t, a, u, e, n) {
    var c = 0;
    if (((u = l), typeof l == 'function')) hc(l) && (c = 1);
    else if (typeof l == 'string')
      c = tv(l, a, sl.current)
        ? 26
        : l === 'html' || l === 'head' || l === 'body'
          ? 27
          : 5;
    else
      l: switch (l) {
        case pa:
          return (
            (l = Ul(31, a, t, e)),
            (l.elementType = pa),
            (l.lanes = n),
            l
          );
        case Yl:
          return ia(a.children, e, n, t);
        case Et:
          ((c = 8), (e |= 24));
          break;
        case la:
          return (
            (l = Ul(12, a, t, e | 2)),
            (l.elementType = la),
            (l.lanes = n),
            l
          );
        case ta:
          return (
            (l = Ul(13, a, t, e)),
            (l.elementType = ta),
            (l.lanes = n),
            l
          );
        case tt:
          return (
            (l = Ul(19, a, t, e)),
            (l.elementType = tt),
            (l.lanes = n),
            l
          );
        default:
          if (typeof l == 'object' && l !== null)
            switch (l.$$typeof) {
              case se:
              case Gl:
                c = 10;
                break l;
              case su:
                c = 9;
                break l;
              case Dt:
                c = 11;
                break l;
              case dt:
                c = 14;
                break l;
              case Fl:
                ((c = 16), (u = null));
                break l;
            }
          ((c = 29),
            (a = Error(b(130, l === null ? 'null' : typeof l, ''))),
            (u = null));
      }
    return (
      (t = Ul(c, a, t, e)),
      (t.elementType = l),
      (t.type = u),
      (t.lanes = n),
      t
    );
  }
  function ia(l, t, a, u) {
    return ((l = Ul(7, l, u, t)), (l.lanes = a), l);
  }
  function mc(l, t, a) {
    return ((l = Ul(6, l, null, t)), (l.lanes = a), l);
  }
  function vc(l, t, a) {
    return (
      (t = Ul(4, l.children !== null ? l.children : [], l.key, t)),
      (t.lanes = a),
      (t.stateNode = {
        containerInfo: l.containerInfo,
        pendingChildren: null,
        implementation: l.implementation,
      }),
      t
    );
  }
  var Qa = [],
    Za = 0,
    qe = null,
    Re = 0,
    Kl = [],
    Ll = 0,
    fa = null,
    yt = 1,
    ot = '';
  function sa(l, t) {
    ((Qa[Za++] = Re), (Qa[Za++] = qe), (qe = l), (Re = t));
  }
  function Ff(l, t, a) {
    ((Kl[Ll++] = yt), (Kl[Ll++] = ot), (Kl[Ll++] = fa), (fa = l));
    var u = yt;
    l = ot;
    var e = 32 - jl(u) - 1;
    ((u &= ~(1 << e)), (a += 1));
    var n = 32 - jl(t) + e;
    if (30 < n) {
      var c = e - (e % 5);
      ((n = (u & ((1 << c) - 1)).toString(32)),
        (u >>= c),
        (e -= c),
        (yt = (1 << (32 - jl(t) + e)) | (a << e) | u),
        (ot = n + l));
    } else ((yt = (1 << n) | (a << e) | u), (ot = l));
  }
  function rc(l) {
    l.return !== null && (sa(l, 1), Ff(l, 1, 0));
  }
  function yc(l) {
    for (; l === qe; )
      ((qe = Qa[--Za]), (Qa[Za] = null), (Re = Qa[--Za]), (Qa[Za] = null));
    for (; l === fa; )
      ((fa = Kl[--Ll]),
        (Kl[Ll] = null),
        (ot = Kl[--Ll]),
        (Kl[Ll] = null),
        (yt = Kl[--Ll]),
        (Kl[Ll] = null));
  }
  var Sl = null,
    I = null,
    B = !1,
    da = null,
    et = !1,
    oc = Error(b(519));
  function ha(l) {
    var t = Error(b(418, ''));
    throw (Eu(Vl(t, l)), oc);
  }
  function If(l) {
    var t = l.stateNode,
      a = l.type,
      u = l.memoizedProps;
    switch (((t[bl] = l), (t[zl] = u), a)) {
      case 'dialog':
        (_('cancel', t), _('close', t));
        break;
      case 'iframe':
      case 'object':
      case 'embed':
        _('load', t);
        break;
      case 'video':
      case 'audio':
        for (a = 0; a < Fu.length; a++) _(Fu[a], t);
        break;
      case 'source':
        _('error', t);
        break;
      case 'img':
      case 'image':
      case 'link':
        (_('error', t), _('load', t));
        break;
      case 'details':
        _('toggle', t);
        break;
      case 'input':
        (_('invalid', t),
          vf(
            t,
            u.value,
            u.defaultValue,
            u.checked,
            u.defaultChecked,
            u.type,
            u.name,
            !0,
          ),
          pe(t));
        break;
      case 'select':
        _('invalid', t);
        break;
      case 'textarea':
        (_('invalid', t), yf(t, u.value, u.defaultValue, u.children), pe(t));
    }
    ((a = u.children),
      (typeof a != 'string' && typeof a != 'number' && typeof a != 'bigint') ||
      t.textContent === '' + a ||
      u.suppressHydrationWarning === !0 ||
      yd(t.textContent, a)
        ? (u.popover != null && (_('beforetoggle', t), _('toggle', t)),
          u.onScroll != null && _('scroll', t),
          u.onScrollEnd != null && _('scrollend', t),
          u.onClick != null && (t.onclick = on),
          (t = !0))
        : (t = !1),
      t || ha(l));
  }
  function Pf(l) {
    for (Sl = l.return; Sl; )
      switch (Sl.tag) {
        case 5:
        case 13:
          et = !1;
          return;
        case 27:
        case 3:
          et = !0;
          return;
        default:
          Sl = Sl.return;
      }
  }
  function Tu(l) {
    if (l !== Sl) return !1;
    if (!B) return (Pf(l), (B = !0), !1);
    var t = l.tag,
      a;
    if (
      ((a = t !== 3 && t !== 27) &&
        ((a = t === 5) &&
          ((a = l.type),
          (a =
            !(a !== 'form' && a !== 'button') || Hi(l.type, l.memoizedProps))),
        (a = !a)),
      a && I && ha(l),
      Pf(l),
      t === 13)
    ) {
      if (((l = l.memoizedState), (l = l !== null ? l.dehydrated : null), !l))
        throw Error(b(317));
      l: {
        for (l = l.nextSibling, t = 0; l; ) {
          if (l.nodeType === 8)
            if (((a = l.data), a === '/$')) {
              if (t === 0) {
                I = lt(l.nextSibling);
                break l;
              }
              t--;
            } else (a !== '$' && a !== '$!' && a !== '$?') || t++;
          l = l.nextSibling;
        }
        I = null;
      }
    } else
      t === 27
        ? ((t = I), Wt(l.type) ? ((l = Bi), (Bi = null), (I = l)) : (I = t))
        : (I = Sl ? lt(l.stateNode.nextSibling) : null);
    return !0;
  }
  function Mu() {
    ((I = Sl = null), (B = !1));
  }
  function ls() {
    var l = da;
    return (
      l !== null &&
        (Ml === null ? (Ml = l) : Ml.push.apply(Ml, l), (da = null)),
      l
    );
  }
  function Eu(l) {
    da === null ? (da = [l]) : da.push(l);
  }
  var bc = xl(null),
    ma = null,
    bt = null;
  function _t(l, t, a) {
    (X(bc, t._currentValue), (t._currentValue = a));
  }
  function gt(l) {
    ((l._currentValue = bc.current), $(bc));
  }
  function gc(l, t, a) {
    for (; l !== null; ) {
      var u = l.alternate;
      if (
        ((l.childLanes & t) !== t
          ? ((l.childLanes |= t), u !== null && (u.childLanes |= t))
          : u !== null && (u.childLanes & t) !== t && (u.childLanes |= t),
        l === a)
      )
        break;
      l = l.return;
    }
  }
  function xc(l, t, a, u) {
    var e = l.child;
    for (e !== null && (e.return = l); e !== null; ) {
      var n = e.dependencies;
      if (n !== null) {
        var c = e.child;
        n = n.firstContext;
        l: for (; n !== null; ) {
          var i = n;
          n = e;
          for (var f = 0; f < t.length; f++)
            if (i.context === t[f]) {
              ((n.lanes |= a),
                (i = n.alternate),
                i !== null && (i.lanes |= a),
                gc(n.return, a, l),
                u || (c = null));
              break l;
            }
          n = i.next;
        }
      } else if (e.tag === 18) {
        if (((c = e.return), c === null)) throw Error(b(341));
        ((c.lanes |= a),
          (n = c.alternate),
          n !== null && (n.lanes |= a),
          gc(c, a, l),
          (c = null));
      } else c = e.child;
      if (c !== null) c.return = e;
      else
        for (c = e; c !== null; ) {
          if (c === l) {
            c = null;
            break;
          }
          if (((e = c.sibling), e !== null)) {
            ((e.return = c.return), (c = e));
            break;
          }
          c = c.return;
        }
      e = c;
    }
  }
  function Du(l, t, a, u) {
    l = null;
    for (var e = t, n = !1; e !== null; ) {
      if (!n) {
        if ((e.flags & 524288) !== 0) n = !0;
        else if ((e.flags & 262144) !== 0) break;
      }
      if (e.tag === 10) {
        var c = e.alternate;
        if (c === null) throw Error(b(387));
        if (((c = c.memoizedProps), c !== null)) {
          var i = e.type;
          Ol(e.pendingProps.value, c.value) ||
            (l !== null ? l.push(i) : (l = [i]));
        }
      } else if (e === me.current) {
        if (((c = e.alternate), c === null)) throw Error(b(387));
        c.memoizedState.memoizedState !== e.memoizedState.memoizedState &&
          (l !== null ? l.push(ue) : (l = [ue]));
      }
      e = e.return;
    }
    (l !== null && xc(t, l, a, u), (t.flags |= 262144));
  }
  function Be(l) {
    for (l = l.firstContext; l !== null; ) {
      if (!Ol(l.context._currentValue, l.memoizedValue)) return !0;
      l = l.next;
    }
    return !1;
  }
  function va(l) {
    ((ma = l),
      (bt = null),
      (l = l.dependencies),
      l !== null && (l.firstContext = null));
  }
  function gl(l) {
    return ts(ma, l);
  }
  function Ye(l, t) {
    return (ma === null && va(l), ts(l, t));
  }
  function ts(l, t) {
    var a = t._currentValue;
    if (((t = { context: t, memoizedValue: a, next: null }), bt === null)) {
      if (l === null) throw Error(b(308));
      ((bt = t),
        (l.dependencies = { lanes: 0, firstContext: t }),
        (l.flags |= 524288));
    } else bt = bt.next = t;
    return a;
  }
  var lm =
      typeof AbortController < 'u'
        ? AbortController
        : function () {
            var l = [],
              t = (this.signal = {
                aborted: !1,
                addEventListener: function (a, u) {
                  l.push(u);
                },
              });
            this.abort = function () {
              ((t.aborted = !0),
                l.forEach(function (a) {
                  return a();
                }));
            };
          },
    tm = A.unstable_scheduleCallback,
    am = A.unstable_NormalPriority,
    nl = {
      $$typeof: Gl,
      Consumer: null,
      Provider: null,
      _currentValue: null,
      _currentValue2: null,
      _threadCount: 0,
    };
  function Sc() {
    return { controller: new lm(), data: new Map(), refCount: 0 };
  }
  function ju(l) {
    (l.refCount--,
      l.refCount === 0 &&
        tm(am, function () {
          l.controller.abort();
        }));
  }
  var Ou = null,
    pc = 0,
    Va = 0,
    Ca = null;
  function um(l, t) {
    if (Ou === null) {
      var a = (Ou = []);
      ((pc = 0),
        (Va = Ni()),
        (Ca = {
          status: 'pending',
          value: void 0,
          then: function (u) {
            a.push(u);
          },
        }));
    }
    return (pc++, t.then(as, as), t);
  }
  function as() {
    if (--pc === 0 && Ou !== null) {
      Ca !== null && (Ca.status = 'fulfilled');
      var l = Ou;
      ((Ou = null), (Va = 0), (Ca = null));
      for (var t = 0; t < l.length; t++) (0, l[t])();
    }
  }
  function em(l, t) {
    var a = [],
      u = {
        status: 'pending',
        value: null,
        reason: null,
        then: function (e) {
          a.push(e);
        },
      };
    return (
      l.then(
        function () {
          ((u.status = 'fulfilled'), (u.value = t));
          for (var e = 0; e < a.length; e++) (0, a[e])(t);
        },
        function (e) {
          for (u.status = 'rejected', u.reason = e, e = 0; e < a.length; e++)
            (0, a[e])(void 0);
        },
      ),
      u
    );
  }
  var us = x.S;
  x.S = function (l, t) {
    (typeof t == 'object' &&
      t !== null &&
      typeof t.then == 'function' &&
      um(l, t),
      us !== null && us(l, t));
  };
  var ra = xl(null);
  function zc() {
    var l = ra.current;
    return l !== null ? l : L.pooledCache;
  }
  function Ge(l, t) {
    t === null ? X(ra, ra.current) : X(ra, t.pool);
  }
  function es() {
    var l = zc();
    return l === null ? null : { parent: nl._currentValue, pool: l };
  }
  var Uu = Error(b(460)),
    ns = Error(b(474)),
    Xe = Error(b(542)),
    Nc = { then: function () {} };
  function cs(l) {
    return ((l = l.status), l === 'fulfilled' || l === 'rejected');
  }
  function Qe() {}
  function is(l, t, a) {
    switch (
      ((a = l[a]),
      a === void 0 ? l.push(t) : a !== t && (t.then(Qe, Qe), (t = a)),
      t.status)
    ) {
      case 'fulfilled':
        return t.value;
      case 'rejected':
        throw ((l = t.reason), ss(l), l);
      default:
        if (typeof t.status == 'string') t.then(Qe, Qe);
        else {
          if (((l = L), l !== null && 100 < l.shellSuspendCounter))
            throw Error(b(482));
          ((l = t),
            (l.status = 'pending'),
            l.then(
              function (u) {
                if (t.status === 'pending') {
                  var e = t;
                  ((e.status = 'fulfilled'), (e.value = u));
                }
              },
              function (u) {
                if (t.status === 'pending') {
                  var e = t;
                  ((e.status = 'rejected'), (e.reason = u));
                }
              },
            ));
        }
        switch (t.status) {
          case 'fulfilled':
            return t.value;
          case 'rejected':
            throw ((l = t.reason), ss(l), l);
        }
        throw ((Hu = t), Uu);
    }
  }
  var Hu = null;
  function fs() {
    if (Hu === null) throw Error(b(459));
    var l = Hu;
    return ((Hu = null), l);
  }
  function ss(l) {
    if (l === Uu || l === Xe) throw Error(b(483));
  }
  var qt = !1;
  function Ac(l) {
    l.updateQueue = {
      baseState: l.memoizedState,
      firstBaseUpdate: null,
      lastBaseUpdate: null,
      shared: { pending: null, lanes: 0, hiddenCallbacks: null },
      callbacks: null,
    };
  }
  function Tc(l, t) {
    ((l = l.updateQueue),
      t.updateQueue === l &&
        (t.updateQueue = {
          baseState: l.baseState,
          firstBaseUpdate: l.firstBaseUpdate,
          lastBaseUpdate: l.lastBaseUpdate,
          shared: l.shared,
          callbacks: null,
        }));
  }
  function Rt(l) {
    return { lane: l, tag: 0, payload: null, callback: null, next: null };
  }
  function Bt(l, t, a) {
    var u = l.updateQueue;
    if (u === null) return null;
    if (((u = u.shared), (Y & 2) !== 0)) {
      var e = u.pending;
      return (
        e === null ? (t.next = t) : ((t.next = e.next), (e.next = t)),
        (u.pending = t),
        (t = He(l)),
        kf(l, null, a),
        t
      );
    }
    return (Ue(l, u, t, a), He(l));
  }
  function _u(l, t, a) {
    if (
      ((t = t.updateQueue), t !== null && ((t = t.shared), (a & 4194048) !== 0))
    ) {
      var u = t.lanes;
      ((u &= l.pendingLanes), (a |= u), (t.lanes = a), tf(l, a));
    }
  }
  function Mc(l, t) {
    var a = l.updateQueue,
      u = l.alternate;
    if (u !== null && ((u = u.updateQueue), a === u)) {
      var e = null,
        n = null;
      if (((a = a.firstBaseUpdate), a !== null)) {
        do {
          var c = {
            lane: a.lane,
            tag: a.tag,
            payload: a.payload,
            callback: null,
            next: null,
          };
          (n === null ? (e = n = c) : (n = n.next = c), (a = a.next));
        } while (a !== null);
        n === null ? (e = n = t) : (n = n.next = t);
      } else e = n = t;
      ((a = {
        baseState: u.baseState,
        firstBaseUpdate: e,
        lastBaseUpdate: n,
        shared: u.shared,
        callbacks: u.callbacks,
      }),
        (l.updateQueue = a));
      return;
    }
    ((l = a.lastBaseUpdate),
      l === null ? (a.firstBaseUpdate = t) : (l.next = t),
      (a.lastBaseUpdate = t));
  }
  var Ec = !1;
  function qu() {
    if (Ec) {
      var l = Ca;
      if (l !== null) throw l;
    }
  }
  function Ru(l, t, a, u) {
    Ec = !1;
    var e = l.updateQueue;
    qt = !1;
    var n = e.firstBaseUpdate,
      c = e.lastBaseUpdate,
      i = e.shared.pending;
    if (i !== null) {
      e.shared.pending = null;
      var f = i,
        v = f.next;
      ((f.next = null), c === null ? (n = v) : (c.next = v), (c = f));
      var o = l.alternate;
      o !== null &&
        ((o = o.updateQueue),
        (i = o.lastBaseUpdate),
        i !== c &&
          (i === null ? (o.firstBaseUpdate = v) : (i.next = v),
          (o.lastBaseUpdate = f)));
    }
    if (n !== null) {
      var S = e.baseState;
      ((c = 0), (o = v = f = null), (i = n));
      do {
        var r = i.lane & -536870913,
          y = r !== i.lane;
        if (y ? (q & r) === r : (u & r) === r) {
          (r !== 0 && r === Va && (Ec = !0),
            o !== null &&
              (o = o.next =
                {
                  lane: 0,
                  tag: i.tag,
                  payload: i.payload,
                  callback: null,
                  next: null,
                }));
          l: {
            var E = l,
              T = i;
            r = t;
            var V = a;
            switch (T.tag) {
              case 1:
                if (((E = T.payload), typeof E == 'function')) {
                  S = E.call(V, S, r);
                  break l;
                }
                S = E;
                break l;
              case 3:
                E.flags = (E.flags & -65537) | 128;
              case 0:
                if (
                  ((E = T.payload),
                  (r = typeof E == 'function' ? E.call(V, S, r) : E),
                  r == null)
                )
                  break l;
                S = C({}, S, r);
                break l;
              case 2:
                qt = !0;
            }
          }
          ((r = i.callback),
            r !== null &&
              ((l.flags |= 64),
              y && (l.flags |= 8192),
              (y = e.callbacks),
              y === null ? (e.callbacks = [r]) : y.push(r)));
        } else
          ((y = {
            lane: r,
            tag: i.tag,
            payload: i.payload,
            callback: i.callback,
            next: null,
          }),
            o === null ? ((v = o = y), (f = S)) : (o = o.next = y),
            (c |= r));
        if (((i = i.next), i === null)) {
          if (((i = e.shared.pending), i === null)) break;
          ((y = i),
            (i = y.next),
            (y.next = null),
            (e.lastBaseUpdate = y),
            (e.shared.pending = null));
        }
      } while (!0);
      (o === null && (f = S),
        (e.baseState = f),
        (e.firstBaseUpdate = v),
        (e.lastBaseUpdate = o),
        n === null && (e.shared.lanes = 0),
        (Kt |= c),
        (l.lanes = c),
        (l.memoizedState = S));
    }
  }
  function ds(l, t) {
    if (typeof l != 'function') throw Error(b(191, l));
    l.call(t);
  }
  function hs(l, t) {
    var a = l.callbacks;
    if (a !== null)
      for (l.callbacks = null, l = 0; l < a.length; l++) ds(a[l], t);
  }
  var Ka = xl(null),
    Ze = xl(0);
  function ms(l, t) {
    ((l = Tt), X(Ze, l), X(Ka, t), (Tt = l | t.baseLanes));
  }
  function Dc() {
    (X(Ze, Tt), X(Ka, Ka.current));
  }
  function jc() {
    ((Tt = Ze.current), $(Ka), $(Ze));
  }
  var Yt = 0,
    O = null,
    Q = null,
    ul = null,
    Ve = !1,
    La = !1,
    ya = !1,
    Ce = 0,
    Bu = 0,
    Ja = null,
    nm = 0;
  function tl() {
    throw Error(b(321));
  }
  function Oc(l, t) {
    if (t === null) return !1;
    for (var a = 0; a < t.length && a < l.length; a++)
      if (!Ol(l[a], t[a])) return !1;
    return !0;
  }
  function Uc(l, t, a, u, e, n) {
    return (
      (Yt = n),
      (O = t),
      (t.memoizedState = null),
      (t.updateQueue = null),
      (t.lanes = 0),
      (x.H = l === null || l.memoizedState === null ? ks : $s),
      (ya = !1),
      (n = a(u, e)),
      (ya = !1),
      La && (n = rs(t, a, u, e)),
      vs(l),
      n
    );
  }
  function vs(l) {
    x.H = ke;
    var t = Q !== null && Q.next !== null;
    if (((Yt = 0), (ul = Q = O = null), (Ve = !1), (Bu = 0), (Ja = null), t))
      throw Error(b(300));
    l === null ||
      hl ||
      ((l = l.dependencies), l !== null && Be(l) && (hl = !0));
  }
  function rs(l, t, a, u) {
    O = l;
    var e = 0;
    do {
      if ((La && (Ja = null), (Bu = 0), (La = !1), 25 <= e))
        throw Error(b(301));
      if (((e += 1), (ul = Q = null), l.updateQueue != null)) {
        var n = l.updateQueue;
        ((n.lastEffect = null),
          (n.events = null),
          (n.stores = null),
          n.memoCache != null && (n.memoCache.index = 0));
      }
      ((x.H = mm), (n = t(a, u)));
    } while (La);
    return n;
  }
  function cm() {
    var l = x.H,
      t = l.useState()[0];
    return (
      (t = typeof t.then == 'function' ? Yu(t) : t),
      (l = l.useState()[0]),
      (Q !== null ? Q.memoizedState : null) !== l && (O.flags |= 1024),
      t
    );
  }
  function Hc() {
    var l = Ce !== 0;
    return ((Ce = 0), l);
  }
  function _c(l, t, a) {
    ((t.updateQueue = l.updateQueue), (t.flags &= -2053), (l.lanes &= ~a));
  }
  function qc(l) {
    if (Ve) {
      for (l = l.memoizedState; l !== null; ) {
        var t = l.queue;
        (t !== null && (t.pending = null), (l = l.next));
      }
      Ve = !1;
    }
    ((Yt = 0), (ul = Q = O = null), (La = !1), (Bu = Ce = 0), (Ja = null));
  }
  function Al() {
    var l = {
      memoizedState: null,
      baseState: null,
      baseQueue: null,
      queue: null,
      next: null,
    };
    return (ul === null ? (O.memoizedState = ul = l) : (ul = ul.next = l), ul);
  }
  function el() {
    if (Q === null) {
      var l = O.alternate;
      l = l !== null ? l.memoizedState : null;
    } else l = Q.next;
    var t = ul === null ? O.memoizedState : ul.next;
    if (t !== null) ((ul = t), (Q = l));
    else {
      if (l === null)
        throw O.alternate === null ? Error(b(467)) : Error(b(310));
      ((Q = l),
        (l = {
          memoizedState: Q.memoizedState,
          baseState: Q.baseState,
          baseQueue: Q.baseQueue,
          queue: Q.queue,
          next: null,
        }),
        ul === null ? (O.memoizedState = ul = l) : (ul = ul.next = l));
    }
    return ul;
  }
  function Rc() {
    return { lastEffect: null, events: null, stores: null, memoCache: null };
  }
  function Yu(l) {
    var t = Bu;
    return (
      (Bu += 1),
      Ja === null && (Ja = []),
      (l = is(Ja, l, t)),
      (t = O),
      (ul === null ? t.memoizedState : ul.next) === null &&
        ((t = t.alternate),
        (x.H = t === null || t.memoizedState === null ? ks : $s)),
      l
    );
  }
  function Ke(l) {
    if (l !== null && typeof l == 'object') {
      if (typeof l.then == 'function') return Yu(l);
      if (l.$$typeof === Gl) return gl(l);
    }
    throw Error(b(438, String(l)));
  }
  function Bc(l) {
    var t = null,
      a = O.updateQueue;
    if ((a !== null && (t = a.memoCache), t == null)) {
      var u = O.alternate;
      u !== null &&
        ((u = u.updateQueue),
        u !== null &&
          ((u = u.memoCache),
          u != null &&
            (t = {
              data: u.data.map(function (e) {
                return e.slice();
              }),
              index: 0,
            })));
    }
    if (
      (t == null && (t = { data: [], index: 0 }),
      a === null && ((a = Rc()), (O.updateQueue = a)),
      (a.memoCache = t),
      (a = t.data[t.index]),
      a === void 0)
    )
      for (a = t.data[t.index] = Array(l), u = 0; u < l; u++) a[u] = de;
    return (t.index++, a);
  }
  function xt(l, t) {
    return typeof t == 'function' ? t(l) : t;
  }
  function Le(l) {
    var t = el();
    return Yc(t, Q, l);
  }
  function Yc(l, t, a) {
    var u = l.queue;
    if (u === null) throw Error(b(311));
    u.lastRenderedReducer = a;
    var e = l.baseQueue,
      n = u.pending;
    if (n !== null) {
      if (e !== null) {
        var c = e.next;
        ((e.next = n.next), (n.next = c));
      }
      ((t.baseQueue = e = n), (u.pending = null));
    }
    if (((n = l.baseState), e === null)) l.memoizedState = n;
    else {
      t = e.next;
      var i = (c = null),
        f = null,
        v = t,
        o = !1;
      do {
        var S = v.lane & -536870913;
        if (S !== v.lane ? (q & S) === S : (Yt & S) === S) {
          var r = v.revertLane;
          if (r === 0)
            (f !== null &&
              (f = f.next =
                {
                  lane: 0,
                  revertLane: 0,
                  action: v.action,
                  hasEagerState: v.hasEagerState,
                  eagerState: v.eagerState,
                  next: null,
                }),
              S === Va && (o = !0));
          else if ((Yt & r) === r) {
            ((v = v.next), r === Va && (o = !0));
            continue;
          } else
            ((S = {
              lane: 0,
              revertLane: v.revertLane,
              action: v.action,
              hasEagerState: v.hasEagerState,
              eagerState: v.eagerState,
              next: null,
            }),
              f === null ? ((i = f = S), (c = n)) : (f = f.next = S),
              (O.lanes |= r),
              (Kt |= r));
          ((S = v.action),
            ya && a(n, S),
            (n = v.hasEagerState ? v.eagerState : a(n, S)));
        } else
          ((r = {
            lane: S,
            revertLane: v.revertLane,
            action: v.action,
            hasEagerState: v.hasEagerState,
            eagerState: v.eagerState,
            next: null,
          }),
            f === null ? ((i = f = r), (c = n)) : (f = f.next = r),
            (O.lanes |= S),
            (Kt |= S));
        v = v.next;
      } while (v !== null && v !== t);
      if (
        (f === null ? (c = n) : (f.next = i),
        !Ol(n, l.memoizedState) && ((hl = !0), o && ((a = Ca), a !== null)))
      )
        throw a;
      ((l.memoizedState = n),
        (l.baseState = c),
        (l.baseQueue = f),
        (u.lastRenderedState = n));
    }
    return (e === null && (u.lanes = 0), [l.memoizedState, u.dispatch]);
  }
  function Gc(l) {
    var t = el(),
      a = t.queue;
    if (a === null) throw Error(b(311));
    a.lastRenderedReducer = l;
    var u = a.dispatch,
      e = a.pending,
      n = t.memoizedState;
    if (e !== null) {
      a.pending = null;
      var c = (e = e.next);
      do ((n = l(n, c.action)), (c = c.next));
      while (c !== e);
      (Ol(n, t.memoizedState) || (hl = !0),
        (t.memoizedState = n),
        t.baseQueue === null && (t.baseState = n),
        (a.lastRenderedState = n));
    }
    return [n, u];
  }
  function ys(l, t, a) {
    var u = O,
      e = el(),
      n = B;
    if (n) {
      if (a === void 0) throw Error(b(407));
      a = a();
    } else a = t();
    var c = !Ol((Q || e).memoizedState, a);
    (c && ((e.memoizedState = a), (hl = !0)), (e = e.queue));
    var i = gs.bind(null, u, e, l);
    if (
      (Gu(2048, 8, i, [l]),
      e.getSnapshot !== t || c || (ul !== null && ul.memoizedState.tag & 1))
    ) {
      if (
        ((u.flags |= 2048),
        wa(9, Je(), bs.bind(null, u, e, a, t), null),
        L === null)
      )
        throw Error(b(349));
      n || (Yt & 124) !== 0 || os(u, t, a);
    }
    return a;
  }
  function os(l, t, a) {
    ((l.flags |= 16384),
      (l = { getSnapshot: t, value: a }),
      (t = O.updateQueue),
      t === null
        ? ((t = Rc()), (O.updateQueue = t), (t.stores = [l]))
        : ((a = t.stores), a === null ? (t.stores = [l]) : a.push(l)));
  }
  function bs(l, t, a, u) {
    ((t.value = a), (t.getSnapshot = u), xs(t) && Ss(l));
  }
  function gs(l, t, a) {
    return a(function () {
      xs(t) && Ss(l);
    });
  }
  function xs(l) {
    var t = l.getSnapshot;
    l = l.value;
    try {
      var a = t();
      return !Ol(l, a);
    } catch {
      return !0;
    }
  }
  function Ss(l) {
    var t = Ga(l, 2);
    t !== null && Bl(t, l, 2);
  }
  function Xc(l) {
    var t = Al();
    if (typeof l == 'function') {
      var a = l;
      if (((l = a()), ya)) {
        Ot(!0);
        try {
          a();
        } finally {
          Ot(!1);
        }
      }
    }
    return (
      (t.memoizedState = t.baseState = l),
      (t.queue = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: xt,
        lastRenderedState: l,
      }),
      t
    );
  }
  function ps(l, t, a, u) {
    return ((l.baseState = a), Yc(l, Q, typeof u == 'function' ? u : xt));
  }
  function im(l, t, a, u, e) {
    if (We(l)) throw Error(b(485));
    if (((l = t.action), l !== null)) {
      var n = {
        payload: e,
        action: l,
        next: null,
        isTransition: !0,
        status: 'pending',
        value: null,
        reason: null,
        listeners: [],
        then: function (c) {
          n.listeners.push(c);
        },
      };
      (x.T !== null ? a(!0) : (n.isTransition = !1),
        u(n),
        (a = t.pending),
        a === null
          ? ((n.next = t.pending = n), zs(t, n))
          : ((n.next = a.next), (t.pending = a.next = n)));
    }
  }
  function zs(l, t) {
    var a = t.action,
      u = t.payload,
      e = l.state;
    if (t.isTransition) {
      var n = x.T,
        c = {};
      x.T = c;
      try {
        var i = a(e, u),
          f = x.S;
        (f !== null && f(c, i), Ns(l, t, i));
      } catch (v) {
        Qc(l, t, v);
      } finally {
        x.T = n;
      }
    } else
      try {
        ((n = a(e, u)), Ns(l, t, n));
      } catch (v) {
        Qc(l, t, v);
      }
  }
  function Ns(l, t, a) {
    a !== null && typeof a == 'object' && typeof a.then == 'function'
      ? a.then(
          function (u) {
            As(l, t, u);
          },
          function (u) {
            return Qc(l, t, u);
          },
        )
      : As(l, t, a);
  }
  function As(l, t, a) {
    ((t.status = 'fulfilled'),
      (t.value = a),
      Ts(t),
      (l.state = a),
      (t = l.pending),
      t !== null &&
        ((a = t.next),
        a === t ? (l.pending = null) : ((a = a.next), (t.next = a), zs(l, a))));
  }
  function Qc(l, t, a) {
    var u = l.pending;
    if (((l.pending = null), u !== null)) {
      u = u.next;
      do ((t.status = 'rejected'), (t.reason = a), Ts(t), (t = t.next));
      while (t !== u);
    }
    l.action = null;
  }
  function Ts(l) {
    l = l.listeners;
    for (var t = 0; t < l.length; t++) (0, l[t])();
  }
  function Ms(l, t) {
    return t;
  }
  function Es(l, t) {
    if (B) {
      var a = L.formState;
      if (a !== null) {
        l: {
          var u = O;
          if (B) {
            if (I) {
              t: {
                for (var e = I, n = et; e.nodeType !== 8; ) {
                  if (!n) {
                    e = null;
                    break t;
                  }
                  if (((e = lt(e.nextSibling)), e === null)) {
                    e = null;
                    break t;
                  }
                }
                ((n = e.data), (e = n === 'F!' || n === 'F' ? e : null));
              }
              if (e) {
                ((I = lt(e.nextSibling)), (u = e.data === 'F!'));
                break l;
              }
            }
            ha(u);
          }
          u = !1;
        }
        u && (t = a[0]);
      }
    }
    return (
      (a = Al()),
      (a.memoizedState = a.baseState = t),
      (u = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: Ms,
        lastRenderedState: t,
      }),
      (a.queue = u),
      (a = Js.bind(null, O, u)),
      (u.dispatch = a),
      (u = Xc(!1)),
      (n = Lc.bind(null, O, !1, u.queue)),
      (u = Al()),
      (e = { state: t, dispatch: null, action: l, pending: null }),
      (u.queue = e),
      (a = im.bind(null, O, e, n, a)),
      (e.dispatch = a),
      (u.memoizedState = l),
      [t, a, !1]
    );
  }
  function Ds(l) {
    var t = el();
    return js(t, Q, l);
  }
  function js(l, t, a) {
    if (
      ((t = Yc(l, t, Ms)[0]),
      (l = Le(xt)[0]),
      typeof t == 'object' && t !== null && typeof t.then == 'function')
    )
      try {
        var u = Yu(t);
      } catch (c) {
        throw c === Uu ? Xe : c;
      }
    else u = t;
    t = el();
    var e = t.queue,
      n = e.dispatch;
    return (
      a !== t.memoizedState &&
        ((O.flags |= 2048), wa(9, Je(), fm.bind(null, e, a), null)),
      [u, n, l]
    );
  }
  function fm(l, t) {
    l.action = t;
  }
  function Os(l) {
    var t = el(),
      a = Q;
    if (a !== null) return js(t, a, l);
    (el(), (t = t.memoizedState), (a = el()));
    var u = a.queue.dispatch;
    return ((a.memoizedState = l), [t, u, !1]);
  }
  function wa(l, t, a, u) {
    return (
      (l = { tag: l, create: a, deps: u, inst: t, next: null }),
      (t = O.updateQueue),
      t === null && ((t = Rc()), (O.updateQueue = t)),
      (a = t.lastEffect),
      a === null
        ? (t.lastEffect = l.next = l)
        : ((u = a.next), (a.next = l), (l.next = u), (t.lastEffect = l)),
      l
    );
  }
  function Je() {
    return { destroy: void 0, resource: void 0 };
  }
  function Us() {
    return el().memoizedState;
  }
  function we(l, t, a, u) {
    var e = Al();
    ((u = u === void 0 ? null : u),
      (O.flags |= l),
      (e.memoizedState = wa(1 | t, Je(), a, u)));
  }
  function Gu(l, t, a, u) {
    var e = el();
    u = u === void 0 ? null : u;
    var n = e.memoizedState.inst;
    Q !== null && u !== null && Oc(u, Q.memoizedState.deps)
      ? (e.memoizedState = wa(t, n, a, u))
      : ((O.flags |= l), (e.memoizedState = wa(1 | t, n, a, u)));
  }
  function Hs(l, t) {
    we(8390656, 8, l, t);
  }
  function _s(l, t) {
    Gu(2048, 8, l, t);
  }
  function qs(l, t) {
    return Gu(4, 2, l, t);
  }
  function Rs(l, t) {
    return Gu(4, 4, l, t);
  }
  function Bs(l, t) {
    if (typeof t == 'function') {
      l = l();
      var a = t(l);
      return function () {
        typeof a == 'function' ? a() : t(null);
      };
    }
    if (t != null)
      return (
        (l = l()),
        (t.current = l),
        function () {
          t.current = null;
        }
      );
  }
  function Ys(l, t, a) {
    ((a = a != null ? a.concat([l]) : null), Gu(4, 4, Bs.bind(null, t, l), a));
  }
  function Zc() {}
  function Gs(l, t) {
    var a = el();
    t = t === void 0 ? null : t;
    var u = a.memoizedState;
    return t !== null && Oc(t, u[1]) ? u[0] : ((a.memoizedState = [l, t]), l);
  }
  function Xs(l, t) {
    var a = el();
    t = t === void 0 ? null : t;
    var u = a.memoizedState;
    if (t !== null && Oc(t, u[1])) return u[0];
    if (((u = l()), ya)) {
      Ot(!0);
      try {
        l();
      } finally {
        Ot(!1);
      }
    }
    return ((a.memoizedState = [u, t]), u);
  }
  function Vc(l, t, a) {
    return a === void 0 || (Yt & 1073741824) !== 0
      ? (l.memoizedState = t)
      : ((l.memoizedState = a), (l = V0()), (O.lanes |= l), (Kt |= l), a);
  }
  function Qs(l, t, a, u) {
    return Ol(a, t)
      ? a
      : Ka.current !== null
        ? ((l = Vc(l, a, u)), Ol(l, t) || (hl = !0), l)
        : (Yt & 42) === 0
          ? ((hl = !0), (l.memoizedState = a))
          : ((l = V0()), (O.lanes |= l), (Kt |= l), t);
  }
  function Zs(l, t, a, u, e) {
    var n = p.p;
    p.p = n !== 0 && 8 > n ? n : 8;
    var c = x.T,
      i = {};
    ((x.T = i), Lc(l, !1, t, a));
    try {
      var f = e(),
        v = x.S;
      if (
        (v !== null && v(i, f),
        f !== null && typeof f == 'object' && typeof f.then == 'function')
      ) {
        var o = em(f, u);
        Xu(l, t, o, Rl(l));
      } else Xu(l, t, u, Rl(l));
    } catch (S) {
      Xu(l, t, { then: function () {}, status: 'rejected', reason: S }, Rl());
    } finally {
      ((p.p = n), (x.T = c));
    }
  }
  function sm() {}
  function Cc(l, t, a, u) {
    if (l.tag !== 5) throw Error(b(476));
    var e = Vs(l).queue;
    Zs(
      l,
      e,
      t,
      D,
      a === null
        ? sm
        : function () {
            return (Cs(l), a(u));
          },
    );
  }
  function Vs(l) {
    var t = l.memoizedState;
    if (t !== null) return t;
    t = {
      memoizedState: D,
      baseState: D,
      baseQueue: null,
      queue: {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: xt,
        lastRenderedState: D,
      },
      next: null,
    };
    var a = {};
    return (
      (t.next = {
        memoizedState: a,
        baseState: a,
        baseQueue: null,
        queue: {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: xt,
          lastRenderedState: a,
        },
        next: null,
      }),
      (l.memoizedState = t),
      (l = l.alternate),
      l !== null && (l.memoizedState = t),
      t
    );
  }
  function Cs(l) {
    var t = Vs(l).next.queue;
    Xu(l, t, {}, Rl());
  }
  function Kc() {
    return gl(ue);
  }
  function Ks() {
    return el().memoizedState;
  }
  function Ls() {
    return el().memoizedState;
  }
  function dm(l) {
    for (var t = l.return; t !== null; ) {
      switch (t.tag) {
        case 24:
        case 3:
          var a = Rl();
          l = Rt(a);
          var u = Bt(t, l, a);
          (u !== null && (Bl(u, t, a), _u(u, t, a)),
            (t = { cache: Sc() }),
            (l.payload = t));
          return;
      }
      t = t.return;
    }
  }
  function hm(l, t, a) {
    var u = Rl();
    ((a = {
      lane: u,
      revertLane: 0,
      action: a,
      hasEagerState: !1,
      eagerState: null,
      next: null,
    }),
      We(l)
        ? ws(t, a)
        : ((a = dc(l, t, a, u)), a !== null && (Bl(a, l, u), Ws(a, t, u))));
  }
  function Js(l, t, a) {
    var u = Rl();
    Xu(l, t, a, u);
  }
  function Xu(l, t, a, u) {
    var e = {
      lane: u,
      revertLane: 0,
      action: a,
      hasEagerState: !1,
      eagerState: null,
      next: null,
    };
    if (We(l)) ws(t, e);
    else {
      var n = l.alternate;
      if (
        l.lanes === 0 &&
        (n === null || n.lanes === 0) &&
        ((n = t.lastRenderedReducer), n !== null)
      )
        try {
          var c = t.lastRenderedState,
            i = n(c, a);
          if (((e.hasEagerState = !0), (e.eagerState = i), Ol(i, c)))
            return (Ue(l, t, e, 0), L === null && Oe(), !1);
        } catch {
        } finally {
        }
      if (((a = dc(l, t, e, u)), a !== null))
        return (Bl(a, l, u), Ws(a, t, u), !0);
    }
    return !1;
  }
  function Lc(l, t, a, u) {
    if (
      ((u = {
        lane: 2,
        revertLane: Ni(),
        action: u,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      }),
      We(l))
    ) {
      if (t) throw Error(b(479));
    } else ((t = dc(l, a, u, 2)), t !== null && Bl(t, l, 2));
  }
  function We(l) {
    var t = l.alternate;
    return l === O || (t !== null && t === O);
  }
  function ws(l, t) {
    La = Ve = !0;
    var a = l.pending;
    (a === null ? (t.next = t) : ((t.next = a.next), (a.next = t)),
      (l.pending = t));
  }
  function Ws(l, t, a) {
    if ((a & 4194048) !== 0) {
      var u = t.lanes;
      ((u &= l.pendingLanes), (a |= u), (t.lanes = a), tf(l, a));
    }
  }
  var ke = {
      readContext: gl,
      use: Ke,
      useCallback: tl,
      useContext: tl,
      useEffect: tl,
      useImperativeHandle: tl,
      useLayoutEffect: tl,
      useInsertionEffect: tl,
      useMemo: tl,
      useReducer: tl,
      useRef: tl,
      useState: tl,
      useDebugValue: tl,
      useDeferredValue: tl,
      useTransition: tl,
      useSyncExternalStore: tl,
      useId: tl,
      useHostTransitionStatus: tl,
      useFormState: tl,
      useActionState: tl,
      useOptimistic: tl,
      useMemoCache: tl,
      useCacheRefresh: tl,
    },
    ks = {
      readContext: gl,
      use: Ke,
      useCallback: function (l, t) {
        return ((Al().memoizedState = [l, t === void 0 ? null : t]), l);
      },
      useContext: gl,
      useEffect: Hs,
      useImperativeHandle: function (l, t, a) {
        ((a = a != null ? a.concat([l]) : null),
          we(4194308, 4, Bs.bind(null, t, l), a));
      },
      useLayoutEffect: function (l, t) {
        return we(4194308, 4, l, t);
      },
      useInsertionEffect: function (l, t) {
        we(4, 2, l, t);
      },
      useMemo: function (l, t) {
        var a = Al();
        t = t === void 0 ? null : t;
        var u = l();
        if (ya) {
          Ot(!0);
          try {
            l();
          } finally {
            Ot(!1);
          }
        }
        return ((a.memoizedState = [u, t]), u);
      },
      useReducer: function (l, t, a) {
        var u = Al();
        if (a !== void 0) {
          var e = a(t);
          if (ya) {
            Ot(!0);
            try {
              a(t);
            } finally {
              Ot(!1);
            }
          }
        } else e = t;
        return (
          (u.memoizedState = u.baseState = e),
          (l = {
            pending: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: l,
            lastRenderedState: e,
          }),
          (u.queue = l),
          (l = l.dispatch = hm.bind(null, O, l)),
          [u.memoizedState, l]
        );
      },
      useRef: function (l) {
        var t = Al();
        return ((l = { current: l }), (t.memoizedState = l));
      },
      useState: function (l) {
        l = Xc(l);
        var t = l.queue,
          a = Js.bind(null, O, t);
        return ((t.dispatch = a), [l.memoizedState, a]);
      },
      useDebugValue: Zc,
      useDeferredValue: function (l, t) {
        var a = Al();
        return Vc(a, l, t);
      },
      useTransition: function () {
        var l = Xc(!1);
        return (
          (l = Zs.bind(null, O, l.queue, !0, !1)),
          (Al().memoizedState = l),
          [!1, l]
        );
      },
      useSyncExternalStore: function (l, t, a) {
        var u = O,
          e = Al();
        if (B) {
          if (a === void 0) throw Error(b(407));
          a = a();
        } else {
          if (((a = t()), L === null)) throw Error(b(349));
          (q & 124) !== 0 || os(u, t, a);
        }
        e.memoizedState = a;
        var n = { value: a, getSnapshot: t };
        return (
          (e.queue = n),
          Hs(gs.bind(null, u, n, l), [l]),
          (u.flags |= 2048),
          wa(9, Je(), bs.bind(null, u, n, a, t), null),
          a
        );
      },
      useId: function () {
        var l = Al(),
          t = L.identifierPrefix;
        if (B) {
          var a = ot,
            u = yt;
          ((a = (u & ~(1 << (32 - jl(u) - 1))).toString(32) + a),
            (t = '«' + t + 'R' + a),
            (a = Ce++),
            0 < a && (t += 'H' + a.toString(32)),
            (t += '»'));
        } else ((a = nm++), (t = '«' + t + 'r' + a.toString(32) + '»'));
        return (l.memoizedState = t);
      },
      useHostTransitionStatus: Kc,
      useFormState: Es,
      useActionState: Es,
      useOptimistic: function (l) {
        var t = Al();
        t.memoizedState = t.baseState = l;
        var a = {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: null,
          lastRenderedState: null,
        };
        return (
          (t.queue = a),
          (t = Lc.bind(null, O, !0, a)),
          (a.dispatch = t),
          [l, t]
        );
      },
      useMemoCache: Bc,
      useCacheRefresh: function () {
        return (Al().memoizedState = dm.bind(null, O));
      },
    },
    $s = {
      readContext: gl,
      use: Ke,
      useCallback: Gs,
      useContext: gl,
      useEffect: _s,
      useImperativeHandle: Ys,
      useInsertionEffect: qs,
      useLayoutEffect: Rs,
      useMemo: Xs,
      useReducer: Le,
      useRef: Us,
      useState: function () {
        return Le(xt);
      },
      useDebugValue: Zc,
      useDeferredValue: function (l, t) {
        var a = el();
        return Qs(a, Q.memoizedState, l, t);
      },
      useTransition: function () {
        var l = Le(xt)[0],
          t = el().memoizedState;
        return [typeof l == 'boolean' ? l : Yu(l), t];
      },
      useSyncExternalStore: ys,
      useId: Ks,
      useHostTransitionStatus: Kc,
      useFormState: Ds,
      useActionState: Ds,
      useOptimistic: function (l, t) {
        var a = el();
        return ps(a, Q, l, t);
      },
      useMemoCache: Bc,
      useCacheRefresh: Ls,
    },
    mm = {
      readContext: gl,
      use: Ke,
      useCallback: Gs,
      useContext: gl,
      useEffect: _s,
      useImperativeHandle: Ys,
      useInsertionEffect: qs,
      useLayoutEffect: Rs,
      useMemo: Xs,
      useReducer: Gc,
      useRef: Us,
      useState: function () {
        return Gc(xt);
      },
      useDebugValue: Zc,
      useDeferredValue: function (l, t) {
        var a = el();
        return Q === null ? Vc(a, l, t) : Qs(a, Q.memoizedState, l, t);
      },
      useTransition: function () {
        var l = Gc(xt)[0],
          t = el().memoizedState;
        return [typeof l == 'boolean' ? l : Yu(l), t];
      },
      useSyncExternalStore: ys,
      useId: Ks,
      useHostTransitionStatus: Kc,
      useFormState: Os,
      useActionState: Os,
      useOptimistic: function (l, t) {
        var a = el();
        return Q !== null
          ? ps(a, Q, l, t)
          : ((a.baseState = l), [l, a.queue.dispatch]);
      },
      useMemoCache: Bc,
      useCacheRefresh: Ls,
    },
    Wa = null,
    Qu = 0;
  function $e(l) {
    var t = Qu;
    return ((Qu += 1), Wa === null && (Wa = []), is(Wa, l, t));
  }
  function Zu(l, t) {
    ((t = t.props.ref), (l.ref = t !== void 0 ? t : null));
  }
  function Fe(l, t) {
    throw t.$$typeof === pl
      ? Error(b(525))
      : ((l = Object.prototype.toString.call(t)),
        Error(
          b(
            31,
            l === '[object Object]'
              ? 'object with keys {' + Object.keys(t).join(', ') + '}'
              : l,
          ),
        ));
  }
  function Fs(l) {
    var t = l._init;
    return t(l._payload);
  }
  function Is(l) {
    function t(d, s) {
      if (l) {
        var m = d.deletions;
        m === null ? ((d.deletions = [s]), (d.flags |= 16)) : m.push(s);
      }
    }
    function a(d, s) {
      if (!l) return null;
      for (; s !== null; ) (t(d, s), (s = s.sibling));
      return null;
    }
    function u(d) {
      for (var s = new Map(); d !== null; )
        (d.key !== null ? s.set(d.key, d) : s.set(d.index, d), (d = d.sibling));
      return s;
    }
    function e(d, s) {
      return ((d = rt(d, s)), (d.index = 0), (d.sibling = null), d);
    }
    function n(d, s, m) {
      return (
        (d.index = m),
        l
          ? ((m = d.alternate),
            m !== null
              ? ((m = m.index), m < s ? ((d.flags |= 67108866), s) : m)
              : ((d.flags |= 67108866), s))
          : ((d.flags |= 1048576), s)
      );
    }
    function c(d) {
      return (l && d.alternate === null && (d.flags |= 67108866), d);
    }
    function i(d, s, m, g) {
      return s === null || s.tag !== 6
        ? ((s = mc(m, d.mode, g)), (s.return = d), s)
        : ((s = e(s, m)), (s.return = d), s);
    }
    function f(d, s, m, g) {
      var z = m.type;
      return z === Yl
        ? o(d, s, m.props.children, g, m.key)
        : s !== null &&
            (s.elementType === z ||
              (typeof z == 'object' &&
                z !== null &&
                z.$$typeof === Fl &&
                Fs(z) === s.type))
          ? ((s = e(s, m.props)), Zu(s, m), (s.return = d), s)
          : ((s = _e(m.type, m.key, m.props, null, d.mode, g)),
            Zu(s, m),
            (s.return = d),
            s);
    }
    function v(d, s, m, g) {
      return s === null ||
        s.tag !== 4 ||
        s.stateNode.containerInfo !== m.containerInfo ||
        s.stateNode.implementation !== m.implementation
        ? ((s = vc(m, d.mode, g)), (s.return = d), s)
        : ((s = e(s, m.children || [])), (s.return = d), s);
    }
    function o(d, s, m, g, z) {
      return s === null || s.tag !== 7
        ? ((s = ia(m, d.mode, g, z)), (s.return = d), s)
        : ((s = e(s, m)), (s.return = d), s);
    }
    function S(d, s, m) {
      if (
        (typeof s == 'string' && s !== '') ||
        typeof s == 'number' ||
        typeof s == 'bigint'
      )
        return ((s = mc('' + s, d.mode, m)), (s.return = d), s);
      if (typeof s == 'object' && s !== null) {
        switch (s.$$typeof) {
          case ll:
            return (
              (m = _e(s.type, s.key, s.props, null, d.mode, m)),
              Zu(m, s),
              (m.return = d),
              m
            );
          case st:
            return ((s = vc(s, d.mode, m)), (s.return = d), s);
          case Fl:
            var g = s._init;
            return ((s = g(s._payload)), S(d, s, m));
        }
        if (ht(s) || Xl(s))
          return ((s = ia(s, d.mode, m, null)), (s.return = d), s);
        if (typeof s.then == 'function') return S(d, $e(s), m);
        if (s.$$typeof === Gl) return S(d, Ye(d, s), m);
        Fe(d, s);
      }
      return null;
    }
    function r(d, s, m, g) {
      var z = s !== null ? s.key : null;
      if (
        (typeof m == 'string' && m !== '') ||
        typeof m == 'number' ||
        typeof m == 'bigint'
      )
        return z !== null ? null : i(d, s, '' + m, g);
      if (typeof m == 'object' && m !== null) {
        switch (m.$$typeof) {
          case ll:
            return m.key === z ? f(d, s, m, g) : null;
          case st:
            return m.key === z ? v(d, s, m, g) : null;
          case Fl:
            return ((z = m._init), (m = z(m._payload)), r(d, s, m, g));
        }
        if (ht(m) || Xl(m)) return z !== null ? null : o(d, s, m, g, null);
        if (typeof m.then == 'function') return r(d, s, $e(m), g);
        if (m.$$typeof === Gl) return r(d, s, Ye(d, m), g);
        Fe(d, m);
      }
      return null;
    }
    function y(d, s, m, g, z) {
      if (
        (typeof g == 'string' && g !== '') ||
        typeof g == 'number' ||
        typeof g == 'bigint'
      )
        return ((d = d.get(m) || null), i(s, d, '' + g, z));
      if (typeof g == 'object' && g !== null) {
        switch (g.$$typeof) {
          case ll:
            return (
              (d = d.get(g.key === null ? m : g.key) || null),
              f(s, d, g, z)
            );
          case st:
            return (
              (d = d.get(g.key === null ? m : g.key) || null),
              v(s, d, g, z)
            );
          case Fl:
            var U = g._init;
            return ((g = U(g._payload)), y(d, s, m, g, z));
        }
        if (ht(g) || Xl(g))
          return ((d = d.get(m) || null), o(s, d, g, z, null));
        if (typeof g.then == 'function') return y(d, s, m, $e(g), z);
        if (g.$$typeof === Gl) return y(d, s, m, Ye(s, g), z);
        Fe(s, g);
      }
      return null;
    }
    function E(d, s, m, g) {
      for (
        var z = null, U = null, N = s, M = (s = 0), vl = null;
        N !== null && M < m.length;
        M++
      ) {
        N.index > M ? ((vl = N), (N = null)) : (vl = N.sibling);
        var R = r(d, N, m[M], g);
        if (R === null) {
          N === null && (N = vl);
          break;
        }
        (l && N && R.alternate === null && t(d, N),
          (s = n(R, s, M)),
          U === null ? (z = R) : (U.sibling = R),
          (U = R),
          (N = vl));
      }
      if (M === m.length) return (a(d, N), B && sa(d, M), z);
      if (N === null) {
        for (; M < m.length; M++)
          ((N = S(d, m[M], g)),
            N !== null &&
              ((s = n(N, s, M)),
              U === null ? (z = N) : (U.sibling = N),
              (U = N)));
        return (B && sa(d, M), z);
      }
      for (N = u(N); M < m.length; M++)
        ((vl = y(N, d, M, m[M], g)),
          vl !== null &&
            (l &&
              vl.alternate !== null &&
              N.delete(vl.key === null ? M : vl.key),
            (s = n(vl, s, M)),
            U === null ? (z = vl) : (U.sibling = vl),
            (U = vl)));
      return (
        l &&
          N.forEach(function (Pt) {
            return t(d, Pt);
          }),
        B && sa(d, M),
        z
      );
    }
    function T(d, s, m, g) {
      if (m == null) throw Error(b(151));
      for (
        var z = null, U = null, N = s, M = (s = 0), vl = null, R = m.next();
        N !== null && !R.done;
        M++, R = m.next()
      ) {
        N.index > M ? ((vl = N), (N = null)) : (vl = N.sibling);
        var Pt = r(d, N, R.value, g);
        if (Pt === null) {
          N === null && (N = vl);
          break;
        }
        (l && N && Pt.alternate === null && t(d, N),
          (s = n(Pt, s, M)),
          U === null ? (z = Pt) : (U.sibling = Pt),
          (U = Pt),
          (N = vl));
      }
      if (R.done) return (a(d, N), B && sa(d, M), z);
      if (N === null) {
        for (; !R.done; M++, R = m.next())
          ((R = S(d, R.value, g)),
            R !== null &&
              ((s = n(R, s, M)),
              U === null ? (z = R) : (U.sibling = R),
              (U = R)));
        return (B && sa(d, M), z);
      }
      for (N = u(N); !R.done; M++, R = m.next())
        ((R = y(N, d, M, R.value, g)),
          R !== null &&
            (l && R.alternate !== null && N.delete(R.key === null ? M : R.key),
            (s = n(R, s, M)),
            U === null ? (z = R) : (U.sibling = R),
            (U = R)));
      return (
        l &&
          N.forEach(function (vv) {
            return t(d, vv);
          }),
        B && sa(d, M),
        z
      );
    }
    function V(d, s, m, g) {
      if (
        (typeof m == 'object' &&
          m !== null &&
          m.type === Yl &&
          m.key === null &&
          (m = m.props.children),
        typeof m == 'object' && m !== null)
      ) {
        switch (m.$$typeof) {
          case ll:
            l: {
              for (var z = m.key; s !== null; ) {
                if (s.key === z) {
                  if (((z = m.type), z === Yl)) {
                    if (s.tag === 7) {
                      (a(d, s.sibling),
                        (g = e(s, m.props.children)),
                        (g.return = d),
                        (d = g));
                      break l;
                    }
                  } else if (
                    s.elementType === z ||
                    (typeof z == 'object' &&
                      z !== null &&
                      z.$$typeof === Fl &&
                      Fs(z) === s.type)
                  ) {
                    (a(d, s.sibling),
                      (g = e(s, m.props)),
                      Zu(g, m),
                      (g.return = d),
                      (d = g));
                    break l;
                  }
                  a(d, s);
                  break;
                } else t(d, s);
                s = s.sibling;
              }
              m.type === Yl
                ? ((g = ia(m.props.children, d.mode, g, m.key)),
                  (g.return = d),
                  (d = g))
                : ((g = _e(m.type, m.key, m.props, null, d.mode, g)),
                  Zu(g, m),
                  (g.return = d),
                  (d = g));
            }
            return c(d);
          case st:
            l: {
              for (z = m.key; s !== null; ) {
                if (s.key === z)
                  if (
                    s.tag === 4 &&
                    s.stateNode.containerInfo === m.containerInfo &&
                    s.stateNode.implementation === m.implementation
                  ) {
                    (a(d, s.sibling),
                      (g = e(s, m.children || [])),
                      (g.return = d),
                      (d = g));
                    break l;
                  } else {
                    a(d, s);
                    break;
                  }
                else t(d, s);
                s = s.sibling;
              }
              ((g = vc(m, d.mode, g)), (g.return = d), (d = g));
            }
            return c(d);
          case Fl:
            return ((z = m._init), (m = z(m._payload)), V(d, s, m, g));
        }
        if (ht(m)) return E(d, s, m, g);
        if (Xl(m)) {
          if (((z = Xl(m)), typeof z != 'function')) throw Error(b(150));
          return ((m = z.call(m)), T(d, s, m, g));
        }
        if (typeof m.then == 'function') return V(d, s, $e(m), g);
        if (m.$$typeof === Gl) return V(d, s, Ye(d, m), g);
        Fe(d, m);
      }
      return (typeof m == 'string' && m !== '') ||
        typeof m == 'number' ||
        typeof m == 'bigint'
        ? ((m = '' + m),
          s !== null && s.tag === 6
            ? (a(d, s.sibling), (g = e(s, m)), (g.return = d), (d = g))
            : (a(d, s), (g = mc(m, d.mode, g)), (g.return = d), (d = g)),
          c(d))
        : a(d, s);
    }
    return function (d, s, m, g) {
      try {
        Qu = 0;
        var z = V(d, s, m, g);
        return ((Wa = null), z);
      } catch (N) {
        if (N === Uu || N === Xe) throw N;
        var U = Ul(29, N, null, d.mode);
        return ((U.lanes = g), (U.return = d), U);
      } finally {
      }
    };
  }
  var ka = Is(!0),
    Ps = Is(!1),
    Jl = xl(null),
    nt = null;
  function Gt(l) {
    var t = l.alternate;
    (X(cl, cl.current & 1),
      X(Jl, l),
      nt === null &&
        (t === null || Ka.current !== null || t.memoizedState !== null) &&
        (nt = l));
  }
  function l0(l) {
    if (l.tag === 22) {
      if ((X(cl, cl.current), X(Jl, l), nt === null)) {
        var t = l.alternate;
        t !== null && t.memoizedState !== null && (nt = l);
      }
    } else Xt();
  }
  function Xt() {
    (X(cl, cl.current), X(Jl, Jl.current));
  }
  function St(l) {
    ($(Jl), nt === l && (nt = null), $(cl));
  }
  var cl = xl(0);
  function Ie(l) {
    for (var t = l; t !== null; ) {
      if (t.tag === 13) {
        var a = t.memoizedState;
        if (
          a !== null &&
          ((a = a.dehydrated), a === null || a.data === '$?' || Ri(a))
        )
          return t;
      } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
        if ((t.flags & 128) !== 0) return t;
      } else if (t.child !== null) {
        ((t.child.return = t), (t = t.child));
        continue;
      }
      if (t === l) break;
      for (; t.sibling === null; ) {
        if (t.return === null || t.return === l) return null;
        t = t.return;
      }
      ((t.sibling.return = t.return), (t = t.sibling));
    }
    return null;
  }
  function Jc(l, t, a, u) {
    ((t = l.memoizedState),
      (a = a(u, t)),
      (a = a == null ? t : C({}, t, a)),
      (l.memoizedState = a),
      l.lanes === 0 && (l.updateQueue.baseState = a));
  }
  var wc = {
    enqueueSetState: function (l, t, a) {
      l = l._reactInternals;
      var u = Rl(),
        e = Rt(u);
      ((e.payload = t),
        a != null && (e.callback = a),
        (t = Bt(l, e, u)),
        t !== null && (Bl(t, l, u), _u(t, l, u)));
    },
    enqueueReplaceState: function (l, t, a) {
      l = l._reactInternals;
      var u = Rl(),
        e = Rt(u);
      ((e.tag = 1),
        (e.payload = t),
        a != null && (e.callback = a),
        (t = Bt(l, e, u)),
        t !== null && (Bl(t, l, u), _u(t, l, u)));
    },
    enqueueForceUpdate: function (l, t) {
      l = l._reactInternals;
      var a = Rl(),
        u = Rt(a);
      ((u.tag = 2),
        t != null && (u.callback = t),
        (t = Bt(l, u, a)),
        t !== null && (Bl(t, l, a), _u(t, l, a)));
    },
  };
  function t0(l, t, a, u, e, n, c) {
    return (
      (l = l.stateNode),
      typeof l.shouldComponentUpdate == 'function'
        ? l.shouldComponentUpdate(u, n, c)
        : t.prototype && t.prototype.isPureReactComponent
          ? !Nu(a, u) || !Nu(e, n)
          : !0
    );
  }
  function a0(l, t, a, u) {
    ((l = t.state),
      typeof t.componentWillReceiveProps == 'function' &&
        t.componentWillReceiveProps(a, u),
      typeof t.UNSAFE_componentWillReceiveProps == 'function' &&
        t.UNSAFE_componentWillReceiveProps(a, u),
      t.state !== l && wc.enqueueReplaceState(t, t.state, null));
  }
  function oa(l, t) {
    var a = t;
    if ('ref' in t) {
      a = {};
      for (var u in t) u !== 'ref' && (a[u] = t[u]);
    }
    if ((l = l.defaultProps)) {
      a === t && (a = C({}, a));
      for (var e in l) a[e] === void 0 && (a[e] = l[e]);
    }
    return a;
  }
  var Pe =
    typeof reportError == 'function'
      ? reportError
      : function (l) {
          if (
            typeof window == 'object' &&
            typeof window.ErrorEvent == 'function'
          ) {
            var t = new window.ErrorEvent('error', {
              bubbles: !0,
              cancelable: !0,
              message:
                typeof l == 'object' &&
                l !== null &&
                typeof l.message == 'string'
                  ? String(l.message)
                  : String(l),
              error: l,
            });
            if (!window.dispatchEvent(t)) return;
          } else if (
            typeof process == 'object' &&
            typeof process.emit == 'function'
          ) {
            process.emit('uncaughtException', l);
            return;
          }
          console.error(l);
        };
  function u0(l) {
    Pe(l);
  }
  function e0(l) {
    console.error(l);
  }
  function n0(l) {
    Pe(l);
  }
  function ln(l, t) {
    try {
      var a = l.onUncaughtError;
      a(t.value, { componentStack: t.stack });
    } catch (u) {
      setTimeout(function () {
        throw u;
      });
    }
  }
  function c0(l, t, a) {
    try {
      var u = l.onCaughtError;
      u(a.value, {
        componentStack: a.stack,
        errorBoundary: t.tag === 1 ? t.stateNode : null,
      });
    } catch (e) {
      setTimeout(function () {
        throw e;
      });
    }
  }
  function Wc(l, t, a) {
    return (
      (a = Rt(a)),
      (a.tag = 3),
      (a.payload = { element: null }),
      (a.callback = function () {
        ln(l, t);
      }),
      a
    );
  }
  function i0(l) {
    return ((l = Rt(l)), (l.tag = 3), l);
  }
  function f0(l, t, a, u) {
    var e = a.type.getDerivedStateFromError;
    if (typeof e == 'function') {
      var n = u.value;
      ((l.payload = function () {
        return e(n);
      }),
        (l.callback = function () {
          c0(t, a, u);
        }));
    }
    var c = a.stateNode;
    c !== null &&
      typeof c.componentDidCatch == 'function' &&
      (l.callback = function () {
        (c0(t, a, u),
          typeof e != 'function' &&
            (Lt === null ? (Lt = new Set([this])) : Lt.add(this)));
        var i = u.stack;
        this.componentDidCatch(u.value, {
          componentStack: i !== null ? i : '',
        });
      });
  }
  function vm(l, t, a, u, e) {
    if (
      ((a.flags |= 32768),
      u !== null && typeof u == 'object' && typeof u.then == 'function')
    ) {
      if (
        ((t = a.alternate),
        t !== null && Du(t, a, e, !0),
        (a = Jl.current),
        a !== null)
      ) {
        switch (a.tag) {
          case 13:
            return (
              nt === null ? gi() : a.alternate === null && P === 0 && (P = 3),
              (a.flags &= -257),
              (a.flags |= 65536),
              (a.lanes = e),
              u === Nc
                ? (a.flags |= 16384)
                : ((t = a.updateQueue),
                  t === null ? (a.updateQueue = new Set([u])) : t.add(u),
                  Si(l, u, e)),
              !1
            );
          case 22:
            return (
              (a.flags |= 65536),
              u === Nc
                ? (a.flags |= 16384)
                : ((t = a.updateQueue),
                  t === null
                    ? ((t = {
                        transitions: null,
                        markerInstances: null,
                        retryQueue: new Set([u]),
                      }),
                      (a.updateQueue = t))
                    : ((a = t.retryQueue),
                      a === null ? (t.retryQueue = new Set([u])) : a.add(u)),
                  Si(l, u, e)),
              !1
            );
        }
        throw Error(b(435, a.tag));
      }
      return (Si(l, u, e), gi(), !1);
    }
    if (B)
      return (
        (t = Jl.current),
        t !== null
          ? ((t.flags & 65536) === 0 && (t.flags |= 256),
            (t.flags |= 65536),
            (t.lanes = e),
            u !== oc && ((l = Error(b(422), { cause: u })), Eu(Vl(l, a))))
          : (u !== oc && ((t = Error(b(423), { cause: u })), Eu(Vl(t, a))),
            (l = l.current.alternate),
            (l.flags |= 65536),
            (e &= -e),
            (l.lanes |= e),
            (u = Vl(u, a)),
            (e = Wc(l.stateNode, u, e)),
            Mc(l, e),
            P !== 4 && (P = 2)),
        !1
      );
    var n = Error(b(520), { cause: u });
    if (
      ((n = Vl(n, a)),
      Wu === null ? (Wu = [n]) : Wu.push(n),
      P !== 4 && (P = 2),
      t === null)
    )
      return !0;
    ((u = Vl(u, a)), (a = t));
    do {
      switch (a.tag) {
        case 3:
          return (
            (a.flags |= 65536),
            (l = e & -e),
            (a.lanes |= l),
            (l = Wc(a.stateNode, u, l)),
            Mc(a, l),
            !1
          );
        case 1:
          if (
            ((t = a.type),
            (n = a.stateNode),
            (a.flags & 128) === 0 &&
              (typeof t.getDerivedStateFromError == 'function' ||
                (n !== null &&
                  typeof n.componentDidCatch == 'function' &&
                  (Lt === null || !Lt.has(n)))))
          )
            return (
              (a.flags |= 65536),
              (e &= -e),
              (a.lanes |= e),
              (e = i0(e)),
              f0(e, l, a, u),
              Mc(a, e),
              !1
            );
      }
      a = a.return;
    } while (a !== null);
    return !1;
  }
  var s0 = Error(b(461)),
    hl = !1;
  function rl(l, t, a, u) {
    t.child = l === null ? Ps(t, null, a, u) : ka(t, l.child, a, u);
  }
  function d0(l, t, a, u, e) {
    a = a.render;
    var n = t.ref;
    if ('ref' in u) {
      var c = {};
      for (var i in u) i !== 'ref' && (c[i] = u[i]);
    } else c = u;
    return (
      va(t),
      (u = Uc(l, t, a, c, n, e)),
      (i = Hc()),
      l !== null && !hl
        ? (_c(l, t, e), pt(l, t, e))
        : (B && i && rc(t), (t.flags |= 1), rl(l, t, u, e), t.child)
    );
  }
  function h0(l, t, a, u, e) {
    if (l === null) {
      var n = a.type;
      return typeof n == 'function' &&
        !hc(n) &&
        n.defaultProps === void 0 &&
        a.compare === null
        ? ((t.tag = 15), (t.type = n), m0(l, t, n, u, e))
        : ((l = _e(a.type, null, u, t, t.mode, e)),
          (l.ref = t.ref),
          (l.return = t),
          (t.child = l));
    }
    if (((n = l.child), !ai(l, e))) {
      var c = n.memoizedProps;
      if (
        ((a = a.compare), (a = a !== null ? a : Nu), a(c, u) && l.ref === t.ref)
      )
        return pt(l, t, e);
    }
    return (
      (t.flags |= 1),
      (l = rt(n, u)),
      (l.ref = t.ref),
      (l.return = t),
      (t.child = l)
    );
  }
  function m0(l, t, a, u, e) {
    if (l !== null) {
      var n = l.memoizedProps;
      if (Nu(n, u) && l.ref === t.ref)
        if (((hl = !1), (t.pendingProps = u = n), ai(l, e)))
          (l.flags & 131072) !== 0 && (hl = !0);
        else return ((t.lanes = l.lanes), pt(l, t, e));
    }
    return kc(l, t, a, u, e);
  }
  function v0(l, t, a) {
    var u = t.pendingProps,
      e = u.children,
      n = l !== null ? l.memoizedState : null;
    if (u.mode === 'hidden') {
      if ((t.flags & 128) !== 0) {
        if (((u = n !== null ? n.baseLanes | a : a), l !== null)) {
          for (e = t.child = l.child, n = 0; e !== null; )
            ((n = n | e.lanes | e.childLanes), (e = e.sibling));
          t.childLanes = n & ~u;
        } else ((t.childLanes = 0), (t.child = null));
        return r0(l, t, u, a);
      }
      if ((a & 536870912) !== 0)
        ((t.memoizedState = { baseLanes: 0, cachePool: null }),
          l !== null && Ge(t, n !== null ? n.cachePool : null),
          n !== null ? ms(t, n) : Dc(),
          l0(t));
      else
        return (
          (t.lanes = t.childLanes = 536870912),
          r0(l, t, n !== null ? n.baseLanes | a : a, a)
        );
    } else
      n !== null
        ? (Ge(t, n.cachePool), ms(t, n), Xt(), (t.memoizedState = null))
        : (l !== null && Ge(t, null), Dc(), Xt());
    return (rl(l, t, e, a), t.child);
  }
  function r0(l, t, a, u) {
    var e = zc();
    return (
      (e = e === null ? null : { parent: nl._currentValue, pool: e }),
      (t.memoizedState = { baseLanes: a, cachePool: e }),
      l !== null && Ge(t, null),
      Dc(),
      l0(t),
      l !== null && Du(l, t, u, !0),
      null
    );
  }
  function tn(l, t) {
    var a = t.ref;
    if (a === null) l !== null && l.ref !== null && (t.flags |= 4194816);
    else {
      if (typeof a != 'function' && typeof a != 'object') throw Error(b(284));
      (l === null || l.ref !== a) && (t.flags |= 4194816);
    }
  }
  function kc(l, t, a, u, e) {
    return (
      va(t),
      (a = Uc(l, t, a, u, void 0, e)),
      (u = Hc()),
      l !== null && !hl
        ? (_c(l, t, e), pt(l, t, e))
        : (B && u && rc(t), (t.flags |= 1), rl(l, t, a, e), t.child)
    );
  }
  function y0(l, t, a, u, e, n) {
    return (
      va(t),
      (t.updateQueue = null),
      (a = rs(t, u, a, e)),
      vs(l),
      (u = Hc()),
      l !== null && !hl
        ? (_c(l, t, n), pt(l, t, n))
        : (B && u && rc(t), (t.flags |= 1), rl(l, t, a, n), t.child)
    );
  }
  function o0(l, t, a, u, e) {
    if ((va(t), t.stateNode === null)) {
      var n = Xa,
        c = a.contextType;
      (typeof c == 'object' && c !== null && (n = gl(c)),
        (n = new a(u, n)),
        (t.memoizedState =
          n.state !== null && n.state !== void 0 ? n.state : null),
        (n.updater = wc),
        (t.stateNode = n),
        (n._reactInternals = t),
        (n = t.stateNode),
        (n.props = u),
        (n.state = t.memoizedState),
        (n.refs = {}),
        Ac(t),
        (c = a.contextType),
        (n.context = typeof c == 'object' && c !== null ? gl(c) : Xa),
        (n.state = t.memoizedState),
        (c = a.getDerivedStateFromProps),
        typeof c == 'function' && (Jc(t, a, c, u), (n.state = t.memoizedState)),
        typeof a.getDerivedStateFromProps == 'function' ||
          typeof n.getSnapshotBeforeUpdate == 'function' ||
          (typeof n.UNSAFE_componentWillMount != 'function' &&
            typeof n.componentWillMount != 'function') ||
          ((c = n.state),
          typeof n.componentWillMount == 'function' && n.componentWillMount(),
          typeof n.UNSAFE_componentWillMount == 'function' &&
            n.UNSAFE_componentWillMount(),
          c !== n.state && wc.enqueueReplaceState(n, n.state, null),
          Ru(t, u, n, e),
          qu(),
          (n.state = t.memoizedState)),
        typeof n.componentDidMount == 'function' && (t.flags |= 4194308),
        (u = !0));
    } else if (l === null) {
      n = t.stateNode;
      var i = t.memoizedProps,
        f = oa(a, i);
      n.props = f;
      var v = n.context,
        o = a.contextType;
      ((c = Xa), typeof o == 'object' && o !== null && (c = gl(o)));
      var S = a.getDerivedStateFromProps;
      ((o =
        typeof S == 'function' ||
        typeof n.getSnapshotBeforeUpdate == 'function'),
        (i = t.pendingProps !== i),
        o ||
          (typeof n.UNSAFE_componentWillReceiveProps != 'function' &&
            typeof n.componentWillReceiveProps != 'function') ||
          ((i || v !== c) && a0(t, n, u, c)),
        (qt = !1));
      var r = t.memoizedState;
      ((n.state = r),
        Ru(t, u, n, e),
        qu(),
        (v = t.memoizedState),
        i || r !== v || qt
          ? (typeof S == 'function' && (Jc(t, a, S, u), (v = t.memoizedState)),
            (f = qt || t0(t, a, f, u, r, v, c))
              ? (o ||
                  (typeof n.UNSAFE_componentWillMount != 'function' &&
                    typeof n.componentWillMount != 'function') ||
                  (typeof n.componentWillMount == 'function' &&
                    n.componentWillMount(),
                  typeof n.UNSAFE_componentWillMount == 'function' &&
                    n.UNSAFE_componentWillMount()),
                typeof n.componentDidMount == 'function' &&
                  (t.flags |= 4194308))
              : (typeof n.componentDidMount == 'function' &&
                  (t.flags |= 4194308),
                (t.memoizedProps = u),
                (t.memoizedState = v)),
            (n.props = u),
            (n.state = v),
            (n.context = c),
            (u = f))
          : (typeof n.componentDidMount == 'function' && (t.flags |= 4194308),
            (u = !1)));
    } else {
      ((n = t.stateNode),
        Tc(l, t),
        (c = t.memoizedProps),
        (o = oa(a, c)),
        (n.props = o),
        (S = t.pendingProps),
        (r = n.context),
        (v = a.contextType),
        (f = Xa),
        typeof v == 'object' && v !== null && (f = gl(v)),
        (i = a.getDerivedStateFromProps),
        (v =
          typeof i == 'function' ||
          typeof n.getSnapshotBeforeUpdate == 'function') ||
          (typeof n.UNSAFE_componentWillReceiveProps != 'function' &&
            typeof n.componentWillReceiveProps != 'function') ||
          ((c !== S || r !== f) && a0(t, n, u, f)),
        (qt = !1),
        (r = t.memoizedState),
        (n.state = r),
        Ru(t, u, n, e),
        qu());
      var y = t.memoizedState;
      c !== S ||
      r !== y ||
      qt ||
      (l !== null && l.dependencies !== null && Be(l.dependencies))
        ? (typeof i == 'function' && (Jc(t, a, i, u), (y = t.memoizedState)),
          (o =
            qt ||
            t0(t, a, o, u, r, y, f) ||
            (l !== null && l.dependencies !== null && Be(l.dependencies)))
            ? (v ||
                (typeof n.UNSAFE_componentWillUpdate != 'function' &&
                  typeof n.componentWillUpdate != 'function') ||
                (typeof n.componentWillUpdate == 'function' &&
                  n.componentWillUpdate(u, y, f),
                typeof n.UNSAFE_componentWillUpdate == 'function' &&
                  n.UNSAFE_componentWillUpdate(u, y, f)),
              typeof n.componentDidUpdate == 'function' && (t.flags |= 4),
              typeof n.getSnapshotBeforeUpdate == 'function' &&
                (t.flags |= 1024))
            : (typeof n.componentDidUpdate != 'function' ||
                (c === l.memoizedProps && r === l.memoizedState) ||
                (t.flags |= 4),
              typeof n.getSnapshotBeforeUpdate != 'function' ||
                (c === l.memoizedProps && r === l.memoizedState) ||
                (t.flags |= 1024),
              (t.memoizedProps = u),
              (t.memoizedState = y)),
          (n.props = u),
          (n.state = y),
          (n.context = f),
          (u = o))
        : (typeof n.componentDidUpdate != 'function' ||
            (c === l.memoizedProps && r === l.memoizedState) ||
            (t.flags |= 4),
          typeof n.getSnapshotBeforeUpdate != 'function' ||
            (c === l.memoizedProps && r === l.memoizedState) ||
            (t.flags |= 1024),
          (u = !1));
    }
    return (
      (n = u),
      tn(l, t),
      (u = (t.flags & 128) !== 0),
      n || u
        ? ((n = t.stateNode),
          (a =
            u && typeof a.getDerivedStateFromError != 'function'
              ? null
              : n.render()),
          (t.flags |= 1),
          l !== null && u
            ? ((t.child = ka(t, l.child, null, e)),
              (t.child = ka(t, null, a, e)))
            : rl(l, t, a, e),
          (t.memoizedState = n.state),
          (l = t.child))
        : (l = pt(l, t, e)),
      l
    );
  }
  function b0(l, t, a, u) {
    return (Mu(), (t.flags |= 256), rl(l, t, a, u), t.child);
  }
  var $c = {
    dehydrated: null,
    treeContext: null,
    retryLane: 0,
    hydrationErrors: null,
  };
  function Fc(l) {
    return { baseLanes: l, cachePool: es() };
  }
  function Ic(l, t, a) {
    return ((l = l !== null ? l.childLanes & ~a : 0), t && (l |= wl), l);
  }
  function g0(l, t, a) {
    var u = t.pendingProps,
      e = !1,
      n = (t.flags & 128) !== 0,
      c;
    if (
      ((c = n) ||
        (c =
          l !== null && l.memoizedState === null ? !1 : (cl.current & 2) !== 0),
      c && ((e = !0), (t.flags &= -129)),
      (c = (t.flags & 32) !== 0),
      (t.flags &= -33),
      l === null)
    ) {
      if (B) {
        if ((e ? Gt(t) : Xt(), B)) {
          var i = I,
            f;
          if ((f = i)) {
            l: {
              for (f = i, i = et; f.nodeType !== 8; ) {
                if (!i) {
                  i = null;
                  break l;
                }
                if (((f = lt(f.nextSibling)), f === null)) {
                  i = null;
                  break l;
                }
              }
              i = f;
            }
            i !== null
              ? ((t.memoizedState = {
                  dehydrated: i,
                  treeContext: fa !== null ? { id: yt, overflow: ot } : null,
                  retryLane: 536870912,
                  hydrationErrors: null,
                }),
                (f = Ul(18, null, null, 0)),
                (f.stateNode = i),
                (f.return = t),
                (t.child = f),
                (Sl = t),
                (I = null),
                (f = !0))
              : (f = !1);
          }
          f || ha(t);
        }
        if (
          ((i = t.memoizedState),
          i !== null && ((i = i.dehydrated), i !== null))
        )
          return (Ri(i) ? (t.lanes = 32) : (t.lanes = 536870912), null);
        St(t);
      }
      return (
        (i = u.children),
        (u = u.fallback),
        e
          ? (Xt(),
            (e = t.mode),
            (i = an({ mode: 'hidden', children: i }, e)),
            (u = ia(u, e, a, null)),
            (i.return = t),
            (u.return = t),
            (i.sibling = u),
            (t.child = i),
            (e = t.child),
            (e.memoizedState = Fc(a)),
            (e.childLanes = Ic(l, c, a)),
            (t.memoizedState = $c),
            u)
          : (Gt(t), Pc(t, i))
      );
    }
    if (
      ((f = l.memoizedState), f !== null && ((i = f.dehydrated), i !== null))
    ) {
      if (n)
        t.flags & 256
          ? (Gt(t), (t.flags &= -257), (t = li(l, t, a)))
          : t.memoizedState !== null
            ? (Xt(), (t.child = l.child), (t.flags |= 128), (t = null))
            : (Xt(),
              (e = u.fallback),
              (i = t.mode),
              (u = an({ mode: 'visible', children: u.children }, i)),
              (e = ia(e, i, a, null)),
              (e.flags |= 2),
              (u.return = t),
              (e.return = t),
              (u.sibling = e),
              (t.child = u),
              ka(t, l.child, null, a),
              (u = t.child),
              (u.memoizedState = Fc(a)),
              (u.childLanes = Ic(l, c, a)),
              (t.memoizedState = $c),
              (t = e));
      else if ((Gt(t), Ri(i))) {
        if (((c = i.nextSibling && i.nextSibling.dataset), c)) var v = c.dgst;
        ((c = v),
          (u = Error(b(419))),
          (u.stack = ''),
          (u.digest = c),
          Eu({ value: u, source: null, stack: null }),
          (t = li(l, t, a)));
      } else if (
        (hl || Du(l, t, a, !1), (c = (a & l.childLanes) !== 0), hl || c)
      ) {
        if (
          ((c = L),
          c !== null &&
            ((u = a & -a),
            (u = (u & 42) !== 0 ? 1 : Bn(u)),
            (u = (u & (c.suspendedLanes | a)) !== 0 ? 0 : u),
            u !== 0 && u !== f.retryLane))
        )
          throw ((f.retryLane = u), Ga(l, u), Bl(c, l, u), s0);
        (i.data === '$?' || gi(), (t = li(l, t, a)));
      } else
        i.data === '$?'
          ? ((t.flags |= 192), (t.child = l.child), (t = null))
          : ((l = f.treeContext),
            (I = lt(i.nextSibling)),
            (Sl = t),
            (B = !0),
            (da = null),
            (et = !1),
            l !== null &&
              ((Kl[Ll++] = yt),
              (Kl[Ll++] = ot),
              (Kl[Ll++] = fa),
              (yt = l.id),
              (ot = l.overflow),
              (fa = t)),
            (t = Pc(t, u.children)),
            (t.flags |= 4096));
      return t;
    }
    return e
      ? (Xt(),
        (e = u.fallback),
        (i = t.mode),
        (f = l.child),
        (v = f.sibling),
        (u = rt(f, { mode: 'hidden', children: u.children })),
        (u.subtreeFlags = f.subtreeFlags & 65011712),
        v !== null ? (e = rt(v, e)) : ((e = ia(e, i, a, null)), (e.flags |= 2)),
        (e.return = t),
        (u.return = t),
        (u.sibling = e),
        (t.child = u),
        (u = e),
        (e = t.child),
        (i = l.child.memoizedState),
        i === null
          ? (i = Fc(a))
          : ((f = i.cachePool),
            f !== null
              ? ((v = nl._currentValue),
                (f = f.parent !== v ? { parent: v, pool: v } : f))
              : (f = es()),
            (i = { baseLanes: i.baseLanes | a, cachePool: f })),
        (e.memoizedState = i),
        (e.childLanes = Ic(l, c, a)),
        (t.memoizedState = $c),
        u)
      : (Gt(t),
        (a = l.child),
        (l = a.sibling),
        (a = rt(a, { mode: 'visible', children: u.children })),
        (a.return = t),
        (a.sibling = null),
        l !== null &&
          ((c = t.deletions),
          c === null ? ((t.deletions = [l]), (t.flags |= 16)) : c.push(l)),
        (t.child = a),
        (t.memoizedState = null),
        a);
  }
  function Pc(l, t) {
    return (
      (t = an({ mode: 'visible', children: t }, l.mode)),
      (t.return = l),
      (l.child = t)
    );
  }
  function an(l, t) {
    return (
      (l = Ul(22, l, null, t)),
      (l.lanes = 0),
      (l.stateNode = {
        _visibility: 1,
        _pendingMarkers: null,
        _retryCache: null,
        _transitions: null,
      }),
      l
    );
  }
  function li(l, t, a) {
    return (
      ka(t, l.child, null, a),
      (l = Pc(t, t.pendingProps.children)),
      (l.flags |= 2),
      (t.memoizedState = null),
      l
    );
  }
  function x0(l, t, a) {
    l.lanes |= t;
    var u = l.alternate;
    (u !== null && (u.lanes |= t), gc(l.return, t, a));
  }
  function ti(l, t, a, u, e) {
    var n = l.memoizedState;
    n === null
      ? (l.memoizedState = {
          isBackwards: t,
          rendering: null,
          renderingStartTime: 0,
          last: u,
          tail: a,
          tailMode: e,
        })
      : ((n.isBackwards = t),
        (n.rendering = null),
        (n.renderingStartTime = 0),
        (n.last = u),
        (n.tail = a),
        (n.tailMode = e));
  }
  function S0(l, t, a) {
    var u = t.pendingProps,
      e = u.revealOrder,
      n = u.tail;
    if ((rl(l, t, u.children, a), (u = cl.current), (u & 2) !== 0))
      ((u = (u & 1) | 2), (t.flags |= 128));
    else {
      if (l !== null && (l.flags & 128) !== 0)
        l: for (l = t.child; l !== null; ) {
          if (l.tag === 13) l.memoizedState !== null && x0(l, a, t);
          else if (l.tag === 19) x0(l, a, t);
          else if (l.child !== null) {
            ((l.child.return = l), (l = l.child));
            continue;
          }
          if (l === t) break l;
          for (; l.sibling === null; ) {
            if (l.return === null || l.return === t) break l;
            l = l.return;
          }
          ((l.sibling.return = l.return), (l = l.sibling));
        }
      u &= 1;
    }
    switch ((X(cl, u), e)) {
      case 'forwards':
        for (a = t.child, e = null; a !== null; )
          ((l = a.alternate),
            l !== null && Ie(l) === null && (e = a),
            (a = a.sibling));
        ((a = e),
          a === null
            ? ((e = t.child), (t.child = null))
            : ((e = a.sibling), (a.sibling = null)),
          ti(t, !1, e, a, n));
        break;
      case 'backwards':
        for (a = null, e = t.child, t.child = null; e !== null; ) {
          if (((l = e.alternate), l !== null && Ie(l) === null)) {
            t.child = e;
            break;
          }
          ((l = e.sibling), (e.sibling = a), (a = e), (e = l));
        }
        ti(t, !0, a, null, n);
        break;
      case 'together':
        ti(t, !1, null, null, void 0);
        break;
      default:
        t.memoizedState = null;
    }
    return t.child;
  }
  function pt(l, t, a) {
    if (
      (l !== null && (t.dependencies = l.dependencies),
      (Kt |= t.lanes),
      (a & t.childLanes) === 0)
    )
      if (l !== null) {
        if ((Du(l, t, a, !1), (a & t.childLanes) === 0)) return null;
      } else return null;
    if (l !== null && t.child !== l.child) throw Error(b(153));
    if (t.child !== null) {
      for (
        l = t.child, a = rt(l, l.pendingProps), t.child = a, a.return = t;
        l.sibling !== null;

      )
        ((l = l.sibling),
          (a = a.sibling = rt(l, l.pendingProps)),
          (a.return = t));
      a.sibling = null;
    }
    return t.child;
  }
  function ai(l, t) {
    return (l.lanes & t) !== 0
      ? !0
      : ((l = l.dependencies), !!(l !== null && Be(l)));
  }
  function rm(l, t, a) {
    switch (t.tag) {
      case 3:
        (ve(t, t.stateNode.containerInfo),
          _t(t, nl, l.memoizedState.cache),
          Mu());
        break;
      case 27:
      case 5:
        Un(t);
        break;
      case 4:
        ve(t, t.stateNode.containerInfo);
        break;
      case 10:
        _t(t, t.type, t.memoizedProps.value);
        break;
      case 13:
        var u = t.memoizedState;
        if (u !== null)
          return u.dehydrated !== null
            ? (Gt(t), (t.flags |= 128), null)
            : (a & t.child.childLanes) !== 0
              ? g0(l, t, a)
              : (Gt(t), (l = pt(l, t, a)), l !== null ? l.sibling : null);
        Gt(t);
        break;
      case 19:
        var e = (l.flags & 128) !== 0;
        if (
          ((u = (a & t.childLanes) !== 0),
          u || (Du(l, t, a, !1), (u = (a & t.childLanes) !== 0)),
          e)
        ) {
          if (u) return S0(l, t, a);
          t.flags |= 128;
        }
        if (
          ((e = t.memoizedState),
          e !== null &&
            ((e.rendering = null), (e.tail = null), (e.lastEffect = null)),
          X(cl, cl.current),
          u)
        )
          break;
        return null;
      case 22:
      case 23:
        return ((t.lanes = 0), v0(l, t, a));
      case 24:
        _t(t, nl, l.memoizedState.cache);
    }
    return pt(l, t, a);
  }
  function p0(l, t, a) {
    if (l !== null)
      if (l.memoizedProps !== t.pendingProps) hl = !0;
      else {
        if (!ai(l, a) && (t.flags & 128) === 0) return ((hl = !1), rm(l, t, a));
        hl = (l.flags & 131072) !== 0;
      }
    else ((hl = !1), B && (t.flags & 1048576) !== 0 && Ff(t, Re, t.index));
    switch (((t.lanes = 0), t.tag)) {
      case 16:
        l: {
          l = t.pendingProps;
          var u = t.elementType,
            e = u._init;
          if (((u = e(u._payload)), (t.type = u), typeof u == 'function'))
            hc(u)
              ? ((l = oa(u, l)), (t.tag = 1), (t = o0(null, t, u, l, a)))
              : ((t.tag = 0), (t = kc(null, t, u, l, a)));
          else {
            if (u != null) {
              if (((e = u.$$typeof), e === Dt)) {
                ((t.tag = 11), (t = d0(null, t, u, l, a)));
                break l;
              } else if (e === dt) {
                ((t.tag = 14), (t = h0(null, t, u, l, a)));
                break l;
              }
            }
            throw ((t = du(u) || u), Error(b(306, t, '')));
          }
        }
        return t;
      case 0:
        return kc(l, t, t.type, t.pendingProps, a);
      case 1:
        return ((u = t.type), (e = oa(u, t.pendingProps)), o0(l, t, u, e, a));
      case 3:
        l: {
          if ((ve(t, t.stateNode.containerInfo), l === null))
            throw Error(b(387));
          u = t.pendingProps;
          var n = t.memoizedState;
          ((e = n.element), Tc(l, t), Ru(t, u, null, a));
          var c = t.memoizedState;
          if (
            ((u = c.cache),
            _t(t, nl, u),
            u !== n.cache && xc(t, [nl], a, !0),
            qu(),
            (u = c.element),
            n.isDehydrated)
          )
            if (
              ((n = { element: u, isDehydrated: !1, cache: c.cache }),
              (t.updateQueue.baseState = n),
              (t.memoizedState = n),
              t.flags & 256)
            ) {
              t = b0(l, t, u, a);
              break l;
            } else if (u !== e) {
              ((e = Vl(Error(b(424)), t)), Eu(e), (t = b0(l, t, u, a)));
              break l;
            } else {
              switch (((l = t.stateNode.containerInfo), l.nodeType)) {
                case 9:
                  l = l.body;
                  break;
                default:
                  l = l.nodeName === 'HTML' ? l.ownerDocument.body : l;
              }
              for (
                I = lt(l.firstChild),
                  Sl = t,
                  B = !0,
                  da = null,
                  et = !0,
                  a = Ps(t, null, u, a),
                  t.child = a;
                a;

              )
                ((a.flags = (a.flags & -3) | 4096), (a = a.sibling));
            }
          else {
            if ((Mu(), u === e)) {
              t = pt(l, t, a);
              break l;
            }
            rl(l, t, u, a);
          }
          t = t.child;
        }
        return t;
      case 26:
        return (
          tn(l, t),
          l === null
            ? (a = Td(t.type, null, t.pendingProps, null))
              ? (t.memoizedState = a)
              : B ||
                ((a = t.type),
                (l = t.pendingProps),
                (u = bn(jt.current).createElement(a)),
                (u[bl] = t),
                (u[zl] = l),
                ol(u, a, l),
                dl(u),
                (t.stateNode = u))
            : (t.memoizedState = Td(
                t.type,
                l.memoizedProps,
                t.pendingProps,
                l.memoizedState,
              )),
          null
        );
      case 27:
        return (
          Un(t),
          l === null &&
            B &&
            ((u = t.stateNode = zd(t.type, t.pendingProps, jt.current)),
            (Sl = t),
            (et = !0),
            (e = I),
            Wt(t.type) ? ((Bi = e), (I = lt(u.firstChild))) : (I = e)),
          rl(l, t, t.pendingProps.children, a),
          tn(l, t),
          l === null && (t.flags |= 4194304),
          t.child
        );
      case 5:
        return (
          l === null &&
            B &&
            ((e = u = I) &&
              ((u = Vm(u, t.type, t.pendingProps, et)),
              u !== null
                ? ((t.stateNode = u),
                  (Sl = t),
                  (I = lt(u.firstChild)),
                  (et = !1),
                  (e = !0))
                : (e = !1)),
            e || ha(t)),
          Un(t),
          (e = t.type),
          (n = t.pendingProps),
          (c = l !== null ? l.memoizedProps : null),
          (u = n.children),
          Hi(e, n) ? (u = null) : c !== null && Hi(e, c) && (t.flags |= 32),
          t.memoizedState !== null &&
            ((e = Uc(l, t, cm, null, null, a)), (ue._currentValue = e)),
          tn(l, t),
          rl(l, t, u, a),
          t.child
        );
      case 6:
        return (
          l === null &&
            B &&
            ((l = a = I) &&
              ((a = Cm(a, t.pendingProps, et)),
              a !== null
                ? ((t.stateNode = a), (Sl = t), (I = null), (l = !0))
                : (l = !1)),
            l || ha(t)),
          null
        );
      case 13:
        return g0(l, t, a);
      case 4:
        return (
          ve(t, t.stateNode.containerInfo),
          (u = t.pendingProps),
          l === null ? (t.child = ka(t, null, u, a)) : rl(l, t, u, a),
          t.child
        );
      case 11:
        return d0(l, t, t.type, t.pendingProps, a);
      case 7:
        return (rl(l, t, t.pendingProps, a), t.child);
      case 8:
        return (rl(l, t, t.pendingProps.children, a), t.child);
      case 12:
        return (rl(l, t, t.pendingProps.children, a), t.child);
      case 10:
        return (
          (u = t.pendingProps),
          _t(t, t.type, u.value),
          rl(l, t, u.children, a),
          t.child
        );
      case 9:
        return (
          (e = t.type._context),
          (u = t.pendingProps.children),
          va(t),
          (e = gl(e)),
          (u = u(e)),
          (t.flags |= 1),
          rl(l, t, u, a),
          t.child
        );
      case 14:
        return h0(l, t, t.type, t.pendingProps, a);
      case 15:
        return m0(l, t, t.type, t.pendingProps, a);
      case 19:
        return S0(l, t, a);
      case 31:
        return (
          (u = t.pendingProps),
          (a = t.mode),
          (u = { mode: u.mode, children: u.children }),
          l === null
            ? ((a = an(u, a)),
              (a.ref = t.ref),
              (t.child = a),
              (a.return = t),
              (t = a))
            : ((a = rt(l.child, u)),
              (a.ref = t.ref),
              (t.child = a),
              (a.return = t),
              (t = a)),
          t
        );
      case 22:
        return v0(l, t, a);
      case 24:
        return (
          va(t),
          (u = gl(nl)),
          l === null
            ? ((e = zc()),
              e === null &&
                ((e = L),
                (n = Sc()),
                (e.pooledCache = n),
                n.refCount++,
                n !== null && (e.pooledCacheLanes |= a),
                (e = n)),
              (t.memoizedState = { parent: u, cache: e }),
              Ac(t),
              _t(t, nl, e))
            : ((l.lanes & a) !== 0 && (Tc(l, t), Ru(t, null, null, a), qu()),
              (e = l.memoizedState),
              (n = t.memoizedState),
              e.parent !== u
                ? ((e = { parent: u, cache: u }),
                  (t.memoizedState = e),
                  t.lanes === 0 &&
                    (t.memoizedState = t.updateQueue.baseState = e),
                  _t(t, nl, u))
                : ((u = n.cache),
                  _t(t, nl, u),
                  u !== e.cache && xc(t, [nl], a, !0))),
          rl(l, t, t.pendingProps.children, a),
          t.child
        );
      case 29:
        throw t.pendingProps;
    }
    throw Error(b(156, t.tag));
  }
  function zt(l) {
    l.flags |= 4;
  }
  function z0(l, t) {
    if (t.type !== 'stylesheet' || (t.state.loading & 4) !== 0)
      l.flags &= -16777217;
    else if (((l.flags |= 16777216), !Od(t))) {
      if (
        ((t = Jl.current),
        t !== null &&
          ((q & 4194048) === q
            ? nt !== null
            : ((q & 62914560) !== q && (q & 536870912) === 0) || t !== nt))
      )
        throw ((Hu = Nc), ns);
      l.flags |= 8192;
    }
  }
  function un(l, t) {
    (t !== null && (l.flags |= 4),
      l.flags & 16384 &&
        ((t = l.tag !== 22 ? Pi() : 536870912), (l.lanes |= t), (Pa |= t)));
  }
  function Vu(l, t) {
    if (!B)
      switch (l.tailMode) {
        case 'hidden':
          t = l.tail;
          for (var a = null; t !== null; )
            (t.alternate !== null && (a = t), (t = t.sibling));
          a === null ? (l.tail = null) : (a.sibling = null);
          break;
        case 'collapsed':
          a = l.tail;
          for (var u = null; a !== null; )
            (a.alternate !== null && (u = a), (a = a.sibling));
          u === null
            ? t || l.tail === null
              ? (l.tail = null)
              : (l.tail.sibling = null)
            : (u.sibling = null);
      }
  }
  function F(l) {
    var t = l.alternate !== null && l.alternate.child === l.child,
      a = 0,
      u = 0;
    if (t)
      for (var e = l.child; e !== null; )
        ((a |= e.lanes | e.childLanes),
          (u |= e.subtreeFlags & 65011712),
          (u |= e.flags & 65011712),
          (e.return = l),
          (e = e.sibling));
    else
      for (e = l.child; e !== null; )
        ((a |= e.lanes | e.childLanes),
          (u |= e.subtreeFlags),
          (u |= e.flags),
          (e.return = l),
          (e = e.sibling));
    return ((l.subtreeFlags |= u), (l.childLanes = a), t);
  }
  function ym(l, t, a) {
    var u = t.pendingProps;
    switch ((yc(t), t.tag)) {
      case 31:
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return (F(t), null);
      case 1:
        return (F(t), null);
      case 3:
        return (
          (a = t.stateNode),
          (u = null),
          l !== null && (u = l.memoizedState.cache),
          t.memoizedState.cache !== u && (t.flags |= 2048),
          gt(nl),
          Na(),
          a.pendingContext &&
            ((a.context = a.pendingContext), (a.pendingContext = null)),
          (l === null || l.child === null) &&
            (Tu(t)
              ? zt(t)
              : l === null ||
                (l.memoizedState.isDehydrated && (t.flags & 256) === 0) ||
                ((t.flags |= 1024), ls())),
          F(t),
          null
        );
      case 26:
        return (
          (a = t.memoizedState),
          l === null
            ? (zt(t),
              a !== null ? (F(t), z0(t, a)) : (F(t), (t.flags &= -16777217)))
            : a
              ? a !== l.memoizedState
                ? (zt(t), F(t), z0(t, a))
                : (F(t), (t.flags &= -16777217))
              : (l.memoizedProps !== u && zt(t), F(t), (t.flags &= -16777217)),
          null
        );
      case 27:
        (re(t), (a = jt.current));
        var e = t.type;
        if (l !== null && t.stateNode != null) l.memoizedProps !== u && zt(t);
        else {
          if (!u) {
            if (t.stateNode === null) throw Error(b(166));
            return (F(t), null);
          }
          ((l = sl.current),
            Tu(t) ? If(t) : ((l = zd(e, u, a)), (t.stateNode = l), zt(t)));
        }
        return (F(t), null);
      case 5:
        if ((re(t), (a = t.type), l !== null && t.stateNode != null))
          l.memoizedProps !== u && zt(t);
        else {
          if (!u) {
            if (t.stateNode === null) throw Error(b(166));
            return (F(t), null);
          }
          if (((l = sl.current), Tu(t))) If(t);
          else {
            switch (((e = bn(jt.current)), l)) {
              case 1:
                l = e.createElementNS('http://www.w3.org/2000/svg', a);
                break;
              case 2:
                l = e.createElementNS('http://www.w3.org/1998/Math/MathML', a);
                break;
              default:
                switch (a) {
                  case 'svg':
                    l = e.createElementNS('http://www.w3.org/2000/svg', a);
                    break;
                  case 'math':
                    l = e.createElementNS(
                      'http://www.w3.org/1998/Math/MathML',
                      a,
                    );
                    break;
                  case 'script':
                    ((l = e.createElement('div')),
                      (l.innerHTML = '<script><\/script>'),
                      (l = l.removeChild(l.firstChild)));
                    break;
                  case 'select':
                    ((l =
                      typeof u.is == 'string'
                        ? e.createElement('select', { is: u.is })
                        : e.createElement('select')),
                      u.multiple
                        ? (l.multiple = !0)
                        : u.size && (l.size = u.size));
                    break;
                  default:
                    l =
                      typeof u.is == 'string'
                        ? e.createElement(a, { is: u.is })
                        : e.createElement(a);
                }
            }
            ((l[bl] = t), (l[zl] = u));
            l: for (e = t.child; e !== null; ) {
              if (e.tag === 5 || e.tag === 6) l.appendChild(e.stateNode);
              else if (e.tag !== 4 && e.tag !== 27 && e.child !== null) {
                ((e.child.return = e), (e = e.child));
                continue;
              }
              if (e === t) break l;
              for (; e.sibling === null; ) {
                if (e.return === null || e.return === t) break l;
                e = e.return;
              }
              ((e.sibling.return = e.return), (e = e.sibling));
            }
            t.stateNode = l;
            l: switch ((ol(l, a, u), a)) {
              case 'button':
              case 'input':
              case 'select':
              case 'textarea':
                l = !!u.autoFocus;
                break l;
              case 'img':
                l = !0;
                break l;
              default:
                l = !1;
            }
            l && zt(t);
          }
        }
        return (F(t), (t.flags &= -16777217), null);
      case 6:
        if (l && t.stateNode != null) l.memoizedProps !== u && zt(t);
        else {
          if (typeof u != 'string' && t.stateNode === null) throw Error(b(166));
          if (((l = jt.current), Tu(t))) {
            if (
              ((l = t.stateNode),
              (a = t.memoizedProps),
              (u = null),
              (e = Sl),
              e !== null)
            )
              switch (e.tag) {
                case 27:
                case 5:
                  u = e.memoizedProps;
              }
            ((l[bl] = t),
              (l = !!(
                l.nodeValue === a ||
                (u !== null && u.suppressHydrationWarning === !0) ||
                yd(l.nodeValue, a)
              )),
              l || ha(t));
          } else
            ((l = bn(l).createTextNode(u)), (l[bl] = t), (t.stateNode = l));
        }
        return (F(t), null);
      case 13:
        if (
          ((u = t.memoizedState),
          l === null ||
            (l.memoizedState !== null && l.memoizedState.dehydrated !== null))
        ) {
          if (((e = Tu(t)), u !== null && u.dehydrated !== null)) {
            if (l === null) {
              if (!e) throw Error(b(318));
              if (
                ((e = t.memoizedState),
                (e = e !== null ? e.dehydrated : null),
                !e)
              )
                throw Error(b(317));
              e[bl] = t;
            } else
              (Mu(),
                (t.flags & 128) === 0 && (t.memoizedState = null),
                (t.flags |= 4));
            (F(t), (e = !1));
          } else
            ((e = ls()),
              l !== null &&
                l.memoizedState !== null &&
                (l.memoizedState.hydrationErrors = e),
              (e = !0));
          if (!e) return t.flags & 256 ? (St(t), t) : (St(t), null);
        }
        if ((St(t), (t.flags & 128) !== 0)) return ((t.lanes = a), t);
        if (
          ((a = u !== null), (l = l !== null && l.memoizedState !== null), a)
        ) {
          ((u = t.child),
            (e = null),
            u.alternate !== null &&
              u.alternate.memoizedState !== null &&
              u.alternate.memoizedState.cachePool !== null &&
              (e = u.alternate.memoizedState.cachePool.pool));
          var n = null;
          (u.memoizedState !== null &&
            u.memoizedState.cachePool !== null &&
            (n = u.memoizedState.cachePool.pool),
            n !== e && (u.flags |= 2048));
        }
        return (
          a !== l && a && (t.child.flags |= 8192),
          un(t, t.updateQueue),
          F(t),
          null
        );
      case 4:
        return (Na(), l === null && Ei(t.stateNode.containerInfo), F(t), null);
      case 10:
        return (gt(t.type), F(t), null);
      case 19:
        if (($(cl), (e = t.memoizedState), e === null)) return (F(t), null);
        if (((u = (t.flags & 128) !== 0), (n = e.rendering), n === null))
          if (u) Vu(e, !1);
          else {
            if (P !== 0 || (l !== null && (l.flags & 128) !== 0))
              for (l = t.child; l !== null; ) {
                if (((n = Ie(l)), n !== null)) {
                  for (
                    t.flags |= 128,
                      Vu(e, !1),
                      l = n.updateQueue,
                      t.updateQueue = l,
                      un(t, l),
                      t.subtreeFlags = 0,
                      l = a,
                      a = t.child;
                    a !== null;

                  )
                    ($f(a, l), (a = a.sibling));
                  return (X(cl, (cl.current & 1) | 2), t.child);
                }
                l = l.sibling;
              }
            e.tail !== null &&
              ut() > cn &&
              ((t.flags |= 128), (u = !0), Vu(e, !1), (t.lanes = 4194304));
          }
        else {
          if (!u)
            if (((l = Ie(n)), l !== null)) {
              if (
                ((t.flags |= 128),
                (u = !0),
                (l = l.updateQueue),
                (t.updateQueue = l),
                un(t, l),
                Vu(e, !0),
                e.tail === null &&
                  e.tailMode === 'hidden' &&
                  !n.alternate &&
                  !B)
              )
                return (F(t), null);
            } else
              2 * ut() - e.renderingStartTime > cn &&
                a !== 536870912 &&
                ((t.flags |= 128), (u = !0), Vu(e, !1), (t.lanes = 4194304));
          e.isBackwards
            ? ((n.sibling = t.child), (t.child = n))
            : ((l = e.last),
              l !== null ? (l.sibling = n) : (t.child = n),
              (e.last = n));
        }
        return e.tail !== null
          ? ((t = e.tail),
            (e.rendering = t),
            (e.tail = t.sibling),
            (e.renderingStartTime = ut()),
            (t.sibling = null),
            (l = cl.current),
            X(cl, u ? (l & 1) | 2 : l & 1),
            t)
          : (F(t), null);
      case 22:
      case 23:
        return (
          St(t),
          jc(),
          (u = t.memoizedState !== null),
          l !== null
            ? (l.memoizedState !== null) !== u && (t.flags |= 8192)
            : u && (t.flags |= 8192),
          u
            ? (a & 536870912) !== 0 &&
              (t.flags & 128) === 0 &&
              (F(t), t.subtreeFlags & 6 && (t.flags |= 8192))
            : F(t),
          (a = t.updateQueue),
          a !== null && un(t, a.retryQueue),
          (a = null),
          l !== null &&
            l.memoizedState !== null &&
            l.memoizedState.cachePool !== null &&
            (a = l.memoizedState.cachePool.pool),
          (u = null),
          t.memoizedState !== null &&
            t.memoizedState.cachePool !== null &&
            (u = t.memoizedState.cachePool.pool),
          u !== a && (t.flags |= 2048),
          l !== null && $(ra),
          null
        );
      case 24:
        return (
          (a = null),
          l !== null && (a = l.memoizedState.cache),
          t.memoizedState.cache !== a && (t.flags |= 2048),
          gt(nl),
          F(t),
          null
        );
      case 25:
        return null;
      case 30:
        return null;
    }
    throw Error(b(156, t.tag));
  }
  function om(l, t) {
    switch ((yc(t), t.tag)) {
      case 1:
        return (
          (l = t.flags),
          l & 65536 ? ((t.flags = (l & -65537) | 128), t) : null
        );
      case 3:
        return (
          gt(nl),
          Na(),
          (l = t.flags),
          (l & 65536) !== 0 && (l & 128) === 0
            ? ((t.flags = (l & -65537) | 128), t)
            : null
        );
      case 26:
      case 27:
      case 5:
        return (re(t), null);
      case 13:
        if (
          (St(t), (l = t.memoizedState), l !== null && l.dehydrated !== null)
        ) {
          if (t.alternate === null) throw Error(b(340));
          Mu();
        }
        return (
          (l = t.flags),
          l & 65536 ? ((t.flags = (l & -65537) | 128), t) : null
        );
      case 19:
        return ($(cl), null);
      case 4:
        return (Na(), null);
      case 10:
        return (gt(t.type), null);
      case 22:
      case 23:
        return (
          St(t),
          jc(),
          l !== null && $(ra),
          (l = t.flags),
          l & 65536 ? ((t.flags = (l & -65537) | 128), t) : null
        );
      case 24:
        return (gt(nl), null);
      case 25:
        return null;
      default:
        return null;
    }
  }
  function N0(l, t) {
    switch ((yc(t), t.tag)) {
      case 3:
        (gt(nl), Na());
        break;
      case 26:
      case 27:
      case 5:
        re(t);
        break;
      case 4:
        Na();
        break;
      case 13:
        St(t);
        break;
      case 19:
        $(cl);
        break;
      case 10:
        gt(t.type);
        break;
      case 22:
      case 23:
        (St(t), jc(), l !== null && $(ra));
        break;
      case 24:
        gt(nl);
    }
  }
  function Cu(l, t) {
    try {
      var a = t.updateQueue,
        u = a !== null ? a.lastEffect : null;
      if (u !== null) {
        var e = u.next;
        a = e;
        do {
          if ((a.tag & l) === l) {
            u = void 0;
            var n = a.create,
              c = a.inst;
            ((u = n()), (c.destroy = u));
          }
          a = a.next;
        } while (a !== e);
      }
    } catch (i) {
      K(t, t.return, i);
    }
  }
  function Qt(l, t, a) {
    try {
      var u = t.updateQueue,
        e = u !== null ? u.lastEffect : null;
      if (e !== null) {
        var n = e.next;
        u = n;
        do {
          if ((u.tag & l) === l) {
            var c = u.inst,
              i = c.destroy;
            if (i !== void 0) {
              ((c.destroy = void 0), (e = t));
              var f = a,
                v = i;
              try {
                v();
              } catch (o) {
                K(e, f, o);
              }
            }
          }
          u = u.next;
        } while (u !== n);
      }
    } catch (o) {
      K(t, t.return, o);
    }
  }
  function A0(l) {
    var t = l.updateQueue;
    if (t !== null) {
      var a = l.stateNode;
      try {
        hs(t, a);
      } catch (u) {
        K(l, l.return, u);
      }
    }
  }
  function T0(l, t, a) {
    ((a.props = oa(l.type, l.memoizedProps)), (a.state = l.memoizedState));
    try {
      a.componentWillUnmount();
    } catch (u) {
      K(l, t, u);
    }
  }
  function Ku(l, t) {
    try {
      var a = l.ref;
      if (a !== null) {
        switch (l.tag) {
          case 26:
          case 27:
          case 5:
            var u = l.stateNode;
            break;
          case 30:
            u = l.stateNode;
            break;
          default:
            u = l.stateNode;
        }
        typeof a == 'function' ? (l.refCleanup = a(u)) : (a.current = u);
      }
    } catch (e) {
      K(l, t, e);
    }
  }
  function ct(l, t) {
    var a = l.ref,
      u = l.refCleanup;
    if (a !== null)
      if (typeof u == 'function')
        try {
          u();
        } catch (e) {
          K(l, t, e);
        } finally {
          ((l.refCleanup = null),
            (l = l.alternate),
            l != null && (l.refCleanup = null));
        }
      else if (typeof a == 'function')
        try {
          a(null);
        } catch (e) {
          K(l, t, e);
        }
      else a.current = null;
  }
  function M0(l) {
    var t = l.type,
      a = l.memoizedProps,
      u = l.stateNode;
    try {
      l: switch (t) {
        case 'button':
        case 'input':
        case 'select':
        case 'textarea':
          a.autoFocus && u.focus();
          break l;
        case 'img':
          a.src ? (u.src = a.src) : a.srcSet && (u.srcset = a.srcSet);
      }
    } catch (e) {
      K(l, l.return, e);
    }
  }
  function ui(l, t, a) {
    try {
      var u = l.stateNode;
      (Ym(u, l.type, a, t), (u[zl] = t));
    } catch (e) {
      K(l, l.return, e);
    }
  }
  function E0(l) {
    return (
      l.tag === 5 ||
      l.tag === 3 ||
      l.tag === 26 ||
      (l.tag === 27 && Wt(l.type)) ||
      l.tag === 4
    );
  }
  function ei(l) {
    l: for (;;) {
      for (; l.sibling === null; ) {
        if (l.return === null || E0(l.return)) return null;
        l = l.return;
      }
      for (
        l.sibling.return = l.return, l = l.sibling;
        l.tag !== 5 && l.tag !== 6 && l.tag !== 18;

      ) {
        if (
          (l.tag === 27 && Wt(l.type)) ||
          l.flags & 2 ||
          l.child === null ||
          l.tag === 4
        )
          continue l;
        ((l.child.return = l), (l = l.child));
      }
      if (!(l.flags & 2)) return l.stateNode;
    }
  }
  function ni(l, t, a) {
    var u = l.tag;
    if (u === 5 || u === 6)
      ((l = l.stateNode),
        t
          ? (a.nodeType === 9
              ? a.body
              : a.nodeName === 'HTML'
                ? a.ownerDocument.body
                : a
            ).insertBefore(l, t)
          : ((t =
              a.nodeType === 9
                ? a.body
                : a.nodeName === 'HTML'
                  ? a.ownerDocument.body
                  : a),
            t.appendChild(l),
            (a = a._reactRootContainer),
            a != null || t.onclick !== null || (t.onclick = on)));
    else if (
      u !== 4 &&
      (u === 27 && Wt(l.type) && ((a = l.stateNode), (t = null)),
      (l = l.child),
      l !== null)
    )
      for (ni(l, t, a), l = l.sibling; l !== null; )
        (ni(l, t, a), (l = l.sibling));
  }
  function en(l, t, a) {
    var u = l.tag;
    if (u === 5 || u === 6)
      ((l = l.stateNode), t ? a.insertBefore(l, t) : a.appendChild(l));
    else if (
      u !== 4 &&
      (u === 27 && Wt(l.type) && (a = l.stateNode), (l = l.child), l !== null)
    )
      for (en(l, t, a), l = l.sibling; l !== null; )
        (en(l, t, a), (l = l.sibling));
  }
  function D0(l) {
    var t = l.stateNode,
      a = l.memoizedProps;
    try {
      for (var u = l.type, e = t.attributes; e.length; )
        t.removeAttributeNode(e[0]);
      (ol(t, u, a), (t[bl] = l), (t[zl] = a));
    } catch (n) {
      K(l, l.return, n);
    }
  }
  var Nt = !1,
    al = !1,
    ci = !1,
    j0 = typeof WeakSet == 'function' ? WeakSet : Set,
    ml = null;
  function bm(l, t) {
    if (((l = l.containerInfo), (Oi = Nn), (l = Qf(l)), ec(l))) {
      if ('selectionStart' in l)
        var a = { start: l.selectionStart, end: l.selectionEnd };
      else
        l: {
          a = ((a = l.ownerDocument) && a.defaultView) || window;
          var u = a.getSelection && a.getSelection();
          if (u && u.rangeCount !== 0) {
            a = u.anchorNode;
            var e = u.anchorOffset,
              n = u.focusNode;
            u = u.focusOffset;
            try {
              (a.nodeType, n.nodeType);
            } catch {
              a = null;
              break l;
            }
            var c = 0,
              i = -1,
              f = -1,
              v = 0,
              o = 0,
              S = l,
              r = null;
            t: for (;;) {
              for (
                var y;
                S !== a || (e !== 0 && S.nodeType !== 3) || (i = c + e),
                  S !== n || (u !== 0 && S.nodeType !== 3) || (f = c + u),
                  S.nodeType === 3 && (c += S.nodeValue.length),
                  (y = S.firstChild) !== null;

              )
                ((r = S), (S = y));
              for (;;) {
                if (S === l) break t;
                if (
                  (r === a && ++v === e && (i = c),
                  r === n && ++o === u && (f = c),
                  (y = S.nextSibling) !== null)
                )
                  break;
                ((S = r), (r = S.parentNode));
              }
              S = y;
            }
            a = i === -1 || f === -1 ? null : { start: i, end: f };
          } else a = null;
        }
      a = a || { start: 0, end: 0 };
    } else a = null;
    for (
      Ui = { focusedElem: l, selectionRange: a }, Nn = !1, ml = t;
      ml !== null;

    )
      if (
        ((t = ml), (l = t.child), (t.subtreeFlags & 1024) !== 0 && l !== null)
      )
        ((l.return = t), (ml = l));
      else
        for (; ml !== null; ) {
          switch (((t = ml), (n = t.alternate), (l = t.flags), t.tag)) {
            case 0:
              break;
            case 11:
            case 15:
              break;
            case 1:
              if ((l & 1024) !== 0 && n !== null) {
                ((l = void 0),
                  (a = t),
                  (e = n.memoizedProps),
                  (n = n.memoizedState),
                  (u = a.stateNode));
                try {
                  var E = oa(a.type, e, a.elementType === a.type);
                  ((l = u.getSnapshotBeforeUpdate(E, n)),
                    (u.__reactInternalSnapshotBeforeUpdate = l));
                } catch (T) {
                  K(a, a.return, T);
                }
              }
              break;
            case 3:
              if ((l & 1024) !== 0) {
                if (
                  ((l = t.stateNode.containerInfo), (a = l.nodeType), a === 9)
                )
                  qi(l);
                else if (a === 1)
                  switch (l.nodeName) {
                    case 'HEAD':
                    case 'HTML':
                    case 'BODY':
                      qi(l);
                      break;
                    default:
                      l.textContent = '';
                  }
              }
              break;
            case 5:
            case 26:
            case 27:
            case 6:
            case 4:
            case 17:
              break;
            default:
              if ((l & 1024) !== 0) throw Error(b(163));
          }
          if (((l = t.sibling), l !== null)) {
            ((l.return = t.return), (ml = l));
            break;
          }
          ml = t.return;
        }
  }
  function O0(l, t, a) {
    var u = a.flags;
    switch (a.tag) {
      case 0:
      case 11:
      case 15:
        (Zt(l, a), u & 4 && Cu(5, a));
        break;
      case 1:
        if ((Zt(l, a), u & 4))
          if (((l = a.stateNode), t === null))
            try {
              l.componentDidMount();
            } catch (c) {
              K(a, a.return, c);
            }
          else {
            var e = oa(a.type, t.memoizedProps);
            t = t.memoizedState;
            try {
              l.componentDidUpdate(e, t, l.__reactInternalSnapshotBeforeUpdate);
            } catch (c) {
              K(a, a.return, c);
            }
          }
        (u & 64 && A0(a), u & 512 && Ku(a, a.return));
        break;
      case 3:
        if ((Zt(l, a), u & 64 && ((l = a.updateQueue), l !== null))) {
          if (((t = null), a.child !== null))
            switch (a.child.tag) {
              case 27:
              case 5:
                t = a.child.stateNode;
                break;
              case 1:
                t = a.child.stateNode;
            }
          try {
            hs(l, t);
          } catch (c) {
            K(a, a.return, c);
          }
        }
        break;
      case 27:
        t === null && u & 4 && D0(a);
      case 26:
      case 5:
        (Zt(l, a), t === null && u & 4 && M0(a), u & 512 && Ku(a, a.return));
        break;
      case 12:
        Zt(l, a);
        break;
      case 13:
        (Zt(l, a),
          u & 4 && _0(l, a),
          u & 64 &&
            ((l = a.memoizedState),
            l !== null &&
              ((l = l.dehydrated),
              l !== null && ((a = Mm.bind(null, a)), Km(l, a)))));
        break;
      case 22:
        if (((u = a.memoizedState !== null || Nt), !u)) {
          ((t = (t !== null && t.memoizedState !== null) || al), (e = Nt));
          var n = al;
          ((Nt = u),
            (al = t) && !n ? Vt(l, a, (a.subtreeFlags & 8772) !== 0) : Zt(l, a),
            (Nt = e),
            (al = n));
        }
        break;
      case 30:
        break;
      default:
        Zt(l, a);
    }
  }
  function U0(l) {
    var t = l.alternate;
    (t !== null && ((l.alternate = null), U0(t)),
      (l.child = null),
      (l.deletions = null),
      (l.sibling = null),
      l.tag === 5 && ((t = l.stateNode), t !== null && Xn(t)),
      (l.stateNode = null),
      (l.return = null),
      (l.dependencies = null),
      (l.memoizedProps = null),
      (l.memoizedState = null),
      (l.pendingProps = null),
      (l.stateNode = null),
      (l.updateQueue = null));
  }
  var k = null,
    Tl = !1;
  function At(l, t, a) {
    for (a = a.child; a !== null; ) (H0(l, t, a), (a = a.sibling));
  }
  function H0(l, t, a) {
    if (Dl && typeof Dl.onCommitFiberUnmount == 'function')
      try {
        Dl.onCommitFiberUnmount(hu, a);
      } catch {}
    switch (a.tag) {
      case 26:
        (al || ct(a, t),
          At(l, t, a),
          a.memoizedState
            ? a.memoizedState.count--
            : a.stateNode && ((a = a.stateNode), a.parentNode.removeChild(a)));
        break;
      case 27:
        al || ct(a, t);
        var u = k,
          e = Tl;
        (Wt(a.type) && ((k = a.stateNode), (Tl = !1)),
          At(l, t, a),
          Pu(a.stateNode),
          (k = u),
          (Tl = e));
        break;
      case 5:
        al || ct(a, t);
      case 6:
        if (
          ((u = k),
          (e = Tl),
          (k = null),
          At(l, t, a),
          (k = u),
          (Tl = e),
          k !== null)
        )
          if (Tl)
            try {
              (k.nodeType === 9
                ? k.body
                : k.nodeName === 'HTML'
                  ? k.ownerDocument.body
                  : k
              ).removeChild(a.stateNode);
            } catch (n) {
              K(a, t, n);
            }
          else
            try {
              k.removeChild(a.stateNode);
            } catch (n) {
              K(a, t, n);
            }
        break;
      case 18:
        k !== null &&
          (Tl
            ? ((l = k),
              Sd(
                l.nodeType === 9
                  ? l.body
                  : l.nodeName === 'HTML'
                    ? l.ownerDocument.body
                    : l,
                a.stateNode,
              ),
              ie(l))
            : Sd(k, a.stateNode));
        break;
      case 4:
        ((u = k),
          (e = Tl),
          (k = a.stateNode.containerInfo),
          (Tl = !0),
          At(l, t, a),
          (k = u),
          (Tl = e));
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        (al || Qt(2, a, t), al || Qt(4, a, t), At(l, t, a));
        break;
      case 1:
        (al ||
          (ct(a, t),
          (u = a.stateNode),
          typeof u.componentWillUnmount == 'function' && T0(a, t, u)),
          At(l, t, a));
        break;
      case 21:
        At(l, t, a);
        break;
      case 22:
        ((al = (u = al) || a.memoizedState !== null), At(l, t, a), (al = u));
        break;
      default:
        At(l, t, a);
    }
  }
  function _0(l, t) {
    if (
      t.memoizedState === null &&
      ((l = t.alternate),
      l !== null &&
        ((l = l.memoizedState), l !== null && ((l = l.dehydrated), l !== null)))
    )
      try {
        ie(l);
      } catch (a) {
        K(t, t.return, a);
      }
  }
  function gm(l) {
    switch (l.tag) {
      case 13:
      case 19:
        var t = l.stateNode;
        return (t === null && (t = l.stateNode = new j0()), t);
      case 22:
        return (
          (l = l.stateNode),
          (t = l._retryCache),
          t === null && (t = l._retryCache = new j0()),
          t
        );
      default:
        throw Error(b(435, l.tag));
    }
  }
  function ii(l, t) {
    var a = gm(l);
    t.forEach(function (u) {
      var e = Em.bind(null, l, u);
      a.has(u) || (a.add(u), u.then(e, e));
    });
  }
  function Hl(l, t) {
    var a = t.deletions;
    if (a !== null)
      for (var u = 0; u < a.length; u++) {
        var e = a[u],
          n = l,
          c = t,
          i = c;
        l: for (; i !== null; ) {
          switch (i.tag) {
            case 27:
              if (Wt(i.type)) {
                ((k = i.stateNode), (Tl = !1));
                break l;
              }
              break;
            case 5:
              ((k = i.stateNode), (Tl = !1));
              break l;
            case 3:
            case 4:
              ((k = i.stateNode.containerInfo), (Tl = !0));
              break l;
          }
          i = i.return;
        }
        if (k === null) throw Error(b(160));
        (H0(n, c, e),
          (k = null),
          (Tl = !1),
          (n = e.alternate),
          n !== null && (n.return = null),
          (e.return = null));
      }
    if (t.subtreeFlags & 13878)
      for (t = t.child; t !== null; ) (q0(t, l), (t = t.sibling));
  }
  var Pl = null;
  function q0(l, t) {
    var a = l.alternate,
      u = l.flags;
    switch (l.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        (Hl(t, l),
          _l(l),
          u & 4 && (Qt(3, l, l.return), Cu(3, l), Qt(5, l, l.return)));
        break;
      case 1:
        (Hl(t, l),
          _l(l),
          u & 512 && (al || a === null || ct(a, a.return)),
          u & 64 &&
            Nt &&
            ((l = l.updateQueue),
            l !== null &&
              ((u = l.callbacks),
              u !== null &&
                ((a = l.shared.hiddenCallbacks),
                (l.shared.hiddenCallbacks = a === null ? u : a.concat(u))))));
        break;
      case 26:
        var e = Pl;
        if (
          (Hl(t, l),
          _l(l),
          u & 512 && (al || a === null || ct(a, a.return)),
          u & 4)
        ) {
          var n = a !== null ? a.memoizedState : null;
          if (((u = l.memoizedState), a === null))
            if (u === null)
              if (l.stateNode === null) {
                l: {
                  ((u = l.type),
                    (a = l.memoizedProps),
                    (e = e.ownerDocument || e));
                  t: switch (u) {
                    case 'title':
                      ((n = e.getElementsByTagName('title')[0]),
                        (!n ||
                          n[ru] ||
                          n[bl] ||
                          n.namespaceURI === 'http://www.w3.org/2000/svg' ||
                          n.hasAttribute('itemprop')) &&
                          ((n = e.createElement(u)),
                          e.head.insertBefore(
                            n,
                            e.querySelector('head > title'),
                          )),
                        ol(n, u, a),
                        (n[bl] = l),
                        dl(n),
                        (u = n));
                      break l;
                    case 'link':
                      var c = Dd('link', 'href', e).get(u + (a.href || ''));
                      if (c) {
                        for (var i = 0; i < c.length; i++)
                          if (
                            ((n = c[i]),
                            n.getAttribute('href') ===
                              (a.href == null || a.href === ''
                                ? null
                                : a.href) &&
                              n.getAttribute('rel') ===
                                (a.rel == null ? null : a.rel) &&
                              n.getAttribute('title') ===
                                (a.title == null ? null : a.title) &&
                              n.getAttribute('crossorigin') ===
                                (a.crossOrigin == null ? null : a.crossOrigin))
                          ) {
                            c.splice(i, 1);
                            break t;
                          }
                      }
                      ((n = e.createElement(u)),
                        ol(n, u, a),
                        e.head.appendChild(n));
                      break;
                    case 'meta':
                      if (
                        (c = Dd('meta', 'content', e).get(
                          u + (a.content || ''),
                        ))
                      ) {
                        for (i = 0; i < c.length; i++)
                          if (
                            ((n = c[i]),
                            n.getAttribute('content') ===
                              (a.content == null ? null : '' + a.content) &&
                              n.getAttribute('name') ===
                                (a.name == null ? null : a.name) &&
                              n.getAttribute('property') ===
                                (a.property == null ? null : a.property) &&
                              n.getAttribute('http-equiv') ===
                                (a.httpEquiv == null ? null : a.httpEquiv) &&
                              n.getAttribute('charset') ===
                                (a.charSet == null ? null : a.charSet))
                          ) {
                            c.splice(i, 1);
                            break t;
                          }
                      }
                      ((n = e.createElement(u)),
                        ol(n, u, a),
                        e.head.appendChild(n));
                      break;
                    default:
                      throw Error(b(468, u));
                  }
                  ((n[bl] = l), dl(n), (u = n));
                }
                l.stateNode = u;
              } else jd(e, l.type, l.stateNode);
            else l.stateNode = Ed(e, u, l.memoizedProps);
          else
            n !== u
              ? (n === null
                  ? a.stateNode !== null &&
                    ((a = a.stateNode), a.parentNode.removeChild(a))
                  : n.count--,
                u === null
                  ? jd(e, l.type, l.stateNode)
                  : Ed(e, u, l.memoizedProps))
              : u === null &&
                l.stateNode !== null &&
                ui(l, l.memoizedProps, a.memoizedProps);
        }
        break;
      case 27:
        (Hl(t, l),
          _l(l),
          u & 512 && (al || a === null || ct(a, a.return)),
          a !== null && u & 4 && ui(l, l.memoizedProps, a.memoizedProps));
        break;
      case 5:
        if (
          (Hl(t, l),
          _l(l),
          u & 512 && (al || a === null || ct(a, a.return)),
          l.flags & 32)
        ) {
          e = l.stateNode;
          try {
            Ua(e, '');
          } catch (y) {
            K(l, l.return, y);
          }
        }
        (u & 4 &&
          l.stateNode != null &&
          ((e = l.memoizedProps), ui(l, e, a !== null ? a.memoizedProps : e)),
          u & 1024 && (ci = !0));
        break;
      case 6:
        if ((Hl(t, l), _l(l), u & 4)) {
          if (l.stateNode === null) throw Error(b(162));
          ((u = l.memoizedProps), (a = l.stateNode));
          try {
            a.nodeValue = u;
          } catch (y) {
            K(l, l.return, y);
          }
        }
        break;
      case 3:
        if (
          ((Sn = null),
          (e = Pl),
          (Pl = gn(t.containerInfo)),
          Hl(t, l),
          (Pl = e),
          _l(l),
          u & 4 && a !== null && a.memoizedState.isDehydrated)
        )
          try {
            ie(t.containerInfo);
          } catch (y) {
            K(l, l.return, y);
          }
        ci && ((ci = !1), R0(l));
        break;
      case 4:
        ((u = Pl),
          (Pl = gn(l.stateNode.containerInfo)),
          Hl(t, l),
          _l(l),
          (Pl = u));
        break;
      case 12:
        (Hl(t, l), _l(l));
        break;
      case 13:
        (Hl(t, l),
          _l(l),
          l.child.flags & 8192 &&
            (l.memoizedState !== null) !=
              (a !== null && a.memoizedState !== null) &&
            (vi = ut()),
          u & 4 &&
            ((u = l.updateQueue),
            u !== null && ((l.updateQueue = null), ii(l, u))));
        break;
      case 22:
        e = l.memoizedState !== null;
        var f = a !== null && a.memoizedState !== null,
          v = Nt,
          o = al;
        if (
          ((Nt = v || e),
          (al = o || f),
          Hl(t, l),
          (al = o),
          (Nt = v),
          _l(l),
          u & 8192)
        )
          l: for (
            t = l.stateNode,
              t._visibility = e ? t._visibility & -2 : t._visibility | 1,
              e && (a === null || f || Nt || al || ba(l)),
              a = null,
              t = l;
            ;

          ) {
            if (t.tag === 5 || t.tag === 26) {
              if (a === null) {
                f = a = t;
                try {
                  if (((n = f.stateNode), e))
                    ((c = n.style),
                      typeof c.setProperty == 'function'
                        ? c.setProperty('display', 'none', 'important')
                        : (c.display = 'none'));
                  else {
                    i = f.stateNode;
                    var S = f.memoizedProps.style,
                      r =
                        S != null && S.hasOwnProperty('display')
                          ? S.display
                          : null;
                    i.style.display =
                      r == null || typeof r == 'boolean' ? '' : ('' + r).trim();
                  }
                } catch (y) {
                  K(f, f.return, y);
                }
              }
            } else if (t.tag === 6) {
              if (a === null) {
                f = t;
                try {
                  f.stateNode.nodeValue = e ? '' : f.memoizedProps;
                } catch (y) {
                  K(f, f.return, y);
                }
              }
            } else if (
              ((t.tag !== 22 && t.tag !== 23) ||
                t.memoizedState === null ||
                t === l) &&
              t.child !== null
            ) {
              ((t.child.return = t), (t = t.child));
              continue;
            }
            if (t === l) break l;
            for (; t.sibling === null; ) {
              if (t.return === null || t.return === l) break l;
              (a === t && (a = null), (t = t.return));
            }
            (a === t && (a = null),
              (t.sibling.return = t.return),
              (t = t.sibling));
          }
        u & 4 &&
          ((u = l.updateQueue),
          u !== null &&
            ((a = u.retryQueue),
            a !== null && ((u.retryQueue = null), ii(l, a))));
        break;
      case 19:
        (Hl(t, l),
          _l(l),
          u & 4 &&
            ((u = l.updateQueue),
            u !== null && ((l.updateQueue = null), ii(l, u))));
        break;
      case 30:
        break;
      case 21:
        break;
      default:
        (Hl(t, l), _l(l));
    }
  }
  function _l(l) {
    var t = l.flags;
    if (t & 2) {
      try {
        for (var a, u = l.return; u !== null; ) {
          if (E0(u)) {
            a = u;
            break;
          }
          u = u.return;
        }
        if (a == null) throw Error(b(160));
        switch (a.tag) {
          case 27:
            var e = a.stateNode,
              n = ei(l);
            en(l, n, e);
            break;
          case 5:
            var c = a.stateNode;
            a.flags & 32 && (Ua(c, ''), (a.flags &= -33));
            var i = ei(l);
            en(l, i, c);
            break;
          case 3:
          case 4:
            var f = a.stateNode.containerInfo,
              v = ei(l);
            ni(l, v, f);
            break;
          default:
            throw Error(b(161));
        }
      } catch (o) {
        K(l, l.return, o);
      }
      l.flags &= -3;
    }
    t & 4096 && (l.flags &= -4097);
  }
  function R0(l) {
    if (l.subtreeFlags & 1024)
      for (l = l.child; l !== null; ) {
        var t = l;
        (R0(t),
          t.tag === 5 && t.flags & 1024 && t.stateNode.reset(),
          (l = l.sibling));
      }
  }
  function Zt(l, t) {
    if (t.subtreeFlags & 8772)
      for (t = t.child; t !== null; ) (O0(l, t.alternate, t), (t = t.sibling));
  }
  function ba(l) {
    for (l = l.child; l !== null; ) {
      var t = l;
      switch (t.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          (Qt(4, t, t.return), ba(t));
          break;
        case 1:
          ct(t, t.return);
          var a = t.stateNode;
          (typeof a.componentWillUnmount == 'function' && T0(t, t.return, a),
            ba(t));
          break;
        case 27:
          Pu(t.stateNode);
        case 26:
        case 5:
          (ct(t, t.return), ba(t));
          break;
        case 22:
          t.memoizedState === null && ba(t);
          break;
        case 30:
          ba(t);
          break;
        default:
          ba(t);
      }
      l = l.sibling;
    }
  }
  function Vt(l, t, a) {
    for (a = a && (t.subtreeFlags & 8772) !== 0, t = t.child; t !== null; ) {
      var u = t.alternate,
        e = l,
        n = t,
        c = n.flags;
      switch (n.tag) {
        case 0:
        case 11:
        case 15:
          (Vt(e, n, a), Cu(4, n));
          break;
        case 1:
          if (
            (Vt(e, n, a),
            (u = n),
            (e = u.stateNode),
            typeof e.componentDidMount == 'function')
          )
            try {
              e.componentDidMount();
            } catch (v) {
              K(u, u.return, v);
            }
          if (((u = n), (e = u.updateQueue), e !== null)) {
            var i = u.stateNode;
            try {
              var f = e.shared.hiddenCallbacks;
              if (f !== null)
                for (e.shared.hiddenCallbacks = null, e = 0; e < f.length; e++)
                  ds(f[e], i);
            } catch (v) {
              K(u, u.return, v);
            }
          }
          (a && c & 64 && A0(n), Ku(n, n.return));
          break;
        case 27:
          D0(n);
        case 26:
        case 5:
          (Vt(e, n, a), a && u === null && c & 4 && M0(n), Ku(n, n.return));
          break;
        case 12:
          Vt(e, n, a);
          break;
        case 13:
          (Vt(e, n, a), a && c & 4 && _0(e, n));
          break;
        case 22:
          (n.memoizedState === null && Vt(e, n, a), Ku(n, n.return));
          break;
        case 30:
          break;
        default:
          Vt(e, n, a);
      }
      t = t.sibling;
    }
  }
  function fi(l, t) {
    var a = null;
    (l !== null &&
      l.memoizedState !== null &&
      l.memoizedState.cachePool !== null &&
      (a = l.memoizedState.cachePool.pool),
      (l = null),
      t.memoizedState !== null &&
        t.memoizedState.cachePool !== null &&
        (l = t.memoizedState.cachePool.pool),
      l !== a && (l != null && l.refCount++, a != null && ju(a)));
  }
  function si(l, t) {
    ((l = null),
      t.alternate !== null && (l = t.alternate.memoizedState.cache),
      (t = t.memoizedState.cache),
      t !== l && (t.refCount++, l != null && ju(l)));
  }
  function it(l, t, a, u) {
    if (t.subtreeFlags & 10256)
      for (t = t.child; t !== null; ) (B0(l, t, a, u), (t = t.sibling));
  }
  function B0(l, t, a, u) {
    var e = t.flags;
    switch (t.tag) {
      case 0:
      case 11:
      case 15:
        (it(l, t, a, u), e & 2048 && Cu(9, t));
        break;
      case 1:
        it(l, t, a, u);
        break;
      case 3:
        (it(l, t, a, u),
          e & 2048 &&
            ((l = null),
            t.alternate !== null && (l = t.alternate.memoizedState.cache),
            (t = t.memoizedState.cache),
            t !== l && (t.refCount++, l != null && ju(l))));
        break;
      case 12:
        if (e & 2048) {
          (it(l, t, a, u), (l = t.stateNode));
          try {
            var n = t.memoizedProps,
              c = n.id,
              i = n.onPostCommit;
            typeof i == 'function' &&
              i(
                c,
                t.alternate === null ? 'mount' : 'update',
                l.passiveEffectDuration,
                -0,
              );
          } catch (f) {
            K(t, t.return, f);
          }
        } else it(l, t, a, u);
        break;
      case 13:
        it(l, t, a, u);
        break;
      case 23:
        break;
      case 22:
        ((n = t.stateNode),
          (c = t.alternate),
          t.memoizedState !== null
            ? n._visibility & 2
              ? it(l, t, a, u)
              : Lu(l, t)
            : n._visibility & 2
              ? it(l, t, a, u)
              : ((n._visibility |= 2),
                $a(l, t, a, u, (t.subtreeFlags & 10256) !== 0)),
          e & 2048 && fi(c, t));
        break;
      case 24:
        (it(l, t, a, u), e & 2048 && si(t.alternate, t));
        break;
      default:
        it(l, t, a, u);
    }
  }
  function $a(l, t, a, u, e) {
    for (e = e && (t.subtreeFlags & 10256) !== 0, t = t.child; t !== null; ) {
      var n = l,
        c = t,
        i = a,
        f = u,
        v = c.flags;
      switch (c.tag) {
        case 0:
        case 11:
        case 15:
          ($a(n, c, i, f, e), Cu(8, c));
          break;
        case 23:
          break;
        case 22:
          var o = c.stateNode;
          (c.memoizedState !== null
            ? o._visibility & 2
              ? $a(n, c, i, f, e)
              : Lu(n, c)
            : ((o._visibility |= 2), $a(n, c, i, f, e)),
            e && v & 2048 && fi(c.alternate, c));
          break;
        case 24:
          ($a(n, c, i, f, e), e && v & 2048 && si(c.alternate, c));
          break;
        default:
          $a(n, c, i, f, e);
      }
      t = t.sibling;
    }
  }
  function Lu(l, t) {
    if (t.subtreeFlags & 10256)
      for (t = t.child; t !== null; ) {
        var a = l,
          u = t,
          e = u.flags;
        switch (u.tag) {
          case 22:
            (Lu(a, u), e & 2048 && fi(u.alternate, u));
            break;
          case 24:
            (Lu(a, u), e & 2048 && si(u.alternate, u));
            break;
          default:
            Lu(a, u);
        }
        t = t.sibling;
      }
  }
  var Ju = 8192;
  function Fa(l) {
    if (l.subtreeFlags & Ju)
      for (l = l.child; l !== null; ) (Y0(l), (l = l.sibling));
  }
  function Y0(l) {
    switch (l.tag) {
      case 26:
        (Fa(l),
          l.flags & Ju &&
            l.memoizedState !== null &&
            uv(Pl, l.memoizedState, l.memoizedProps));
        break;
      case 5:
        Fa(l);
        break;
      case 3:
      case 4:
        var t = Pl;
        ((Pl = gn(l.stateNode.containerInfo)), Fa(l), (Pl = t));
        break;
      case 22:
        l.memoizedState === null &&
          ((t = l.alternate),
          t !== null && t.memoizedState !== null
            ? ((t = Ju), (Ju = 16777216), Fa(l), (Ju = t))
            : Fa(l));
        break;
      default:
        Fa(l);
    }
  }
  function G0(l) {
    var t = l.alternate;
    if (t !== null && ((l = t.child), l !== null)) {
      t.child = null;
      do ((t = l.sibling), (l.sibling = null), (l = t));
      while (l !== null);
    }
  }
  function wu(l) {
    var t = l.deletions;
    if ((l.flags & 16) !== 0) {
      if (t !== null)
        for (var a = 0; a < t.length; a++) {
          var u = t[a];
          ((ml = u), Q0(u, l));
        }
      G0(l);
    }
    if (l.subtreeFlags & 10256)
      for (l = l.child; l !== null; ) (X0(l), (l = l.sibling));
  }
  function X0(l) {
    switch (l.tag) {
      case 0:
      case 11:
      case 15:
        (wu(l), l.flags & 2048 && Qt(9, l, l.return));
        break;
      case 3:
        wu(l);
        break;
      case 12:
        wu(l);
        break;
      case 22:
        var t = l.stateNode;
        l.memoizedState !== null &&
        t._visibility & 2 &&
        (l.return === null || l.return.tag !== 13)
          ? ((t._visibility &= -3), nn(l))
          : wu(l);
        break;
      default:
        wu(l);
    }
  }
  function nn(l) {
    var t = l.deletions;
    if ((l.flags & 16) !== 0) {
      if (t !== null)
        for (var a = 0; a < t.length; a++) {
          var u = t[a];
          ((ml = u), Q0(u, l));
        }
      G0(l);
    }
    for (l = l.child; l !== null; ) {
      switch (((t = l), t.tag)) {
        case 0:
        case 11:
        case 15:
          (Qt(8, t, t.return), nn(t));
          break;
        case 22:
          ((a = t.stateNode),
            a._visibility & 2 && ((a._visibility &= -3), nn(t)));
          break;
        default:
          nn(t);
      }
      l = l.sibling;
    }
  }
  function Q0(l, t) {
    for (; ml !== null; ) {
      var a = ml;
      switch (a.tag) {
        case 0:
        case 11:
        case 15:
          Qt(8, a, t);
          break;
        case 23:
        case 22:
          if (a.memoizedState !== null && a.memoizedState.cachePool !== null) {
            var u = a.memoizedState.cachePool.pool;
            u != null && u.refCount++;
          }
          break;
        case 24:
          ju(a.memoizedState.cache);
      }
      if (((u = a.child), u !== null)) ((u.return = a), (ml = u));
      else
        l: for (a = l; ml !== null; ) {
          u = ml;
          var e = u.sibling,
            n = u.return;
          if ((U0(u), u === a)) {
            ml = null;
            break l;
          }
          if (e !== null) {
            ((e.return = n), (ml = e));
            break l;
          }
          ml = n;
        }
    }
  }
  var xm = {
      getCacheForType: function (l) {
        var t = gl(nl),
          a = t.data.get(l);
        return (a === void 0 && ((a = l()), t.data.set(l, a)), a);
      },
    },
    Sm = typeof WeakMap == 'function' ? WeakMap : Map,
    Y = 0,
    L = null,
    H = null,
    q = 0,
    G = 0,
    ql = null,
    Ct = !1,
    Ia = !1,
    di = !1,
    Tt = 0,
    P = 0,
    Kt = 0,
    ga = 0,
    hi = 0,
    wl = 0,
    Pa = 0,
    Wu = null,
    Ml = null,
    mi = !1,
    vi = 0,
    cn = 1 / 0,
    fn = null,
    Lt = null,
    yl = 0,
    Jt = null,
    lu = null,
    tu = 0,
    ri = 0,
    yi = null,
    Z0 = null,
    ku = 0,
    oi = null;
  function Rl() {
    if ((Y & 2) !== 0 && q !== 0) return q & -q;
    if (x.T !== null) {
      var l = Va;
      return l !== 0 ? l : Ni();
    }
    return af();
  }
  function V0() {
    wl === 0 && (wl = (q & 536870912) === 0 || B ? Ii() : 536870912);
    var l = Jl.current;
    return (l !== null && (l.flags |= 32), wl);
  }
  function Bl(l, t, a) {
    (((l === L && (G === 2 || G === 9)) || l.cancelPendingCommit !== null) &&
      (au(l, 0), wt(l, q, wl, !1)),
      vu(l, a),
      ((Y & 2) === 0 || l !== L) &&
        (l === L && ((Y & 2) === 0 && (ga |= a), P === 4 && wt(l, q, wl, !1)),
        ft(l)));
  }
  function C0(l, t, a) {
    if ((Y & 6) !== 0) throw Error(b(327));
    var u = (!a && (t & 124) === 0 && (t & l.expiredLanes) === 0) || mu(l, t),
      e = u ? Nm(l, t) : xi(l, t, !0),
      n = u;
    do {
      if (e === 0) {
        Ia && !u && wt(l, t, 0, !1);
        break;
      } else {
        if (((a = l.current.alternate), n && !pm(a))) {
          ((e = xi(l, t, !1)), (n = !1));
          continue;
        }
        if (e === 2) {
          if (((n = t), l.errorRecoveryDisabledLanes & n)) var c = 0;
          else
            ((c = l.pendingLanes & -536870913),
              (c = c !== 0 ? c : c & 536870912 ? 536870912 : 0));
          if (c !== 0) {
            t = c;
            l: {
              var i = l;
              e = Wu;
              var f = i.current.memoizedState.isDehydrated;
              if ((f && (au(i, c).flags |= 256), (c = xi(i, c, !1)), c !== 2)) {
                if (di && !f) {
                  ((i.errorRecoveryDisabledLanes |= n), (ga |= n), (e = 4));
                  break l;
                }
                ((n = Ml),
                  (Ml = e),
                  n !== null &&
                    (Ml === null ? (Ml = n) : Ml.push.apply(Ml, n)));
              }
              e = c;
            }
            if (((n = !1), e !== 2)) continue;
          }
        }
        if (e === 1) {
          (au(l, 0), wt(l, t, 0, !0));
          break;
        }
        l: {
          switch (((u = l), (n = e), n)) {
            case 0:
            case 1:
              throw Error(b(345));
            case 4:
              if ((t & 4194048) !== t) break;
            case 6:
              wt(u, t, wl, !Ct);
              break l;
            case 2:
              Ml = null;
              break;
            case 3:
            case 5:
              break;
            default:
              throw Error(b(329));
          }
          if ((t & 62914560) === t && ((e = vi + 300 - ut()), 10 < e)) {
            if ((wt(u, t, wl, !Ct), ge(u, 0, !0) !== 0)) break l;
            u.timeoutHandle = gd(
              K0.bind(null, u, a, Ml, fn, mi, t, wl, ga, Pa, Ct, n, 2, -0, 0),
              e,
            );
            break l;
          }
          K0(u, a, Ml, fn, mi, t, wl, ga, Pa, Ct, n, 0, -0, 0);
        }
      }
      break;
    } while (!0);
    ft(l);
  }
  function K0(l, t, a, u, e, n, c, i, f, v, o, S, r, y) {
    if (
      ((l.timeoutHandle = -1),
      (S = t.subtreeFlags),
      (S & 8192 || (S & 16785408) === 16785408) &&
        ((ae = { stylesheets: null, count: 0, unsuspend: av }),
        Y0(t),
        (S = ev()),
        S !== null))
    ) {
      ((l.cancelPendingCommit = S(
        F0.bind(null, l, t, n, a, u, e, c, i, f, o, 1, r, y),
      )),
        wt(l, n, c, !v));
      return;
    }
    F0(l, t, n, a, u, e, c, i, f);
  }
  function pm(l) {
    for (var t = l; ; ) {
      var a = t.tag;
      if (
        (a === 0 || a === 11 || a === 15) &&
        t.flags & 16384 &&
        ((a = t.updateQueue), a !== null && ((a = a.stores), a !== null))
      )
        for (var u = 0; u < a.length; u++) {
          var e = a[u],
            n = e.getSnapshot;
          e = e.value;
          try {
            if (!Ol(n(), e)) return !1;
          } catch {
            return !1;
          }
        }
      if (((a = t.child), t.subtreeFlags & 16384 && a !== null))
        ((a.return = t), (t = a));
      else {
        if (t === l) break;
        for (; t.sibling === null; ) {
          if (t.return === null || t.return === l) return !0;
          t = t.return;
        }
        ((t.sibling.return = t.return), (t = t.sibling));
      }
    }
    return !0;
  }
  function wt(l, t, a, u) {
    ((t &= ~hi),
      (t &= ~ga),
      (l.suspendedLanes |= t),
      (l.pingedLanes &= ~t),
      u && (l.warmLanes |= t),
      (u = l.expirationTimes));
    for (var e = t; 0 < e; ) {
      var n = 31 - jl(e),
        c = 1 << n;
      ((u[n] = -1), (e &= ~c));
    }
    a !== 0 && lf(l, a, t);
  }
  function sn() {
    return (Y & 6) === 0 ? ($u(0), !1) : !0;
  }
  function bi() {
    if (H !== null) {
      if (G === 0) var l = H.return;
      else ((l = H), (bt = ma = null), qc(l), (Wa = null), (Qu = 0), (l = H));
      for (; l !== null; ) (N0(l.alternate, l), (l = l.return));
      H = null;
    }
  }
  function au(l, t) {
    var a = l.timeoutHandle;
    (a !== -1 && ((l.timeoutHandle = -1), Xm(a)),
      (a = l.cancelPendingCommit),
      a !== null && ((l.cancelPendingCommit = null), a()),
      bi(),
      (L = l),
      (H = a = rt(l.current, null)),
      (q = t),
      (G = 0),
      (ql = null),
      (Ct = !1),
      (Ia = mu(l, t)),
      (di = !1),
      (Pa = wl = hi = ga = Kt = P = 0),
      (Ml = Wu = null),
      (mi = !1),
      (t & 8) !== 0 && (t |= t & 32));
    var u = l.entangledLanes;
    if (u !== 0)
      for (l = l.entanglements, u &= t; 0 < u; ) {
        var e = 31 - jl(u),
          n = 1 << e;
        ((t |= l[e]), (u &= ~n));
      }
    return ((Tt = t), Oe(), a);
  }
  function L0(l, t) {
    ((O = null),
      (x.H = ke),
      t === Uu || t === Xe
        ? ((t = fs()), (G = 3))
        : t === ns
          ? ((t = fs()), (G = 4))
          : (G =
              t === s0
                ? 8
                : t !== null &&
                    typeof t == 'object' &&
                    typeof t.then == 'function'
                  ? 6
                  : 1),
      (ql = t),
      H === null && ((P = 1), ln(l, Vl(t, l.current))));
  }
  function J0() {
    var l = x.H;
    return ((x.H = ke), l === null ? ke : l);
  }
  function w0() {
    var l = x.A;
    return ((x.A = xm), l);
  }
  function gi() {
    ((P = 4),
      Ct || ((q & 4194048) !== q && Jl.current !== null) || (Ia = !0),
      ((Kt & 134217727) === 0 && (ga & 134217727) === 0) ||
        L === null ||
        wt(L, q, wl, !1));
  }
  function xi(l, t, a) {
    var u = Y;
    Y |= 2;
    var e = J0(),
      n = w0();
    ((L !== l || q !== t) && ((fn = null), au(l, t)), (t = !1));
    var c = P;
    l: do
      try {
        if (G !== 0 && H !== null) {
          var i = H,
            f = ql;
          switch (G) {
            case 8:
              (bi(), (c = 6));
              break l;
            case 3:
            case 2:
            case 9:
            case 6:
              Jl.current === null && (t = !0);
              var v = G;
              if (((G = 0), (ql = null), uu(l, i, f, v), a && Ia)) {
                c = 0;
                break l;
              }
              break;
            default:
              ((v = G), (G = 0), (ql = null), uu(l, i, f, v));
          }
        }
        (zm(), (c = P));
        break;
      } catch (o) {
        L0(l, o);
      }
    while (!0);
    return (
      t && l.shellSuspendCounter++,
      (bt = ma = null),
      (Y = u),
      (x.H = e),
      (x.A = n),
      H === null && ((L = null), (q = 0), Oe()),
      c
    );
  }
  function zm() {
    for (; H !== null; ) W0(H);
  }
  function Nm(l, t) {
    var a = Y;
    Y |= 2;
    var u = J0(),
      e = w0();
    L !== l || q !== t
      ? ((fn = null), (cn = ut() + 500), au(l, t))
      : (Ia = mu(l, t));
    l: do
      try {
        if (G !== 0 && H !== null) {
          t = H;
          var n = ql;
          t: switch (G) {
            case 1:
              ((G = 0), (ql = null), uu(l, t, n, 1));
              break;
            case 2:
            case 9:
              if (cs(n)) {
                ((G = 0), (ql = null), k0(t));
                break;
              }
              ((t = function () {
                ((G !== 2 && G !== 9) || L !== l || (G = 7), ft(l));
              }),
                n.then(t, t));
              break l;
            case 3:
              G = 7;
              break l;
            case 4:
              G = 5;
              break l;
            case 7:
              cs(n)
                ? ((G = 0), (ql = null), k0(t))
                : ((G = 0), (ql = null), uu(l, t, n, 7));
              break;
            case 5:
              var c = null;
              switch (H.tag) {
                case 26:
                  c = H.memoizedState;
                case 5:
                case 27:
                  var i = H;
                  if (!c || Od(c)) {
                    ((G = 0), (ql = null));
                    var f = i.sibling;
                    if (f !== null) H = f;
                    else {
                      var v = i.return;
                      v !== null ? ((H = v), dn(v)) : (H = null);
                    }
                    break t;
                  }
              }
              ((G = 0), (ql = null), uu(l, t, n, 5));
              break;
            case 6:
              ((G = 0), (ql = null), uu(l, t, n, 6));
              break;
            case 8:
              (bi(), (P = 6));
              break l;
            default:
              throw Error(b(462));
          }
        }
        Am();
        break;
      } catch (o) {
        L0(l, o);
      }
    while (!0);
    return (
      (bt = ma = null),
      (x.H = u),
      (x.A = e),
      (Y = a),
      H !== null ? 0 : ((L = null), (q = 0), Oe(), P)
    );
  }
  function Am() {
    for (; H !== null && !Jd(); ) W0(H);
  }
  function W0(l) {
    var t = p0(l.alternate, l, Tt);
    ((l.memoizedProps = l.pendingProps), t === null ? dn(l) : (H = t));
  }
  function k0(l) {
    var t = l,
      a = t.alternate;
    switch (t.tag) {
      case 15:
      case 0:
        t = y0(a, t, t.pendingProps, t.type, void 0, q);
        break;
      case 11:
        t = y0(a, t, t.pendingProps, t.type.render, t.ref, q);
        break;
      case 5:
        qc(t);
      default:
        (N0(a, t), (t = H = $f(t, Tt)), (t = p0(a, t, Tt)));
    }
    ((l.memoizedProps = l.pendingProps), t === null ? dn(l) : (H = t));
  }
  function uu(l, t, a, u) {
    ((bt = ma = null), qc(t), (Wa = null), (Qu = 0));
    var e = t.return;
    try {
      if (vm(l, e, t, a, q)) {
        ((P = 1), ln(l, Vl(a, l.current)), (H = null));
        return;
      }
    } catch (n) {
      if (e !== null) throw ((H = e), n);
      ((P = 1), ln(l, Vl(a, l.current)), (H = null));
      return;
    }
    t.flags & 32768
      ? (B || u === 1
          ? (l = !0)
          : Ia || (q & 536870912) !== 0
            ? (l = !1)
            : ((Ct = l = !0),
              (u === 2 || u === 9 || u === 3 || u === 6) &&
                ((u = Jl.current),
                u !== null && u.tag === 13 && (u.flags |= 16384))),
        $0(t, l))
      : dn(t);
  }
  function dn(l) {
    var t = l;
    do {
      if ((t.flags & 32768) !== 0) {
        $0(t, Ct);
        return;
      }
      l = t.return;
      var a = ym(t.alternate, t, Tt);
      if (a !== null) {
        H = a;
        return;
      }
      if (((t = t.sibling), t !== null)) {
        H = t;
        return;
      }
      H = t = l;
    } while (t !== null);
    P === 0 && (P = 5);
  }
  function $0(l, t) {
    do {
      var a = om(l.alternate, l);
      if (a !== null) {
        ((a.flags &= 32767), (H = a));
        return;
      }
      if (
        ((a = l.return),
        a !== null &&
          ((a.flags |= 32768), (a.subtreeFlags = 0), (a.deletions = null)),
        !t && ((l = l.sibling), l !== null))
      ) {
        H = l;
        return;
      }
      H = l = a;
    } while (l !== null);
    ((P = 6), (H = null));
  }
  function F0(l, t, a, u, e, n, c, i, f) {
    l.cancelPendingCommit = null;
    do hn();
    while (yl !== 0);
    if ((Y & 6) !== 0) throw Error(b(327));
    if (t !== null) {
      if (t === l.current) throw Error(b(177));
      if (
        ((n = t.lanes | t.childLanes),
        (n |= sc),
        ah(l, a, n, c, i, f),
        l === L && ((H = L = null), (q = 0)),
        (lu = t),
        (Jt = l),
        (tu = a),
        (ri = n),
        (yi = e),
        (Z0 = u),
        (t.subtreeFlags & 10256) !== 0 || (t.flags & 10256) !== 0
          ? ((l.callbackNode = null),
            (l.callbackPriority = 0),
            Dm(ye, function () {
              return (ad(), null);
            }))
          : ((l.callbackNode = null), (l.callbackPriority = 0)),
        (u = (t.flags & 13878) !== 0),
        (t.subtreeFlags & 13878) !== 0 || u)
      ) {
        ((u = x.T), (x.T = null), (e = p.p), (p.p = 2), (c = Y), (Y |= 4));
        try {
          bm(l, t, a);
        } finally {
          ((Y = c), (p.p = e), (x.T = u));
        }
      }
      ((yl = 1), I0(), P0(), ld());
    }
  }
  function I0() {
    if (yl === 1) {
      yl = 0;
      var l = Jt,
        t = lu,
        a = (t.flags & 13878) !== 0;
      if ((t.subtreeFlags & 13878) !== 0 || a) {
        ((a = x.T), (x.T = null));
        var u = p.p;
        p.p = 2;
        var e = Y;
        Y |= 4;
        try {
          q0(t, l);
          var n = Ui,
            c = Qf(l.containerInfo),
            i = n.focusedElem,
            f = n.selectionRange;
          if (
            c !== i &&
            i &&
            i.ownerDocument &&
            Xf(i.ownerDocument.documentElement, i)
          ) {
            if (f !== null && ec(i)) {
              var v = f.start,
                o = f.end;
              if ((o === void 0 && (o = v), 'selectionStart' in i))
                ((i.selectionStart = v),
                  (i.selectionEnd = Math.min(o, i.value.length)));
              else {
                var S = i.ownerDocument || document,
                  r = (S && S.defaultView) || window;
                if (r.getSelection) {
                  var y = r.getSelection(),
                    E = i.textContent.length,
                    T = Math.min(f.start, E),
                    V = f.end === void 0 ? T : Math.min(f.end, E);
                  !y.extend && T > V && ((c = V), (V = T), (T = c));
                  var d = Gf(i, T),
                    s = Gf(i, V);
                  if (
                    d &&
                    s &&
                    (y.rangeCount !== 1 ||
                      y.anchorNode !== d.node ||
                      y.anchorOffset !== d.offset ||
                      y.focusNode !== s.node ||
                      y.focusOffset !== s.offset)
                  ) {
                    var m = S.createRange();
                    (m.setStart(d.node, d.offset),
                      y.removeAllRanges(),
                      T > V
                        ? (y.addRange(m), y.extend(s.node, s.offset))
                        : (m.setEnd(s.node, s.offset), y.addRange(m)));
                  }
                }
              }
            }
            for (S = [], y = i; (y = y.parentNode); )
              y.nodeType === 1 &&
                S.push({ element: y, left: y.scrollLeft, top: y.scrollTop });
            for (
              typeof i.focus == 'function' && i.focus(), i = 0;
              i < S.length;
              i++
            ) {
              var g = S[i];
              ((g.element.scrollLeft = g.left), (g.element.scrollTop = g.top));
            }
          }
          ((Nn = !!Oi), (Ui = Oi = null));
        } finally {
          ((Y = e), (p.p = u), (x.T = a));
        }
      }
      ((l.current = t), (yl = 2));
    }
  }
  function P0() {
    if (yl === 2) {
      yl = 0;
      var l = Jt,
        t = lu,
        a = (t.flags & 8772) !== 0;
      if ((t.subtreeFlags & 8772) !== 0 || a) {
        ((a = x.T), (x.T = null));
        var u = p.p;
        p.p = 2;
        var e = Y;
        Y |= 4;
        try {
          O0(l, t.alternate, t);
        } finally {
          ((Y = e), (p.p = u), (x.T = a));
        }
      }
      yl = 3;
    }
  }
  function ld() {
    if (yl === 4 || yl === 3) {
      ((yl = 0), wd());
      var l = Jt,
        t = lu,
        a = tu,
        u = Z0;
      (t.subtreeFlags & 10256) !== 0 || (t.flags & 10256) !== 0
        ? (yl = 5)
        : ((yl = 0), (lu = Jt = null), td(l, l.pendingLanes));
      var e = l.pendingLanes;
      if (
        (e === 0 && (Lt = null),
        Yn(a),
        (t = t.stateNode),
        Dl && typeof Dl.onCommitFiberRoot == 'function')
      )
        try {
          Dl.onCommitFiberRoot(hu, t, void 0, (t.current.flags & 128) === 128);
        } catch {}
      if (u !== null) {
        ((t = x.T), (e = p.p), (p.p = 2), (x.T = null));
        try {
          for (var n = l.onRecoverableError, c = 0; c < u.length; c++) {
            var i = u[c];
            n(i.value, { componentStack: i.stack });
          }
        } finally {
          ((x.T = t), (p.p = e));
        }
      }
      ((tu & 3) !== 0 && hn(),
        ft(l),
        (e = l.pendingLanes),
        (a & 4194090) !== 0 && (e & 42) !== 0
          ? l === oi
            ? ku++
            : ((ku = 0), (oi = l))
          : (ku = 0),
        $u(0));
    }
  }
  function td(l, t) {
    (l.pooledCacheLanes &= t) === 0 &&
      ((t = l.pooledCache), t != null && ((l.pooledCache = null), ju(t)));
  }
  function hn(l) {
    return (I0(), P0(), ld(), ad());
  }
  function ad() {
    if (yl !== 5) return !1;
    var l = Jt,
      t = ri;
    ri = 0;
    var a = Yn(tu),
      u = x.T,
      e = p.p;
    try {
      ((p.p = 32 > a ? 32 : a), (x.T = null), (a = yi), (yi = null));
      var n = Jt,
        c = tu;
      if (((yl = 0), (lu = Jt = null), (tu = 0), (Y & 6) !== 0))
        throw Error(b(331));
      var i = Y;
      if (
        ((Y |= 4),
        X0(n.current),
        B0(n, n.current, c, a),
        (Y = i),
        $u(0, !1),
        Dl && typeof Dl.onPostCommitFiberRoot == 'function')
      )
        try {
          Dl.onPostCommitFiberRoot(hu, n);
        } catch {}
      return !0;
    } finally {
      ((p.p = e), (x.T = u), td(l, t));
    }
  }
  function ud(l, t, a) {
    ((t = Vl(a, t)),
      (t = Wc(l.stateNode, t, 2)),
      (l = Bt(l, t, 2)),
      l !== null && (vu(l, 2), ft(l)));
  }
  function K(l, t, a) {
    if (l.tag === 3) ud(l, l, a);
    else
      for (; t !== null; ) {
        if (t.tag === 3) {
          ud(t, l, a);
          break;
        } else if (t.tag === 1) {
          var u = t.stateNode;
          if (
            typeof t.type.getDerivedStateFromError == 'function' ||
            (typeof u.componentDidCatch == 'function' &&
              (Lt === null || !Lt.has(u)))
          ) {
            ((l = Vl(a, l)),
              (a = i0(2)),
              (u = Bt(t, a, 2)),
              u !== null && (f0(a, u, t, l), vu(u, 2), ft(u)));
            break;
          }
        }
        t = t.return;
      }
  }
  function Si(l, t, a) {
    var u = l.pingCache;
    if (u === null) {
      u = l.pingCache = new Sm();
      var e = new Set();
      u.set(t, e);
    } else ((e = u.get(t)), e === void 0 && ((e = new Set()), u.set(t, e)));
    e.has(a) ||
      ((di = !0), e.add(a), (l = Tm.bind(null, l, t, a)), t.then(l, l));
  }
  function Tm(l, t, a) {
    var u = l.pingCache;
    (u !== null && u.delete(t),
      (l.pingedLanes |= l.suspendedLanes & a),
      (l.warmLanes &= ~a),
      L === l &&
        (q & a) === a &&
        (P === 4 || (P === 3 && (q & 62914560) === q && 300 > ut() - vi)
          ? (Y & 2) === 0 && au(l, 0)
          : (hi |= a),
        Pa === q && (Pa = 0)),
      ft(l));
  }
  function ed(l, t) {
    (t === 0 && (t = Pi()), (l = Ga(l, t)), l !== null && (vu(l, t), ft(l)));
  }
  function Mm(l) {
    var t = l.memoizedState,
      a = 0;
    (t !== null && (a = t.retryLane), ed(l, a));
  }
  function Em(l, t) {
    var a = 0;
    switch (l.tag) {
      case 13:
        var u = l.stateNode,
          e = l.memoizedState;
        e !== null && (a = e.retryLane);
        break;
      case 19:
        u = l.stateNode;
        break;
      case 22:
        u = l.stateNode._retryCache;
        break;
      default:
        throw Error(b(314));
    }
    (u !== null && u.delete(t), ed(l, a));
  }
  function Dm(l, t) {
    return _n(l, t);
  }
  var mn = null,
    eu = null,
    pi = !1,
    vn = !1,
    zi = !1,
    xa = 0;
  function ft(l) {
    (l !== eu &&
      l.next === null &&
      (eu === null ? (mn = eu = l) : (eu = eu.next = l)),
      (vn = !0),
      pi || ((pi = !0), Om()));
  }
  function $u(l, t) {
    if (!zi && vn) {
      zi = !0;
      do
        for (var a = !1, u = mn; u !== null; ) {
          if (l !== 0) {
            var e = u.pendingLanes;
            if (e === 0) var n = 0;
            else {
              var c = u.suspendedLanes,
                i = u.pingedLanes;
              ((n = (1 << (31 - jl(42 | l) + 1)) - 1),
                (n &= e & ~(c & ~i)),
                (n = n & 201326741 ? (n & 201326741) | 1 : n ? n | 2 : 0));
            }
            n !== 0 && ((a = !0), fd(u, n));
          } else
            ((n = q),
              (n = ge(
                u,
                u === L ? n : 0,
                u.cancelPendingCommit !== null || u.timeoutHandle !== -1,
              )),
              (n & 3) === 0 || mu(u, n) || ((a = !0), fd(u, n)));
          u = u.next;
        }
      while (a);
      zi = !1;
    }
  }
  function jm() {
    nd();
  }
  function nd() {
    vn = pi = !1;
    var l = 0;
    xa !== 0 && (Gm() && (l = xa), (xa = 0));
    for (var t = ut(), a = null, u = mn; u !== null; ) {
      var e = u.next,
        n = cd(u, t);
      (n === 0
        ? ((u.next = null),
          a === null ? (mn = e) : (a.next = e),
          e === null && (eu = a))
        : ((a = u), (l !== 0 || (n & 3) !== 0) && (vn = !0)),
        (u = e));
    }
    $u(l);
  }
  function cd(l, t) {
    for (
      var a = l.suspendedLanes,
        u = l.pingedLanes,
        e = l.expirationTimes,
        n = l.pendingLanes & -62914561;
      0 < n;

    ) {
      var c = 31 - jl(n),
        i = 1 << c,
        f = e[c];
      (f === -1
        ? ((i & a) === 0 || (i & u) !== 0) && (e[c] = th(i, t))
        : f <= t && (l.expiredLanes |= i),
        (n &= ~i));
    }
    if (
      ((t = L),
      (a = q),
      (a = ge(
        l,
        l === t ? a : 0,
        l.cancelPendingCommit !== null || l.timeoutHandle !== -1,
      )),
      (u = l.callbackNode),
      a === 0 ||
        (l === t && (G === 2 || G === 9)) ||
        l.cancelPendingCommit !== null)
    )
      return (
        u !== null && u !== null && qn(u),
        (l.callbackNode = null),
        (l.callbackPriority = 0)
      );
    if ((a & 3) === 0 || mu(l, a)) {
      if (((t = a & -a), t === l.callbackPriority)) return t;
      switch ((u !== null && qn(u), Yn(a))) {
        case 2:
        case 8:
          a = $i;
          break;
        case 32:
          a = ye;
          break;
        case 268435456:
          a = Fi;
          break;
        default:
          a = ye;
      }
      return (
        (u = id.bind(null, l)),
        (a = _n(a, u)),
        (l.callbackPriority = t),
        (l.callbackNode = a),
        t
      );
    }
    return (
      u !== null && u !== null && qn(u),
      (l.callbackPriority = 2),
      (l.callbackNode = null),
      2
    );
  }
  function id(l, t) {
    if (yl !== 0 && yl !== 5)
      return ((l.callbackNode = null), (l.callbackPriority = 0), null);
    var a = l.callbackNode;
    if (hn() && l.callbackNode !== a) return null;
    var u = q;
    return (
      (u = ge(
        l,
        l === L ? u : 0,
        l.cancelPendingCommit !== null || l.timeoutHandle !== -1,
      )),
      u === 0
        ? null
        : (C0(l, u, t),
          cd(l, ut()),
          l.callbackNode != null && l.callbackNode === a
            ? id.bind(null, l)
            : null)
    );
  }
  function fd(l, t) {
    if (hn()) return null;
    C0(l, t, !0);
  }
  function Om() {
    Qm(function () {
      (Y & 6) !== 0 ? _n(ki, jm) : nd();
    });
  }
  function Ni() {
    return (xa === 0 && (xa = Ii()), xa);
  }
  function sd(l) {
    return l == null || typeof l == 'symbol' || typeof l == 'boolean'
      ? null
      : typeof l == 'function'
        ? l
        : Ne('' + l);
  }
  function dd(l, t) {
    var a = t.ownerDocument.createElement('input');
    return (
      (a.name = t.name),
      (a.value = t.value),
      l.id && a.setAttribute('form', l.id),
      t.parentNode.insertBefore(a, t),
      (l = new FormData(l)),
      a.parentNode.removeChild(a),
      l
    );
  }
  function Um(l, t, a, u, e) {
    if (t === 'submit' && a && a.stateNode === e) {
      var n = sd((e[zl] || null).action),
        c = u.submitter;
      c &&
        ((t = (t = c[zl] || null)
          ? sd(t.formAction)
          : c.getAttribute('formAction')),
        t !== null && ((n = t), (c = null)));
      var i = new Ee('action', 'action', null, u, e);
      l.push({
        event: i,
        listeners: [
          {
            instance: null,
            listener: function () {
              if (u.defaultPrevented) {
                if (xa !== 0) {
                  var f = c ? dd(e, c) : new FormData(e);
                  Cc(
                    a,
                    { pending: !0, data: f, method: e.method, action: n },
                    null,
                    f,
                  );
                }
              } else
                typeof n == 'function' &&
                  (i.preventDefault(),
                  (f = c ? dd(e, c) : new FormData(e)),
                  Cc(
                    a,
                    { pending: !0, data: f, method: e.method, action: n },
                    n,
                    f,
                  ));
            },
            currentTarget: e,
          },
        ],
      });
    }
  }
  for (var Ai = 0; Ai < fc.length; Ai++) {
    var Ti = fc[Ai],
      Hm = Ti.toLowerCase(),
      _m = Ti[0].toUpperCase() + Ti.slice(1);
    Il(Hm, 'on' + _m);
  }
  (Il(Cf, 'onAnimationEnd'),
    Il(Kf, 'onAnimationIteration'),
    Il(Lf, 'onAnimationStart'),
    Il('dblclick', 'onDoubleClick'),
    Il('focusin', 'onFocus'),
    Il('focusout', 'onBlur'),
    Il($h, 'onTransitionRun'),
    Il(Fh, 'onTransitionStart'),
    Il(Ih, 'onTransitionCancel'),
    Il(Jf, 'onTransitionEnd'),
    Da('onMouseEnter', ['mouseout', 'mouseover']),
    Da('onMouseLeave', ['mouseout', 'mouseover']),
    Da('onPointerEnter', ['pointerout', 'pointerover']),
    Da('onPointerLeave', ['pointerout', 'pointerover']),
    ua(
      'onChange',
      'change click focusin focusout input keydown keyup selectionchange'.split(
        ' ',
      ),
    ),
    ua(
      'onSelect',
      'focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange'.split(
        ' ',
      ),
    ),
    ua('onBeforeInput', ['compositionend', 'keypress', 'textInput', 'paste']),
    ua(
      'onCompositionEnd',
      'compositionend focusout keydown keypress keyup mousedown'.split(' '),
    ),
    ua(
      'onCompositionStart',
      'compositionstart focusout keydown keypress keyup mousedown'.split(' '),
    ),
    ua(
      'onCompositionUpdate',
      'compositionupdate focusout keydown keypress keyup mousedown'.split(' '),
    ));
  var Fu =
      'abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting'.split(
        ' ',
      ),
    qm = new Set(
      'beforetoggle cancel close invalid load scroll scrollend toggle'
        .split(' ')
        .concat(Fu),
    );
  function hd(l, t) {
    t = (t & 4) !== 0;
    for (var a = 0; a < l.length; a++) {
      var u = l[a],
        e = u.event;
      u = u.listeners;
      l: {
        var n = void 0;
        if (t)
          for (var c = u.length - 1; 0 <= c; c--) {
            var i = u[c],
              f = i.instance,
              v = i.currentTarget;
            if (((i = i.listener), f !== n && e.isPropagationStopped()))
              break l;
            ((n = i), (e.currentTarget = v));
            try {
              n(e);
            } catch (o) {
              Pe(o);
            }
            ((e.currentTarget = null), (n = f));
          }
        else
          for (c = 0; c < u.length; c++) {
            if (
              ((i = u[c]),
              (f = i.instance),
              (v = i.currentTarget),
              (i = i.listener),
              f !== n && e.isPropagationStopped())
            )
              break l;
            ((n = i), (e.currentTarget = v));
            try {
              n(e);
            } catch (o) {
              Pe(o);
            }
            ((e.currentTarget = null), (n = f));
          }
      }
    }
  }
  function _(l, t) {
    var a = t[Gn];
    a === void 0 && (a = t[Gn] = new Set());
    var u = l + '__bubble';
    a.has(u) || (md(t, l, 2, !1), a.add(u));
  }
  function Mi(l, t, a) {
    var u = 0;
    (t && (u |= 4), md(a, l, u, t));
  }
  var rn = '_reactListening' + Math.random().toString(36).slice(2);
  function Ei(l) {
    if (!l[rn]) {
      ((l[rn] = !0),
        ef.forEach(function (a) {
          a !== 'selectionchange' && (qm.has(a) || Mi(a, !1, l), Mi(a, !0, l));
        }));
      var t = l.nodeType === 9 ? l : l.ownerDocument;
      t === null || t[rn] || ((t[rn] = !0), Mi('selectionchange', !1, t));
    }
  }
  function md(l, t, a, u) {
    switch (Bd(t)) {
      case 2:
        var e = iv;
        break;
      case 8:
        e = fv;
        break;
      default:
        e = Zi;
    }
    ((a = e.bind(null, t, a, l)),
      (e = void 0),
      !kn ||
        (t !== 'touchstart' && t !== 'touchmove' && t !== 'wheel') ||
        (e = !0),
      u
        ? e !== void 0
          ? l.addEventListener(t, a, { capture: !0, passive: e })
          : l.addEventListener(t, a, !0)
        : e !== void 0
          ? l.addEventListener(t, a, { passive: e })
          : l.addEventListener(t, a, !1));
  }
  function Di(l, t, a, u, e) {
    var n = u;
    if ((t & 1) === 0 && (t & 2) === 0 && u !== null)
      l: for (;;) {
        if (u === null) return;
        var c = u.tag;
        if (c === 3 || c === 4) {
          var i = u.stateNode.containerInfo;
          if (i === e) break;
          if (c === 4)
            for (c = u.return; c !== null; ) {
              var f = c.tag;
              if ((f === 3 || f === 4) && c.stateNode.containerInfo === e)
                return;
              c = c.return;
            }
          for (; i !== null; ) {
            if (((c = Ta(i)), c === null)) return;
            if (((f = c.tag), f === 5 || f === 6 || f === 26 || f === 27)) {
              u = n = c;
              continue l;
            }
            i = i.parentNode;
          }
        }
        u = u.return;
      }
    xf(function () {
      var v = n,
        o = wn(a),
        S = [];
      l: {
        var r = wf.get(l);
        if (r !== void 0) {
          var y = Ee,
            E = l;
          switch (l) {
            case 'keypress':
              if (Te(a) === 0) break l;
            case 'keydown':
            case 'keyup':
              y = Dh;
              break;
            case 'focusin':
              ((E = 'focus'), (y = Pn));
              break;
            case 'focusout':
              ((E = 'blur'), (y = Pn));
              break;
            case 'beforeblur':
            case 'afterblur':
              y = Pn;
              break;
            case 'click':
              if (a.button === 2) break l;
            case 'auxclick':
            case 'dblclick':
            case 'mousedown':
            case 'mousemove':
            case 'mouseup':
            case 'mouseout':
            case 'mouseover':
            case 'contextmenu':
              y = zf;
              break;
            case 'drag':
            case 'dragend':
            case 'dragenter':
            case 'dragexit':
            case 'dragleave':
            case 'dragover':
            case 'dragstart':
            case 'drop':
              y = oh;
              break;
            case 'touchcancel':
            case 'touchend':
            case 'touchmove':
            case 'touchstart':
              y = Uh;
              break;
            case Cf:
            case Kf:
            case Lf:
              y = xh;
              break;
            case Jf:
              y = _h;
              break;
            case 'scroll':
            case 'scrollend':
              y = rh;
              break;
            case 'wheel':
              y = Rh;
              break;
            case 'copy':
            case 'cut':
            case 'paste':
              y = ph;
              break;
            case 'gotpointercapture':
            case 'lostpointercapture':
            case 'pointercancel':
            case 'pointerdown':
            case 'pointermove':
            case 'pointerout':
            case 'pointerover':
            case 'pointerup':
              y = Af;
              break;
            case 'toggle':
            case 'beforetoggle':
              y = Yh;
          }
          var T = (t & 4) !== 0,
            V = !T && (l === 'scroll' || l === 'scrollend'),
            d = T ? (r !== null ? r + 'Capture' : null) : r;
          T = [];
          for (var s = v, m; s !== null; ) {
            var g = s;
            if (
              ((m = g.stateNode),
              (g = g.tag),
              (g !== 5 && g !== 26 && g !== 27) ||
                m === null ||
                d === null ||
                ((g = ou(s, d)), g != null && T.push(Iu(s, g, m))),
              V)
            )
              break;
            s = s.return;
          }
          0 < T.length &&
            ((r = new y(r, E, null, a, o)), S.push({ event: r, listeners: T }));
        }
      }
      if ((t & 7) === 0) {
        l: {
          if (
            ((r = l === 'mouseover' || l === 'pointerover'),
            (y = l === 'mouseout' || l === 'pointerout'),
            r &&
              a !== Jn &&
              (E = a.relatedTarget || a.fromElement) &&
              (Ta(E) || E[Aa]))
          )
            break l;
          if (
            (y || r) &&
            ((r =
              o.window === o
                ? o
                : (r = o.ownerDocument)
                  ? r.defaultView || r.parentWindow
                  : window),
            y
              ? ((E = a.relatedTarget || a.toElement),
                (y = v),
                (E = E ? Ta(E) : null),
                E !== null &&
                  ((V = j(E)),
                  (T = E.tag),
                  E !== V || (T !== 5 && T !== 27 && T !== 6)) &&
                  (E = null))
              : ((y = null), (E = v)),
            y !== E)
          ) {
            if (
              ((T = zf),
              (g = 'onMouseLeave'),
              (d = 'onMouseEnter'),
              (s = 'mouse'),
              (l === 'pointerout' || l === 'pointerover') &&
                ((T = Af),
                (g = 'onPointerLeave'),
                (d = 'onPointerEnter'),
                (s = 'pointer')),
              (V = y == null ? r : yu(y)),
              (m = E == null ? r : yu(E)),
              (r = new T(g, s + 'leave', y, a, o)),
              (r.target = V),
              (r.relatedTarget = m),
              (g = null),
              Ta(o) === v &&
                ((T = new T(d, s + 'enter', E, a, o)),
                (T.target = m),
                (T.relatedTarget = V),
                (g = T)),
              (V = g),
              y && E)
            )
              t: {
                for (T = y, d = E, s = 0, m = T; m; m = nu(m)) s++;
                for (m = 0, g = d; g; g = nu(g)) m++;
                for (; 0 < s - m; ) ((T = nu(T)), s--);
                for (; 0 < m - s; ) ((d = nu(d)), m--);
                for (; s--; ) {
                  if (T === d || (d !== null && T === d.alternate)) break t;
                  ((T = nu(T)), (d = nu(d)));
                }
                T = null;
              }
            else T = null;
            (y !== null && vd(S, r, y, T, !1),
              E !== null && V !== null && vd(S, V, E, T, !0));
          }
        }
        l: {
          if (
            ((r = v ? yu(v) : window),
            (y = r.nodeName && r.nodeName.toLowerCase()),
            y === 'select' || (y === 'input' && r.type === 'file'))
          )
            var z = Hf;
          else if (Of(r))
            if (_f) z = wh;
            else {
              z = Lh;
              var U = Kh;
            }
          else
            ((y = r.nodeName),
              !y ||
              y.toLowerCase() !== 'input' ||
              (r.type !== 'checkbox' && r.type !== 'radio')
                ? v && Ln(v.elementType) && (z = Hf)
                : (z = Jh));
          if (z && (z = z(l, v))) {
            Uf(S, z, a, o);
            break l;
          }
          (U && U(l, r, v),
            l === 'focusout' &&
              v &&
              r.type === 'number' &&
              v.memoizedProps.value != null &&
              Kn(r, 'number', r.value));
        }
        switch (((U = v ? yu(v) : window), l)) {
          case 'focusin':
            (Of(U) || U.contentEditable === 'true') &&
              ((Ra = U), (nc = v), (Au = null));
            break;
          case 'focusout':
            Au = nc = Ra = null;
            break;
          case 'mousedown':
            cc = !0;
            break;
          case 'contextmenu':
          case 'mouseup':
          case 'dragend':
            ((cc = !1), Zf(S, a, o));
            break;
          case 'selectionchange':
            if (kh) break;
          case 'keydown':
          case 'keyup':
            Zf(S, a, o);
        }
        var N;
        if (tc)
          l: {
            switch (l) {
              case 'compositionstart':
                var M = 'onCompositionStart';
                break l;
              case 'compositionend':
                M = 'onCompositionEnd';
                break l;
              case 'compositionupdate':
                M = 'onCompositionUpdate';
                break l;
            }
            M = void 0;
          }
        else
          qa
            ? Df(l, a) && (M = 'onCompositionEnd')
            : l === 'keydown' &&
              a.keyCode === 229 &&
              (M = 'onCompositionStart');
        (M &&
          (Tf &&
            a.locale !== 'ko' &&
            (qa || M !== 'onCompositionStart'
              ? M === 'onCompositionEnd' && qa && (N = Sf())
              : ((Ht = o),
                ($n = 'value' in Ht ? Ht.value : Ht.textContent),
                (qa = !0))),
          (U = yn(v, M)),
          0 < U.length &&
            ((M = new Nf(M, l, null, a, o)),
            S.push({ event: M, listeners: U }),
            N ? (M.data = N) : ((N = jf(a)), N !== null && (M.data = N)))),
          (N = Xh ? Qh(l, a) : Zh(l, a)) &&
            ((M = yn(v, 'onBeforeInput')),
            0 < M.length &&
              ((U = new Nf('onBeforeInput', 'beforeinput', null, a, o)),
              S.push({ event: U, listeners: M }),
              (U.data = N))),
          Um(S, l, v, a, o));
      }
      hd(S, t);
    });
  }
  function Iu(l, t, a) {
    return { instance: l, listener: t, currentTarget: a };
  }
  function yn(l, t) {
    for (var a = t + 'Capture', u = []; l !== null; ) {
      var e = l,
        n = e.stateNode;
      if (
        ((e = e.tag),
        (e !== 5 && e !== 26 && e !== 27) ||
          n === null ||
          ((e = ou(l, a)),
          e != null && u.unshift(Iu(l, e, n)),
          (e = ou(l, t)),
          e != null && u.push(Iu(l, e, n))),
        l.tag === 3)
      )
        return u;
      l = l.return;
    }
    return [];
  }
  function nu(l) {
    if (l === null) return null;
    do l = l.return;
    while (l && l.tag !== 5 && l.tag !== 27);
    return l || null;
  }
  function vd(l, t, a, u, e) {
    for (var n = t._reactName, c = []; a !== null && a !== u; ) {
      var i = a,
        f = i.alternate,
        v = i.stateNode;
      if (((i = i.tag), f !== null && f === u)) break;
      ((i !== 5 && i !== 26 && i !== 27) ||
        v === null ||
        ((f = v),
        e
          ? ((v = ou(a, n)), v != null && c.unshift(Iu(a, v, f)))
          : e || ((v = ou(a, n)), v != null && c.push(Iu(a, v, f)))),
        (a = a.return));
    }
    c.length !== 0 && l.push({ event: t, listeners: c });
  }
  var Rm = /\r\n?/g,
    Bm = /\u0000|\uFFFD/g;
  function rd(l) {
    return (typeof l == 'string' ? l : '' + l)
      .replace(
        Rm,
        `
`,
      )
      .replace(Bm, '');
  }
  function yd(l, t) {
    return ((t = rd(t)), rd(l) === t);
  }
  function on() {}
  function Z(l, t, a, u, e, n) {
    switch (a) {
      case 'children':
        typeof u == 'string'
          ? t === 'body' || (t === 'textarea' && u === '') || Ua(l, u)
          : (typeof u == 'number' || typeof u == 'bigint') &&
            t !== 'body' &&
            Ua(l, '' + u);
        break;
      case 'className':
        Se(l, 'class', u);
        break;
      case 'tabIndex':
        Se(l, 'tabindex', u);
        break;
      case 'dir':
      case 'role':
      case 'viewBox':
      case 'width':
      case 'height':
        Se(l, a, u);
        break;
      case 'style':
        bf(l, u, n);
        break;
      case 'data':
        if (t !== 'object') {
          Se(l, 'data', u);
          break;
        }
      case 'src':
      case 'href':
        if (u === '' && (t !== 'a' || a !== 'href')) {
          l.removeAttribute(a);
          break;
        }
        if (
          u == null ||
          typeof u == 'function' ||
          typeof u == 'symbol' ||
          typeof u == 'boolean'
        ) {
          l.removeAttribute(a);
          break;
        }
        ((u = Ne('' + u)), l.setAttribute(a, u));
        break;
      case 'action':
      case 'formAction':
        if (typeof u == 'function') {
          l.setAttribute(
            a,
            "javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')",
          );
          break;
        } else
          typeof n == 'function' &&
            (a === 'formAction'
              ? (t !== 'input' && Z(l, t, 'name', e.name, e, null),
                Z(l, t, 'formEncType', e.formEncType, e, null),
                Z(l, t, 'formMethod', e.formMethod, e, null),
                Z(l, t, 'formTarget', e.formTarget, e, null))
              : (Z(l, t, 'encType', e.encType, e, null),
                Z(l, t, 'method', e.method, e, null),
                Z(l, t, 'target', e.target, e, null)));
        if (u == null || typeof u == 'symbol' || typeof u == 'boolean') {
          l.removeAttribute(a);
          break;
        }
        ((u = Ne('' + u)), l.setAttribute(a, u));
        break;
      case 'onClick':
        u != null && (l.onclick = on);
        break;
      case 'onScroll':
        u != null && _('scroll', l);
        break;
      case 'onScrollEnd':
        u != null && _('scrollend', l);
        break;
      case 'dangerouslySetInnerHTML':
        if (u != null) {
          if (typeof u != 'object' || !('__html' in u)) throw Error(b(61));
          if (((a = u.__html), a != null)) {
            if (e.children != null) throw Error(b(60));
            l.innerHTML = a;
          }
        }
        break;
      case 'multiple':
        l.multiple = u && typeof u != 'function' && typeof u != 'symbol';
        break;
      case 'muted':
        l.muted = u && typeof u != 'function' && typeof u != 'symbol';
        break;
      case 'suppressContentEditableWarning':
      case 'suppressHydrationWarning':
      case 'defaultValue':
      case 'defaultChecked':
      case 'innerHTML':
      case 'ref':
        break;
      case 'autoFocus':
        break;
      case 'xlinkHref':
        if (
          u == null ||
          typeof u == 'function' ||
          typeof u == 'boolean' ||
          typeof u == 'symbol'
        ) {
          l.removeAttribute('xlink:href');
          break;
        }
        ((a = Ne('' + u)),
          l.setAttributeNS('http://www.w3.org/1999/xlink', 'xlink:href', a));
        break;
      case 'contentEditable':
      case 'spellCheck':
      case 'draggable':
      case 'value':
      case 'autoReverse':
      case 'externalResourcesRequired':
      case 'focusable':
      case 'preserveAlpha':
        u != null && typeof u != 'function' && typeof u != 'symbol'
          ? l.setAttribute(a, '' + u)
          : l.removeAttribute(a);
        break;
      case 'inert':
      case 'allowFullScreen':
      case 'async':
      case 'autoPlay':
      case 'controls':
      case 'default':
      case 'defer':
      case 'disabled':
      case 'disablePictureInPicture':
      case 'disableRemotePlayback':
      case 'formNoValidate':
      case 'hidden':
      case 'loop':
      case 'noModule':
      case 'noValidate':
      case 'open':
      case 'playsInline':
      case 'readOnly':
      case 'required':
      case 'reversed':
      case 'scoped':
      case 'seamless':
      case 'itemScope':
        u && typeof u != 'function' && typeof u != 'symbol'
          ? l.setAttribute(a, '')
          : l.removeAttribute(a);
        break;
      case 'capture':
      case 'download':
        u === !0
          ? l.setAttribute(a, '')
          : u !== !1 &&
              u != null &&
              typeof u != 'function' &&
              typeof u != 'symbol'
            ? l.setAttribute(a, u)
            : l.removeAttribute(a);
        break;
      case 'cols':
      case 'rows':
      case 'size':
      case 'span':
        u != null &&
        typeof u != 'function' &&
        typeof u != 'symbol' &&
        !isNaN(u) &&
        1 <= u
          ? l.setAttribute(a, u)
          : l.removeAttribute(a);
        break;
      case 'rowSpan':
      case 'start':
        u == null || typeof u == 'function' || typeof u == 'symbol' || isNaN(u)
          ? l.removeAttribute(a)
          : l.setAttribute(a, u);
        break;
      case 'popover':
        (_('beforetoggle', l), _('toggle', l), xe(l, 'popover', u));
        break;
      case 'xlinkActuate':
        mt(l, 'http://www.w3.org/1999/xlink', 'xlink:actuate', u);
        break;
      case 'xlinkArcrole':
        mt(l, 'http://www.w3.org/1999/xlink', 'xlink:arcrole', u);
        break;
      case 'xlinkRole':
        mt(l, 'http://www.w3.org/1999/xlink', 'xlink:role', u);
        break;
      case 'xlinkShow':
        mt(l, 'http://www.w3.org/1999/xlink', 'xlink:show', u);
        break;
      case 'xlinkTitle':
        mt(l, 'http://www.w3.org/1999/xlink', 'xlink:title', u);
        break;
      case 'xlinkType':
        mt(l, 'http://www.w3.org/1999/xlink', 'xlink:type', u);
        break;
      case 'xmlBase':
        mt(l, 'http://www.w3.org/XML/1998/namespace', 'xml:base', u);
        break;
      case 'xmlLang':
        mt(l, 'http://www.w3.org/XML/1998/namespace', 'xml:lang', u);
        break;
      case 'xmlSpace':
        mt(l, 'http://www.w3.org/XML/1998/namespace', 'xml:space', u);
        break;
      case 'is':
        xe(l, 'is', u);
        break;
      case 'innerText':
      case 'textContent':
        break;
      default:
        (!(2 < a.length) ||
          (a[0] !== 'o' && a[0] !== 'O') ||
          (a[1] !== 'n' && a[1] !== 'N')) &&
          ((a = mh.get(a) || a), xe(l, a, u));
    }
  }
  function ji(l, t, a, u, e, n) {
    switch (a) {
      case 'style':
        bf(l, u, n);
        break;
      case 'dangerouslySetInnerHTML':
        if (u != null) {
          if (typeof u != 'object' || !('__html' in u)) throw Error(b(61));
          if (((a = u.__html), a != null)) {
            if (e.children != null) throw Error(b(60));
            l.innerHTML = a;
          }
        }
        break;
      case 'children':
        typeof u == 'string'
          ? Ua(l, u)
          : (typeof u == 'number' || typeof u == 'bigint') && Ua(l, '' + u);
        break;
      case 'onScroll':
        u != null && _('scroll', l);
        break;
      case 'onScrollEnd':
        u != null && _('scrollend', l);
        break;
      case 'onClick':
        u != null && (l.onclick = on);
        break;
      case 'suppressContentEditableWarning':
      case 'suppressHydrationWarning':
      case 'innerHTML':
      case 'ref':
        break;
      case 'innerText':
      case 'textContent':
        break;
      default:
        if (!nf.hasOwnProperty(a))
          l: {
            if (
              a[0] === 'o' &&
              a[1] === 'n' &&
              ((e = a.endsWith('Capture')),
              (t = a.slice(2, e ? a.length - 7 : void 0)),
              (n = l[zl] || null),
              (n = n != null ? n[a] : null),
              typeof n == 'function' && l.removeEventListener(t, n, e),
              typeof u == 'function')
            ) {
              (typeof n != 'function' &&
                n !== null &&
                (a in l
                  ? (l[a] = null)
                  : l.hasAttribute(a) && l.removeAttribute(a)),
                l.addEventListener(t, u, e));
              break l;
            }
            a in l
              ? (l[a] = u)
              : u === !0
                ? l.setAttribute(a, '')
                : xe(l, a, u);
          }
    }
  }
  function ol(l, t, a) {
    switch (t) {
      case 'div':
      case 'span':
      case 'svg':
      case 'path':
      case 'a':
      case 'g':
      case 'p':
      case 'li':
        break;
      case 'img':
        (_('error', l), _('load', l));
        var u = !1,
          e = !1,
          n;
        for (n in a)
          if (a.hasOwnProperty(n)) {
            var c = a[n];
            if (c != null)
              switch (n) {
                case 'src':
                  u = !0;
                  break;
                case 'srcSet':
                  e = !0;
                  break;
                case 'children':
                case 'dangerouslySetInnerHTML':
                  throw Error(b(137, t));
                default:
                  Z(l, t, n, c, a, null);
              }
          }
        (e && Z(l, t, 'srcSet', a.srcSet, a, null),
          u && Z(l, t, 'src', a.src, a, null));
        return;
      case 'input':
        _('invalid', l);
        var i = (n = c = e = null),
          f = null,
          v = null;
        for (u in a)
          if (a.hasOwnProperty(u)) {
            var o = a[u];
            if (o != null)
              switch (u) {
                case 'name':
                  e = o;
                  break;
                case 'type':
                  c = o;
                  break;
                case 'checked':
                  f = o;
                  break;
                case 'defaultChecked':
                  v = o;
                  break;
                case 'value':
                  n = o;
                  break;
                case 'defaultValue':
                  i = o;
                  break;
                case 'children':
                case 'dangerouslySetInnerHTML':
                  if (o != null) throw Error(b(137, t));
                  break;
                default:
                  Z(l, t, u, o, a, null);
              }
          }
        (vf(l, n, i, f, v, c, e, !1), pe(l));
        return;
      case 'select':
        (_('invalid', l), (u = c = n = null));
        for (e in a)
          if (a.hasOwnProperty(e) && ((i = a[e]), i != null))
            switch (e) {
              case 'value':
                n = i;
                break;
              case 'defaultValue':
                c = i;
                break;
              case 'multiple':
                u = i;
              default:
                Z(l, t, e, i, a, null);
            }
        ((t = n),
          (a = c),
          (l.multiple = !!u),
          t != null ? Oa(l, !!u, t, !1) : a != null && Oa(l, !!u, a, !0));
        return;
      case 'textarea':
        (_('invalid', l), (n = e = u = null));
        for (c in a)
          if (a.hasOwnProperty(c) && ((i = a[c]), i != null))
            switch (c) {
              case 'value':
                u = i;
                break;
              case 'defaultValue':
                e = i;
                break;
              case 'children':
                n = i;
                break;
              case 'dangerouslySetInnerHTML':
                if (i != null) throw Error(b(91));
                break;
              default:
                Z(l, t, c, i, a, null);
            }
        (yf(l, u, e, n), pe(l));
        return;
      case 'option':
        for (f in a)
          if (a.hasOwnProperty(f) && ((u = a[f]), u != null))
            switch (f) {
              case 'selected':
                l.selected =
                  u && typeof u != 'function' && typeof u != 'symbol';
                break;
              default:
                Z(l, t, f, u, a, null);
            }
        return;
      case 'dialog':
        (_('beforetoggle', l), _('toggle', l), _('cancel', l), _('close', l));
        break;
      case 'iframe':
      case 'object':
        _('load', l);
        break;
      case 'video':
      case 'audio':
        for (u = 0; u < Fu.length; u++) _(Fu[u], l);
        break;
      case 'image':
        (_('error', l), _('load', l));
        break;
      case 'details':
        _('toggle', l);
        break;
      case 'embed':
      case 'source':
      case 'link':
        (_('error', l), _('load', l));
      case 'area':
      case 'base':
      case 'br':
      case 'col':
      case 'hr':
      case 'keygen':
      case 'meta':
      case 'param':
      case 'track':
      case 'wbr':
      case 'menuitem':
        for (v in a)
          if (a.hasOwnProperty(v) && ((u = a[v]), u != null))
            switch (v) {
              case 'children':
              case 'dangerouslySetInnerHTML':
                throw Error(b(137, t));
              default:
                Z(l, t, v, u, a, null);
            }
        return;
      default:
        if (Ln(t)) {
          for (o in a)
            a.hasOwnProperty(o) &&
              ((u = a[o]), u !== void 0 && ji(l, t, o, u, a, void 0));
          return;
        }
    }
    for (i in a)
      a.hasOwnProperty(i) && ((u = a[i]), u != null && Z(l, t, i, u, a, null));
  }
  function Ym(l, t, a, u) {
    switch (t) {
      case 'div':
      case 'span':
      case 'svg':
      case 'path':
      case 'a':
      case 'g':
      case 'p':
      case 'li':
        break;
      case 'input':
        var e = null,
          n = null,
          c = null,
          i = null,
          f = null,
          v = null,
          o = null;
        for (y in a) {
          var S = a[y];
          if (a.hasOwnProperty(y) && S != null)
            switch (y) {
              case 'checked':
                break;
              case 'value':
                break;
              case 'defaultValue':
                f = S;
              default:
                u.hasOwnProperty(y) || Z(l, t, y, null, u, S);
            }
        }
        for (var r in u) {
          var y = u[r];
          if (((S = a[r]), u.hasOwnProperty(r) && (y != null || S != null)))
            switch (r) {
              case 'type':
                n = y;
                break;
              case 'name':
                e = y;
                break;
              case 'checked':
                v = y;
                break;
              case 'defaultChecked':
                o = y;
                break;
              case 'value':
                c = y;
                break;
              case 'defaultValue':
                i = y;
                break;
              case 'children':
              case 'dangerouslySetInnerHTML':
                if (y != null) throw Error(b(137, t));
                break;
              default:
                y !== S && Z(l, t, r, y, u, S);
            }
        }
        Cn(l, c, i, f, v, o, n, e);
        return;
      case 'select':
        y = c = i = r = null;
        for (n in a)
          if (((f = a[n]), a.hasOwnProperty(n) && f != null))
            switch (n) {
              case 'value':
                break;
              case 'multiple':
                y = f;
              default:
                u.hasOwnProperty(n) || Z(l, t, n, null, u, f);
            }
        for (e in u)
          if (
            ((n = u[e]),
            (f = a[e]),
            u.hasOwnProperty(e) && (n != null || f != null))
          )
            switch (e) {
              case 'value':
                r = n;
                break;
              case 'defaultValue':
                i = n;
                break;
              case 'multiple':
                c = n;
              default:
                n !== f && Z(l, t, e, n, u, f);
            }
        ((t = i),
          (a = c),
          (u = y),
          r != null
            ? Oa(l, !!a, r, !1)
            : !!u != !!a &&
              (t != null ? Oa(l, !!a, t, !0) : Oa(l, !!a, a ? [] : '', !1)));
        return;
      case 'textarea':
        y = r = null;
        for (i in a)
          if (
            ((e = a[i]),
            a.hasOwnProperty(i) && e != null && !u.hasOwnProperty(i))
          )
            switch (i) {
              case 'value':
                break;
              case 'children':
                break;
              default:
                Z(l, t, i, null, u, e);
            }
        for (c in u)
          if (
            ((e = u[c]),
            (n = a[c]),
            u.hasOwnProperty(c) && (e != null || n != null))
          )
            switch (c) {
              case 'value':
                r = e;
                break;
              case 'defaultValue':
                y = e;
                break;
              case 'children':
                break;
              case 'dangerouslySetInnerHTML':
                if (e != null) throw Error(b(91));
                break;
              default:
                e !== n && Z(l, t, c, e, u, n);
            }
        rf(l, r, y);
        return;
      case 'option':
        for (var E in a)
          if (
            ((r = a[E]),
            a.hasOwnProperty(E) && r != null && !u.hasOwnProperty(E))
          )
            switch (E) {
              case 'selected':
                l.selected = !1;
                break;
              default:
                Z(l, t, E, null, u, r);
            }
        for (f in u)
          if (
            ((r = u[f]),
            (y = a[f]),
            u.hasOwnProperty(f) && r !== y && (r != null || y != null))
          )
            switch (f) {
              case 'selected':
                l.selected =
                  r && typeof r != 'function' && typeof r != 'symbol';
                break;
              default:
                Z(l, t, f, r, u, y);
            }
        return;
      case 'img':
      case 'link':
      case 'area':
      case 'base':
      case 'br':
      case 'col':
      case 'embed':
      case 'hr':
      case 'keygen':
      case 'meta':
      case 'param':
      case 'source':
      case 'track':
      case 'wbr':
      case 'menuitem':
        for (var T in a)
          ((r = a[T]),
            a.hasOwnProperty(T) &&
              r != null &&
              !u.hasOwnProperty(T) &&
              Z(l, t, T, null, u, r));
        for (v in u)
          if (
            ((r = u[v]),
            (y = a[v]),
            u.hasOwnProperty(v) && r !== y && (r != null || y != null))
          )
            switch (v) {
              case 'children':
              case 'dangerouslySetInnerHTML':
                if (r != null) throw Error(b(137, t));
                break;
              default:
                Z(l, t, v, r, u, y);
            }
        return;
      default:
        if (Ln(t)) {
          for (var V in a)
            ((r = a[V]),
              a.hasOwnProperty(V) &&
                r !== void 0 &&
                !u.hasOwnProperty(V) &&
                ji(l, t, V, void 0, u, r));
          for (o in u)
            ((r = u[o]),
              (y = a[o]),
              !u.hasOwnProperty(o) ||
                r === y ||
                (r === void 0 && y === void 0) ||
                ji(l, t, o, r, u, y));
          return;
        }
    }
    for (var d in a)
      ((r = a[d]),
        a.hasOwnProperty(d) &&
          r != null &&
          !u.hasOwnProperty(d) &&
          Z(l, t, d, null, u, r));
    for (S in u)
      ((r = u[S]),
        (y = a[S]),
        !u.hasOwnProperty(S) ||
          r === y ||
          (r == null && y == null) ||
          Z(l, t, S, r, u, y));
  }
  var Oi = null,
    Ui = null;
  function bn(l) {
    return l.nodeType === 9 ? l : l.ownerDocument;
  }
  function od(l) {
    switch (l) {
      case 'http://www.w3.org/2000/svg':
        return 1;
      case 'http://www.w3.org/1998/Math/MathML':
        return 2;
      default:
        return 0;
    }
  }
  function bd(l, t) {
    if (l === 0)
      switch (t) {
        case 'svg':
          return 1;
        case 'math':
          return 2;
        default:
          return 0;
      }
    return l === 1 && t === 'foreignObject' ? 0 : l;
  }
  function Hi(l, t) {
    return (
      l === 'textarea' ||
      l === 'noscript' ||
      typeof t.children == 'string' ||
      typeof t.children == 'number' ||
      typeof t.children == 'bigint' ||
      (typeof t.dangerouslySetInnerHTML == 'object' &&
        t.dangerouslySetInnerHTML !== null &&
        t.dangerouslySetInnerHTML.__html != null)
    );
  }
  var _i = null;
  function Gm() {
    var l = window.event;
    return l && l.type === 'popstate'
      ? l === _i
        ? !1
        : ((_i = l), !0)
      : ((_i = null), !1);
  }
  var gd = typeof setTimeout == 'function' ? setTimeout : void 0,
    Xm = typeof clearTimeout == 'function' ? clearTimeout : void 0,
    xd = typeof Promise == 'function' ? Promise : void 0,
    Qm =
      typeof queueMicrotask == 'function'
        ? queueMicrotask
        : typeof xd < 'u'
          ? function (l) {
              return xd.resolve(null).then(l).catch(Zm);
            }
          : gd;
  function Zm(l) {
    setTimeout(function () {
      throw l;
    });
  }
  function Wt(l) {
    return l === 'head';
  }
  function Sd(l, t) {
    var a = t,
      u = 0,
      e = 0;
    do {
      var n = a.nextSibling;
      if ((l.removeChild(a), n && n.nodeType === 8))
        if (((a = n.data), a === '/$')) {
          if (0 < u && 8 > u) {
            a = u;
            var c = l.ownerDocument;
            if ((a & 1 && Pu(c.documentElement), a & 2 && Pu(c.body), a & 4))
              for (a = c.head, Pu(a), c = a.firstChild; c; ) {
                var i = c.nextSibling,
                  f = c.nodeName;
                (c[ru] ||
                  f === 'SCRIPT' ||
                  f === 'STYLE' ||
                  (f === 'LINK' && c.rel.toLowerCase() === 'stylesheet') ||
                  a.removeChild(c),
                  (c = i));
              }
          }
          if (e === 0) {
            (l.removeChild(n), ie(t));
            return;
          }
          e--;
        } else
          a === '$' || a === '$?' || a === '$!'
            ? e++
            : (u = a.charCodeAt(0) - 48);
      else u = 0;
      a = n;
    } while (a);
    ie(t);
  }
  function qi(l) {
    var t = l.firstChild;
    for (t && t.nodeType === 10 && (t = t.nextSibling); t; ) {
      var a = t;
      switch (((t = t.nextSibling), a.nodeName)) {
        case 'HTML':
        case 'HEAD':
        case 'BODY':
          (qi(a), Xn(a));
          continue;
        case 'SCRIPT':
        case 'STYLE':
          continue;
        case 'LINK':
          if (a.rel.toLowerCase() === 'stylesheet') continue;
      }
      l.removeChild(a);
    }
  }
  function Vm(l, t, a, u) {
    for (; l.nodeType === 1; ) {
      var e = a;
      if (l.nodeName.toLowerCase() !== t.toLowerCase()) {
        if (!u && (l.nodeName !== 'INPUT' || l.type !== 'hidden')) break;
      } else if (u) {
        if (!l[ru])
          switch (t) {
            case 'meta':
              if (!l.hasAttribute('itemprop')) break;
              return l;
            case 'link':
              if (
                ((n = l.getAttribute('rel')),
                n === 'stylesheet' && l.hasAttribute('data-precedence'))
              )
                break;
              if (
                n !== e.rel ||
                l.getAttribute('href') !==
                  (e.href == null || e.href === '' ? null : e.href) ||
                l.getAttribute('crossorigin') !==
                  (e.crossOrigin == null ? null : e.crossOrigin) ||
                l.getAttribute('title') !== (e.title == null ? null : e.title)
              )
                break;
              return l;
            case 'style':
              if (l.hasAttribute('data-precedence')) break;
              return l;
            case 'script':
              if (
                ((n = l.getAttribute('src')),
                (n !== (e.src == null ? null : e.src) ||
                  l.getAttribute('type') !== (e.type == null ? null : e.type) ||
                  l.getAttribute('crossorigin') !==
                    (e.crossOrigin == null ? null : e.crossOrigin)) &&
                  n &&
                  l.hasAttribute('async') &&
                  !l.hasAttribute('itemprop'))
              )
                break;
              return l;
            default:
              return l;
          }
      } else if (t === 'input' && l.type === 'hidden') {
        var n = e.name == null ? null : '' + e.name;
        if (e.type === 'hidden' && l.getAttribute('name') === n) return l;
      } else return l;
      if (((l = lt(l.nextSibling)), l === null)) break;
    }
    return null;
  }
  function Cm(l, t, a) {
    if (t === '') return null;
    for (; l.nodeType !== 3; )
      if (
        ((l.nodeType !== 1 || l.nodeName !== 'INPUT' || l.type !== 'hidden') &&
          !a) ||
        ((l = lt(l.nextSibling)), l === null)
      )
        return null;
    return l;
  }
  function Ri(l) {
    return (
      l.data === '$!' ||
      (l.data === '$?' && l.ownerDocument.readyState === 'complete')
    );
  }
  function Km(l, t) {
    var a = l.ownerDocument;
    if (l.data !== '$?' || a.readyState === 'complete') t();
    else {
      var u = function () {
        (t(), a.removeEventListener('DOMContentLoaded', u));
      };
      (a.addEventListener('DOMContentLoaded', u), (l._reactRetry = u));
    }
  }
  function lt(l) {
    for (; l != null; l = l.nextSibling) {
      var t = l.nodeType;
      if (t === 1 || t === 3) break;
      if (t === 8) {
        if (
          ((t = l.data),
          t === '$' || t === '$!' || t === '$?' || t === 'F!' || t === 'F')
        )
          break;
        if (t === '/$') return null;
      }
    }
    return l;
  }
  var Bi = null;
  function pd(l) {
    l = l.previousSibling;
    for (var t = 0; l; ) {
      if (l.nodeType === 8) {
        var a = l.data;
        if (a === '$' || a === '$!' || a === '$?') {
          if (t === 0) return l;
          t--;
        } else a === '/$' && t++;
      }
      l = l.previousSibling;
    }
    return null;
  }
  function zd(l, t, a) {
    switch (((t = bn(a)), l)) {
      case 'html':
        if (((l = t.documentElement), !l)) throw Error(b(452));
        return l;
      case 'head':
        if (((l = t.head), !l)) throw Error(b(453));
        return l;
      case 'body':
        if (((l = t.body), !l)) throw Error(b(454));
        return l;
      default:
        throw Error(b(451));
    }
  }
  function Pu(l) {
    for (var t = l.attributes; t.length; ) l.removeAttributeNode(t[0]);
    Xn(l);
  }
  var Wl = new Map(),
    Nd = new Set();
  function gn(l) {
    return typeof l.getRootNode == 'function'
      ? l.getRootNode()
      : l.nodeType === 9
        ? l
        : l.ownerDocument;
  }
  var Mt = p.d;
  p.d = { f: Lm, r: Jm, D: wm, C: Wm, L: km, m: $m, X: Im, S: Fm, M: Pm };
  function Lm() {
    var l = Mt.f(),
      t = sn();
    return l || t;
  }
  function Jm(l) {
    var t = Ma(l);
    t !== null && t.tag === 5 && t.type === 'form' ? Cs(t) : Mt.r(l);
  }
  var cu = typeof document > 'u' ? null : document;
  function Ad(l, t, a) {
    var u = cu;
    if (u && typeof t == 'string' && t) {
      var e = Zl(t);
      ((e = 'link[rel="' + l + '"][href="' + e + '"]'),
        typeof a == 'string' && (e += '[crossorigin="' + a + '"]'),
        Nd.has(e) ||
          (Nd.add(e),
          (l = { rel: l, crossOrigin: a, href: t }),
          u.querySelector(e) === null &&
            ((t = u.createElement('link')),
            ol(t, 'link', l),
            dl(t),
            u.head.appendChild(t))));
    }
  }
  function wm(l) {
    (Mt.D(l), Ad('dns-prefetch', l, null));
  }
  function Wm(l, t) {
    (Mt.C(l, t), Ad('preconnect', l, t));
  }
  function km(l, t, a) {
    Mt.L(l, t, a);
    var u = cu;
    if (u && l && t) {
      var e = 'link[rel="preload"][as="' + Zl(t) + '"]';
      t === 'image' && a && a.imageSrcSet
        ? ((e += '[imagesrcset="' + Zl(a.imageSrcSet) + '"]'),
          typeof a.imageSizes == 'string' &&
            (e += '[imagesizes="' + Zl(a.imageSizes) + '"]'))
        : (e += '[href="' + Zl(l) + '"]');
      var n = e;
      switch (t) {
        case 'style':
          n = iu(l);
          break;
        case 'script':
          n = fu(l);
      }
      Wl.has(n) ||
        ((l = C(
          {
            rel: 'preload',
            href: t === 'image' && a && a.imageSrcSet ? void 0 : l,
            as: t,
          },
          a,
        )),
        Wl.set(n, l),
        u.querySelector(e) !== null ||
          (t === 'style' && u.querySelector(le(n))) ||
          (t === 'script' && u.querySelector(te(n))) ||
          ((t = u.createElement('link')),
          ol(t, 'link', l),
          dl(t),
          u.head.appendChild(t)));
    }
  }
  function $m(l, t) {
    Mt.m(l, t);
    var a = cu;
    if (a && l) {
      var u = t && typeof t.as == 'string' ? t.as : 'script',
        e =
          'link[rel="modulepreload"][as="' + Zl(u) + '"][href="' + Zl(l) + '"]',
        n = e;
      switch (u) {
        case 'audioworklet':
        case 'paintworklet':
        case 'serviceworker':
        case 'sharedworker':
        case 'worker':
        case 'script':
          n = fu(l);
      }
      if (
        !Wl.has(n) &&
        ((l = C({ rel: 'modulepreload', href: l }, t)),
        Wl.set(n, l),
        a.querySelector(e) === null)
      ) {
        switch (u) {
          case 'audioworklet':
          case 'paintworklet':
          case 'serviceworker':
          case 'sharedworker':
          case 'worker':
          case 'script':
            if (a.querySelector(te(n))) return;
        }
        ((u = a.createElement('link')),
          ol(u, 'link', l),
          dl(u),
          a.head.appendChild(u));
      }
    }
  }
  function Fm(l, t, a) {
    Mt.S(l, t, a);
    var u = cu;
    if (u && l) {
      var e = Ea(u).hoistableStyles,
        n = iu(l);
      t = t || 'default';
      var c = e.get(n);
      if (!c) {
        var i = { loading: 0, preload: null };
        if ((c = u.querySelector(le(n)))) i.loading = 5;
        else {
          ((l = C({ rel: 'stylesheet', href: l, 'data-precedence': t }, a)),
            (a = Wl.get(n)) && Yi(l, a));
          var f = (c = u.createElement('link'));
          (dl(f),
            ol(f, 'link', l),
            (f._p = new Promise(function (v, o) {
              ((f.onload = v), (f.onerror = o));
            })),
            f.addEventListener('load', function () {
              i.loading |= 1;
            }),
            f.addEventListener('error', function () {
              i.loading |= 2;
            }),
            (i.loading |= 4),
            xn(c, t, u));
        }
        ((c = { type: 'stylesheet', instance: c, count: 1, state: i }),
          e.set(n, c));
      }
    }
  }
  function Im(l, t) {
    Mt.X(l, t);
    var a = cu;
    if (a && l) {
      var u = Ea(a).hoistableScripts,
        e = fu(l),
        n = u.get(e);
      n ||
        ((n = a.querySelector(te(e))),
        n ||
          ((l = C({ src: l, async: !0 }, t)),
          (t = Wl.get(e)) && Gi(l, t),
          (n = a.createElement('script')),
          dl(n),
          ol(n, 'link', l),
          a.head.appendChild(n)),
        (n = { type: 'script', instance: n, count: 1, state: null }),
        u.set(e, n));
    }
  }
  function Pm(l, t) {
    Mt.M(l, t);
    var a = cu;
    if (a && l) {
      var u = Ea(a).hoistableScripts,
        e = fu(l),
        n = u.get(e);
      n ||
        ((n = a.querySelector(te(e))),
        n ||
          ((l = C({ src: l, async: !0, type: 'module' }, t)),
          (t = Wl.get(e)) && Gi(l, t),
          (n = a.createElement('script')),
          dl(n),
          ol(n, 'link', l),
          a.head.appendChild(n)),
        (n = { type: 'script', instance: n, count: 1, state: null }),
        u.set(e, n));
    }
  }
  function Td(l, t, a, u) {
    var e = (e = jt.current) ? gn(e) : null;
    if (!e) throw Error(b(446));
    switch (l) {
      case 'meta':
      case 'title':
        return null;
      case 'style':
        return typeof a.precedence == 'string' && typeof a.href == 'string'
          ? ((t = iu(a.href)),
            (a = Ea(e).hoistableStyles),
            (u = a.get(t)),
            u ||
              ((u = { type: 'style', instance: null, count: 0, state: null }),
              a.set(t, u)),
            u)
          : { type: 'void', instance: null, count: 0, state: null };
      case 'link':
        if (
          a.rel === 'stylesheet' &&
          typeof a.href == 'string' &&
          typeof a.precedence == 'string'
        ) {
          l = iu(a.href);
          var n = Ea(e).hoistableStyles,
            c = n.get(l);
          if (
            (c ||
              ((e = e.ownerDocument || e),
              (c = {
                type: 'stylesheet',
                instance: null,
                count: 0,
                state: { loading: 0, preload: null },
              }),
              n.set(l, c),
              (n = e.querySelector(le(l))) &&
                !n._p &&
                ((c.instance = n), (c.state.loading = 5)),
              Wl.has(l) ||
                ((a = {
                  rel: 'preload',
                  as: 'style',
                  href: a.href,
                  crossOrigin: a.crossOrigin,
                  integrity: a.integrity,
                  media: a.media,
                  hrefLang: a.hrefLang,
                  referrerPolicy: a.referrerPolicy,
                }),
                Wl.set(l, a),
                n || lv(e, l, a, c.state))),
            t && u === null)
          )
            throw Error(b(528, ''));
          return c;
        }
        if (t && u !== null) throw Error(b(529, ''));
        return null;
      case 'script':
        return (
          (t = a.async),
          (a = a.src),
          typeof a == 'string' &&
          t &&
          typeof t != 'function' &&
          typeof t != 'symbol'
            ? ((t = fu(a)),
              (a = Ea(e).hoistableScripts),
              (u = a.get(t)),
              u ||
                ((u = {
                  type: 'script',
                  instance: null,
                  count: 0,
                  state: null,
                }),
                a.set(t, u)),
              u)
            : { type: 'void', instance: null, count: 0, state: null }
        );
      default:
        throw Error(b(444, l));
    }
  }
  function iu(l) {
    return 'href="' + Zl(l) + '"';
  }
  function le(l) {
    return 'link[rel="stylesheet"][' + l + ']';
  }
  function Md(l) {
    return C({}, l, { 'data-precedence': l.precedence, precedence: null });
  }
  function lv(l, t, a, u) {
    l.querySelector('link[rel="preload"][as="style"][' + t + ']')
      ? (u.loading = 1)
      : ((t = l.createElement('link')),
        (u.preload = t),
        t.addEventListener('load', function () {
          return (u.loading |= 1);
        }),
        t.addEventListener('error', function () {
          return (u.loading |= 2);
        }),
        ol(t, 'link', a),
        dl(t),
        l.head.appendChild(t));
  }
  function fu(l) {
    return '[src="' + Zl(l) + '"]';
  }
  function te(l) {
    return 'script[async]' + l;
  }
  function Ed(l, t, a) {
    if ((t.count++, t.instance === null))
      switch (t.type) {
        case 'style':
          var u = l.querySelector('style[data-href~="' + Zl(a.href) + '"]');
          if (u) return ((t.instance = u), dl(u), u);
          var e = C({}, a, {
            'data-href': a.href,
            'data-precedence': a.precedence,
            href: null,
            precedence: null,
          });
          return (
            (u = (l.ownerDocument || l).createElement('style')),
            dl(u),
            ol(u, 'style', e),
            xn(u, a.precedence, l),
            (t.instance = u)
          );
        case 'stylesheet':
          e = iu(a.href);
          var n = l.querySelector(le(e));
          if (n) return ((t.state.loading |= 4), (t.instance = n), dl(n), n);
          ((u = Md(a)),
            (e = Wl.get(e)) && Yi(u, e),
            (n = (l.ownerDocument || l).createElement('link')),
            dl(n));
          var c = n;
          return (
            (c._p = new Promise(function (i, f) {
              ((c.onload = i), (c.onerror = f));
            })),
            ol(n, 'link', u),
            (t.state.loading |= 4),
            xn(n, a.precedence, l),
            (t.instance = n)
          );
        case 'script':
          return (
            (n = fu(a.src)),
            (e = l.querySelector(te(n)))
              ? ((t.instance = e), dl(e), e)
              : ((u = a),
                (e = Wl.get(n)) && ((u = C({}, a)), Gi(u, e)),
                (l = l.ownerDocument || l),
                (e = l.createElement('script')),
                dl(e),
                ol(e, 'link', u),
                l.head.appendChild(e),
                (t.instance = e))
          );
        case 'void':
          return null;
        default:
          throw Error(b(443, t.type));
      }
    else
      t.type === 'stylesheet' &&
        (t.state.loading & 4) === 0 &&
        ((u = t.instance), (t.state.loading |= 4), xn(u, a.precedence, l));
    return t.instance;
  }
  function xn(l, t, a) {
    for (
      var u = a.querySelectorAll(
          'link[rel="stylesheet"][data-precedence],style[data-precedence]',
        ),
        e = u.length ? u[u.length - 1] : null,
        n = e,
        c = 0;
      c < u.length;
      c++
    ) {
      var i = u[c];
      if (i.dataset.precedence === t) n = i;
      else if (n !== e) break;
    }
    n
      ? n.parentNode.insertBefore(l, n.nextSibling)
      : ((t = a.nodeType === 9 ? a.head : a), t.insertBefore(l, t.firstChild));
  }
  function Yi(l, t) {
    (l.crossOrigin == null && (l.crossOrigin = t.crossOrigin),
      l.referrerPolicy == null && (l.referrerPolicy = t.referrerPolicy),
      l.title == null && (l.title = t.title));
  }
  function Gi(l, t) {
    (l.crossOrigin == null && (l.crossOrigin = t.crossOrigin),
      l.referrerPolicy == null && (l.referrerPolicy = t.referrerPolicy),
      l.integrity == null && (l.integrity = t.integrity));
  }
  var Sn = null;
  function Dd(l, t, a) {
    if (Sn === null) {
      var u = new Map(),
        e = (Sn = new Map());
      e.set(a, u);
    } else ((e = Sn), (u = e.get(a)), u || ((u = new Map()), e.set(a, u)));
    if (u.has(l)) return u;
    for (
      u.set(l, null), a = a.getElementsByTagName(l), e = 0;
      e < a.length;
      e++
    ) {
      var n = a[e];
      if (
        !(
          n[ru] ||
          n[bl] ||
          (l === 'link' && n.getAttribute('rel') === 'stylesheet')
        ) &&
        n.namespaceURI !== 'http://www.w3.org/2000/svg'
      ) {
        var c = n.getAttribute(t) || '';
        c = l + c;
        var i = u.get(c);
        i ? i.push(n) : u.set(c, [n]);
      }
    }
    return u;
  }
  function jd(l, t, a) {
    ((l = l.ownerDocument || l),
      l.head.insertBefore(
        a,
        t === 'title' ? l.querySelector('head > title') : null,
      ));
  }
  function tv(l, t, a) {
    if (a === 1 || t.itemProp != null) return !1;
    switch (l) {
      case 'meta':
      case 'title':
        return !0;
      case 'style':
        if (
          typeof t.precedence != 'string' ||
          typeof t.href != 'string' ||
          t.href === ''
        )
          break;
        return !0;
      case 'link':
        if (
          typeof t.rel != 'string' ||
          typeof t.href != 'string' ||
          t.href === '' ||
          t.onLoad ||
          t.onError
        )
          break;
        switch (t.rel) {
          case 'stylesheet':
            return (
              (l = t.disabled),
              typeof t.precedence == 'string' && l == null
            );
          default:
            return !0;
        }
      case 'script':
        if (
          t.async &&
          typeof t.async != 'function' &&
          typeof t.async != 'symbol' &&
          !t.onLoad &&
          !t.onError &&
          t.src &&
          typeof t.src == 'string'
        )
          return !0;
    }
    return !1;
  }
  function Od(l) {
    return !(l.type === 'stylesheet' && (l.state.loading & 3) === 0);
  }
  var ae = null;
  function av() {}
  function uv(l, t, a) {
    if (ae === null) throw Error(b(475));
    var u = ae;
    if (
      t.type === 'stylesheet' &&
      (typeof a.media != 'string' || matchMedia(a.media).matches !== !1) &&
      (t.state.loading & 4) === 0
    ) {
      if (t.instance === null) {
        var e = iu(a.href),
          n = l.querySelector(le(e));
        if (n) {
          ((l = n._p),
            l !== null &&
              typeof l == 'object' &&
              typeof l.then == 'function' &&
              (u.count++, (u = pn.bind(u)), l.then(u, u)),
            (t.state.loading |= 4),
            (t.instance = n),
            dl(n));
          return;
        }
        ((n = l.ownerDocument || l),
          (a = Md(a)),
          (e = Wl.get(e)) && Yi(a, e),
          (n = n.createElement('link')),
          dl(n));
        var c = n;
        ((c._p = new Promise(function (i, f) {
          ((c.onload = i), (c.onerror = f));
        })),
          ol(n, 'link', a),
          (t.instance = n));
      }
      (u.stylesheets === null && (u.stylesheets = new Map()),
        u.stylesheets.set(t, l),
        (l = t.state.preload) &&
          (t.state.loading & 3) === 0 &&
          (u.count++,
          (t = pn.bind(u)),
          l.addEventListener('load', t),
          l.addEventListener('error', t)));
    }
  }
  function ev() {
    if (ae === null) throw Error(b(475));
    var l = ae;
    return (
      l.stylesheets && l.count === 0 && Xi(l, l.stylesheets),
      0 < l.count
        ? function (t) {
            var a = setTimeout(function () {
              if ((l.stylesheets && Xi(l, l.stylesheets), l.unsuspend)) {
                var u = l.unsuspend;
                ((l.unsuspend = null), u());
              }
            }, 6e4);
            return (
              (l.unsuspend = t),
              function () {
                ((l.unsuspend = null), clearTimeout(a));
              }
            );
          }
        : null
    );
  }
  function pn() {
    if ((this.count--, this.count === 0)) {
      if (this.stylesheets) Xi(this, this.stylesheets);
      else if (this.unsuspend) {
        var l = this.unsuspend;
        ((this.unsuspend = null), l());
      }
    }
  }
  var zn = null;
  function Xi(l, t) {
    ((l.stylesheets = null),
      l.unsuspend !== null &&
        (l.count++,
        (zn = new Map()),
        t.forEach(nv, l),
        (zn = null),
        pn.call(l)));
  }
  function nv(l, t) {
    if (!(t.state.loading & 4)) {
      var a = zn.get(l);
      if (a) var u = a.get(null);
      else {
        ((a = new Map()), zn.set(l, a));
        for (
          var e = l.querySelectorAll(
              'link[data-precedence],style[data-precedence]',
            ),
            n = 0;
          n < e.length;
          n++
        ) {
          var c = e[n];
          (c.nodeName === 'LINK' || c.getAttribute('media') !== 'not all') &&
            (a.set(c.dataset.precedence, c), (u = c));
        }
        u && a.set(null, u);
      }
      ((e = t.instance),
        (c = e.getAttribute('data-precedence')),
        (n = a.get(c) || u),
        n === u && a.set(null, e),
        a.set(c, e),
        this.count++,
        (u = pn.bind(this)),
        e.addEventListener('load', u),
        e.addEventListener('error', u),
        n
          ? n.parentNode.insertBefore(e, n.nextSibling)
          : ((l = l.nodeType === 9 ? l.head : l),
            l.insertBefore(e, l.firstChild)),
        (t.state.loading |= 4));
    }
  }
  var ue = {
    $$typeof: Gl,
    Provider: null,
    Consumer: null,
    _currentValue: D,
    _currentValue2: D,
    _threadCount: 0,
  };
  function cv(l, t, a, u, e, n, c, i) {
    ((this.tag = 1),
      (this.containerInfo = l),
      (this.pingCache = this.current = this.pendingChildren = null),
      (this.timeoutHandle = -1),
      (this.callbackNode =
        this.next =
        this.pendingContext =
        this.context =
        this.cancelPendingCommit =
          null),
      (this.callbackPriority = 0),
      (this.expirationTimes = Rn(-1)),
      (this.entangledLanes =
        this.shellSuspendCounter =
        this.errorRecoveryDisabledLanes =
        this.expiredLanes =
        this.warmLanes =
        this.pingedLanes =
        this.suspendedLanes =
        this.pendingLanes =
          0),
      (this.entanglements = Rn(0)),
      (this.hiddenUpdates = Rn(null)),
      (this.identifierPrefix = u),
      (this.onUncaughtError = e),
      (this.onCaughtError = n),
      (this.onRecoverableError = c),
      (this.pooledCache = null),
      (this.pooledCacheLanes = 0),
      (this.formState = i),
      (this.incompleteTransitions = new Map()));
  }
  function Ud(l, t, a, u, e, n, c, i, f, v, o, S) {
    return (
      (l = new cv(l, t, a, c, i, f, v, S)),
      (t = 1),
      n === !0 && (t |= 24),
      (n = Ul(3, null, null, t)),
      (l.current = n),
      (n.stateNode = l),
      (t = Sc()),
      t.refCount++,
      (l.pooledCache = t),
      t.refCount++,
      (n.memoizedState = { element: u, isDehydrated: a, cache: t }),
      Ac(n),
      l
    );
  }
  function Hd(l) {
    return l ? ((l = Xa), l) : Xa;
  }
  function _d(l, t, a, u, e, n) {
    ((e = Hd(e)),
      u.context === null ? (u.context = e) : (u.pendingContext = e),
      (u = Rt(t)),
      (u.payload = { element: a }),
      (n = n === void 0 ? null : n),
      n !== null && (u.callback = n),
      (a = Bt(l, u, t)),
      a !== null && (Bl(a, l, t), _u(a, l, t)));
  }
  function qd(l, t) {
    if (((l = l.memoizedState), l !== null && l.dehydrated !== null)) {
      var a = l.retryLane;
      l.retryLane = a !== 0 && a < t ? a : t;
    }
  }
  function Qi(l, t) {
    (qd(l, t), (l = l.alternate) && qd(l, t));
  }
  function Rd(l) {
    if (l.tag === 13) {
      var t = Ga(l, 67108864);
      (t !== null && Bl(t, l, 67108864), Qi(l, 67108864));
    }
  }
  var Nn = !0;
  function iv(l, t, a, u) {
    var e = x.T;
    x.T = null;
    var n = p.p;
    try {
      ((p.p = 2), Zi(l, t, a, u));
    } finally {
      ((p.p = n), (x.T = e));
    }
  }
  function fv(l, t, a, u) {
    var e = x.T;
    x.T = null;
    var n = p.p;
    try {
      ((p.p = 8), Zi(l, t, a, u));
    } finally {
      ((p.p = n), (x.T = e));
    }
  }
  function Zi(l, t, a, u) {
    if (Nn) {
      var e = Vi(u);
      if (e === null) (Di(l, t, u, An, a), Yd(l, u));
      else if (dv(e, l, t, a, u)) u.stopPropagation();
      else if ((Yd(l, u), t & 4 && -1 < sv.indexOf(l))) {
        for (; e !== null; ) {
          var n = Ma(e);
          if (n !== null)
            switch (n.tag) {
              case 3:
                if (((n = n.stateNode), n.current.memoizedState.isDehydrated)) {
                  var c = aa(n.pendingLanes);
                  if (c !== 0) {
                    var i = n;
                    for (i.pendingLanes |= 2, i.entangledLanes |= 2; c; ) {
                      var f = 1 << (31 - jl(c));
                      ((i.entanglements[1] |= f), (c &= ~f));
                    }
                    (ft(n), (Y & 6) === 0 && ((cn = ut() + 500), $u(0)));
                  }
                }
                break;
              case 13:
                ((i = Ga(n, 2)), i !== null && Bl(i, n, 2), sn(), Qi(n, 2));
            }
          if (((n = Vi(u)), n === null && Di(l, t, u, An, a), n === e)) break;
          e = n;
        }
        e !== null && u.stopPropagation();
      } else Di(l, t, u, null, a);
    }
  }
  function Vi(l) {
    return ((l = wn(l)), Ci(l));
  }
  var An = null;
  function Ci(l) {
    if (((An = null), (l = Ta(l)), l !== null)) {
      var t = j(l);
      if (t === null) l = null;
      else {
        var a = t.tag;
        if (a === 13) {
          if (((l = El(t)), l !== null)) return l;
          l = null;
        } else if (a === 3) {
          if (t.stateNode.current.memoizedState.isDehydrated)
            return t.tag === 3 ? t.stateNode.containerInfo : null;
          l = null;
        } else t !== l && (l = null);
      }
    }
    return ((An = l), null);
  }
  function Bd(l) {
    switch (l) {
      case 'beforetoggle':
      case 'cancel':
      case 'click':
      case 'close':
      case 'contextmenu':
      case 'copy':
      case 'cut':
      case 'auxclick':
      case 'dblclick':
      case 'dragend':
      case 'dragstart':
      case 'drop':
      case 'focusin':
      case 'focusout':
      case 'input':
      case 'invalid':
      case 'keydown':
      case 'keypress':
      case 'keyup':
      case 'mousedown':
      case 'mouseup':
      case 'paste':
      case 'pause':
      case 'play':
      case 'pointercancel':
      case 'pointerdown':
      case 'pointerup':
      case 'ratechange':
      case 'reset':
      case 'resize':
      case 'seeked':
      case 'submit':
      case 'toggle':
      case 'touchcancel':
      case 'touchend':
      case 'touchstart':
      case 'volumechange':
      case 'change':
      case 'selectionchange':
      case 'textInput':
      case 'compositionstart':
      case 'compositionend':
      case 'compositionupdate':
      case 'beforeblur':
      case 'afterblur':
      case 'beforeinput':
      case 'blur':
      case 'fullscreenchange':
      case 'focus':
      case 'hashchange':
      case 'popstate':
      case 'select':
      case 'selectstart':
        return 2;
      case 'drag':
      case 'dragenter':
      case 'dragexit':
      case 'dragleave':
      case 'dragover':
      case 'mousemove':
      case 'mouseout':
      case 'mouseover':
      case 'pointermove':
      case 'pointerout':
      case 'pointerover':
      case 'scroll':
      case 'touchmove':
      case 'wheel':
      case 'mouseenter':
      case 'mouseleave':
      case 'pointerenter':
      case 'pointerleave':
        return 8;
      case 'message':
        switch (Wd()) {
          case ki:
            return 2;
          case $i:
            return 8;
          case ye:
          case kd:
            return 32;
          case Fi:
            return 268435456;
          default:
            return 32;
        }
      default:
        return 32;
    }
  }
  var Ki = !1,
    kt = null,
    $t = null,
    Ft = null,
    ee = new Map(),
    ne = new Map(),
    It = [],
    sv =
      'mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset'.split(
        ' ',
      );
  function Yd(l, t) {
    switch (l) {
      case 'focusin':
      case 'focusout':
        kt = null;
        break;
      case 'dragenter':
      case 'dragleave':
        $t = null;
        break;
      case 'mouseover':
      case 'mouseout':
        Ft = null;
        break;
      case 'pointerover':
      case 'pointerout':
        ee.delete(t.pointerId);
        break;
      case 'gotpointercapture':
      case 'lostpointercapture':
        ne.delete(t.pointerId);
    }
  }
  function ce(l, t, a, u, e, n) {
    return l === null || l.nativeEvent !== n
      ? ((l = {
          blockedOn: t,
          domEventName: a,
          eventSystemFlags: u,
          nativeEvent: n,
          targetContainers: [e],
        }),
        t !== null && ((t = Ma(t)), t !== null && Rd(t)),
        l)
      : ((l.eventSystemFlags |= u),
        (t = l.targetContainers),
        e !== null && t.indexOf(e) === -1 && t.push(e),
        l);
  }
  function dv(l, t, a, u, e) {
    switch (t) {
      case 'focusin':
        return ((kt = ce(kt, l, t, a, u, e)), !0);
      case 'dragenter':
        return (($t = ce($t, l, t, a, u, e)), !0);
      case 'mouseover':
        return ((Ft = ce(Ft, l, t, a, u, e)), !0);
      case 'pointerover':
        var n = e.pointerId;
        return (ee.set(n, ce(ee.get(n) || null, l, t, a, u, e)), !0);
      case 'gotpointercapture':
        return (
          (n = e.pointerId),
          ne.set(n, ce(ne.get(n) || null, l, t, a, u, e)),
          !0
        );
    }
    return !1;
  }
  function Gd(l) {
    var t = Ta(l.target);
    if (t !== null) {
      var a = j(t);
      if (a !== null) {
        if (((t = a.tag), t === 13)) {
          if (((t = El(a)), t !== null)) {
            ((l.blockedOn = t),
              uh(l.priority, function () {
                if (a.tag === 13) {
                  var u = Rl();
                  u = Bn(u);
                  var e = Ga(a, u);
                  (e !== null && Bl(e, a, u), Qi(a, u));
                }
              }));
            return;
          }
        } else if (t === 3 && a.stateNode.current.memoizedState.isDehydrated) {
          l.blockedOn = a.tag === 3 ? a.stateNode.containerInfo : null;
          return;
        }
      }
    }
    l.blockedOn = null;
  }
  function Tn(l) {
    if (l.blockedOn !== null) return !1;
    for (var t = l.targetContainers; 0 < t.length; ) {
      var a = Vi(l.nativeEvent);
      if (a === null) {
        a = l.nativeEvent;
        var u = new a.constructor(a.type, a);
        ((Jn = u), a.target.dispatchEvent(u), (Jn = null));
      } else return ((t = Ma(a)), t !== null && Rd(t), (l.blockedOn = a), !1);
      t.shift();
    }
    return !0;
  }
  function Xd(l, t, a) {
    Tn(l) && a.delete(t);
  }
  function hv() {
    ((Ki = !1),
      kt !== null && Tn(kt) && (kt = null),
      $t !== null && Tn($t) && ($t = null),
      Ft !== null && Tn(Ft) && (Ft = null),
      ee.forEach(Xd),
      ne.forEach(Xd));
  }
  function Mn(l, t) {
    l.blockedOn === t &&
      ((l.blockedOn = null),
      Ki ||
        ((Ki = !0),
        A.unstable_scheduleCallback(A.unstable_NormalPriority, hv)));
  }
  var En = null;
  function Qd(l) {
    En !== l &&
      ((En = l),
      A.unstable_scheduleCallback(A.unstable_NormalPriority, function () {
        En === l && (En = null);
        for (var t = 0; t < l.length; t += 3) {
          var a = l[t],
            u = l[t + 1],
            e = l[t + 2];
          if (typeof u != 'function') {
            if (Ci(u || a) === null) continue;
            break;
          }
          var n = Ma(a);
          n !== null &&
            (l.splice(t, 3),
            (t -= 3),
            Cc(n, { pending: !0, data: e, method: a.method, action: u }, u, e));
        }
      }));
  }
  function ie(l) {
    function t(f) {
      return Mn(f, l);
    }
    (kt !== null && Mn(kt, l),
      $t !== null && Mn($t, l),
      Ft !== null && Mn(Ft, l),
      ee.forEach(t),
      ne.forEach(t));
    for (var a = 0; a < It.length; a++) {
      var u = It[a];
      u.blockedOn === l && (u.blockedOn = null);
    }
    for (; 0 < It.length && ((a = It[0]), a.blockedOn === null); )
      (Gd(a), a.blockedOn === null && It.shift());
    if (((a = (l.ownerDocument || l).$$reactFormReplay), a != null))
      for (u = 0; u < a.length; u += 3) {
        var e = a[u],
          n = a[u + 1],
          c = e[zl] || null;
        if (typeof n == 'function') c || Qd(a);
        else if (c) {
          var i = null;
          if (n && n.hasAttribute('formAction')) {
            if (((e = n), (c = n[zl] || null))) i = c.formAction;
            else if (Ci(e) !== null) continue;
          } else i = c.action;
          (typeof i == 'function' ? (a[u + 1] = i) : (a.splice(u, 3), (u -= 3)),
            Qd(a));
        }
      }
  }
  function Li(l) {
    this._internalRoot = l;
  }
  ((Dn.prototype.render = Li.prototype.render =
    function (l) {
      var t = this._internalRoot;
      if (t === null) throw Error(b(409));
      var a = t.current,
        u = Rl();
      _d(a, u, l, t, null, null);
    }),
    (Dn.prototype.unmount = Li.prototype.unmount =
      function () {
        var l = this._internalRoot;
        if (l !== null) {
          this._internalRoot = null;
          var t = l.containerInfo;
          (_d(l.current, 2, null, l, null, null), sn(), (t[Aa] = null));
        }
      }));
  function Dn(l) {
    this._internalRoot = l;
  }
  Dn.prototype.unstable_scheduleHydration = function (l) {
    if (l) {
      var t = af();
      l = { blockedOn: null, target: l, priority: t };
      for (var a = 0; a < It.length && t !== 0 && t < It[a].priority; a++);
      (It.splice(a, 0, l), a === 0 && Gd(l));
    }
  };
  var Zd = il.version;
  if (Zd !== '19.1.0') throw Error(b(527, Zd, '19.1.0'));
  p.findDOMNode = function (l) {
    var t = l._reactInternals;
    if (t === void 0)
      throw typeof l.render == 'function'
        ? Error(b(188))
        : ((l = Object.keys(l).join(',')), Error(b(268, l)));
    return (
      (l = kl(t)),
      (l = l !== null ? $l(l) : null),
      (l = l === null ? null : l.stateNode),
      l
    );
  };
  var mv = {
    bundleType: 0,
    version: '19.1.0',
    rendererPackageName: 'react-dom',
    currentDispatcherRef: x,
    reconcilerVersion: '19.1.0',
  };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < 'u') {
    var jn = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!jn.isDisabled && jn.supportsFiber)
      try {
        ((hu = jn.inject(mv)), (Dl = jn));
      } catch {}
  }
  return (
    (fe.createRoot = function (l, t) {
      if (!J(l)) throw Error(b(299));
      var a = !1,
        u = '',
        e = u0,
        n = e0,
        c = n0,
        i = null;
      return (
        t != null &&
          (t.unstable_strictMode === !0 && (a = !0),
          t.identifierPrefix !== void 0 && (u = t.identifierPrefix),
          t.onUncaughtError !== void 0 && (e = t.onUncaughtError),
          t.onCaughtError !== void 0 && (n = t.onCaughtError),
          t.onRecoverableError !== void 0 && (c = t.onRecoverableError),
          t.unstable_transitionCallbacks !== void 0 &&
            (i = t.unstable_transitionCallbacks)),
        (t = Ud(l, 1, !1, null, null, a, u, e, n, c, i, null)),
        (l[Aa] = t.current),
        Ei(l),
        new Li(t)
      );
    }),
    (fe.hydrateRoot = function (l, t, a) {
      if (!J(l)) throw Error(b(299));
      var u = !1,
        e = '',
        n = u0,
        c = e0,
        i = n0,
        f = null,
        v = null;
      return (
        a != null &&
          (a.unstable_strictMode === !0 && (u = !0),
          a.identifierPrefix !== void 0 && (e = a.identifierPrefix),
          a.onUncaughtError !== void 0 && (n = a.onUncaughtError),
          a.onCaughtError !== void 0 && (c = a.onCaughtError),
          a.onRecoverableError !== void 0 && (i = a.onRecoverableError),
          a.unstable_transitionCallbacks !== void 0 &&
            (f = a.unstable_transitionCallbacks),
          a.formState !== void 0 && (v = a.formState)),
        (t = Ud(l, 1, !0, t, a ?? null, u, e, n, c, i, f, v)),
        (t.context = Hd(null)),
        (a = t.current),
        (u = Rl()),
        (u = Bn(u)),
        (e = Rt(u)),
        (e.callback = null),
        Bt(a, e, u),
        (a = u),
        (t.current.lanes = a),
        vu(t, a),
        ft(t),
        (l[Aa] = t.current),
        Ei(l),
        new Dn(t)
      );
    }),
    (fe.version = '19.1.0'),
    fe
  );
}
var Ld;
function pv() {
  if (Ld) return Ji.exports;
  Ld = 1;
  function A() {
    if (
      !(
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > 'u' ||
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != 'function'
      )
    )
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(A);
      } catch (il) {
        console.error(il);
      }
  }
  return (A(), (Ji.exports = Sv()), Ji.exports);
}
var zv = pv();
const Nv = bv(zv);
function Av() {
  const [A, il] = On.useState('landing'),
    [fl] = On.useState({
      id: 'demo-user',
      username: 'epic.adventurer',
      email: 'demo@worldarchitect.ai',
      displayName: 'Epic Adventurer',
    }),
    [b] = On.useState([
      {
        id: '1',
        title: "The Dragon's Hoard",
        description:
          "A classic fantasy adventure where brave heroes must infiltrate an ancient dragon's lair to recover stolen treasures and save the kingdom.",
        theme: 'fantasy',
        players: 4,
        maxPlayers: 6,
        lastPlayed: '2 days ago',
        status: 'active',
        difficulty: 'intermediate',
      },
      {
        id: '2',
        title: 'Neon Shadows',
        description:
          'In the sprawling megacity of Neo-Tokyo 2087, corporate espionage and cyber-enhanced mercenaries clash in the digital underground.',
        theme: 'cyberpunk',
        players: 3,
        maxPlayers: 5,
        lastPlayed: '1 week ago',
        status: 'recruiting',
        difficulty: 'advanced',
      },
      {
        id: '3',
        title: 'The Cursed Crown',
        description:
          'Dark magic has corrupted the royal bloodline. Navigate political intrigue and supernatural horrors in this gothic fantasy campaign.',
        theme: 'dark-fantasy',
        players: 5,
        maxPlayers: 6,
        lastPlayed: '3 days ago',
        status: 'active',
        difficulty: 'beginner',
      },
    ]),
    [J] = On.useState(!1);
  return J
    ? h.jsx('div', {
        className:
          'min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-purple-900 flex items-center justify-center',
        children: h.jsx('div', {
          className: 'text-white text-xl',
          children: 'Loading...',
        }),
      })
    : fl
      ? h.jsxs('div', {
          className:
            'min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-purple-900',
          children: [
            h.jsx('header', {
              className:
                'bg-black/20 backdrop-blur-sm border-b border-purple-500/20',
              children: h.jsxs('div', {
                className:
                  'container mx-auto px-4 py-4 flex justify-between items-center',
                children: [
                  h.jsxs('div', {
                    className: 'flex items-center space-x-2',
                    children: [
                      h.jsx('span', { className: 'text-2xl', children: '🎲' }),
                      h.jsx('h1', {
                        className: 'text-xl font-bold text-white',
                        children: 'WorldArchitect.AI',
                      }),
                    ],
                  }),
                  h.jsxs('div', {
                    className: 'flex items-center space-x-4',
                    children: [
                      h.jsxs('span', {
                        className: 'text-purple-200',
                        children: ['Welcome, ', fl.displayName],
                      }),
                      h.jsx('div', {
                        className:
                          'w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center',
                        children: h.jsx('span', {
                          className: 'text-white text-sm',
                          children: fl.displayName
                            .split(' ')
                            .map((j) => j[0])
                            .join(''),
                        }),
                      }),
                    ],
                  }),
                ],
              }),
            }),
            h.jsxs('main', {
              className: 'container mx-auto px-4 py-8',
              children: [
                A === 'landing' &&
                  h.jsxs('div', {
                    className: 'text-center',
                    children: [
                      h.jsxs('div', {
                        className: 'mb-20 pt-20',
                        children: [
                          h.jsx('h1', {
                            className:
                              'text-6xl md:text-8xl text-white drop-shadow-2xl mb-4',
                            children: 'Welcome, Epic',
                          }),
                          h.jsx('p', {
                            className: 'text-xl text-purple-200 mb-8',
                            children: 'Your AI-powered D&D Game Master awaits',
                          }),
                        ],
                      }),
                      h.jsx('div', {
                        className: 'max-w-6xl mx-auto mb-16',
                        children: h.jsxs('div', {
                          className:
                            'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6',
                          children: [
                            h.jsx('div', {
                              className:
                                'bg-purple-900/40 backdrop-blur-sm border border-purple-300/20 rounded-lg p-6 hover:bg-purple-800/50 transition-all duration-300 cursor-pointer',
                              children: h.jsxs('div', {
                                className: 'text-center',
                                children: [
                                  h.jsx('div', {
                                    className: 'text-4xl mb-4',
                                    children: '👑',
                                  }),
                                  h.jsx('h3', {
                                    className: 'text-xl text-white mb-2',
                                    children: 'AI Game Master',
                                  }),
                                  h.jsx('p', {
                                    className: 'text-purple-100 text-sm mb-4',
                                    children:
                                      'Dynamic storytelling powered by AI',
                                  }),
                                ],
                              }),
                            }),
                            h.jsx('div', {
                              className:
                                'bg-purple-900/40 backdrop-blur-sm border border-purple-300/20 rounded-lg p-6 hover:bg-purple-800/50 transition-all duration-300 cursor-pointer',
                              children: h.jsxs('div', {
                                className: 'text-center',
                                children: [
                                  h.jsx('div', {
                                    className: 'text-4xl mb-4',
                                    children: '📚',
                                  }),
                                  h.jsx('h3', {
                                    className: 'text-xl text-white mb-2',
                                    children: 'Rich Storytelling',
                                  }),
                                  h.jsx('p', {
                                    className: 'text-purple-100 text-sm mb-4',
                                    children: 'Immersive worlds and characters',
                                  }),
                                ],
                              }),
                            }),
                            h.jsx('div', {
                              className:
                                'bg-purple-900/40 backdrop-blur-sm border border-purple-300/20 rounded-lg p-6 hover:bg-purple-800/50 transition-all duration-300 cursor-pointer',
                              children: h.jsxs('div', {
                                className: 'text-center',
                                children: [
                                  h.jsx('div', {
                                    className: 'text-4xl mb-4',
                                    children: '⚔️',
                                  }),
                                  h.jsx('h3', {
                                    className: 'text-xl text-white mb-2',
                                    children: 'Epic Adventures',
                                  }),
                                  h.jsx('p', {
                                    className: 'text-purple-100 text-sm mb-4',
                                    children: 'Create and evolve your hero',
                                  }),
                                ],
                              }),
                            }),
                            h.jsx('div', {
                              className:
                                'bg-purple-900/40 backdrop-blur-sm border border-purple-300/20 rounded-lg p-6 hover:bg-purple-800/50 transition-all duration-300 cursor-pointer',
                              children: h.jsxs('div', {
                                className: 'text-center',
                                children: [
                                  h.jsx('div', {
                                    className: 'text-4xl mb-4',
                                    children: '🏰',
                                  }),
                                  h.jsx('h3', {
                                    className: 'text-xl text-white mb-2',
                                    children: 'Fantasy Worlds',
                                  }),
                                  h.jsx('p', {
                                    className: 'text-purple-100 text-sm mb-4',
                                    children: 'Explore mystical realms',
                                  }),
                                ],
                              }),
                            }),
                            h.jsx('div', {
                              className:
                                'bg-purple-900/40 backdrop-blur-sm border border-purple-300/20 rounded-lg p-6 hover:bg-purple-800/50 transition-all duration-300 cursor-pointer',
                              children: h.jsxs('div', {
                                className: 'text-center',
                                children: [
                                  h.jsx('div', {
                                    className: 'text-4xl mb-4',
                                    children: '⚡',
                                  }),
                                  h.jsx('h3', {
                                    className: 'text-xl text-white mb-2',
                                    children: 'Instant Play',
                                  }),
                                  h.jsx('p', {
                                    className: 'text-purple-100 text-sm mb-4',
                                    children: 'Start adventures immediately',
                                  }),
                                ],
                              }),
                            }),
                            h.jsx('div', {
                              className:
                                'bg-purple-900/40 backdrop-blur-sm border border-purple-300/20 rounded-lg p-6 hover:bg-purple-800/50 transition-all duration-300 cursor-pointer ring-2 ring-purple-400/60',
                              onClick: () => il('campaigns'),
                              children: h.jsxs('div', {
                                className: 'text-center',
                                children: [
                                  h.jsx('div', {
                                    className: 'text-4xl mb-4',
                                    children: '▶️',
                                  }),
                                  h.jsx('h3', {
                                    className: 'text-xl text-white mb-2',
                                    children: 'Create Campaign',
                                  }),
                                  h.jsx('p', {
                                    className: 'text-purple-100 text-sm mb-4',
                                    children: 'Begin your journey today',
                                  }),
                                  h.jsx('button', {
                                    className:
                                      'w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white py-2 px-4 rounded transition-all duration-300',
                                    children: 'Begin Adventure',
                                  }),
                                ],
                              }),
                            }),
                          ],
                        }),
                      }),
                      h.jsxs('div', {
                        className: 'text-center',
                        children: [
                          h.jsx('p', {
                            className: 'text-purple-100 mb-6',
                            children: 'Ready to start your epic journey?',
                          }),
                          h.jsx('button', {
                            onClick: () => il('campaigns'),
                            className:
                              'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white py-3 px-8 rounded-lg text-lg transition-all duration-300',
                            children: '🚀 Start Your Adventure',
                          }),
                        ],
                      }),
                    ],
                  }),
                A === 'campaigns' &&
                  h.jsx('div', {
                    className:
                      'min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 -mx-4 -my-8 px-4 py-8',
                    children: h.jsxs('div', {
                      className: 'container mx-auto px-6 py-8',
                      children: [
                        h.jsxs('div', {
                          className: 'flex justify-between items-center mb-8',
                          children: [
                            h.jsxs('div', {
                              children: [
                                h.jsx('h1', {
                                  className: 'text-4xl text-white mb-2',
                                  children: 'Your Campaigns',
                                }),
                                h.jsx('p', {
                                  className: 'text-purple-200',
                                  children:
                                    'Choose your adventure or create a new one',
                                }),
                              ],
                            }),
                            h.jsxs('div', {
                              className: 'flex items-center space-x-4',
                              children: [
                                h.jsx('button', {
                                  onClick: () => il('landing'),
                                  className: 'text-purple-300 hover:text-white',
                                  children: '← Back',
                                }),
                                h.jsx('button', {
                                  className:
                                    'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-6 py-3 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300',
                                  children: '+ Create New Campaign',
                                }),
                              ],
                            }),
                          ],
                        }),
                        h.jsxs('div', {
                          className:
                            'grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6',
                          children: [
                            b.map((j) => {
                              const El = {
                                  fantasy:
                                    'bg-gradient-to-br from-green-500/20 to-emerald-600/20 border-green-500/30',
                                  cyberpunk:
                                    'bg-gradient-to-br from-cyan-500/20 to-blue-600/20 border-cyan-500/30',
                                  'dark-fantasy':
                                    'bg-gradient-to-br from-purple-500/20 to-red-600/20 border-purple-500/30',
                                },
                                Sa = {
                                  active:
                                    'bg-green-500/20 text-green-300 border-green-500/30',
                                  recruiting:
                                    'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
                                  completed:
                                    'bg-gray-500/20 text-gray-300 border-gray-500/30',
                                };
                              return h.jsxs(
                                'div',
                                {
                                  className: `bg-black/60 backdrop-blur-sm border hover:bg-black/70 transition-all duration-300 hover:scale-105 cursor-pointer rounded-lg p-6 ${El[j.theme]}`,
                                  onClick: () => il('gameplay'),
                                  children: [
                                    h.jsxs('div', {
                                      className: 'mb-3',
                                      children: [
                                        h.jsxs('div', {
                                          className:
                                            'flex justify-between items-start mb-2',
                                          children: [
                                            h.jsx('h3', {
                                              className:
                                                'text-white text-xl font-semibold',
                                              children: j.title,
                                            }),
                                            h.jsx('span', {
                                              className: `px-2 py-1 rounded text-xs border ${Sa[j.status]}`,
                                              children: j.status,
                                            }),
                                          ],
                                        }),
                                        h.jsxs('div', {
                                          className:
                                            'flex items-center gap-2 text-sm text-purple-200',
                                          children: [
                                            j.difficulty === 'beginner' &&
                                              h.jsx('span', { children: '🛡️' }),
                                            j.difficulty === 'intermediate' &&
                                              h.jsx('span', { children: '⚔️' }),
                                            j.difficulty === 'advanced' &&
                                              h.jsx('span', { children: '👑' }),
                                            h.jsx('span', {
                                              className: 'capitalize',
                                              children: j.difficulty,
                                            }),
                                            h.jsx('span', {
                                              className: 'text-purple-300/50',
                                              children: '•',
                                            }),
                                            h.jsx('span', {
                                              className: 'capitalize',
                                              children: j.theme.replace(
                                                '-',
                                                ' ',
                                              ),
                                            }),
                                          ],
                                        }),
                                      ],
                                    }),
                                    h.jsxs('div', {
                                      className: 'space-y-4',
                                      children: [
                                        h.jsx('p', {
                                          className:
                                            'text-purple-100 text-sm leading-relaxed',
                                          children: j.description,
                                        }),
                                        h.jsxs('div', {
                                          className:
                                            'flex justify-between items-center text-sm',
                                          children: [
                                            h.jsxs('div', {
                                              className:
                                                'flex items-center gap-2 text-purple-200',
                                              children: [
                                                h.jsx('span', {
                                                  children: '👥',
                                                }),
                                                h.jsxs('span', {
                                                  children: [
                                                    j.players,
                                                    '/',
                                                    j.maxPlayers,
                                                    ' players',
                                                  ],
                                                }),
                                              ],
                                            }),
                                            h.jsxs('div', {
                                              className:
                                                'flex items-center gap-2 text-purple-200',
                                              children: [
                                                h.jsx('span', {
                                                  children: '📅',
                                                }),
                                                h.jsx('span', {
                                                  children: j.lastPlayed,
                                                }),
                                              ],
                                            }),
                                          ],
                                        }),
                                        h.jsxs('div', {
                                          className: 'flex gap-2 pt-2',
                                          children: [
                                            h.jsxs('button', {
                                              className:
                                                'flex-1 bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded text-sm transition-colors',
                                              children: [
                                                '▶️ ',
                                                j.status === 'recruiting'
                                                  ? 'Join'
                                                  : 'Continue',
                                              ],
                                            }),
                                            h.jsx('button', {
                                              className:
                                                'border border-purple-500/30 text-purple-200 hover:bg-purple-500/20 px-3 py-2 rounded text-sm transition-colors',
                                              children: '⚙️',
                                            }),
                                          ],
                                        }),
                                      ],
                                    }),
                                  ],
                                },
                                j.id,
                              );
                            }),
                            h.jsx('div', {
                              className:
                                'bg-black/40 backdrop-blur-sm border-dashed border-purple-500/50 hover:border-purple-400/70 hover:bg-black/50 transition-all duration-300 flex items-center justify-center min-h-[300px] cursor-pointer rounded-lg',
                              children: h.jsxs('div', {
                                className: 'text-center',
                                children: [
                                  h.jsx('div', {
                                    className:
                                      'w-16 h-16 mx-auto mb-4 bg-purple-600/20 rounded-full flex items-center justify-center hover:bg-purple-600/30 transition-colors',
                                    children: h.jsx('span', {
                                      className: 'text-purple-300 text-2xl',
                                      children: '+',
                                    }),
                                  }),
                                  h.jsx('h3', {
                                    className: 'text-white text-xl mb-2',
                                    children: 'Start New Adventure',
                                  }),
                                  h.jsx('p', {
                                    className: 'text-purple-200 text-sm',
                                    children:
                                      'Create a custom campaign with AI assistance',
                                  }),
                                ],
                              }),
                            }),
                          ],
                        }),
                        h.jsxs('div', {
                          className:
                            'mt-12 grid grid-cols-1 md:grid-cols-3 gap-4',
                          children: [
                            h.jsx('button', {
                              className:
                                'border border-purple-500/30 text-purple-200 hover:bg-purple-500/20 h-16 rounded-lg transition-colors flex items-center justify-center',
                              children: '📚 Browse Templates',
                            }),
                            h.jsx('button', {
                              className:
                                'border border-purple-500/30 text-purple-200 hover:bg-purple-500/20 h-16 rounded-lg transition-colors flex items-center justify-center',
                              children: '👥 Find Players',
                            }),
                            h.jsx('button', {
                              className:
                                'border border-purple-500/30 text-purple-200 hover:bg-purple-500/20 h-16 rounded-lg transition-colors flex items-center justify-center',
                              children: '👑 AI Game Master',
                            }),
                          ],
                        }),
                      ],
                    }),
                  }),
                A === 'gameplay' &&
                  h.jsxs('div', {
                    className:
                      'min-h-screen bg-gradient-to-br from-purple-100 via-purple-50 to-indigo-100 -mx-4 -my-8',
                    children: [
                      h.jsxs('div', {
                        className: 'absolute inset-0 opacity-20',
                        children: [
                          h.jsx('div', {
                            className:
                              'absolute top-20 right-20 w-96 h-96 bg-purple-300/30 rounded-full blur-3xl animate-pulse',
                          }),
                          h.jsx('div', {
                            className:
                              'absolute bottom-20 left-20 w-72 h-72 bg-pink-300/30 rounded-full blur-3xl animate-pulse delay-1000',
                          }),
                        ],
                      }),
                      h.jsxs('div', {
                        className: 'relative z-10',
                        children: [
                          h.jsx('header', {
                            className:
                              'bg-white/80 backdrop-blur-md border-b border-purple-200 px-6 py-4',
                            children: h.jsxs('div', {
                              className:
                                'flex items-center justify-between max-w-7xl mx-auto',
                              children: [
                                h.jsx('div', {
                                  className: 'flex items-center space-x-4',
                                  children: h.jsxs('div', {
                                    className: 'flex items-center space-x-3',
                                    children: [
                                      h.jsx('div', {
                                        className:
                                          'w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center',
                                        children: h.jsx('span', {
                                          className: 'text-white text-lg',
                                          children: '🎲',
                                        }),
                                      }),
                                      h.jsx('h1', {
                                        className:
                                          'text-xl font-semibold text-purple-900',
                                        children: 'WorldArchitect.AI',
                                      }),
                                    ],
                                  }),
                                }),
                                h.jsxs('div', {
                                  className: 'flex items-center space-x-4',
                                  children: [
                                    h.jsx('span', {
                                      className: 'text-sm text-purple-700',
                                      children: 'Epic Adventurer',
                                    }),
                                    h.jsxs('div', {
                                      className: 'flex items-center space-x-1',
                                      children: [
                                        h.jsx('span', {
                                          className: 'text-yellow-500',
                                          children: '⭐',
                                        }),
                                        h.jsx('span', {
                                          className: 'text-yellow-500',
                                          children: '😀',
                                        }),
                                      ],
                                    }),
                                    h.jsx('button', {
                                      className:
                                        'text-purple-700 hover:text-purple-900 hover:bg-purple-100 px-2 py-1 rounded',
                                      children: '🔊',
                                    }),
                                    h.jsx('button', {
                                      className:
                                        'text-purple-700 hover:text-purple-900 hover:bg-purple-100 px-2 py-1 rounded',
                                      children: '⚙️ Settings',
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          }),
                          h.jsx('div', {
                            className:
                              'bg-white/60 backdrop-blur-md border-b border-purple-200 px-6 py-4',
                            children: h.jsxs('div', {
                              className:
                                'flex items-center justify-between max-w-7xl mx-auto',
                              children: [
                                h.jsxs('div', {
                                  className: 'flex items-center space-x-4',
                                  children: [
                                    h.jsx('button', {
                                      onClick: () => il('campaigns'),
                                      className:
                                        'text-purple-700 hover:text-purple-900 hover:bg-purple-100 px-2 py-1 rounded',
                                      children: '← Back',
                                    }),
                                    h.jsx('h2', {
                                      className:
                                        'text-2xl font-semibold text-purple-900',
                                      children: "The Dragon's Hoard",
                                    }),
                                    h.jsx('span', {
                                      className:
                                        'bg-purple-200 text-purple-800 border-purple-300 px-2 py-1 rounded text-sm',
                                      children: '✨ Fantasy Campaign',
                                    }),
                                  ],
                                }),
                                h.jsxs('div', {
                                  className: 'flex items-center space-x-2',
                                  children: [
                                    h.jsx('button', {
                                      className:
                                        'text-purple-700 hover:text-purple-900 hover:bg-purple-100 p-2 rounded',
                                      children: '💾',
                                    }),
                                    h.jsx('button', {
                                      className:
                                        'text-purple-700 hover:text-purple-900 hover:bg-purple-100 p-2 rounded',
                                      children: '🔗',
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          }),
                          h.jsxs('div', {
                            className: 'max-w-5xl mx-auto px-6 py-6',
                            children: [
                              h.jsx('div', {
                                className: 'mb-6',
                                children: h.jsx('div', {
                                  className:
                                    'h-[60vh] overflow-y-auto rounded-lg',
                                  children: h.jsxs('div', {
                                    className: 'space-y-4 pr-4',
                                    children: [
                                      h.jsxs('div', {
                                        className:
                                          'bg-purple-100/50 border-l-4 border-purple-400 p-4 mb-4 rounded-r-lg backdrop-blur-sm',
                                        children: [
                                          h.jsxs('div', {
                                            className:
                                              'flex items-center justify-between mb-2',
                                            children: [
                                              h.jsx('span', {
                                                className:
                                                  'bg-orange-200 text-orange-800 border-orange-300 px-2 py-1 rounded text-xs',
                                                children: 'System',
                                              }),
                                              h.jsx('span', {
                                                className:
                                                  'text-xs text-purple-600',
                                                children:
                                                  new Date().toLocaleTimeString(),
                                              }),
                                            ],
                                          }),
                                          h.jsx('p', {
                                            className:
                                              'text-purple-900 leading-relaxed',
                                            children:
                                              "Welcome to The Dragon's Hoard! Your adventure begins now...",
                                          }),
                                        ],
                                      }),
                                      h.jsxs('div', {
                                        className:
                                          'p-4 rounded-lg mb-4 backdrop-blur-sm border border-purple-200/50 bg-white/60',
                                        children: [
                                          h.jsxs('div', {
                                            className:
                                              'flex items-start justify-between mb-2',
                                            children: [
                                              h.jsx('span', {
                                                className:
                                                  'bg-purple-200 text-purple-800 border-purple-300 px-2 py-1 rounded text-xs',
                                                children: 'Game Master',
                                              }),
                                              h.jsx('span', {
                                                className:
                                                  'text-xs text-purple-600',
                                                children:
                                                  new Date().toLocaleTimeString(),
                                              }),
                                            ],
                                          }),
                                          h.jsx('p', {
                                            className:
                                              'text-purple-900 leading-relaxed',
                                            children:
                                              "Welcome back, brave adventurer! You stand before the ancient dragon's lair. The massive entrance is carved into the mountainside, with intricate draconic runes glowing faintly around the archway...",
                                          }),
                                        ],
                                      }),
                                      h.jsxs('div', {
                                        className:
                                          'p-4 rounded-lg mb-4 backdrop-blur-sm border border-purple-200/50 bg-green-100/50 border-l-4 border-green-400',
                                        children: [
                                          h.jsxs('div', {
                                            className:
                                              'flex items-start justify-between mb-2',
                                            children: [
                                              h.jsx('span', {
                                                className:
                                                  'bg-green-200 text-green-800 border-green-300 px-2 py-1 rounded text-xs',
                                                children: 'You',
                                              }),
                                              h.jsx('span', {
                                                className:
                                                  'text-xs text-purple-600',
                                                children:
                                                  new Date().toLocaleTimeString(),
                                              }),
                                            ],
                                          }),
                                          h.jsx('p', {
                                            className:
                                              'text-purple-900 leading-relaxed',
                                            children:
                                              'I examine the runes closely, looking for any clues about their meaning or potential traps.',
                                          }),
                                        ],
                                      }),
                                      h.jsxs('div', {
                                        children: [
                                          h.jsxs('div', {
                                            className:
                                              'bg-purple-100/50 border-l-4 border-purple-400 p-4 mb-4 rounded-r-lg backdrop-blur-sm',
                                            children: [
                                              h.jsxs('div', {
                                                className:
                                                  'flex items-center justify-between mb-2',
                                                children: [
                                                  h.jsx('span', {
                                                    className:
                                                      'bg-purple-200 text-purple-800 border-purple-300 px-2 py-1 rounded text-xs',
                                                    children: 'Game Master',
                                                  }),
                                                  h.jsx('span', {
                                                    className:
                                                      'text-xs text-purple-600',
                                                    children:
                                                      new Date().toLocaleTimeString(),
                                                  }),
                                                ],
                                              }),
                                              h.jsx('p', {
                                                className:
                                                  'text-purple-900 leading-relaxed italic',
                                                children:
                                                  'Roll for Investigation... You notice the runes seem to be a warning about "those who seek without honor." What would you like to do?',
                                              }),
                                            ],
                                          }),
                                          h.jsx('div', {
                                            className: 'space-y-2',
                                            children: [
                                              'Proceed cautiously',
                                              'Cast Detect Magic',
                                              'Turn back',
                                            ].map((j, El) =>
                                              h.jsx(
                                                'div',
                                                {
                                                  className:
                                                    'bg-white/80 hover:bg-purple-50/80 border border-purple-200 rounded-lg p-3 cursor-pointer transition-all duration-200 backdrop-blur-sm hover:border-purple-300 hover:shadow-sm',
                                                  children: h.jsx('p', {
                                                    className:
                                                      'text-purple-800 text-sm',
                                                    children: j,
                                                  }),
                                                },
                                                El,
                                              ),
                                            ),
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                }),
                              }),
                              h.jsxs('div', {
                                className:
                                  'bg-white/80 backdrop-blur-md border border-purple-200 rounded-lg p-6 shadow-lg',
                                children: [
                                  h.jsx('div', {
                                    className: 'mb-4',
                                    children: h.jsx('textarea', {
                                      placeholder:
                                        'What do you do? Describe your action...',
                                      className:
                                        'w-full min-h-[100px] resize-none border-purple-200 focus:border-purple-400 rounded-lg p-3 bg-white/70 backdrop-blur-sm text-purple-900 placeholder-purple-500',
                                    }),
                                  }),
                                  h.jsxs('div', {
                                    className:
                                      'flex items-center justify-between',
                                    children: [
                                      h.jsxs('div', {
                                        className:
                                          'flex items-center space-x-4',
                                        children: [
                                          h.jsxs('div', {
                                            className:
                                              'flex items-center space-x-2',
                                            children: [
                                              h.jsx('div', {
                                                className:
                                                  'w-3 h-3 rounded-full bg-purple-500',
                                              }),
                                              h.jsx('button', {
                                                className:
                                                  'text-purple-700 bg-purple-100 px-3 py-1 rounded text-sm hover:bg-purple-200',
                                                children: '👤 Character Mode',
                                              }),
                                            ],
                                          }),
                                          h.jsxs('div', {
                                            className:
                                              'flex items-center space-x-2',
                                            children: [
                                              h.jsx('div', {
                                                className:
                                                  'w-3 h-3 rounded-full bg-purple-300',
                                              }),
                                              h.jsx('button', {
                                                className:
                                                  'text-purple-600 px-3 py-1 rounded text-sm hover:bg-purple-100',
                                                children: '👑 God Mode',
                                              }),
                                            ],
                                          }),
                                        ],
                                      }),
                                      h.jsx('button', {
                                        className:
                                          'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-2 shadow-lg rounded-lg',
                                        children: '📤 Send',
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                        ],
                      }),
                    ],
                  }),
              ],
            }),
          ],
        })
      : h.jsx('div', {
          className:
            'min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-purple-900 flex items-center justify-center',
          children: h.jsxs('div', {
            className: 'text-center',
            children: [
              h.jsx('h1', {
                className: 'text-4xl font-bold text-white mb-8',
                children: 'WorldArchitect.AI',
              }),
              h.jsx('p', {
                className: 'text-purple-200 mb-8',
                children: 'Please sign in to continue',
              }),
              h.jsx('a', {
                href: '/auth/google',
                className:
                  'bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors',
                children: 'Sign in with Google',
              }),
            ],
          }),
        });
}
Nv.createRoot(document.getElementById('root')).render(
  h.jsx(rv.StrictMode, { children: h.jsx(Av, {}) }),
);
